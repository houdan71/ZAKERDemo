package com.example.dllo.zaker.community.slidingitem.friends;

import android.view.View;

import com.example.dllo.zaker.R;
import com.example.dllo.zaker.base.BaseFragment;

/**
 * Created by dllo on 16/8/30.
 */
public class CommunityFriendsFragment extends BaseFragment {
    @Override
    protected int initLayout() {
        return R.layout.fragment_community_friends;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
