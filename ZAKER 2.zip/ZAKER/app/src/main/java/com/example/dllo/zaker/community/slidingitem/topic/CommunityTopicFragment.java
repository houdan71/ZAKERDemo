package com.example.dllo.zaker.community.slidingitem.topic;

import android.view.View;

import com.example.dllo.zaker.R;
import com.example.dllo.zaker.base.BaseFragment;

/**
 * Created by dllo on 16/8/30.
 */
public class CommunityTopicFragment extends BaseFragment {

    @Override
    protected int initLayout() {
        return R.layout.fragment_community_topic;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {


    }
}
