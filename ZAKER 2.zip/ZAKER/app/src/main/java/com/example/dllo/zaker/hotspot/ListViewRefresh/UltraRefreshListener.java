package com.example.dllo.zaker.hotspot.ListViewRefresh;

/**
 * Created by dllo on 16/8/31.
 */
public interface UltraRefreshListener {

    //下拉刷新
    void onRefresh();

    //上拉加载
    void addMore();
}
