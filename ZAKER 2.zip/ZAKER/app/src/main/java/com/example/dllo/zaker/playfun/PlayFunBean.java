package com.example.dllo.zaker.playfun;

import java.util.List;

/**
 * Created by dllo on 16/8/30.
 */
public class PlayFunBean {

    /**
     * stat : 1
     * msg : ok
     * data : {"info":{"next_url":"http://wl.myzaker.com/?_appid=AndroidPhone&_v=6.7&_version=6.7&c=columns&city=%E5%A4%A7%E8%BF%9E&p=1&skey=YToxOntzOjg6ImhvbWVwYWdlIjtkOjAuMjAxNjA4MjYwNjk0MDAwMDE7fQ%3D%3D","page":"0","show_category":"N"},"columns":[{"pk":"57baa9399490cb3822000058","score":"0.201608300809","title":"今天","build_banner":"Y","rank":"0.201608300809","banner":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160115/up_1452839250_95189.png","w":"1242","h":"100","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjAxMTUvdXBfMTQ1MjgzOTI1MF85NTE4OS5wbmc=_640.jpg"},"style":"over_pic","show_more":"N","items":[{"pk":"57c3ad909490cb257300004c","title":"Google用6个字母","tag":"","content":"做一本互动的\u201c百科全书\u201d","share_content":"做一本互动的\u201c百科全书\u201d","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472464461_57534_W750H420S43642.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2NDQ2MV81NzUzNF9XNzUwSDQyMFM0MzY0Mi5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3ad909490cb257300004c","type":"a","article":{"pk":"57beae179490cbbc55000078","title":"Google用6个字母，做一本互动的\u201c百科全书\u201d","app_ids":"12266","date":"","auther_name":"Voicer","weburl":"http://iphone.myzaker.com/l.php?l=57beae179490cbbc55000078","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57beae179490cbbc55000078&m=1472467007","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","video_inside":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12266&pk=57beae179490cbbc55000078&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57beae179490cbbc55000078%26app_id%3D12101%26target%3Dweb3","show_jingcai":"N"},"tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}}},{"pk":"57c3fcf99490cb3373000055","title":"当一名特工有多刺激","tag":"","content":"玩这 5 款游戏就知道了","share_content":"玩这 5 款游戏就知道了","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472465711_54965_W750H420S37539.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2NTcxMV81NDk2NV9XNzUwSDQyMFMzNzUzOS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3fcf99490cb3373000055","type":"a","article":{"pk":"57c3faa69490cb167300006e","title":"当一名特工有多刺激？玩这 5 款游戏就知道了","app_ids":"12266","date":"","auther_name":"爱范儿","weburl":"http://iphone.myzaker.com/l.php?l=57c3faa69490cb167300006e","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57c3faa69490cb167300006e&m=1472468532","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","video_inside":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12266&pk=57c3faa69490cb167300006e&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c3faa69490cb167300006e%26app_id%3D12101%26target%3Dweb3","show_jingcai":"N"},"tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}}},{"pk":"57c3fe649490cb5173000078","title":"妹子发明的甜甜圈有什么魔力","tag":"","content":"竟有一万多人主动掏腰包","share_content":"竟有一万多人主动掏腰包","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472464838_71439_W750H420S23152.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2NDgzOF83MTQzOV9XNzUwSDQyMFMyMzE1Mi5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3fe649490cb5173000078","type":"a","article":{"pk":"57c3ebf39490cb461c00004b","title":"有个妹子发明了\u201c甜甜圈\u201d 一万多人主动掏腰包","app_ids":"12266","date":"","auther_name":"一度蜜","weburl":"http://iphone.myzaker.com/l.php?l=57c3ebf39490cb461c00004b","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57c3ebf39490cb461c00004b&m=1472467699","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c3fe6d9490cbd23200001e","title":"选择困难症患者的福音","tag":"","content":"这些APP让你的人生少些纠结","share_content":"这些APP让你的人生少些纠结","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472466753_58243_W750H420S27624.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2Njc1M181ODI0M19XNzUwSDQyMFMyNzYyNC5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3fe6d9490cbd23200001e","type":"a","article":{"pk":"57c3e9ec9490cb207300003a","title":"选择困难症需要的 4 款 App，让人生少些纠结","app_ids":"12266","date":"","auther_name":"appsolution","weburl":"http://iphone.myzaker.com/l.php?l=57c3e9ec9490cb207300003a","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57c3e9ec9490cb207300003a&m=1472468369","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c3fce69490cbfc72000073","title":"当菜市场玩起电子化","tag":"","content":"妈妈们居然要这样买菜","share_content":"妈妈们居然要这样买菜","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472466843_48219_W750H420S98965.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2Njg0M180ODIxOV9XNzUwSDQyMFM5ODk2NS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3fce69490cbfc72000073","type":"a","article":{"pk":"57c3f3fc9490cbed72000045","title":"菜市场搞成这样，社区购物中心得\u201c跪求\u201d","app_ids":"12266","date":"","auther_name":"商业与地产","weburl":"http://iphone.myzaker.com/l.php?l=57c3f3fc9490cbed72000045","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57c3f3fc9490cbed72000045&m=1472461981","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}}]},{"pk":"57baa9249490cb602200004e","score":"0.201608290788","title":"8月29日 星期一","build_banner":"Y","rank":"0.201608290788","banner":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160822/up_1471850786_63306_W1242H100S2988.png","w":"1242","h":"100","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1MDc4Nl82MzMwNl9XMTI0MkgxMDBTMjk4OC5wbmc=_640.jpg"},"style":"over_pic","show_more":"N","items":[{"pk":"57c0047c9490cb7960000069","title":"高峰期如何优雅地搭乘地铁","tag":"","content":"收好这份指南可暂存体面","share_content":"收好这份指南可暂存体面","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472203457_2371_W750H420S36246.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMzQ1N18yMzcxX1c3NTBINDIwUzM2MjQ2LmpwZw==_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9249490cb602200004e&pk=57c0047c9490cb7960000069","type":"a","article":{"pk":"57bff6d19490cb7060000060","title":"如何优雅地搭乘地铁？","app_ids":"12249","date":"","auther_name":"玩物志","weburl":"http://iphone.myzaker.com/l.php?l=57bff6d19490cb7060000060","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12249&pk=57bff6d19490cb7060000060&m=1472201831","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c000989490cba96000004c","title":"外卖软件满天飞","tag":"","content":"为何7-11还是最省心的食堂","share_content":"为何7-11还是最省心的食堂","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472201804_1736_W750H420S62617.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMTgwNF8xNzM2X1c3NTBINDIwUzYyNjE3LmpwZw==_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9249490cb602200004e&pk=57c000989490cba96000004c","type":"a","article":{"pk":"57bfebb49490cb566000005f","title":"外卖软件满天飞，为何 7-11 还是上班族最省心的食堂","app_ids":"12249","date":"","auther_name":"果库","weburl":"http://iphone.myzaker.com/l.php?l=57bfebb49490cb566000005f","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12249&pk=57bfebb49490cb566000005f&m=1472207697","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c0009f9490cbe807000009","title":"是谁让我们超时工作","tag":"","content":"也许是你自己在掏空自己","share_content":"也许是你自己在掏空自己","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472201052_83532_W750H425S53435.jpg","w":"750","h":"425","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMTA1Ml84MzUzMl9XNzUwSDQyNVM1MzQzNS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9249490cb602200004e&pk=57c0009f9490cbe807000009","type":"a","article":{"pk":"57bfbec99490cb772a00001d","title":"一周工作50小时：是谁让我们超时工作？| 也许，是你自己在掏空自己","app_ids":"12249","date":"","auther_name":"Know yourself","weburl":"http://iphone.myzaker.com/l.php?l=57bfbec99490cb772a00001d","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12249&pk=57bfbec99490cb772a00001d&m=1472200540","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c0008d9490cb7660000078","title":"知道自己穿的牛仔裤叫啥不","tag":"","content":"喏 这里有本辞典","share_content":"喏 这里有本辞典","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472202017_65206_W750H420S81751.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMjAxN182NTIwNl9XNzUwSDQyMFM4MTc1MS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9249490cb602200004e&pk=57c0008d9490cb7660000078","type":"a","article":{"pk":"57bfeeea9490cb3d60000065","title":"你知道自己穿的牛仔裤叫啥吗？这里有一份牛仔裤辞典","app_ids":"12249","date":"","auther_name":"好奇心研究所","weburl":"http://iphone.myzaker.com/l.php?l=57bfeeea9490cb3d60000065","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12249&pk=57bfeeea9490cb3d60000065&m=1472199629","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c004799490cb8360000061","title":"想换下居住体验吗","tag":"","content":"变身新公寓的老商场值得一试","share_content":"变身新公寓的老商场值得一试","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472203700_26516_W750H420S86367.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMzcwMF8yNjUxNl9XNzUwSDQyMFM4NjM2Ny5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9249490cb602200004e&pk=57c004799490cb8360000061","type":"a","article":{"pk":"57bff9119490cb4260000062","title":"住在老商场里是怎样一种感受","app_ids":"12249","date":"","auther_name":"TOPYS","weburl":"http://iphone.myzaker.com/l.php?l=57bff9119490cb4260000062","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12249&pk=57bff9119490cb4260000062&m=1472207974","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}}]},{"pk":"57baa9109490cb4d22000051","score":"0.201608280768","title":"8月28日 星期天","build_banner":"Y","rank":"0.201608280768","banner":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160822/up_1471850764_91971_W1242H100S2747.png","w":"1242","h":"100","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1MDc2NF85MTk3MV9XMTI0MkgxMDBTMjc0Ny5wbmc=_640.jpg"},"style":"over_pic","show_more":"N","items":[{"pk":"57bffda69490cb3660000066","title":"票圈中的健身肉体","tag":"","content":"真的那么撩人吗","share_content":"真的那么撩人吗","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472203033_57700_W750H420S46369.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMzAzM181NzcwMF9XNzUwSDQyMFM0NjM2OS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9109490cb4d22000051&pk=57bffda69490cb3660000066","type":"a","article":{"pk":"57bfe4409490cb6e60000049","title":"社交网络中的健身肉体更撩人吗？","app_ids":"12248","date":"","auther_name":"南七道","weburl":"http://iphone.myzaker.com/l.php?l=57bfe4409490cb6e60000049","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12248&pk=57bfe4409490cb6e60000049&m=1472199457","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c000749490cb3760000049","title":"洗晒的重要时节里","tag":"","content":"如何让皮肤能够健康呼吸","share_content":"如何让皮肤能够健康呼吸","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472202390_87920_W750H420S41093.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMjM5MF84NzkyMF9XNzUwSDQyMFM0MTA5My5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9109490cb4d22000051&pk=57c000749490cb3760000049","type":"a","article":{"pk":"57bfbc019490cb8460000048","title":"衣服洗得好，皮肤才能健康呼吸","app_ids":"12248","date":"","auther_name":"LOHAS乐活","weburl":"http://iphone.myzaker.com/l.php?l=57bfbc019490cb8460000048","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12248&pk=57bfbc019490cb8460000048&m=1472206654","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57bfe89e9490cb7310000085","title":"没得过这几种病的","tag":"","content":"都不好意思讲自己是现代人","share_content":"都不好意思讲自己是现代人","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472194764_32738_W750H425S63069.jpg","w":"750","h":"425","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE5NDc2NF8zMjczOF9XNzUwSDQyNVM2MzA2OS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9109490cb4d22000051&pk=57bfe89e9490cb7310000085","type":"a","article":{"pk":"57bea6419490cbcf5500005c","title":"没得过这几种病的人，你确定自己活在这个时代吗？","app_ids":"12248","date":"","auther_name":"好奇心日报","weburl":"http://iphone.myzaker.com/l.php?l=57bea6419490cbcf5500005c","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12248&pk=57bea6419490cbcf5500005c&m=1472194544","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57bffc369490cb826000005a","title":"在吃喝这个神圣命题上","tag":"","content":"你干了多少假装健康的事","share_content":"你干了多少假装健康的事","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472200522_66212_W750H420S61150.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMDUyMl82NjIxMl9XNzUwSDQyMFM2MTE1MC5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9109490cb4d22000051&pk=57bffc369490cb826000005a","type":"a","article":{"pk":"57bfba9c9490cb8c60000036","title":"在吃喝上，你干了多少假装健康的事？","app_ids":"12248","date":"","auther_name":"吃喝梦工厂","weburl":"http://iphone.myzaker.com/l.php?l=57bfba9c9490cb8c60000036","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12248&pk=57bfba9c9490cb8c60000036&m=1472199468","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57bffc3e9490cbbc2900006d","title":"爱笑的女生 牙齿都不会太差","tag":"","content":"但首先得吃遍全世界的牙膏","share_content":"但首先得吃遍全世界的牙膏","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472203353_51793_W750H420S38621.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMzM1M181MTc5M19XNzUwSDQyMFMzODYyMS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9109490cb4d22000051&pk=57bffc3e9490cbbc2900006d","type":"a","article":{"pk":"57bead239490cbb555000054","title":"有生之年，要吃遍全世界好吃的牙膏","app_ids":"12248","date":"","auther_name":"玩物志","weburl":"http://iphone.myzaker.com/l.php?l=57bead239490cbb555000054","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12248&pk=57bead239490cbb555000054&m=1472205593","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}}]},{"pk":"57baa8f59490cb1322000047","score":"0.201608270741","title":"8月27日 星期六","build_banner":"Y","rank":"0.201608270741","banner":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160822/up_1471850734_75698_W1242H100S3193.png","w":"1242","h":"100","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1MDczNF83NTY5OF9XMTI0MkgxMDBTMzE5My5wbmc=_640.jpg"},"style":"over_pic","show_more":"N","items":[{"pk":"57bfb1239490cb3860000030","title":"原来中国不是自行车王国","tag":"","content":"这个国家单车比人口还多","share_content":"这个国家单车比人口还多","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472181104_18757_W750H420S102957.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE4MTEwNF8xODc1N19XNzUwSDQyMFMxMDI5NTcuanBn_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8f59490cb1322000047&pk=57bfb1239490cb3860000030","type":"a","article":{"pk":"57bfae7e9490cba860000011","title":"原来中国不是自行车王国？","app_ids":"12428","date":"","auther_name":"Artvoi","weburl":"http://iphone.myzaker.com/l.php?l=57bfae7e9490cba860000011","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12428&pk=57bfae7e9490cba860000011&m=1472181179","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57becc949490cb456f00001d","title":"日本青年用井盖告诉你","tag":"","content":"创意美学早已被踩在脚下","share_content":"创意美学早已被踩在脚下","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472123148_22782_W750H420S157783.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMzE0OF8yMjc4Ml9XNzUwSDQyMFMxNTc3ODMuanBn_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8f59490cb1322000047&pk=57becc949490cb456f00001d","type":"a","article":{"pk":"57beb9a99490cbe355000076","title":"日本井盖集体卖萌，简直没法好好走路了","app_ids":"12428","date":"","auther_name":"穷游网","weburl":"http://iphone.myzaker.com/l.php?l=57beb9a99490cbe355000076","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12428&pk=57beb9a99490cbe355000076&m=1472121970","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57becc9b9490cbe65500006f","title":"钢管、皮带和振动","tag":"","content":"最早的健身器械就是刑具嘛","share_content":"最早的健身器械就是刑具嘛","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472122788_87301_W750H420S77004.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMjc4OF84NzMwMV9XNzUwSDQyMFM3NzAwNC5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8f59490cb1322000047&pk=57becc9b9490cbe65500006f","type":"a","article":{"pk":"57beb8199490cb2556000063","title":"钢管、皮带和振动：最早的健身器械像刑具...","app_ids":"12428","date":"","auther_name":"男人装","weburl":"http://iphone.myzaker.com/l.php?l=57beb8199490cb2556000063","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12428&pk=57beb8199490cb2556000063&m=1472121915","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57becc5e9490cbb55500006b","title":"无法想象吃货的脑洞有多大","tag":"","content":"艺术家已饿晕在厨房","share_content":"艺术家已饿晕在厨房","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472122761_57180_W750H420S34118.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMjc2MV81NzE4MF9XNzUwSDQyMFMzNDExOC5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8f59490cb1322000047&pk=57becc5e9490cbb55500006b","type":"a","article":{"pk":"57beac319490cb0956000077","title":"吃货的神奇脑洞：食物也能变名画","app_ids":"12428","date":"","auther_name":"趣新闻","weburl":"http://iphone.myzaker.com/l.php?l=57beac319490cb0956000077","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12428&pk=57beac319490cb0956000077&m=1472119386","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57becc8d9490cbc855000080","title":"摄影师的天马与行空","tag":"","content":"超现实主义摄影作品一览","share_content":"超现实主义摄影作品一览","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472122390_18475_W750H420S55383.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMjM5MF8xODQ3NV9XNzUwSDQyMFM1NTM4My5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8f59490cb1322000047&pk=57becc8d9490cbc855000080","type":"a","article":{"pk":"57bec1869490cbf2550000ab","title":"摄影师的天马与行空","app_ids":"12428","date":"","auther_name":"烩设计","weburl":"http://iphone.myzaker.com/l.php?l=57bec1869490cbf2550000ab","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12428&pk=57bec1869490cbf2550000ab&m=1472121920","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}}]},{"pk":"57baa8c69490cb4022000046","score":"0.201608260694","title":"8月26日 星期五","build_banner":"Y","rank":"0.201608260694","banner":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160822/up_1471850691_74055_W1242H100S3207.png","w":"1242","h":"100","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1MDY5MV83NDA1NV9XMTI0MkgxMDBTMzIwNy5wbmc=_640.jpg"},"style":"over_pic","show_more":"N","items":[{"pk":"57bec2719490cbc655000070","title":"便利店果汁选购指南","tag":"","content":"到底哪瓶才是真爱","share_content":"到底哪瓶才是真爱","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472121760_78010_W750H420S60400.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMTc2MF83ODAxMF9XNzUwSDQyMFM2MDQwMC5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8c69490cb4022000046&pk=57bec2719490cbc655000070","type":"a","article":{"pk":"57be938e9490cb2356000058","title":"便利店果汁的选购指南","app_ids":"12250","date":"","auther_name":"KnewOne","weburl":"http://iphone.myzaker.com/l.php?l=57be938e9490cb2356000058","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12250&pk=57be938e9490cb2356000058&m=1472196369","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57bec3aa9490cb265600008f","title":"她才是江浙沪最民国的地方","tag":"","content":"比南京古派比扬州婉约","share_content":"比南京古派比扬州婉约","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472122078_57588_W750H425S147553.jpg","w":"750","h":"425","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMjA3OF81NzU4OF9XNzUwSDQyNVMxNDc1NTMuanBn_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8c69490cb4022000046&pk=57bec3aa9490cb265600008f","type":"a","article":{"pk":"57be5b189490cb1956000027","title":"比南京更古派，比扬州更婉约，她才是江浙沪最民国的地方！","app_ids":"12250","date":"","auther_name":"Feekr旅行","weburl":"http://iphone.myzaker.com/l.php?l=57be5b189490cb1956000027","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12250&pk=57be5b189490cb1956000027&m=1472196507","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57be7b489490cbf555000039","title":"西安不止泡馍和回民街 ","tag":"","content":"老街坊的饭局都被这些地方承包了","share_content":"老街坊的饭局都被这些地方承包了","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472101962_3785_W750H420S49443.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEwMTk2Ml8zNzg1X1c3NTBINDIwUzQ5NDQzLmpwZw==_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8c69490cb4022000046&pk=57be7b489490cbf555000039","type":"a","article":{"pk":"57be5b749490cb0656000043","title":"西安不止泡馍和回民街 老街坊的饭局都被这些地方承包了","app_ids":"12250","date":"","auther_name":"凤凰旅游","weburl":"http://iphone.myzaker.com/l.php?l=57be5b749490cb0656000043","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12250&pk=57be5b749490cb0656000043&m=1472204325","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57bec3b09490cbb61800004f","title":"解救被困在酷暑中的你","tag":"","content":"一杯冰拿铁就够了","share_content":"一杯冰拿铁就够了","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472121222_57485_W750H425S43758.jpg","w":"750","h":"425","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMTIyMl81NzQ4NV9XNzUwSDQyNVM0Mzc1OC5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8c69490cb4022000046&pk=57bec3b09490cbb61800004f","type":"a","article":{"pk":"57be595c9490cbbf5500002e","title":"一杯冰拿铁解救被困在酷暑中的你","app_ids":"12250","date":"","auther_name":"外滩画报","weburl":"http://iphone.myzaker.com/l.php?l=57be595c9490cbbf5500002e","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12250&pk=57be595c9490cbbf5500002e&m=1472182563","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57be7b419490cbf655000037","title":"赶在夏天结束之前","tag":"","content":"把北京的冰品再舔一遍","share_content":"把北京的冰品再舔一遍","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472102743_30908_W750H420S47867.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEwMjc0M18zMDkwOF9XNzUwSDQyMFM0Nzg2Ny5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8c69490cb4022000046&pk=57be7b419490cbf655000037","type":"a","article":{"pk":"57be6c879490cbb455000041","title":"夏天结束前，我想把北京这10家美味冰品店再吃一遍","app_ids":"12250","date":"","auther_name":"赞那度","weburl":"http://iphone.myzaker.com/l.php?l=57be6c879490cbb455000041","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12250&pk=57be6c879490cbb455000041&m=1472100791","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}}]}],"promote":[{"pk":"57c3b71b9490cb4873000030","promotion_img":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472444379_18317_W1242H530S219366.jpg","img_height":"530","img_width":"1242","title":"","end_time":"1504195200","type":"a","pop_type":"","hide_mask":"Y","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c3b71b9490cb4873000030&position=weekend_promotion","start_time":"1472423340","article":{"pk":"57c399019490cb3a73000020","title":"别人度假去海边 玩乐带你进山里","app_ids":"12112","date":"2017-09-01 00:00:00","auther_name":"玩乐","weburl":"http://iphone.myzaker.com/l.php?l=57c399019490cb3a73000020","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12112&pk=57c399019490cb3a73000020&m=1472443794","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c3b71b9490cb4873000030&title=%E5%88%AB%E4%BA%BA%E5%BA%A6%E5%81%87%E5%8E%BB%E6%B5%B7%E8%BE%B9+%E7%8E%A9%E4%B9%90%E5%B8%A6%E4%BD%A0%E8%BF%9B%E5%B1%B1%E9%87%8C&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fwlwap.myzaker.com%2F%3Fmodel%3Dtopic%26wl_topic_id%3D57c399019490cb3a7300001f%26target%3Dweb3","show_jingcai":"N"},"hide_original_text_btn":"Y"}},{"pk":"57bfbb7c9490cb9360000034","promotion_img":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472192643_69611_W1242H530S330939.jpg","img_height":"530","img_width":"1242","title":"","end_time":"1472745600","type":"a","pop_type":"","hide_mask":"Y","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57bfbb7c9490cb9360000034&position=weekend_promotion","start_time":"1472183097","article":{"pk":"57bd848f9490cbb856000096","title":"跑遍全世界，人类已经无法阻止他的脚步","app_ids":"12112","date":"2016-09-02 00:00:00","auther_name":"ZAKER生活家","weburl":"http://iphone.myzaker.com/l.php?l=57bd848f9490cbb856000096","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12112&pk=57bd848f9490cbb856000096&m=1472182394","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57bfbb7c9490cb9360000034&title=%E8%B7%91%E9%81%8D%E5%85%A8%E4%B8%96%E7%95%8C%EF%BC%8C%E4%BA%BA%E7%B1%BB%E5%B7%B2%E7%BB%8F%E6%97%A0%E6%B3%95%E9%98%BB%E6%AD%A2%E4%BB%96%E7%9A%84%E8%84%9A%E6%AD%A5&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_car.php%3Fpk%3D57bfa22f9490cb8960000019%26target%3Dweb3%26article_pk%3D57bd848f9490cbb856000096","show_jingcai":"N"}}}],"display":[{"pk":"5744235d9490cbf11d000030","title":"积分商城","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160607/up_1465297868_38561.png","w":"566","h":"240","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA2MDcvdXBfMTQ2NTI5Nzg2OF8zODU2MS5wbmc=_400.jpg"},"click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=display_click&pk=5744235d9490cbf11d000030","type":"web","web":{"url":"http://m.zkshop.myzaker.com/","type":"","need_user_info":"Y"}},{"pk":"5744243b9490cb1361000083","title":"ZAKER 俱乐部","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160607/up_1465297886_80043.png","w":"566","h":"240","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA2MDcvdXBfMTQ2NTI5Nzg4Nl84MDA0My5wbmc=_400.jpg"},"click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=display_click&pk=5744243b9490cb1361000083","type":"web","web":{"url":"http://iphone.myzaker.com/zaker/hd_center.php","type":"","need_user_info":"Y"}},{"pk":"56ef724e9490cb474d000002","title":"一味","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160406/up_1459915164_16300.png","w":"566","h":"240","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA0MDYvdXBfMTQ1OTkxNTE2NF8xNjMwMC5wbmc=_400.jpg"},"click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=display_click&pk=56ef724e9490cb474d000002","type":"block","block_info":{"pk":"12289","title":"一味","stitle":"","block_title":"一味","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=12289","data_type":"","pic":"http://zkres.myzaker.com/data/image/logo/12289.png?t=1457518908","large_pic":"http://zkres.myzaker.com/data/image/logo/ipad3/12289.png?t=1457518908"}},{"pk":"56ef72cf9490cb9c01000002","title":"摄影札记","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160406/up_1459915228_85267.png","w":"566","h":"240","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA0MDYvdXBfMTQ1OTkxNTIyOF84NTI2Ny5wbmc=_400.jpg"},"click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=display_click&pk=56ef72cf9490cb9c01000002","type":"block","block_info":{"pk":"12304","title":"摄影札记","stitle":"","block_title":"摄影札记","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=12304","data_type":"","pic":"http://zkres.myzaker.com/data/image/logo/12304.png?t=1458293354","large_pic":"http://zkres.myzaker.com/data/image/logo/ipad3/12304.png?t=1458293354"}}]}
     */

    private String stat;
    private String msg;
    /**
     * info : {"next_url":"http://wl.myzaker.com/?_appid=AndroidPhone&_v=6.7&_version=6.7&c=columns&city=%E5%A4%A7%E8%BF%9E&p=1&skey=YToxOntzOjg6ImhvbWVwYWdlIjtkOjAuMjAxNjA4MjYwNjk0MDAwMDE7fQ%3D%3D","page":"0","show_category":"N"}
     * columns : [{"pk":"57baa9399490cb3822000058","score":"0.201608300809","title":"今天","build_banner":"Y","rank":"0.201608300809","banner":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160115/up_1452839250_95189.png","w":"1242","h":"100","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjAxMTUvdXBfMTQ1MjgzOTI1MF85NTE4OS5wbmc=_640.jpg"},"style":"over_pic","show_more":"N","items":[{"pk":"57c3ad909490cb257300004c","title":"Google用6个字母","tag":"","content":"做一本互动的\u201c百科全书\u201d","share_content":"做一本互动的\u201c百科全书\u201d","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472464461_57534_W750H420S43642.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2NDQ2MV81NzUzNF9XNzUwSDQyMFM0MzY0Mi5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3ad909490cb257300004c","type":"a","article":{"pk":"57beae179490cbbc55000078","title":"Google用6个字母，做一本互动的\u201c百科全书\u201d","app_ids":"12266","date":"","auther_name":"Voicer","weburl":"http://iphone.myzaker.com/l.php?l=57beae179490cbbc55000078","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57beae179490cbbc55000078&m=1472467007","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","video_inside":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12266&pk=57beae179490cbbc55000078&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57beae179490cbbc55000078%26app_id%3D12101%26target%3Dweb3","show_jingcai":"N"},"tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}}},{"pk":"57c3fcf99490cb3373000055","title":"当一名特工有多刺激","tag":"","content":"玩这 5 款游戏就知道了","share_content":"玩这 5 款游戏就知道了","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472465711_54965_W750H420S37539.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2NTcxMV81NDk2NV9XNzUwSDQyMFMzNzUzOS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3fcf99490cb3373000055","type":"a","article":{"pk":"57c3faa69490cb167300006e","title":"当一名特工有多刺激？玩这 5 款游戏就知道了","app_ids":"12266","date":"","auther_name":"爱范儿","weburl":"http://iphone.myzaker.com/l.php?l=57c3faa69490cb167300006e","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57c3faa69490cb167300006e&m=1472468532","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","video_inside":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12266&pk=57c3faa69490cb167300006e&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c3faa69490cb167300006e%26app_id%3D12101%26target%3Dweb3","show_jingcai":"N"},"tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}}},{"pk":"57c3fe649490cb5173000078","title":"妹子发明的甜甜圈有什么魔力","tag":"","content":"竟有一万多人主动掏腰包","share_content":"竟有一万多人主动掏腰包","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472464838_71439_W750H420S23152.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2NDgzOF83MTQzOV9XNzUwSDQyMFMyMzE1Mi5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3fe649490cb5173000078","type":"a","article":{"pk":"57c3ebf39490cb461c00004b","title":"有个妹子发明了\u201c甜甜圈\u201d 一万多人主动掏腰包","app_ids":"12266","date":"","auther_name":"一度蜜","weburl":"http://iphone.myzaker.com/l.php?l=57c3ebf39490cb461c00004b","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57c3ebf39490cb461c00004b&m=1472467699","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c3fe6d9490cbd23200001e","title":"选择困难症患者的福音","tag":"","content":"这些APP让你的人生少些纠结","share_content":"这些APP让你的人生少些纠结","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472466753_58243_W750H420S27624.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2Njc1M181ODI0M19XNzUwSDQyMFMyNzYyNC5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3fe6d9490cbd23200001e","type":"a","article":{"pk":"57c3e9ec9490cb207300003a","title":"选择困难症需要的 4 款 App，让人生少些纠结","app_ids":"12266","date":"","auther_name":"appsolution","weburl":"http://iphone.myzaker.com/l.php?l=57c3e9ec9490cb207300003a","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57c3e9ec9490cb207300003a&m=1472468369","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c3fce69490cbfc72000073","title":"当菜市场玩起电子化","tag":"","content":"妈妈们居然要这样买菜","share_content":"妈妈们居然要这样买菜","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472466843_48219_W750H420S98965.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2Njg0M180ODIxOV9XNzUwSDQyMFM5ODk2NS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3fce69490cbfc72000073","type":"a","article":{"pk":"57c3f3fc9490cbed72000045","title":"菜市场搞成这样，社区购物中心得\u201c跪求\u201d","app_ids":"12266","date":"","auther_name":"商业与地产","weburl":"http://iphone.myzaker.com/l.php?l=57c3f3fc9490cbed72000045","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57c3f3fc9490cbed72000045&m=1472461981","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}}]},{"pk":"57baa9249490cb602200004e","score":"0.201608290788","title":"8月29日 星期一","build_banner":"Y","rank":"0.201608290788","banner":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160822/up_1471850786_63306_W1242H100S2988.png","w":"1242","h":"100","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1MDc4Nl82MzMwNl9XMTI0MkgxMDBTMjk4OC5wbmc=_640.jpg"},"style":"over_pic","show_more":"N","items":[{"pk":"57c0047c9490cb7960000069","title":"高峰期如何优雅地搭乘地铁","tag":"","content":"收好这份指南可暂存体面","share_content":"收好这份指南可暂存体面","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472203457_2371_W750H420S36246.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMzQ1N18yMzcxX1c3NTBINDIwUzM2MjQ2LmpwZw==_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9249490cb602200004e&pk=57c0047c9490cb7960000069","type":"a","article":{"pk":"57bff6d19490cb7060000060","title":"如何优雅地搭乘地铁？","app_ids":"12249","date":"","auther_name":"玩物志","weburl":"http://iphone.myzaker.com/l.php?l=57bff6d19490cb7060000060","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12249&pk=57bff6d19490cb7060000060&m=1472201831","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c000989490cba96000004c","title":"外卖软件满天飞","tag":"","content":"为何7-11还是最省心的食堂","share_content":"为何7-11还是最省心的食堂","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472201804_1736_W750H420S62617.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMTgwNF8xNzM2X1c3NTBINDIwUzYyNjE3LmpwZw==_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9249490cb602200004e&pk=57c000989490cba96000004c","type":"a","article":{"pk":"57bfebb49490cb566000005f","title":"外卖软件满天飞，为何 7-11 还是上班族最省心的食堂","app_ids":"12249","date":"","auther_name":"果库","weburl":"http://iphone.myzaker.com/l.php?l=57bfebb49490cb566000005f","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12249&pk=57bfebb49490cb566000005f&m=1472207697","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c0009f9490cbe807000009","title":"是谁让我们超时工作","tag":"","content":"也许是你自己在掏空自己","share_content":"也许是你自己在掏空自己","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472201052_83532_W750H425S53435.jpg","w":"750","h":"425","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMTA1Ml84MzUzMl9XNzUwSDQyNVM1MzQzNS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9249490cb602200004e&pk=57c0009f9490cbe807000009","type":"a","article":{"pk":"57bfbec99490cb772a00001d","title":"一周工作50小时：是谁让我们超时工作？| 也许，是你自己在掏空自己","app_ids":"12249","date":"","auther_name":"Know yourself","weburl":"http://iphone.myzaker.com/l.php?l=57bfbec99490cb772a00001d","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12249&pk=57bfbec99490cb772a00001d&m=1472200540","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c0008d9490cb7660000078","title":"知道自己穿的牛仔裤叫啥不","tag":"","content":"喏 这里有本辞典","share_content":"喏 这里有本辞典","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472202017_65206_W750H420S81751.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMjAxN182NTIwNl9XNzUwSDQyMFM4MTc1MS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9249490cb602200004e&pk=57c0008d9490cb7660000078","type":"a","article":{"pk":"57bfeeea9490cb3d60000065","title":"你知道自己穿的牛仔裤叫啥吗？这里有一份牛仔裤辞典","app_ids":"12249","date":"","auther_name":"好奇心研究所","weburl":"http://iphone.myzaker.com/l.php?l=57bfeeea9490cb3d60000065","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12249&pk=57bfeeea9490cb3d60000065&m=1472199629","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c004799490cb8360000061","title":"想换下居住体验吗","tag":"","content":"变身新公寓的老商场值得一试","share_content":"变身新公寓的老商场值得一试","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472203700_26516_W750H420S86367.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMzcwMF8yNjUxNl9XNzUwSDQyMFM4NjM2Ny5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9249490cb602200004e&pk=57c004799490cb8360000061","type":"a","article":{"pk":"57bff9119490cb4260000062","title":"住在老商场里是怎样一种感受","app_ids":"12249","date":"","auther_name":"TOPYS","weburl":"http://iphone.myzaker.com/l.php?l=57bff9119490cb4260000062","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12249&pk=57bff9119490cb4260000062&m=1472207974","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}}]},{"pk":"57baa9109490cb4d22000051","score":"0.201608280768","title":"8月28日 星期天","build_banner":"Y","rank":"0.201608280768","banner":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160822/up_1471850764_91971_W1242H100S2747.png","w":"1242","h":"100","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1MDc2NF85MTk3MV9XMTI0MkgxMDBTMjc0Ny5wbmc=_640.jpg"},"style":"over_pic","show_more":"N","items":[{"pk":"57bffda69490cb3660000066","title":"票圈中的健身肉体","tag":"","content":"真的那么撩人吗","share_content":"真的那么撩人吗","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472203033_57700_W750H420S46369.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMzAzM181NzcwMF9XNzUwSDQyMFM0NjM2OS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9109490cb4d22000051&pk=57bffda69490cb3660000066","type":"a","article":{"pk":"57bfe4409490cb6e60000049","title":"社交网络中的健身肉体更撩人吗？","app_ids":"12248","date":"","auther_name":"南七道","weburl":"http://iphone.myzaker.com/l.php?l=57bfe4409490cb6e60000049","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12248&pk=57bfe4409490cb6e60000049&m=1472199457","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c000749490cb3760000049","title":"洗晒的重要时节里","tag":"","content":"如何让皮肤能够健康呼吸","share_content":"如何让皮肤能够健康呼吸","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472202390_87920_W750H420S41093.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMjM5MF84NzkyMF9XNzUwSDQyMFM0MTA5My5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9109490cb4d22000051&pk=57c000749490cb3760000049","type":"a","article":{"pk":"57bfbc019490cb8460000048","title":"衣服洗得好，皮肤才能健康呼吸","app_ids":"12248","date":"","auther_name":"LOHAS乐活","weburl":"http://iphone.myzaker.com/l.php?l=57bfbc019490cb8460000048","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12248&pk=57bfbc019490cb8460000048&m=1472206654","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57bfe89e9490cb7310000085","title":"没得过这几种病的","tag":"","content":"都不好意思讲自己是现代人","share_content":"都不好意思讲自己是现代人","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472194764_32738_W750H425S63069.jpg","w":"750","h":"425","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE5NDc2NF8zMjczOF9XNzUwSDQyNVM2MzA2OS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9109490cb4d22000051&pk=57bfe89e9490cb7310000085","type":"a","article":{"pk":"57bea6419490cbcf5500005c","title":"没得过这几种病的人，你确定自己活在这个时代吗？","app_ids":"12248","date":"","auther_name":"好奇心日报","weburl":"http://iphone.myzaker.com/l.php?l=57bea6419490cbcf5500005c","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12248&pk=57bea6419490cbcf5500005c&m=1472194544","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57bffc369490cb826000005a","title":"在吃喝这个神圣命题上","tag":"","content":"你干了多少假装健康的事","share_content":"你干了多少假装健康的事","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472200522_66212_W750H420S61150.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMDUyMl82NjIxMl9XNzUwSDQyMFM2MTE1MC5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9109490cb4d22000051&pk=57bffc369490cb826000005a","type":"a","article":{"pk":"57bfba9c9490cb8c60000036","title":"在吃喝上，你干了多少假装健康的事？","app_ids":"12248","date":"","auther_name":"吃喝梦工厂","weburl":"http://iphone.myzaker.com/l.php?l=57bfba9c9490cb8c60000036","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12248&pk=57bfba9c9490cb8c60000036&m=1472199468","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57bffc3e9490cbbc2900006d","title":"爱笑的女生 牙齿都不会太差","tag":"","content":"但首先得吃遍全世界的牙膏","share_content":"但首先得吃遍全世界的牙膏","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472203353_51793_W750H420S38621.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwMzM1M181MTc5M19XNzUwSDQyMFMzODYyMS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9109490cb4d22000051&pk=57bffc3e9490cbbc2900006d","type":"a","article":{"pk":"57bead239490cbb555000054","title":"有生之年，要吃遍全世界好吃的牙膏","app_ids":"12248","date":"","auther_name":"玩物志","weburl":"http://iphone.myzaker.com/l.php?l=57bead239490cbb555000054","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12248&pk=57bead239490cbb555000054&m=1472205593","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}}]},{"pk":"57baa8f59490cb1322000047","score":"0.201608270741","title":"8月27日 星期六","build_banner":"Y","rank":"0.201608270741","banner":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160822/up_1471850734_75698_W1242H100S3193.png","w":"1242","h":"100","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1MDczNF83NTY5OF9XMTI0MkgxMDBTMzE5My5wbmc=_640.jpg"},"style":"over_pic","show_more":"N","items":[{"pk":"57bfb1239490cb3860000030","title":"原来中国不是自行车王国","tag":"","content":"这个国家单车比人口还多","share_content":"这个国家单车比人口还多","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472181104_18757_W750H420S102957.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE4MTEwNF8xODc1N19XNzUwSDQyMFMxMDI5NTcuanBn_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8f59490cb1322000047&pk=57bfb1239490cb3860000030","type":"a","article":{"pk":"57bfae7e9490cba860000011","title":"原来中国不是自行车王国？","app_ids":"12428","date":"","auther_name":"Artvoi","weburl":"http://iphone.myzaker.com/l.php?l=57bfae7e9490cba860000011","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12428&pk=57bfae7e9490cba860000011&m=1472181179","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57becc949490cb456f00001d","title":"日本青年用井盖告诉你","tag":"","content":"创意美学早已被踩在脚下","share_content":"创意美学早已被踩在脚下","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472123148_22782_W750H420S157783.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMzE0OF8yMjc4Ml9XNzUwSDQyMFMxNTc3ODMuanBn_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8f59490cb1322000047&pk=57becc949490cb456f00001d","type":"a","article":{"pk":"57beb9a99490cbe355000076","title":"日本井盖集体卖萌，简直没法好好走路了","app_ids":"12428","date":"","auther_name":"穷游网","weburl":"http://iphone.myzaker.com/l.php?l=57beb9a99490cbe355000076","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12428&pk=57beb9a99490cbe355000076&m=1472121970","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57becc9b9490cbe65500006f","title":"钢管、皮带和振动","tag":"","content":"最早的健身器械就是刑具嘛","share_content":"最早的健身器械就是刑具嘛","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472122788_87301_W750H420S77004.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMjc4OF84NzMwMV9XNzUwSDQyMFM3NzAwNC5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8f59490cb1322000047&pk=57becc9b9490cbe65500006f","type":"a","article":{"pk":"57beb8199490cb2556000063","title":"钢管、皮带和振动：最早的健身器械像刑具...","app_ids":"12428","date":"","auther_name":"男人装","weburl":"http://iphone.myzaker.com/l.php?l=57beb8199490cb2556000063","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12428&pk=57beb8199490cb2556000063&m=1472121915","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57becc5e9490cbb55500006b","title":"无法想象吃货的脑洞有多大","tag":"","content":"艺术家已饿晕在厨房","share_content":"艺术家已饿晕在厨房","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472122761_57180_W750H420S34118.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMjc2MV81NzE4MF9XNzUwSDQyMFMzNDExOC5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8f59490cb1322000047&pk=57becc5e9490cbb55500006b","type":"a","article":{"pk":"57beac319490cb0956000077","title":"吃货的神奇脑洞：食物也能变名画","app_ids":"12428","date":"","auther_name":"趣新闻","weburl":"http://iphone.myzaker.com/l.php?l=57beac319490cb0956000077","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12428&pk=57beac319490cb0956000077&m=1472119386","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57becc8d9490cbc855000080","title":"摄影师的天马与行空","tag":"","content":"超现实主义摄影作品一览","share_content":"超现实主义摄影作品一览","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472122390_18475_W750H420S55383.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMjM5MF8xODQ3NV9XNzUwSDQyMFM1NTM4My5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8f59490cb1322000047&pk=57becc8d9490cbc855000080","type":"a","article":{"pk":"57bec1869490cbf2550000ab","title":"摄影师的天马与行空","app_ids":"12428","date":"","auther_name":"烩设计","weburl":"http://iphone.myzaker.com/l.php?l=57bec1869490cbf2550000ab","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12428&pk=57bec1869490cbf2550000ab&m=1472121920","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}}]},{"pk":"57baa8c69490cb4022000046","score":"0.201608260694","title":"8月26日 星期五","build_banner":"Y","rank":"0.201608260694","banner":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160822/up_1471850691_74055_W1242H100S3207.png","w":"1242","h":"100","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1MDY5MV83NDA1NV9XMTI0MkgxMDBTMzIwNy5wbmc=_640.jpg"},"style":"over_pic","show_more":"N","items":[{"pk":"57bec2719490cbc655000070","title":"便利店果汁选购指南","tag":"","content":"到底哪瓶才是真爱","share_content":"到底哪瓶才是真爱","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472121760_78010_W750H420S60400.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMTc2MF83ODAxMF9XNzUwSDQyMFM2MDQwMC5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8c69490cb4022000046&pk=57bec2719490cbc655000070","type":"a","article":{"pk":"57be938e9490cb2356000058","title":"便利店果汁的选购指南","app_ids":"12250","date":"","auther_name":"KnewOne","weburl":"http://iphone.myzaker.com/l.php?l=57be938e9490cb2356000058","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12250&pk=57be938e9490cb2356000058&m=1472196369","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57bec3aa9490cb265600008f","title":"她才是江浙沪最民国的地方","tag":"","content":"比南京古派比扬州婉约","share_content":"比南京古派比扬州婉约","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472122078_57588_W750H425S147553.jpg","w":"750","h":"425","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMjA3OF81NzU4OF9XNzUwSDQyNVMxNDc1NTMuanBn_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8c69490cb4022000046&pk=57bec3aa9490cb265600008f","type":"a","article":{"pk":"57be5b189490cb1956000027","title":"比南京更古派，比扬州更婉约，她才是江浙沪最民国的地方！","app_ids":"12250","date":"","auther_name":"Feekr旅行","weburl":"http://iphone.myzaker.com/l.php?l=57be5b189490cb1956000027","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12250&pk=57be5b189490cb1956000027&m=1472196507","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57be7b489490cbf555000039","title":"西安不止泡馍和回民街 ","tag":"","content":"老街坊的饭局都被这些地方承包了","share_content":"老街坊的饭局都被这些地方承包了","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472101962_3785_W750H420S49443.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEwMTk2Ml8zNzg1X1c3NTBINDIwUzQ5NDQzLmpwZw==_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8c69490cb4022000046&pk=57be7b489490cbf555000039","type":"a","article":{"pk":"57be5b749490cb0656000043","title":"西安不止泡馍和回民街 老街坊的饭局都被这些地方承包了","app_ids":"12250","date":"","auther_name":"凤凰旅游","weburl":"http://iphone.myzaker.com/l.php?l=57be5b749490cb0656000043","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12250&pk=57be5b749490cb0656000043&m=1472204325","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57bec3b09490cbb61800004f","title":"解救被困在酷暑中的你","tag":"","content":"一杯冰拿铁就够了","share_content":"一杯冰拿铁就够了","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472121222_57485_W750H425S43758.jpg","w":"750","h":"425","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEyMTIyMl81NzQ4NV9XNzUwSDQyNVM0Mzc1OC5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8c69490cb4022000046&pk=57bec3b09490cbb61800004f","type":"a","article":{"pk":"57be595c9490cbbf5500002e","title":"一杯冰拿铁解救被困在酷暑中的你","app_ids":"12250","date":"","auther_name":"外滩画报","weburl":"http://iphone.myzaker.com/l.php?l=57be595c9490cbbf5500002e","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12250&pk=57be595c9490cbbf5500002e&m=1472182563","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57be7b419490cbf655000037","title":"赶在夏天结束之前","tag":"","content":"把北京的冰品再舔一遍","share_content":"把北京的冰品再舔一遍","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160825/up_1472102743_30908_W750H420S47867.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjUvdXBfMTQ3MjEwMjc0M18zMDkwOF9XNzUwSDQyMFM0Nzg2Ny5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa8c69490cb4022000046&pk=57be7b419490cbf655000037","type":"a","article":{"pk":"57be6c879490cbb455000041","title":"夏天结束前，我想把北京这10家美味冰品店再吃一遍","app_ids":"12250","date":"","auther_name":"赞那度","weburl":"http://iphone.myzaker.com/l.php?l=57be6c879490cbb455000041","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12250&pk=57be6c879490cbb455000041&m=1472100791","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}}]}]
     * promote : [{"pk":"57c3b71b9490cb4873000030","promotion_img":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472444379_18317_W1242H530S219366.jpg","img_height":"530","img_width":"1242","title":"","end_time":"1504195200","type":"a","pop_type":"","hide_mask":"Y","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c3b71b9490cb4873000030&position=weekend_promotion","start_time":"1472423340","article":{"pk":"57c399019490cb3a73000020","title":"别人度假去海边 玩乐带你进山里","app_ids":"12112","date":"2017-09-01 00:00:00","auther_name":"玩乐","weburl":"http://iphone.myzaker.com/l.php?l=57c399019490cb3a73000020","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12112&pk=57c399019490cb3a73000020&m=1472443794","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c3b71b9490cb4873000030&title=%E5%88%AB%E4%BA%BA%E5%BA%A6%E5%81%87%E5%8E%BB%E6%B5%B7%E8%BE%B9+%E7%8E%A9%E4%B9%90%E5%B8%A6%E4%BD%A0%E8%BF%9B%E5%B1%B1%E9%87%8C&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fwlwap.myzaker.com%2F%3Fmodel%3Dtopic%26wl_topic_id%3D57c399019490cb3a7300001f%26target%3Dweb3","show_jingcai":"N"},"hide_original_text_btn":"Y"}},{"pk":"57bfbb7c9490cb9360000034","promotion_img":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160826/up_1472192643_69611_W1242H530S330939.jpg","img_height":"530","img_width":"1242","title":"","end_time":"1472745600","type":"a","pop_type":"","hide_mask":"Y","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57bfbb7c9490cb9360000034&position=weekend_promotion","start_time":"1472183097","article":{"pk":"57bd848f9490cbb856000096","title":"跑遍全世界，人类已经无法阻止他的脚步","app_ids":"12112","date":"2016-09-02 00:00:00","auther_name":"ZAKER生活家","weburl":"http://iphone.myzaker.com/l.php?l=57bd848f9490cbb856000096","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12112&pk=57bd848f9490cbb856000096&m=1472182394","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57bfbb7c9490cb9360000034&title=%E8%B7%91%E9%81%8D%E5%85%A8%E4%B8%96%E7%95%8C%EF%BC%8C%E4%BA%BA%E7%B1%BB%E5%B7%B2%E7%BB%8F%E6%97%A0%E6%B3%95%E9%98%BB%E6%AD%A2%E4%BB%96%E7%9A%84%E8%84%9A%E6%AD%A5&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_car.php%3Fpk%3D57bfa22f9490cb8960000019%26target%3Dweb3%26article_pk%3D57bd848f9490cbb856000096","show_jingcai":"N"}}}]
     * display : [{"pk":"5744235d9490cbf11d000030","title":"积分商城","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160607/up_1465297868_38561.png","w":"566","h":"240","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA2MDcvdXBfMTQ2NTI5Nzg2OF8zODU2MS5wbmc=_400.jpg"},"click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=display_click&pk=5744235d9490cbf11d000030","type":"web","web":{"url":"http://m.zkshop.myzaker.com/","type":"","need_user_info":"Y"}},{"pk":"5744243b9490cb1361000083","title":"ZAKER 俱乐部","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160607/up_1465297886_80043.png","w":"566","h":"240","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA2MDcvdXBfMTQ2NTI5Nzg4Nl84MDA0My5wbmc=_400.jpg"},"click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=display_click&pk=5744243b9490cb1361000083","type":"web","web":{"url":"http://iphone.myzaker.com/zaker/hd_center.php","type":"","need_user_info":"Y"}},{"pk":"56ef724e9490cb474d000002","title":"一味","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160406/up_1459915164_16300.png","w":"566","h":"240","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA0MDYvdXBfMTQ1OTkxNTE2NF8xNjMwMC5wbmc=_400.jpg"},"click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=display_click&pk=56ef724e9490cb474d000002","type":"block","block_info":{"pk":"12289","title":"一味","stitle":"","block_title":"一味","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=12289","data_type":"","pic":"http://zkres.myzaker.com/data/image/logo/12289.png?t=1457518908","large_pic":"http://zkres.myzaker.com/data/image/logo/ipad3/12289.png?t=1457518908"}},{"pk":"56ef72cf9490cb9c01000002","title":"摄影札记","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160406/up_1459915228_85267.png","w":"566","h":"240","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA0MDYvdXBfMTQ1OTkxNTIyOF84NTI2Ny5wbmc=_400.jpg"},"click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=display_click&pk=56ef72cf9490cb9c01000002","type":"block","block_info":{"pk":"12304","title":"摄影札记","stitle":"","block_title":"摄影札记","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=12304","data_type":"","pic":"http://zkres.myzaker.com/data/image/logo/12304.png?t=1458293354","large_pic":"http://zkres.myzaker.com/data/image/logo/ipad3/12304.png?t=1458293354"}}]
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * next_url : http://wl.myzaker.com/?_appid=AndroidPhone&_v=6.7&_version=6.7&c=columns&city=%E5%A4%A7%E8%BF%9E&p=1&skey=YToxOntzOjg6ImhvbWVwYWdlIjtkOjAuMjAxNjA4MjYwNjk0MDAwMDE7fQ%3D%3D
         * page : 0
         * show_category : N
         */

        private InfoBean info;
        /**
         * pk : 57baa9399490cb3822000058
         * score : 0.201608300809
         * title : 今天
         * build_banner : Y
         * rank : 0.201608300809
         * banner : {"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160115/up_1452839250_95189.png","w":"1242","h":"100","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjAxMTUvdXBfMTQ1MjgzOTI1MF85NTE4OS5wbmc=_640.jpg"}
         * style : over_pic
         * show_more : N
         * items : [{"pk":"57c3ad909490cb257300004c","title":"Google用6个字母","tag":"","content":"做一本互动的\u201c百科全书\u201d","share_content":"做一本互动的\u201c百科全书\u201d","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472464461_57534_W750H420S43642.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2NDQ2MV81NzUzNF9XNzUwSDQyMFM0MzY0Mi5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3ad909490cb257300004c","type":"a","article":{"pk":"57beae179490cbbc55000078","title":"Google用6个字母，做一本互动的\u201c百科全书\u201d","app_ids":"12266","date":"","auther_name":"Voicer","weburl":"http://iphone.myzaker.com/l.php?l=57beae179490cbbc55000078","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57beae179490cbbc55000078&m=1472467007","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","video_inside":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12266&pk=57beae179490cbbc55000078&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57beae179490cbbc55000078%26app_id%3D12101%26target%3Dweb3","show_jingcai":"N"},"tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}}},{"pk":"57c3fcf99490cb3373000055","title":"当一名特工有多刺激","tag":"","content":"玩这 5 款游戏就知道了","share_content":"玩这 5 款游戏就知道了","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472465711_54965_W750H420S37539.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2NTcxMV81NDk2NV9XNzUwSDQyMFMzNzUzOS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3fcf99490cb3373000055","type":"a","article":{"pk":"57c3faa69490cb167300006e","title":"当一名特工有多刺激？玩这 5 款游戏就知道了","app_ids":"12266","date":"","auther_name":"爱范儿","weburl":"http://iphone.myzaker.com/l.php?l=57c3faa69490cb167300006e","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57c3faa69490cb167300006e&m=1472468532","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","video_inside":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12266&pk=57c3faa69490cb167300006e&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c3faa69490cb167300006e%26app_id%3D12101%26target%3Dweb3","show_jingcai":"N"},"tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}}},{"pk":"57c3fe649490cb5173000078","title":"妹子发明的甜甜圈有什么魔力","tag":"","content":"竟有一万多人主动掏腰包","share_content":"竟有一万多人主动掏腰包","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472464838_71439_W750H420S23152.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2NDgzOF83MTQzOV9XNzUwSDQyMFMyMzE1Mi5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3fe649490cb5173000078","type":"a","article":{"pk":"57c3ebf39490cb461c00004b","title":"有个妹子发明了\u201c甜甜圈\u201d 一万多人主动掏腰包","app_ids":"12266","date":"","auther_name":"一度蜜","weburl":"http://iphone.myzaker.com/l.php?l=57c3ebf39490cb461c00004b","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57c3ebf39490cb461c00004b&m=1472467699","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c3fe6d9490cbd23200001e","title":"选择困难症患者的福音","tag":"","content":"这些APP让你的人生少些纠结","share_content":"这些APP让你的人生少些纠结","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472466753_58243_W750H420S27624.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2Njc1M181ODI0M19XNzUwSDQyMFMyNzYyNC5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3fe6d9490cbd23200001e","type":"a","article":{"pk":"57c3e9ec9490cb207300003a","title":"选择困难症需要的 4 款 App，让人生少些纠结","app_ids":"12266","date":"","auther_name":"appsolution","weburl":"http://iphone.myzaker.com/l.php?l=57c3e9ec9490cb207300003a","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57c3e9ec9490cb207300003a&m=1472468369","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}},{"pk":"57c3fce69490cbfc72000073","title":"当菜市场玩起电子化","tag":"","content":"妈妈们居然要这样买菜","share_content":"妈妈们居然要这样买菜","pic":{"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472466843_48219_W750H420S98965.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2Njg0M180ODIxOV9XNzUwSDQyMFM5ODk2NS5qcGc=_400.jpg"},"tpl_cell_style":"over_pic","click_stat_url":"http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3fce69490cbfc72000073","type":"a","article":{"pk":"57c3f3fc9490cbed72000045","title":"菜市场搞成这样，社区购物中心得\u201c跪求\u201d","app_ids":"12266","date":"","auther_name":"商业与地产","weburl":"http://iphone.myzaker.com/l.php?l=57c3f3fc9490cbed72000045","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57c3f3fc9490cbed72000045&m=1472461981","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"},"special_info":{"show_jingcai":"N"}}}]
         */

        private List<ColumnsBean> columns;
        /**
         * pk : 57c3b71b9490cb4873000030
         * promotion_img : http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472444379_18317_W1242H530S219366.jpg
         * img_height : 530
         * img_width : 1242
         * title :
         * end_time : 1504195200
         * type : a
         * pop_type :
         * hide_mask : Y
         * ads_stat_url : http://adm.myzaker.com/ads_stat.php?ads_id=57c3b71b9490cb4873000030&position=weekend_promotion
         * start_time : 1472423340
         * article : {"pk":"57c399019490cb3a73000020","title":"别人度假去海边 玩乐带你进山里","app_ids":"12112","date":"2017-09-01 00:00:00","auther_name":"玩乐","weburl":"http://iphone.myzaker.com/l.php?l=57c399019490cb3a73000020","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12112&pk=57c399019490cb3a73000020&m=1472443794","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c3b71b9490cb4873000030&title=%E5%88%AB%E4%BA%BA%E5%BA%A6%E5%81%87%E5%8E%BB%E6%B5%B7%E8%BE%B9+%E7%8E%A9%E4%B9%90%E5%B8%A6%E4%BD%A0%E8%BF%9B%E5%B1%B1%E9%87%8C&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fwlwap.myzaker.com%2F%3Fmodel%3Dtopic%26wl_topic_id%3D57c399019490cb3a7300001f%26target%3Dweb3","show_jingcai":"N"},"hide_original_text_btn":"Y"}
         */

        private List<PromoteBean> promote;
        /**
         * pk : 5744235d9490cbf11d000030
         * title : 积分商城
         * pic : {"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160607/up_1465297868_38561.png","w":"566","h":"240","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA2MDcvdXBfMTQ2NTI5Nzg2OF8zODU2MS5wbmc=_400.jpg"}
         * click_stat_url : http://wl.myzaker.com/?c=action_stat&m=display_click&pk=5744235d9490cbf11d000030
         * type : web
         * web : {"url":"http://m.zkshop.myzaker.com/","type":"","need_user_info":"Y"}
         */

        private List<DisplayBean> display;

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public List<ColumnsBean> getColumns() {
            return columns;
        }

        public void setColumns(List<ColumnsBean> columns) {
            this.columns = columns;
        }

        public List<PromoteBean> getPromote() {
            return promote;
        }

        public void setPromote(List<PromoteBean> promote) {
            this.promote = promote;
        }

        public List<DisplayBean> getDisplay() {
            return display;
        }

        public void setDisplay(List<DisplayBean> display) {
            this.display = display;
        }

        public static class InfoBean {
            private String next_url;
            private String page;
            private String show_category;

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getShow_category() {
                return show_category;
            }

            public void setShow_category(String show_category) {
                this.show_category = show_category;
            }
        }

        public static class ColumnsBean {
            private String pk;
            private String score;
            private String title;
            private String build_banner;
            private String rank;
            /**
             * url : http://zkres.myzaker.com/img_upload/editor/img_upload/20160115/up_1452839250_95189.png
             * w : 1242
             * h : 100
             * m_url : http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjAxMTUvdXBfMTQ1MjgzOTI1MF85NTE4OS5wbmc=_640.jpg
             */

            private BannerBean banner;
            private String style;
            private String show_more;
            /**
             * pk : 57c3ad909490cb257300004c
             * title : Google用6个字母
             * tag :
             * content : 做一本互动的“百科全书”
             * share_content : 做一本互动的“百科全书”
             * pic : {"url":"http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472464461_57534_W750H420S43642.jpg","w":"750","h":"420","m_url":"http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2NDQ2MV81NzUzNF9XNzUwSDQyMFM0MzY0Mi5qcGc=_400.jpg"}
             * tpl_cell_style : over_pic
             * click_stat_url : http://wl.myzaker.com/?c=action_stat&m=column_item_click&cate_id=57baa9399490cb3822000058&pk=57c3ad909490cb257300004c
             * type : a
             * article : {"pk":"57beae179490cbbc55000078","title":"Google用6个字母，做一本互动的\u201c百科全书\u201d","app_ids":"12266","date":"","auther_name":"Voicer","weburl":"http://iphone.myzaker.com/l.php?l=57beae179490cbbc55000078","is_full":"NO","content":"","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57beae179490cbbc55000078&m=1472467007","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","video_inside":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12266&pk=57beae179490cbbc55000078&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57beae179490cbbc55000078%26app_id%3D12101%26target%3Dweb3","show_jingcai":"N"},"tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}}
             */

            private List<ItemsBean> items;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getScore() {
                return score;
            }

            public void setScore(String score) {
                this.score = score;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBuild_banner() {
                return build_banner;
            }

            public void setBuild_banner(String build_banner) {
                this.build_banner = build_banner;
            }

            public String getRank() {
                return rank;
            }

            public void setRank(String rank) {
                this.rank = rank;
            }

            public BannerBean getBanner() {
                return banner;
            }

            public void setBanner(BannerBean banner) {
                this.banner = banner;
            }

            public String getStyle() {
                return style;
            }

            public void setStyle(String style) {
                this.style = style;
            }

            public String getShow_more() {
                return show_more;
            }

            public void setShow_more(String show_more) {
                this.show_more = show_more;
            }

            public List<ItemsBean> getItems() {
                return items;
            }

            public void setItems(List<ItemsBean> items) {
                this.items = items;
            }

            public static class BannerBean {
                private String url;
                private String w;
                private String h;
                private String m_url;

                public String getUrl() {
                    return url;
                }

                public void setUrl(String url) {
                    this.url = url;
                }

                public String getW() {
                    return w;
                }

                public void setW(String w) {
                    this.w = w;
                }

                public String getH() {
                    return h;
                }

                public void setH(String h) {
                    this.h = h;
                }

                public String getM_url() {
                    return m_url;
                }

                public void setM_url(String m_url) {
                    this.m_url = m_url;
                }
            }

            public static class ItemsBean {
                private String pk;
                private String title;
                private String tag;
                private String content;
                private String share_content;
                /**
                 * url : http://zkres.myzaker.com/img_upload/editor/img_upload/20160829/up_1472464461_57534_W750H420S43642.jpg
                 * w : 750
                 * h : 420
                 * m_url : http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ2NDQ2MV81NzUzNF9XNzUwSDQyMFM0MzY0Mi5qcGc=_400.jpg
                 */

                private PicBean pic;
                private String tpl_cell_style;
                private String click_stat_url;
                private String type;
                /**
                 * pk : 57beae179490cbbc55000078
                 * title : Google用6个字母，做一本互动的“百科全书”
                 * app_ids : 12266
                 * date :
                 * auther_name : Voicer
                 * weburl : http://iphone.myzaker.com/l.php?l=57beae179490cbbc55000078
                 * is_full : NO
                 * content :
                 * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12266&pk=57beae179490cbbc55000078&m=1472467007
                 * type : web3
                 * special_info : {"open_type":"web3","need_user_info":"Y","video_inside":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12266&pk=57beae179490cbbc55000078&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57beae179490cbbc55000078%26app_id%3D12101%26target%3Dweb3","show_jingcai":"N"}
                 * tpl_info : {"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}
                 */

                private ArticleBean article;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getTag() {
                    return tag;
                }

                public void setTag(String tag) {
                    this.tag = tag;
                }

                public String getContent() {
                    return content;
                }

                public void setContent(String content) {
                    this.content = content;
                }

                public String getShare_content() {
                    return share_content;
                }

                public void setShare_content(String share_content) {
                    this.share_content = share_content;
                }

                public PicBean getPic() {
                    return pic;
                }

                public void setPic(PicBean pic) {
                    this.pic = pic;
                }

                public String getTpl_cell_style() {
                    return tpl_cell_style;
                }

                public void setTpl_cell_style(String tpl_cell_style) {
                    this.tpl_cell_style = tpl_cell_style;
                }

                public String getClick_stat_url() {
                    return click_stat_url;
                }

                public void setClick_stat_url(String click_stat_url) {
                    this.click_stat_url = click_stat_url;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public ArticleBean getArticle() {
                    return article;
                }

                public void setArticle(ArticleBean article) {
                    this.article = article;
                }

                public static class PicBean {
                    private String url;
                    private String w;
                    private String h;
                    private String m_url;

                    public String getUrl() {
                        return url;
                    }

                    public void setUrl(String url) {
                        this.url = url;
                    }

                    public String getW() {
                        return w;
                    }

                    public void setW(String w) {
                        this.w = w;
                    }

                    public String getH() {
                        return h;
                    }

                    public void setH(String h) {
                        this.h = h;
                    }

                    public String getM_url() {
                        return m_url;
                    }

                    public void setM_url(String m_url) {
                        this.m_url = m_url;
                    }
                }

                public static class ArticleBean {
                    private String pk;
                    private String title;
                    private String app_ids;
                    private String date;
                    private String auther_name;
                    private String weburl;
                    private String is_full;
                    private String content;
                    private String full_url;
                    private String type;
                    /**
                     * open_type : web3
                     * need_user_info : Y
                     * video_inside : Y
                     * web_url : http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12266&pk=57beae179490cbbc55000078&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57beae179490cbbc55000078%26app_id%3D12101%26target%3Dweb3
                     * show_jingcai : N
                     */

                    private SpecialInfoBean special_info;
                    /**
                     * url : http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403
                     * name : tpl_02
                     * update : 201606281403
                     */

                    private TplInfoBean tpl_info;

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApp_ids() {
                        return app_ids;
                    }

                    public void setApp_ids(String app_ids) {
                        this.app_ids = app_ids;
                    }

                    public String getDate() {
                        return date;
                    }

                    public void setDate(String date) {
                        this.date = date;
                    }

                    public String getAuther_name() {
                        return auther_name;
                    }

                    public void setAuther_name(String auther_name) {
                        this.auther_name = auther_name;
                    }

                    public String getWeburl() {
                        return weburl;
                    }

                    public void setWeburl(String weburl) {
                        this.weburl = weburl;
                    }

                    public String getIs_full() {
                        return is_full;
                    }

                    public void setIs_full(String is_full) {
                        this.is_full = is_full;
                    }

                    public String getContent() {
                        return content;
                    }

                    public void setContent(String content) {
                        this.content = content;
                    }

                    public String getFull_url() {
                        return full_url;
                    }

                    public void setFull_url(String full_url) {
                        this.full_url = full_url;
                    }

                    public String getType() {
                        return type;
                    }

                    public void setType(String type) {
                        this.type = type;
                    }

                    public SpecialInfoBean getSpecial_info() {
                        return special_info;
                    }

                    public void setSpecial_info(SpecialInfoBean special_info) {
                        this.special_info = special_info;
                    }

                    public TplInfoBean getTpl_info() {
                        return tpl_info;
                    }

                    public void setTpl_info(TplInfoBean tpl_info) {
                        this.tpl_info = tpl_info;
                    }

                    public static class SpecialInfoBean {
                        private String open_type;
                        private String need_user_info;
                        private String video_inside;
                        private String web_url;
                        private String show_jingcai;

                        public String getOpen_type() {
                            return open_type;
                        }

                        public void setOpen_type(String open_type) {
                            this.open_type = open_type;
                        }

                        public String getNeed_user_info() {
                            return need_user_info;
                        }

                        public void setNeed_user_info(String need_user_info) {
                            this.need_user_info = need_user_info;
                        }

                        public String getVideo_inside() {
                            return video_inside;
                        }

                        public void setVideo_inside(String video_inside) {
                            this.video_inside = video_inside;
                        }

                        public String getWeb_url() {
                            return web_url;
                        }

                        public void setWeb_url(String web_url) {
                            this.web_url = web_url;
                        }

                        public String getShow_jingcai() {
                            return show_jingcai;
                        }

                        public void setShow_jingcai(String show_jingcai) {
                            this.show_jingcai = show_jingcai;
                        }
                    }

                    public static class TplInfoBean {
                        private String url;
                        private String name;
                        private String update;

                        public String getUrl() {
                            return url;
                        }

                        public void setUrl(String url) {
                            this.url = url;
                        }

                        public String getName() {
                            return name;
                        }

                        public void setName(String name) {
                            this.name = name;
                        }

                        public String getUpdate() {
                            return update;
                        }

                        public void setUpdate(String update) {
                            this.update = update;
                        }
                    }
                }
            }
        }

        public static class PromoteBean {
            private String pk;
            private String promotion_img;
            private String img_height;
            private String img_width;
            private String title;
            private String end_time;
            private String type;
            private String pop_type;
            private String hide_mask;
            private String ads_stat_url;
            private String start_time;
            /**
             * pk : 57c399019490cb3a73000020
             * title : 别人度假去海边 玩乐带你进山里
             * app_ids : 12112
             * date : 2017-09-01 00:00:00
             * auther_name : 玩乐
             * weburl : http://iphone.myzaker.com/l.php?l=57c399019490cb3a73000020
             * is_full : NO
             * content :
             * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12112&pk=57c399019490cb3a73000020&m=1472443794
             * type : web3
             * special_info : {"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c3b71b9490cb4873000030&title=%E5%88%AB%E4%BA%BA%E5%BA%A6%E5%81%87%E5%8E%BB%E6%B5%B7%E8%BE%B9+%E7%8E%A9%E4%B9%90%E5%B8%A6%E4%BD%A0%E8%BF%9B%E5%B1%B1%E9%87%8C&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fwlwap.myzaker.com%2F%3Fmodel%3Dtopic%26wl_topic_id%3D57c399019490cb3a7300001f%26target%3Dweb3","show_jingcai":"N"}
             * hide_original_text_btn : Y
             */

            private ArticleBean article;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getPromotion_img() {
                return promotion_img;
            }

            public void setPromotion_img(String promotion_img) {
                this.promotion_img = promotion_img;
            }

            public String getImg_height() {
                return img_height;
            }

            public void setImg_height(String img_height) {
                this.img_height = img_height;
            }

            public String getImg_width() {
                return img_width;
            }

            public void setImg_width(String img_width) {
                this.img_width = img_width;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getEnd_time() {
                return end_time;
            }

            public void setEnd_time(String end_time) {
                this.end_time = end_time;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getPop_type() {
                return pop_type;
            }

            public void setPop_type(String pop_type) {
                this.pop_type = pop_type;
            }

            public String getHide_mask() {
                return hide_mask;
            }

            public void setHide_mask(String hide_mask) {
                this.hide_mask = hide_mask;
            }

            public String getAds_stat_url() {
                return ads_stat_url;
            }

            public void setAds_stat_url(String ads_stat_url) {
                this.ads_stat_url = ads_stat_url;
            }

            public String getStart_time() {
                return start_time;
            }

            public void setStart_time(String start_time) {
                this.start_time = start_time;
            }

            public ArticleBean getArticle() {
                return article;
            }

            public void setArticle(ArticleBean article) {
                this.article = article;
            }

            public static class ArticleBean {
                private String pk;
                private String title;
                private String app_ids;
                private String date;
                private String auther_name;
                private String weburl;
                private String is_full;
                private String content;
                private String full_url;
                private String type;
                /**
                 * open_type : web3
                 * need_user_info : Y
                 * web_url : http://iphone.myzaker.com/zaker/ad_article.php?_id=57c3b71b9490cb4873000030&title=%E5%88%AB%E4%BA%BA%E5%BA%A6%E5%81%87%E5%8E%BB%E6%B5%B7%E8%BE%B9+%E7%8E%A9%E4%B9%90%E5%B8%A6%E4%BD%A0%E8%BF%9B%E5%B1%B1%E9%87%8C&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fwlwap.myzaker.com%2F%3Fmodel%3Dtopic%26wl_topic_id%3D57c399019490cb3a7300001f%26target%3Dweb3
                 * show_jingcai : N
                 */

                private SpecialInfoBean special_info;
                private String hide_original_text_btn;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getApp_ids() {
                    return app_ids;
                }

                public void setApp_ids(String app_ids) {
                    this.app_ids = app_ids;
                }

                public String getDate() {
                    return date;
                }

                public void setDate(String date) {
                    this.date = date;
                }

                public String getAuther_name() {
                    return auther_name;
                }

                public void setAuther_name(String auther_name) {
                    this.auther_name = auther_name;
                }

                public String getWeburl() {
                    return weburl;
                }

                public void setWeburl(String weburl) {
                    this.weburl = weburl;
                }

                public String getIs_full() {
                    return is_full;
                }

                public void setIs_full(String is_full) {
                    this.is_full = is_full;
                }

                public String getContent() {
                    return content;
                }

                public void setContent(String content) {
                    this.content = content;
                }

                public String getFull_url() {
                    return full_url;
                }

                public void setFull_url(String full_url) {
                    this.full_url = full_url;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public SpecialInfoBean getSpecial_info() {
                    return special_info;
                }

                public void setSpecial_info(SpecialInfoBean special_info) {
                    this.special_info = special_info;
                }

                public String getHide_original_text_btn() {
                    return hide_original_text_btn;
                }

                public void setHide_original_text_btn(String hide_original_text_btn) {
                    this.hide_original_text_btn = hide_original_text_btn;
                }

                public static class SpecialInfoBean {
                    private String open_type;
                    private String need_user_info;
                    private String web_url;
                    private String show_jingcai;

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }

                    public String getNeed_user_info() {
                        return need_user_info;
                    }

                    public void setNeed_user_info(String need_user_info) {
                        this.need_user_info = need_user_info;
                    }

                    public String getWeb_url() {
                        return web_url;
                    }

                    public void setWeb_url(String web_url) {
                        this.web_url = web_url;
                    }

                    public String getShow_jingcai() {
                        return show_jingcai;
                    }

                    public void setShow_jingcai(String show_jingcai) {
                        this.show_jingcai = show_jingcai;
                    }
                }
            }
        }

        public static class DisplayBean {
            private String pk;
            private String title;
            /**
             * url : http://zkres.myzaker.com/img_upload/editor/img_upload/20160607/up_1465297868_38561.png
             * w : 566
             * h : 240
             * m_url : http://actres.myzaker.com/img/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA2MDcvdXBfMTQ2NTI5Nzg2OF8zODU2MS5wbmc=_400.jpg
             */

            private PicBean pic;
            private String click_stat_url;
            private String type;
            /**
             * url : http://m.zkshop.myzaker.com/
             * type :
             * need_user_info : Y
             */
            private block_infoBean  block_info;


            private WebBean web;

            public block_infoBean getBlock_info() {
                return block_info;
            }

            public void setBlock_info(block_infoBean block_info) {
                this.block_info = block_info;
            }

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public PicBean getPic() {
                return pic;
            }

            public void setPic(PicBean pic) {
                this.pic = pic;
            }

            public String getClick_stat_url() {
                return click_stat_url;
            }

            public void setClick_stat_url(String click_stat_url) {
                this.click_stat_url = click_stat_url;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public WebBean getWeb() {
                return web;
            }

            public void setWeb(WebBean web) {
                this.web = web;
            }

            public static class PicBean {
                private String url;
                private String w;
                private String h;
                private String m_url;

                public String getUrl() {
                    return url;
                }

                public void setUrl(String url) {
                    this.url = url;
                }

                public String getW() {
                    return w;
                }

                public void setW(String w) {
                    this.w = w;
                }

                public String getH() {
                    return h;
                }

                public void setH(String h) {
                    this.h = h;
                }

                public String getM_url() {
                    return m_url;
                }

                public void setM_url(String m_url) {
                    this.m_url = m_url;
                }
            }

            public static class block_infoBean{
                private String pk;
                private String title;
                private String stitle;
                private String block_title;
                private String api_url;
                private String data_type;
                private String pic;
                private String large_pic;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getBlock_title() {
                    return block_title;
                }

                public void setBlock_title(String block_title) {
                    this.block_title = block_title;
                }

                public String getStitle() {
                    return stitle;
                }

                public void setStitle(String stitle) {
                    this.stitle = stitle;
                }

                public String getData_type() {
                    return data_type;
                }

                public void setData_type(String data_type) {
                    this.data_type = data_type;
                }

                public String getApi_url() {
                    return api_url;
                }

                public void setApi_url(String api_url) {
                    this.api_url = api_url;
                }

                public String getPic() {
                    return pic;
                }

                public void setPic(String pic) {
                    this.pic = pic;
                }

                public String getLarge_pic() {
                    return large_pic;
                }

                public void setLarge_pic(String large_pic) {
                    this.large_pic = large_pic;
                }
            }

            public static class WebBean {
                private String url;
                private String type;
                private String need_user_info;

                public String getUrl() {
                    return url;
                }

                public void setUrl(String url) {
                    this.url = url;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public String getNeed_user_info() {
                    return need_user_info;
                }

                public void setNeed_user_info(String need_user_info) {
                    this.need_user_info = need_user_info;
                }
            }
        }
    }
}
