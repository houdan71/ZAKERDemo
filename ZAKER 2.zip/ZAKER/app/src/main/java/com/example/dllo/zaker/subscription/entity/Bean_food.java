package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/1.
 */
public class Bean_food {

    /**
     * stat : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=12289&since_date=1471400792&nt=1&_appid=androidphone&top_tab_id=10386","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=12289&need_app_integration=1","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12289&ids=54f40b639490cb12100000da&k=201609011740"},"catalog":"","articles":[{"pk":"57c4e7c49490cba013000024","title":"食尚西餐 | 焗烤扇贝佐菠菜","date":"","auther_name":"饭合","weburl":"http://iphone.myzaker.com/l.php?l=57c4e7c49490cba013000024","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"20","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c4e7c49490cba013000024&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c4e7c49490cba013000024%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c4e7c49490cba013000024&m=1472698368","list_dtime":""},{"pk":"57c7d83a9490cb902c000074","title":"家常菜 | 番茄蘑菇炖鲳鱼，这味道酸爽！","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57c7d83a9490cb902c000074","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNDg3OV8yNzkyMl9XNjQwSDM2MFM1MTU3OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNDg3OV8yNzkyMl9XNjQwSDM2MFM1MTU3OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNDg3OV8yNzkyMl9XNjQwSDM2MFM1MTU3OC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNDg3OV8yNzkyMl9XNjQwSDM2MFM1MTU3OC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNDg3OV8yNzkyMl9XNjQwSDM2MFM1MTU3OC5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c7d83a9490cb902c000074&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c7d83a9490cb902c000074%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c7d83a9490cb902c000074&m=1472714882","list_dtime":""},{"pk":"57c78fb09490cba02c000037","title":"简美一餐 | 一碗饭搞定处女座的味噌牛肉饭","date":"","auther_name":"日日煮DayDayCook","weburl":"http://iphone.myzaker.com/l.php?l=57c78fb09490cba02c000037","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1Y2FiYjdmNTJlOTI3NWUwMDAxZjZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1Y2FiYjdmNTJlOTI3NWUwMDAxZjZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"400,225","media_count":"21","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1Y2FiYjdmNTJlOTI3NWUwMDAxZjZfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1Y2FiYjdmNTJlOTI3NWUwMDAxZjZfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1Y2FiYjdmNTJlOTI3NWUwMDAxZjZfNjQwLmpwZw==_1242.jpg","w":"400","h":"225"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c78fb09490cba02c000037&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c78fb09490cba02c000037%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c78fb09490cba02c000037&m=1472698243","list_dtime":""},{"pk":"57c6376a9490cb194b000011","title":"家常菜 | 猪蹄太油腻怎么办？凉拌！","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57c6376a9490cb194b000011","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwODI3NV84MjY0NV9XNjQwSDM2MFM1MDk0Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwODI3NV84MjY0NV9XNjQwSDM2MFM1MDk0Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwODI3NV84MjY0NV9XNjQwSDM2MFM1MDk0Ni5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwODI3NV84MjY0NV9XNjQwSDM2MFM1MDk0Ni5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwODI3NV84MjY0NV9XNjQwSDM2MFM1MDk0Ni5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c6376a9490cb194b000011&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c6376a9490cb194b000011%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c6376a9490cb194b000011&m=1472625395","list_dtime":""},{"pk":"57c4e5f19490cb8713000010","title":"零嘴杂食 | 芝士的3+1种有爱吃法","date":"","auther_name":"厨娘物语","weburl":"http://iphone.myzaker.com/l.php?l=57c4e5f19490cb8713000010","thumbnail_pic":"http://zkres.myzaker.com/201608/57beca3e7f52e94f3b000250_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57beca3e7f52e94f3b000250_320.jpg","thumbnail_picsize":"350,197","media_count":"37","thumbnail_medias":[{"type":"image","id":"57beca3e7f52e94f3b000250","url":"http://zkres.myzaker.com/201608/57beca3e7f52e94f3b000250_640.jpg","m_url":"http://zkres.myzaker.com/201608/57beca3e7f52e94f3b000250_320.jpg","min_url":"http://zkres.myzaker.com/201608/57beca3e7f52e94f3b000250_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_gif/rf6wRw7ib1R1ytDUzcjPMCy5uzXQgABle7xNEwiboibfbGu5VjqcozKEuNk5eBHz78y8ENxvXxtAn7mqu2iadXpicOg/0?wx_fmt=gif","w":"350","h":"197","gif_url":"http://zkres.myzaker.com/201608/57beca3e7f52e94f3b000250_raw.gif"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c4e5f19490cb8713000010&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c4e5f19490cb8713000010%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c4e5f19490cb8713000010&m=1472607980","list_dtime":""},{"pk":"57bff3ca9490cb4960000056","title":"家常菜 | 酸梅蒸排骨：猪肉怎么吃都不腻","title_line_break":"家常菜 | 酸梅蒸排骨：\n猪肉怎么吃都不腻","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57bff3ca9490cb4960000056","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwNzg3M180MTc3Nl9XNjQwSDM2MFM1MzAwOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwNzg3M180MTc3Nl9XNjQwSDM2MFM1MzAwOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwNzg3M180MTc3Nl9XNjQwSDM2MFM1MzAwOC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwNzg3M180MTc3Nl9XNjQwSDM2MFM1MzAwOC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwNzg3M180MTc3Nl9XNjQwSDM2MFM1MzAwOC5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bff3ca9490cb4960000056&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bff3ca9490cb4960000056%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bff3ca9490cb4960000056&m=1472607928","list_dtime":""},{"pk":"57c4e2f09490cb531300002e","title":"甜在心 | 3分钟学会做黑白巧克力慕斯","date":"","auther_name":"贝太厨房","weburl":"http://iphone.myzaker.com/l.php?l=57c4e2f09490cb531300002e","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjk0NjdmNTJlOWJiMDkwMDAyNzhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjk0NjdmNTJlOWJiMDkwMDAyNzhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,362","media_count":"20","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjk0NjdmNTJlOWJiMDkwMDAyNzhfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjk0NjdmNTJlOWJiMDkwMDAyNzhfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjk0NjdmNTJlOWJiMDkwMDAyNzhfNjQwLmpwZw==_1242.jpg","w":"640","h":"362"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c4e2f09490cb531300002e&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c4e2f09490cb531300002e%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c4e2f09490cb531300002e&m=1472521003","list_dtime":""},{"pk":"57c4e7c49490cba013000028","title":"开眼 | 帝王蟹你真的吃对了么？","date":"","auther_name":"饭合","weburl":"http://iphone.myzaker.com/l.php?l=57c4e7c49490cba013000028","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2FlMTIyNTdmNTJlOWE0MmYwMDAzMDhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2FlMTIyNTdmNTJlOWE0MmYwMDAzMDhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"13","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2FlMTIyNTdmNTJlOWE0MmYwMDAzMDhfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2FlMTIyNTdmNTJlOWE0MmYwMDAzMDhfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2FlMTIyNTdmNTJlOWE0MmYwMDAzMDhfNjQwLmpwZw==_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c4e7c49490cba013000028&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c4e7c49490cba013000028%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c4e7c49490cba013000028&m=1472607631","list_dtime":""},{"pk":"57c3971b9490cb287300000d","title":"开眼 | 寿司制作的精妙美学，看着就是种享受","date":"","auther_name":"豆果美食","weburl":"http://iphone.myzaker.com/l.php?l=57c3971b9490cb287300000d","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTE0MV8yMTA0Nl9XNjQwSDM2MFM3NzUyNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTE0MV8yMTA0Nl9XNjQwSDM2MFM3NzUyNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTE0MV8yMTA0Nl9XNjQwSDM2MFM3NzUyNC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTE0MV8yMTA0Nl9XNjQwSDM2MFM3NzUyNC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTE0MV8yMTA0Nl9XNjQwSDM2MFM3NzUyNC5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c3971b9490cb287300000d&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c3971b9490cb287300000d%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c3971b9490cb287300000d&m=1472443031","list_dtime":""},{"pk":"57c392329490cbfc7200003c","title":"家常菜 | 家常小海鲜这么做，零失败！","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57c392329490cbfc7200003c","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTA2NV8yMzk5X1c2NDBIMzYwUzUxNTM3LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTA2NV8yMzk5X1c2NDBIMzYwUzUxNTM3LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTA2NV8yMzk5X1c2NDBIMzYwUzUxNTM3LmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTA2NV8yMzk5X1c2NDBIMzYwUzUxNTM3LmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTA2NV8yMzk5X1c2NDBIMzYwUzUxNTM3LmpwZw==_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"other","special_info":{"open_type":"article_video","video_label":"02:15","video_size":"16,10","show_jingcai":"Y","item_type":"1_v"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c392329490cbfc7200003c&m=1472452037","list_dtime":""},{"pk":"57c17a619490cb1e3b000086","title":"零嘴杂食 | 半半炸鸡，你要原味or甜辣味？","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57c17a619490cb1e3b000086","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmZDUyODdmNTJlOTY5MTYwMDBkMTVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmZDUyODdmNTJlOTY5MTYwMDBkMTVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"16","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmZDUyODdmNTJlOTY5MTYwMDBkMTVfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmZDUyODdmNTJlOTY5MTYwMDBkMTVfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmZDUyODdmNTJlOTY5MTYwMDBkMTVfNjQwLmpwZw==_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c17a619490cb1e3b000086&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c17a619490cb1e3b000086%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c17a619490cb1e3b000086&m=1472440821","list_dtime":""},{"pk":"57c0100e9490cb736000005b","title":"简美一餐 | 一碗 酸辣粉，辣得欲罢不能！","date":"","auther_name":"日食记","weburl":"http://iphone.myzaker.com/l.php?l=57c0100e9490cb736000005b","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmYzU0NjdmNTJlOTY5MTYwMDAzMjRfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmYzU0NjdmNTJlOTY5MTYwMDAzMjRfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"370,209","media_count":"14","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmYzU0NjdmNTJlOTY5MTYwMDAzMjRfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmYzU0NjdmNTJlOTY5MTYwMDAzMjRfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmYzU0NjdmNTJlOTY5MTYwMDAzMjRfNjQwLmpwZw==_1242.jpg","w":"370","h":"209"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c0100e9490cb736000005b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c0100e9490cb736000005b%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c0100e9490cb736000005b&m=1472366819","list_dtime":""},{"pk":"57bd00229490cb7456000021","title":"简美一餐 | 这可不是寿司，荞麦面卷着吃","date":"","auther_name":"日日煮DayDayCook","weburl":"http://iphone.myzaker.com/l.php?l=57bd00229490cb7456000021","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjZjVkYjdmNTJlOTRjMzMwMDAwM2JfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjZjVkYjdmNTJlOTRjMzMwMDAwM2JfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"23","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjZjVkYjdmNTJlOTRjMzMwMDAwM2JfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjZjVkYjdmNTJlOTRjMzMwMDAwM2JfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjZjVkYjdmNTJlOTRjMzMwMDAwM2JfNjQwLmpwZw==_1242.jpg","w":"640","h":"427"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bd00229490cb7456000021&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bd00229490cb7456000021%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bd00229490cb7456000021&m=1472263331","list_dtime":""},{"pk":"57c014679490cb9860000062","title":"微醺之美 | 4款夏日豆浆新做法","date":"","auther_name":"美食杰","weburl":"http://iphone.myzaker.com/l.php?l=57c014679490cb9860000062","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MwMTQ2ZGEwN2FlY2Y3N2UwMTAwZTRfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MwMTQ2ZGEwN2FlY2Y3N2UwMTAwZTRfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,357","media_count":"10","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MwMTQ2ZGEwN2FlY2Y3N2UwMTAwZTRfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MwMTQ2ZGEwN2FlY2Y3N2UwMTAwZTRfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MwMTQ2ZGEwN2FlY2Y3N2UwMTAwZTRfNjQwLmpwZw==_1242.jpg","w":"640","h":"357"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c014679490cb9860000062&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c014679490cb9860000062%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c014679490cb9860000062&m=1472342694","list_dtime":""},{"pk":"57ba63b79490cb272200002b","title":"零嘴杂食 | 进阶版韩国芝士鸡蛋卷","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57ba63b79490cb272200002b","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2I2YWNmODdmNTJlOWVmMWEwMDAyODZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2I2YWNmODdmNTJlOWVmMWEwMDAyODZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,361","media_count":"13","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2I2YWNmODdmNTJlOWVmMWEwMDAyODZfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2I2YWNmODdmNTJlOWVmMWEwMDAyODZfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2I2YWNmODdmNTJlOWVmMWEwMDAyODZfNjQwLmpwZw==_1242.jpg","w":"640","h":"361"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57ba63b79490cb272200002b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57ba63b79490cb272200002b%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57ba63b79490cb272200002b&m=1472204651","list_dtime":""},{"pk":"57bcfc0d9490cb9f56000022","title":"甜在心丨水果和蔬菜的完美牵手","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57bcfc0d9490cb9f56000022","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JhNzViNzdmNTJlOTExNWIwMDAwNjdfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JhNzViNzdmNTJlOTExNWIwMDAwNjdfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,284","media_count":"25","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JhNzViNzdmNTJlOTExNWIwMDAwNjdfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JhNzViNzdmNTJlOTExNWIwMDAwNjdfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JhNzViNzdmNTJlOTExNWIwMDAwNjdfNjQwLmpwZw==_1242.jpg","w":"500","h":"284"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bcfc0d9490cb9f56000022&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bcfc0d9490cb9f56000022%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bcfc0d9490cb9f56000022&m=1472198819","list_dtime":""},{"pk":"57bff3ca9490cb4960000054","title":"简美一餐 | 如何制作日式冷面","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57bff3ca9490cb4960000054","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE5ODcwM185ODQ2NF9XNjQwSDM2MFM3MTIzOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE5ODcwM185ODQ2NF9XNjQwSDM2MFM3MTIzOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE5ODcwM185ODQ2NF9XNjQwSDM2MFM3MTIzOC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE5ODcwM185ODQ2NF9XNjQwSDM2MFM3MTIzOC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE5ODcwM185ODQ2NF9XNjQwSDM2MFM3MTIzOC5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bff3ca9490cb4960000054&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bff3ca9490cb4960000054%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bff3ca9490cb4960000054&m=1472198709","list_dtime":""},{"pk":"57ba63b69490cb272200002a","title":"家常菜 | 牛尾猪手，强强联手的美味！","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57ba63b69490cb272200002a","thumbnail_pic":"http://zkres.myzaker.com/201608/57b7c9e57f52e9a83c0001a7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b7c9e57f52e9a83c0001a7_320.jpg","thumbnail_picsize":"500,284","media_count":"13","thumbnail_medias":[{"type":"image","id":"57b7c9e57f52e9a83c0001a7","url":"http://zkres.myzaker.com/201608/57b7c9e57f52e9a83c0001a7_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b7c9e57f52e9a83c0001a7_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b7c9e57f52e9a83c0001a7_640.jpg","w":"500","h":"284"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57ba63b69490cb272200002a&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57ba63b69490cb272200002a%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57ba63b69490cb272200002a&m=1472097616","list_dtime":""},{"pk":"57bd00229490cb7456000022","title":"家常菜 | 一只鸭子的可能性，百变鸭料理","date":"","auther_name":"日日煮DayDayCook","weburl":"http://iphone.myzaker.com/l.php?l=57bd00229490cb7456000022","thumbnail_pic":"http://zkres.myzaker.com/201608/57bcf5da7f52e92443000049_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bcf5da7f52e92443000049_320.jpg","thumbnail_picsize":"865,543","media_count":"21","thumbnail_medias":[{"type":"image","id":"57bcf5da7f52e92443000049","url":"http://zkres.myzaker.com/201608/57bcf5da7f52e92443000049_640.jpg","m_url":"http://zkres.myzaker.com/201608/57bcf5da7f52e92443000049_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57bcf5da7f52e92443000049_640.jpg","w":"865","h":"543"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bd00229490cb7456000022&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bd00229490cb7456000022%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bd00229490cb7456000022&m=1472007027","list_dtime":""},{"pk":"57bcfc0d9490cb9f56000021","title":"家常菜 | 蒜蓉粉丝虾，香甜蒜香清新蒸红虾","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57bcfc0d9490cb9f56000021","thumbnail_pic":"http://zkres.myzaker.com/201608/57bcb60e7f52e97a75000021_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bcb60e7f52e97a75000021_320.jpg","thumbnail_picsize":"805,453","media_count":"17","thumbnail_medias":[{"type":"image","id":"57bcb60e7f52e97a75000021","url":"http://zkres.myzaker.com/201608/57bcb60e7f52e97a75000021_640.jpg","m_url":"http://zkres.myzaker.com/201608/57bcb60e7f52e97a75000021_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57bcb60e7f52e97a75000021_640.jpg","w":"805","h":"453"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bcfc0d9490cb9f56000021&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bcfc0d9490cb9f56000021%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bcfc0d9490cb9f56000021&m=1472097631","list_dtime":""},{"pk":"57bd00229490cb7456000023","title":"食尚西餐 | 蒜头橙香烤鸡，香气撩人，欲罢不能","date":"","auther_name":"日日煮DayDayCook","weburl":"http://iphone.myzaker.com/l.php?l=57bd00229490cb7456000023","thumbnail_pic":"http://zkres.myzaker.com/201608/57b9e3f57f52e9d87200025b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b9e3f57f52e9d87200025b_320.jpg","thumbnail_picsize":"1000,750","media_count":"21","thumbnail_medias":[{"type":"image","id":"57b9e3f57f52e9d87200025b","url":"http://zkres.myzaker.com/201608/57b9e3f57f52e9d87200025b_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b9e3f57f52e9d87200025b_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b9e3f57f52e9d87200025b_640.jpg","w":"1000","h":"750"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bd00229490cb7456000023&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bd00229490cb7456000023%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bd00229490cb7456000023&m=1472006976","list_dtime":""},{"pk":"57ba5a9f9490cb3d22000024","title":"简美一餐 | 泡菜海鲜饼，这一口我想跟你一起吃","date":"","auther_name":"日食记","weburl":"http://iphone.myzaker.com/l.php?l=57ba5a9f9490cb3d22000024","thumbnail_pic":"http://zkres.myzaker.com/201608/57b68c1e7f52e9ab37000020_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b68c1e7f52e9ab37000020_320.jpg","thumbnail_picsize":"1280,854","media_count":"14","thumbnail_medias":[{"type":"image","id":"57b68c1e7f52e9ab37000020","url":"http://zkres.myzaker.com/201608/57b68c1e7f52e9ab37000020_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b68c1e7f52e9ab37000020_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b68c1e7f52e9ab37000020_640.jpg","w":"1280","h":"854"}],"app_ids":"12289","is_full":"NO","content":"","type":"other","special_info":{"open_type":"article_video","video_label":"05:38","video_size":"16,10","show_jingcai":"Y","item_type":"1_v"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57ba5a9f9490cb3d22000024&m=1472451958","list_dtime":""},{"pk":"57bab3319490cb2a2200006a","title":"甜在心 | 史上最简单的意式冰淇淋做法","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57bab3319490cb2a2200006a","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMjE1MV85NDQwN19XNjQwSDMwMFM0NDY3Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMjE1MV85NDQwN19XNjQwSDMwMFM0NDY3Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,300","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMjE1MV85NDQwN19XNjQwSDMwMFM0NDY3Ni5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMjE1MV85NDQwN19XNjQwSDMwMFM0NDY3Ni5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMjE1MV85NDQwN19XNjQwSDMwMFM0NDY3Ni5qcGc=_1242.jpg","w":"640","h":"300"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bab3319490cb2a2200006a&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bab3319490cb2a2200006a%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bab3319490cb2a2200006a&m=1471922184","list_dtime":""},{"pk":"57bab3319490cb2a22000069","title":"家常菜 | 总厨教你做最正宗的上海熏鱼","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57bab3319490cb2a22000069","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMTg5NV85NzA1MF9XNjQwSDMwMFM1MjQ3Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMTg5NV85NzA1MF9XNjQwSDMwMFM1MjQ3Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,300","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMTg5NV85NzA1MF9XNjQwSDMwMFM1MjQ3Mi5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMTg5NV85NzA1MF9XNjQwSDMwMFM1MjQ3Mi5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMTg5NV85NzA1MF9XNjQwSDMwMFM1MjQ3Mi5qcGc=_1242.jpg","w":"640","h":"300"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bab3319490cb2a22000069&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bab3319490cb2a22000069%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bab3319490cb2a22000069&m=1471921921","list_dtime":""},{"pk":"57b6674b9490cb8e41000015","title":"家常菜 | 鸡翅红薯塔吉锅，一锅端的美味","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57b6674b9490cb8e41000015","thumbnail_pic":"http://zkres.myzaker.com/201608/57b5398d7f52e9c8740003f5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b5398d7f52e9c8740003f5_320.jpg","thumbnail_picsize":"1280,960","media_count":"21","thumbnail_medias":[{"type":"image","id":"57b5398d7f52e9c8740003f5","url":"http://zkres.myzaker.com/201608/57b5398d7f52e9c8740003f5_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b5398d7f52e9c8740003f5_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b5398d7f52e9c8740003f5_640.jpg","w":"1280","h":"960"}],"app_ids":"12289","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b6674b9490cb8e41000015&m=1471833046","list_dtime":""},{"pk":"57bab3319490cb2a22000068","title":"家常菜 | 桂花糖藕，餐厅神菜的自制版本","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57bab3319490cb2a22000068","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1NTM4Ml85MDIwOF9XNjQwSDMwMFM0MzE3OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1NTM4Ml85MDIwOF9XNjQwSDMwMFM0MzE3OC5qcGc=_1242.jpg","thumbnail_picsize":"640,300","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1NTM4Ml85MDIwOF9XNjQwSDMwMFM0MzE3OC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1NTM4Ml85MDIwOF9XNjQwSDMwMFM0MzE3OC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1NTM4Ml85MDIwOF9XNjQwSDMwMFM0MzE3OC5qcGc=_1242.jpg","w":"640","h":"300"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bab3319490cb2a22000068&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bab3319490cb2a22000068%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bab3319490cb2a22000068&m=1471855573","list_dtime":""},{"pk":"57b5700d9490cb050d00008e","title":"食尚西餐 | 蒜香黄油西红柿烤法包","date":"","auther_name":"日日煮DayDayCook","weburl":"http://iphone.myzaker.com/l.php?l=57b5700d9490cb050d00008e","thumbnail_pic":"http://zkres.myzaker.com/201608/57b471087f52e96f260003b4_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b471087f52e96f260003b4_320.jpg","thumbnail_picsize":"1280,960","media_count":"20","thumbnail_medias":[{"type":"image","id":"57b471087f52e96f260003b4","url":"http://zkres.myzaker.com/201608/57b471087f52e96f260003b4_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b471087f52e96f260003b4_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b471087f52e96f260003b4_640.jpg","w":"1280","h":"960"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b5700d9490cb050d00008e&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b5700d9490cb050d00008e%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b5700d9490cb050d00008e&m=1471739438","list_dtime":""},{"pk":"57b6fb7f9490cb6f41000061","title":"家常菜 | 蒜头饭酿烧汁鱿鱼筒","date":"","auther_name":"日日煮DayDayCook","weburl":"http://iphone.myzaker.com/l.php?l=57b6fb7f9490cb6f41000061","thumbnail_pic":"http://zkres.myzaker.com/201608/57b6a4377f52e9e91a00017c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b6a4377f52e9e91a00017c_320.jpg","thumbnail_picsize":"1000,750","media_count":"20","thumbnail_medias":[{"type":"image","id":"57b6a4377f52e9e91a00017c","url":"http://zkres.myzaker.com/201608/57b6a4377f52e9e91a00017c_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b6a4377f52e9e91a00017c_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b6a4377f52e9e91a00017c_640.jpg","w":"1000","h":"750"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b6fb7f9490cb6f41000061&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b6fb7f9490cb6f41000061%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b6fb7f9490cb6f41000061&m=1471735729","list_dtime":""},{"pk":"57b2867c9490cbb863000007","title":"家常菜 | 巴西椰香鸡，椰香微辣，热情如火","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57b2867c9490cbb863000007","thumbnail_pic":"http://zkres.myzaker.com/201608/57b12de97f52e9f016000150_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b12de97f52e9f016000150_320.jpg","thumbnail_picsize":"500,284","media_count":"12","thumbnail_medias":[{"type":"image","id":"57b12de97f52e9f016000150","url":"http://zkres.myzaker.com/201608/57b12de97f52e9f016000150_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b12de97f52e9f016000150_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b12de97f52e9f016000150_640.jpg","w":"500","h":"284"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b2867c9490cbb863000007&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b2867c9490cbb863000007%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b2867c9490cbb863000007&m=1471645230","list_dtime":""},{"pk":"57b674b69490cb3f41000036","title":"家常菜 | 清蒸，是对鲈鱼的最高赞礼","date":"","auther_name":"美食杰","weburl":"http://iphone.myzaker.com/l.php?l=57b674b69490cb3f41000036","thumbnail_pic":"http://zkres.myzaker.com/201608/57b674c49490cbae41000019_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b674c49490cbae41000019_320.jpg","thumbnail_picsize":"1280,719","media_count":"12","thumbnail_medias":[{"type":"image","id":"57b674c49490cbae41000019","url":"http://zkres.myzaker.com/201608/57b674c49490cbae41000019_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b674c49490cbae41000019_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b674c49490cbae41000019_640.jpg","w":"1280","h":"719"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b674b69490cb3f41000036&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b674b69490cb3f41000036%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b674b69490cb3f41000036&m=1471575239","list_dtime":""},{"pk":"57b1235b9490cbea36000037","title":"零嘴杂食 | 自己做的猪肉脯，才敢放心大胆地吃","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57b1235b9490cbea36000037","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MTgvdXBfMTQ3MTQ4Nzk5MF81NTM0X1c2NDBIMzAwUzY3MTk5LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MTgvdXBfMTQ3MTQ4Nzk5MF81NTM0X1c2NDBIMzAwUzY3MTk5LmpwZw==_1242.jpg","thumbnail_picsize":"640,300","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MTgvdXBfMTQ3MTQ4Nzk5MF81NTM0X1c2NDBIMzAwUzY3MTk5LmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MTgvdXBfMTQ3MTQ4Nzk5MF81NTM0X1c2NDBIMzAwUzY3MTk5LmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MTgvdXBfMTQ3MTQ4Nzk5MF81NTM0X1c2NDBIMzAwUzY3MTk5LmpwZw==_1242.jpg","w":"640","h":"300"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b1235b9490cbea36000037&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b1235b9490cbea36000037%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b1235b9490cbea36000037&m=1471605269","list_dtime":""},{"pk":"57b51f6b9490cb130d00003c","title":"特产学院 | 云南人告诉你，松茸怎么烧最好吃","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57b51f6b9490cb130d00003c","thumbnail_pic":"http://zkres.myzaker.com/201608/57a6bdf07f52e92021000182_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57a6bdf07f52e92021000182_320.jpg","thumbnail_picsize":"640,427","media_count":"16","thumbnail_medias":[{"type":"image","id":"57a6bdf07f52e92021000182","url":"http://zkres.myzaker.com/201608/57a6bdf07f52e92021000182_640.jpg","m_url":"http://zkres.myzaker.com/201608/57a6bdf07f52e92021000182_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57a6bdf07f52e92021000182_640.jpg","w":"640","h":"427"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b51f6b9490cb130d00003c&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b51f6b9490cb130d00003c%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b51f6b9490cb130d00003c&m=1471488083","list_dtime":""},{"pk":"57b1235b9490cbea36000038","title":"甜在心 | 酥软香脆的炸牛奶是怎么做出来的？","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57b1235b9490cbea36000038","thumbnail_pic":"http://zkres.myzaker.com/201608/57aea26d7f52e94679000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57aea26d7f52e94679000007_320.jpg","thumbnail_picsize":"640,360","media_count":"13","thumbnail_medias":[{"type":"image","id":"57aea26d7f52e94679000007","url":"http://zkres.myzaker.com/201608/57aea26d7f52e94679000007_640.jpg","m_url":"http://zkres.myzaker.com/201608/57aea26d7f52e94679000007_320.jpg","min_url":"http://zkres.myzaker.com/201608/57aea26d7f52e94679000007_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/zumoRrmgk7n9k5iadWMvfP3HQF9pFPUZiaEqXHYdAyLsY9WbjdTxXEhO3DFOj4dXldTRicNIJpf33FrYUjKt1XKMA/640?wx_fmt=jpeg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b1235b9490cbea36000038&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b1235b9490cbea36000038%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b1235b9490cbea36000038&m=1471508205","list_dtime":""},{"pk":"57b3c1c19490cb1e5b00001e","title":"简美一餐 | 天呐！这花甲粉连锅碗都省了","date":"","auther_name":"厨娘物语","weburl":"http://iphone.myzaker.com/l.php?l=57b3c1c19490cb1e5b00001e","thumbnail_pic":"http://zkres.myzaker.com/201608/57a2c9d87f52e9251f000074_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57a2c9d87f52e9251f000074_320.jpg","thumbnail_picsize":"1280,720","media_count":"15","thumbnail_medias":[{"type":"image","id":"57a2c9d87f52e9251f000074","url":"http://zkres.myzaker.com/201608/57a2c9d87f52e9251f000074_640.jpg","m_url":"http://zkres.myzaker.com/201608/57a2c9d87f52e9251f000074_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57a2c9d87f52e9251f000074_640.jpg","w":"1280","h":"720"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b3c1c19490cb1e5b00001e&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b3c1c19490cb1e5b00001e%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b3c1c19490cb1e5b00001e&m=1471487607","list_dtime":""},{"pk":"57b3cfd59490cb7c5b000053","title":"家常菜 | 三款排骨独创做法","date":"","auther_name":"香哈菜谱","weburl":"http://iphone.myzaker.com/l.php?l=57b3cfd59490cb7c5b000053","thumbnail_pic":"http://zkres.myzaker.com/201608/57b407eca07aecba09041727_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b407eca07aecba09041727_320.jpg","thumbnail_picsize":"250,188","media_count":"21","thumbnail_medias":[{"type":"image","id":"57b407eca07aecba09041722","url":"http://zkres.myzaker.com/201608/57b407eca07aecba09041722_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b407eca07aecba09041722_320.jpg","min_url":"http://zkres.myzaker.com/201608/57b407eca07aecba09041722_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/QsKLg00DzvteTbz1I7CBbNu45vibAyVT6a1UrbYKOdNNqiccUqUiaVrVaGGvHA7dn417rNMRSBviccXOCibLDMicB4cw/0?wx_fmt=jpeg","w":"250","h":"250"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b3cfd59490cb7c5b000053&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b3cfd59490cb7c5b000053%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b3cfd59490cb7c5b000053&m=1471416788","list_dtime":""},{"pk":"57b3c1c19490cb1e5b00001d","title":"家常菜 | 罐头凉菜的3+2种有爱吃法","date":"","auther_name":"厨娘物语","weburl":"http://iphone.myzaker.com/l.php?l=57b3c1c19490cb1e5b00001d","thumbnail_pic":"http://zkres.myzaker.com/201608/57ad66d47f52e9b53c000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57ad66d47f52e9b53c000011_320.jpg","thumbnail_picsize":"1280,718","media_count":"35","thumbnail_medias":[{"type":"image","id":"57ad66d47f52e9b53c000011","url":"http://zkres.myzaker.com/201608/57ad66d47f52e9b53c000011_640.jpg","m_url":"http://zkres.myzaker.com/201608/57ad66d47f52e9b53c000011_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57ad66d47f52e9b53c000011_640.jpg","w":"1280","h":"718"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b3c1c19490cb1e5b00001d&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b3c1c19490cb1e5b00001d%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b3c1c19490cb1e5b00001d&m=1471400793","list_dtime":""}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c4e7c49490cba013000024,57c7d83a9490cb902c000074,57c78fb09490cba02c000037,57c6376a9490cb194b000011,57c4e5f19490cb8713000010,57bff3ca9490cb4960000056","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c4e2f09490cb531300002e,57c4e7c49490cba013000028,57c3971b9490cb287300000d,57c392329490cbfc7200003c,57c17a619490cb1e3b000086,57c0100e9490cb736000005b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57bd00229490cb7456000021,57c014679490cb9860000062,57ba63b79490cb272200002b,57bcfc0d9490cb9f56000022,57bff3ca9490cb4960000054,57ba63b69490cb272200002a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57bd00229490cb7456000022,57bcfc0d9490cb9f56000021,57bd00229490cb7456000023,57ba5a9f9490cb3d22000024,57bab3319490cb2a2200006a,57bab3319490cb2a22000069","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57b6674b9490cb8e41000015,57bab3319490cb2a22000068,57b5700d9490cb050d00008e,57b6fb7f9490cb6f41000061,57b2867c9490cbb863000007,57b674b69490cb3f41000036","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57b1235b9490cbea36000037,57b51f6b9490cb130d00003c,57b1235b9490cbea36000038,57b3c1c19490cb1e5b00001e,57b3cfd59490cb7c5b000053,57b3c1c19490cb1e5b00001d","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}}],"article_block_colors":["#ff6f6f","#ff6f6f"],"only_text_page_bgcolors":["#ff6f6f","#ff6f6f"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12289.png?t=1467082733","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12289.png?t=1467082733","hidden_time":"24","need_userinfo":"NO","block_title":"美食视频","data_type":"rss","article_list_type":"rss","block_color":"#ff6f6f","desktop_color_number":"8","use_original_icon":"N"},"top_tab_info_url":"http://iphone.myzaker.com/zaker/top_tab_info.php?app_id=12289&full_arg=_appid,_v,_version,_lbs_city","show_type":"top_tab"}
     */

    private String stat;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=12289&since_date=1471400792&nt=1&_appid=androidphone&top_tab_id=10386","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=12289&need_app_integration=1","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12289&ids=54f40b639490cb12100000da&k=201609011740"}
     * catalog :
     * articles : [{"pk":"57c4e7c49490cba013000024","title":"食尚西餐 | 焗烤扇贝佐菠菜","date":"","auther_name":"饭合","weburl":"http://iphone.myzaker.com/l.php?l=57c4e7c49490cba013000024","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"20","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c4e7c49490cba013000024&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c4e7c49490cba013000024%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c4e7c49490cba013000024&m=1472698368","list_dtime":""},{"pk":"57c7d83a9490cb902c000074","title":"家常菜 | 番茄蘑菇炖鲳鱼，这味道酸爽！","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57c7d83a9490cb902c000074","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNDg3OV8yNzkyMl9XNjQwSDM2MFM1MTU3OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNDg3OV8yNzkyMl9XNjQwSDM2MFM1MTU3OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNDg3OV8yNzkyMl9XNjQwSDM2MFM1MTU3OC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNDg3OV8yNzkyMl9XNjQwSDM2MFM1MTU3OC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNDg3OV8yNzkyMl9XNjQwSDM2MFM1MTU3OC5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c7d83a9490cb902c000074&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c7d83a9490cb902c000074%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c7d83a9490cb902c000074&m=1472714882","list_dtime":""},{"pk":"57c78fb09490cba02c000037","title":"简美一餐 | 一碗饭搞定处女座的味噌牛肉饭","date":"","auther_name":"日日煮DayDayCook","weburl":"http://iphone.myzaker.com/l.php?l=57c78fb09490cba02c000037","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1Y2FiYjdmNTJlOTI3NWUwMDAxZjZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1Y2FiYjdmNTJlOTI3NWUwMDAxZjZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"400,225","media_count":"21","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1Y2FiYjdmNTJlOTI3NWUwMDAxZjZfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1Y2FiYjdmNTJlOTI3NWUwMDAxZjZfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1Y2FiYjdmNTJlOTI3NWUwMDAxZjZfNjQwLmpwZw==_1242.jpg","w":"400","h":"225"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c78fb09490cba02c000037&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c78fb09490cba02c000037%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c78fb09490cba02c000037&m=1472698243","list_dtime":""},{"pk":"57c6376a9490cb194b000011","title":"家常菜 | 猪蹄太油腻怎么办？凉拌！","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57c6376a9490cb194b000011","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwODI3NV84MjY0NV9XNjQwSDM2MFM1MDk0Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwODI3NV84MjY0NV9XNjQwSDM2MFM1MDk0Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwODI3NV84MjY0NV9XNjQwSDM2MFM1MDk0Ni5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwODI3NV84MjY0NV9XNjQwSDM2MFM1MDk0Ni5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwODI3NV84MjY0NV9XNjQwSDM2MFM1MDk0Ni5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c6376a9490cb194b000011&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c6376a9490cb194b000011%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c6376a9490cb194b000011&m=1472625395","list_dtime":""},{"pk":"57c4e5f19490cb8713000010","title":"零嘴杂食 | 芝士的3+1种有爱吃法","date":"","auther_name":"厨娘物语","weburl":"http://iphone.myzaker.com/l.php?l=57c4e5f19490cb8713000010","thumbnail_pic":"http://zkres.myzaker.com/201608/57beca3e7f52e94f3b000250_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57beca3e7f52e94f3b000250_320.jpg","thumbnail_picsize":"350,197","media_count":"37","thumbnail_medias":[{"type":"image","id":"57beca3e7f52e94f3b000250","url":"http://zkres.myzaker.com/201608/57beca3e7f52e94f3b000250_640.jpg","m_url":"http://zkres.myzaker.com/201608/57beca3e7f52e94f3b000250_320.jpg","min_url":"http://zkres.myzaker.com/201608/57beca3e7f52e94f3b000250_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_gif/rf6wRw7ib1R1ytDUzcjPMCy5uzXQgABle7xNEwiboibfbGu5VjqcozKEuNk5eBHz78y8ENxvXxtAn7mqu2iadXpicOg/0?wx_fmt=gif","w":"350","h":"197","gif_url":"http://zkres.myzaker.com/201608/57beca3e7f52e94f3b000250_raw.gif"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c4e5f19490cb8713000010&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c4e5f19490cb8713000010%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c4e5f19490cb8713000010&m=1472607980","list_dtime":""},{"pk":"57bff3ca9490cb4960000056","title":"家常菜 | 酸梅蒸排骨：猪肉怎么吃都不腻","title_line_break":"家常菜 | 酸梅蒸排骨：\n猪肉怎么吃都不腻","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57bff3ca9490cb4960000056","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwNzg3M180MTc3Nl9XNjQwSDM2MFM1MzAwOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwNzg3M180MTc3Nl9XNjQwSDM2MFM1MzAwOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwNzg3M180MTc3Nl9XNjQwSDM2MFM1MzAwOC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwNzg3M180MTc3Nl9XNjQwSDM2MFM1MzAwOC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwNzg3M180MTc3Nl9XNjQwSDM2MFM1MzAwOC5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bff3ca9490cb4960000056&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bff3ca9490cb4960000056%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bff3ca9490cb4960000056&m=1472607928","list_dtime":""},{"pk":"57c4e2f09490cb531300002e","title":"甜在心 | 3分钟学会做黑白巧克力慕斯","date":"","auther_name":"贝太厨房","weburl":"http://iphone.myzaker.com/l.php?l=57c4e2f09490cb531300002e","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjk0NjdmNTJlOWJiMDkwMDAyNzhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjk0NjdmNTJlOWJiMDkwMDAyNzhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,362","media_count":"20","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjk0NjdmNTJlOWJiMDkwMDAyNzhfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjk0NjdmNTJlOWJiMDkwMDAyNzhfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjk0NjdmNTJlOWJiMDkwMDAyNzhfNjQwLmpwZw==_1242.jpg","w":"640","h":"362"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c4e2f09490cb531300002e&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c4e2f09490cb531300002e%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c4e2f09490cb531300002e&m=1472521003","list_dtime":""},{"pk":"57c4e7c49490cba013000028","title":"开眼 | 帝王蟹你真的吃对了么？","date":"","auther_name":"饭合","weburl":"http://iphone.myzaker.com/l.php?l=57c4e7c49490cba013000028","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2FlMTIyNTdmNTJlOWE0MmYwMDAzMDhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2FlMTIyNTdmNTJlOWE0MmYwMDAzMDhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"13","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2FlMTIyNTdmNTJlOWE0MmYwMDAzMDhfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2FlMTIyNTdmNTJlOWE0MmYwMDAzMDhfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2FlMTIyNTdmNTJlOWE0MmYwMDAzMDhfNjQwLmpwZw==_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c4e7c49490cba013000028&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c4e7c49490cba013000028%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c4e7c49490cba013000028&m=1472607631","list_dtime":""},{"pk":"57c3971b9490cb287300000d","title":"开眼 | 寿司制作的精妙美学，看着就是种享受","date":"","auther_name":"豆果美食","weburl":"http://iphone.myzaker.com/l.php?l=57c3971b9490cb287300000d","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTE0MV8yMTA0Nl9XNjQwSDM2MFM3NzUyNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTE0MV8yMTA0Nl9XNjQwSDM2MFM3NzUyNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTE0MV8yMTA0Nl9XNjQwSDM2MFM3NzUyNC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTE0MV8yMTA0Nl9XNjQwSDM2MFM3NzUyNC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTE0MV8yMTA0Nl9XNjQwSDM2MFM3NzUyNC5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c3971b9490cb287300000d&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c3971b9490cb287300000d%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c3971b9490cb287300000d&m=1472443031","list_dtime":""},{"pk":"57c392329490cbfc7200003c","title":"家常菜 | 家常小海鲜这么做，零失败！","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57c392329490cbfc7200003c","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTA2NV8yMzk5X1c2NDBIMzYwUzUxNTM3LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTA2NV8yMzk5X1c2NDBIMzYwUzUxNTM3LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTA2NV8yMzk5X1c2NDBIMzYwUzUxNTM3LmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTA2NV8yMzk5X1c2NDBIMzYwUzUxNTM3LmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjkvdXBfMTQ3MjQ0MTA2NV8yMzk5X1c2NDBIMzYwUzUxNTM3LmpwZw==_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"other","special_info":{"open_type":"article_video","video_label":"02:15","video_size":"16,10","show_jingcai":"Y","item_type":"1_v"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c392329490cbfc7200003c&m=1472452037","list_dtime":""},{"pk":"57c17a619490cb1e3b000086","title":"零嘴杂食 | 半半炸鸡，你要原味or甜辣味？","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57c17a619490cb1e3b000086","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmZDUyODdmNTJlOTY5MTYwMDBkMTVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmZDUyODdmNTJlOTY5MTYwMDBkMTVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"16","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmZDUyODdmNTJlOTY5MTYwMDBkMTVfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmZDUyODdmNTJlOTY5MTYwMDBkMTVfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmZDUyODdmNTJlOTY5MTYwMDBkMTVfNjQwLmpwZw==_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c17a619490cb1e3b000086&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c17a619490cb1e3b000086%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c17a619490cb1e3b000086&m=1472440821","list_dtime":""},{"pk":"57c0100e9490cb736000005b","title":"简美一餐 | 一碗 酸辣粉，辣得欲罢不能！","date":"","auther_name":"日食记","weburl":"http://iphone.myzaker.com/l.php?l=57c0100e9490cb736000005b","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmYzU0NjdmNTJlOTY5MTYwMDAzMjRfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmYzU0NjdmNTJlOTY5MTYwMDAzMjRfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"370,209","media_count":"14","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmYzU0NjdmNTJlOTY5MTYwMDAzMjRfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmYzU0NjdmNTJlOTY5MTYwMDAzMjRfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JmYzU0NjdmNTJlOTY5MTYwMDAzMjRfNjQwLmpwZw==_1242.jpg","w":"370","h":"209"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c0100e9490cb736000005b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c0100e9490cb736000005b%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c0100e9490cb736000005b&m=1472366819","list_dtime":""},{"pk":"57bd00229490cb7456000021","title":"简美一餐 | 这可不是寿司，荞麦面卷着吃","date":"","auther_name":"日日煮DayDayCook","weburl":"http://iphone.myzaker.com/l.php?l=57bd00229490cb7456000021","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjZjVkYjdmNTJlOTRjMzMwMDAwM2JfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjZjVkYjdmNTJlOTRjMzMwMDAwM2JfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"23","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjZjVkYjdmNTJlOTRjMzMwMDAwM2JfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjZjVkYjdmNTJlOTRjMzMwMDAwM2JfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjZjVkYjdmNTJlOTRjMzMwMDAwM2JfNjQwLmpwZw==_1242.jpg","w":"640","h":"427"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bd00229490cb7456000021&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bd00229490cb7456000021%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bd00229490cb7456000021&m=1472263331","list_dtime":""},{"pk":"57c014679490cb9860000062","title":"微醺之美 | 4款夏日豆浆新做法","date":"","auther_name":"美食杰","weburl":"http://iphone.myzaker.com/l.php?l=57c014679490cb9860000062","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MwMTQ2ZGEwN2FlY2Y3N2UwMTAwZTRfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MwMTQ2ZGEwN2FlY2Y3N2UwMTAwZTRfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,357","media_count":"10","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MwMTQ2ZGEwN2FlY2Y3N2UwMTAwZTRfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MwMTQ2ZGEwN2FlY2Y3N2UwMTAwZTRfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MwMTQ2ZGEwN2FlY2Y3N2UwMTAwZTRfNjQwLmpwZw==_1242.jpg","w":"640","h":"357"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c014679490cb9860000062&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c014679490cb9860000062%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c014679490cb9860000062&m=1472342694","list_dtime":""},{"pk":"57ba63b79490cb272200002b","title":"零嘴杂食 | 进阶版韩国芝士鸡蛋卷","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57ba63b79490cb272200002b","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2I2YWNmODdmNTJlOWVmMWEwMDAyODZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2I2YWNmODdmNTJlOWVmMWEwMDAyODZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,361","media_count":"13","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2I2YWNmODdmNTJlOWVmMWEwMDAyODZfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2I2YWNmODdmNTJlOWVmMWEwMDAyODZfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2I2YWNmODdmNTJlOWVmMWEwMDAyODZfNjQwLmpwZw==_1242.jpg","w":"640","h":"361"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57ba63b79490cb272200002b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57ba63b79490cb272200002b%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57ba63b79490cb272200002b&m=1472204651","list_dtime":""},{"pk":"57bcfc0d9490cb9f56000022","title":"甜在心丨水果和蔬菜的完美牵手","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57bcfc0d9490cb9f56000022","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JhNzViNzdmNTJlOTExNWIwMDAwNjdfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JhNzViNzdmNTJlOTExNWIwMDAwNjdfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,284","media_count":"25","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JhNzViNzdmNTJlOTExNWIwMDAwNjdfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JhNzViNzdmNTJlOTExNWIwMDAwNjdfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JhNzViNzdmNTJlOTExNWIwMDAwNjdfNjQwLmpwZw==_1242.jpg","w":"500","h":"284"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bcfc0d9490cb9f56000022&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bcfc0d9490cb9f56000022%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bcfc0d9490cb9f56000022&m=1472198819","list_dtime":""},{"pk":"57bff3ca9490cb4960000054","title":"简美一餐 | 如何制作日式冷面","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57bff3ca9490cb4960000054","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE5ODcwM185ODQ2NF9XNjQwSDM2MFM3MTIzOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE5ODcwM185ODQ2NF9XNjQwSDM2MFM3MTIzOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE5ODcwM185ODQ2NF9XNjQwSDM2MFM3MTIzOC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE5ODcwM185ODQ2NF9XNjQwSDM2MFM3MTIzOC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjE5ODcwM185ODQ2NF9XNjQwSDM2MFM3MTIzOC5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bff3ca9490cb4960000054&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bff3ca9490cb4960000054%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bff3ca9490cb4960000054&m=1472198709","list_dtime":""},{"pk":"57ba63b69490cb272200002a","title":"家常菜 | 牛尾猪手，强强联手的美味！","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57ba63b69490cb272200002a","thumbnail_pic":"http://zkres.myzaker.com/201608/57b7c9e57f52e9a83c0001a7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b7c9e57f52e9a83c0001a7_320.jpg","thumbnail_picsize":"500,284","media_count":"13","thumbnail_medias":[{"type":"image","id":"57b7c9e57f52e9a83c0001a7","url":"http://zkres.myzaker.com/201608/57b7c9e57f52e9a83c0001a7_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b7c9e57f52e9a83c0001a7_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b7c9e57f52e9a83c0001a7_640.jpg","w":"500","h":"284"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57ba63b69490cb272200002a&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57ba63b69490cb272200002a%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57ba63b69490cb272200002a&m=1472097616","list_dtime":""},{"pk":"57bd00229490cb7456000022","title":"家常菜 | 一只鸭子的可能性，百变鸭料理","date":"","auther_name":"日日煮DayDayCook","weburl":"http://iphone.myzaker.com/l.php?l=57bd00229490cb7456000022","thumbnail_pic":"http://zkres.myzaker.com/201608/57bcf5da7f52e92443000049_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bcf5da7f52e92443000049_320.jpg","thumbnail_picsize":"865,543","media_count":"21","thumbnail_medias":[{"type":"image","id":"57bcf5da7f52e92443000049","url":"http://zkres.myzaker.com/201608/57bcf5da7f52e92443000049_640.jpg","m_url":"http://zkres.myzaker.com/201608/57bcf5da7f52e92443000049_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57bcf5da7f52e92443000049_640.jpg","w":"865","h":"543"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bd00229490cb7456000022&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bd00229490cb7456000022%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bd00229490cb7456000022&m=1472007027","list_dtime":""},{"pk":"57bcfc0d9490cb9f56000021","title":"家常菜 | 蒜蓉粉丝虾，香甜蒜香清新蒸红虾","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57bcfc0d9490cb9f56000021","thumbnail_pic":"http://zkres.myzaker.com/201608/57bcb60e7f52e97a75000021_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bcb60e7f52e97a75000021_320.jpg","thumbnail_picsize":"805,453","media_count":"17","thumbnail_medias":[{"type":"image","id":"57bcb60e7f52e97a75000021","url":"http://zkres.myzaker.com/201608/57bcb60e7f52e97a75000021_640.jpg","m_url":"http://zkres.myzaker.com/201608/57bcb60e7f52e97a75000021_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57bcb60e7f52e97a75000021_640.jpg","w":"805","h":"453"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bcfc0d9490cb9f56000021&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bcfc0d9490cb9f56000021%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bcfc0d9490cb9f56000021&m=1472097631","list_dtime":""},{"pk":"57bd00229490cb7456000023","title":"食尚西餐 | 蒜头橙香烤鸡，香气撩人，欲罢不能","date":"","auther_name":"日日煮DayDayCook","weburl":"http://iphone.myzaker.com/l.php?l=57bd00229490cb7456000023","thumbnail_pic":"http://zkres.myzaker.com/201608/57b9e3f57f52e9d87200025b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b9e3f57f52e9d87200025b_320.jpg","thumbnail_picsize":"1000,750","media_count":"21","thumbnail_medias":[{"type":"image","id":"57b9e3f57f52e9d87200025b","url":"http://zkres.myzaker.com/201608/57b9e3f57f52e9d87200025b_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b9e3f57f52e9d87200025b_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b9e3f57f52e9d87200025b_640.jpg","w":"1000","h":"750"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bd00229490cb7456000023&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bd00229490cb7456000023%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bd00229490cb7456000023&m=1472006976","list_dtime":""},{"pk":"57ba5a9f9490cb3d22000024","title":"简美一餐 | 泡菜海鲜饼，这一口我想跟你一起吃","date":"","auther_name":"日食记","weburl":"http://iphone.myzaker.com/l.php?l=57ba5a9f9490cb3d22000024","thumbnail_pic":"http://zkres.myzaker.com/201608/57b68c1e7f52e9ab37000020_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b68c1e7f52e9ab37000020_320.jpg","thumbnail_picsize":"1280,854","media_count":"14","thumbnail_medias":[{"type":"image","id":"57b68c1e7f52e9ab37000020","url":"http://zkres.myzaker.com/201608/57b68c1e7f52e9ab37000020_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b68c1e7f52e9ab37000020_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b68c1e7f52e9ab37000020_640.jpg","w":"1280","h":"854"}],"app_ids":"12289","is_full":"NO","content":"","type":"other","special_info":{"open_type":"article_video","video_label":"05:38","video_size":"16,10","show_jingcai":"Y","item_type":"1_v"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57ba5a9f9490cb3d22000024&m=1472451958","list_dtime":""},{"pk":"57bab3319490cb2a2200006a","title":"甜在心 | 史上最简单的意式冰淇淋做法","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57bab3319490cb2a2200006a","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMjE1MV85NDQwN19XNjQwSDMwMFM0NDY3Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMjE1MV85NDQwN19XNjQwSDMwMFM0NDY3Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,300","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMjE1MV85NDQwN19XNjQwSDMwMFM0NDY3Ni5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMjE1MV85NDQwN19XNjQwSDMwMFM0NDY3Ni5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMjE1MV85NDQwN19XNjQwSDMwMFM0NDY3Ni5qcGc=_1242.jpg","w":"640","h":"300"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bab3319490cb2a2200006a&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bab3319490cb2a2200006a%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bab3319490cb2a2200006a&m=1471922184","list_dtime":""},{"pk":"57bab3319490cb2a22000069","title":"家常菜 | 总厨教你做最正宗的上海熏鱼","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57bab3319490cb2a22000069","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMTg5NV85NzA1MF9XNjQwSDMwMFM1MjQ3Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMTg5NV85NzA1MF9XNjQwSDMwMFM1MjQ3Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,300","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMTg5NV85NzA1MF9XNjQwSDMwMFM1MjQ3Mi5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMTg5NV85NzA1MF9XNjQwSDMwMFM1MjQ3Mi5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjMvdXBfMTQ3MTkyMTg5NV85NzA1MF9XNjQwSDMwMFM1MjQ3Mi5qcGc=_1242.jpg","w":"640","h":"300"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bab3319490cb2a22000069&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bab3319490cb2a22000069%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bab3319490cb2a22000069&m=1471921921","list_dtime":""},{"pk":"57b6674b9490cb8e41000015","title":"家常菜 | 鸡翅红薯塔吉锅，一锅端的美味","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57b6674b9490cb8e41000015","thumbnail_pic":"http://zkres.myzaker.com/201608/57b5398d7f52e9c8740003f5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b5398d7f52e9c8740003f5_320.jpg","thumbnail_picsize":"1280,960","media_count":"21","thumbnail_medias":[{"type":"image","id":"57b5398d7f52e9c8740003f5","url":"http://zkres.myzaker.com/201608/57b5398d7f52e9c8740003f5_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b5398d7f52e9c8740003f5_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b5398d7f52e9c8740003f5_640.jpg","w":"1280","h":"960"}],"app_ids":"12289","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b6674b9490cb8e41000015&m=1471833046","list_dtime":""},{"pk":"57bab3319490cb2a22000068","title":"家常菜 | 桂花糖藕，餐厅神菜的自制版本","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57bab3319490cb2a22000068","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1NTM4Ml85MDIwOF9XNjQwSDMwMFM0MzE3OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1NTM4Ml85MDIwOF9XNjQwSDMwMFM0MzE3OC5qcGc=_1242.jpg","thumbnail_picsize":"640,300","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1NTM4Ml85MDIwOF9XNjQwSDMwMFM0MzE3OC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1NTM4Ml85MDIwOF9XNjQwSDMwMFM0MzE3OC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjIvdXBfMTQ3MTg1NTM4Ml85MDIwOF9XNjQwSDMwMFM0MzE3OC5qcGc=_1242.jpg","w":"640","h":"300"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57bab3319490cb2a22000068&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57bab3319490cb2a22000068%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57bab3319490cb2a22000068&m=1471855573","list_dtime":""},{"pk":"57b5700d9490cb050d00008e","title":"食尚西餐 | 蒜香黄油西红柿烤法包","date":"","auther_name":"日日煮DayDayCook","weburl":"http://iphone.myzaker.com/l.php?l=57b5700d9490cb050d00008e","thumbnail_pic":"http://zkres.myzaker.com/201608/57b471087f52e96f260003b4_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b471087f52e96f260003b4_320.jpg","thumbnail_picsize":"1280,960","media_count":"20","thumbnail_medias":[{"type":"image","id":"57b471087f52e96f260003b4","url":"http://zkres.myzaker.com/201608/57b471087f52e96f260003b4_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b471087f52e96f260003b4_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b471087f52e96f260003b4_640.jpg","w":"1280","h":"960"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b5700d9490cb050d00008e&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b5700d9490cb050d00008e%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b5700d9490cb050d00008e&m=1471739438","list_dtime":""},{"pk":"57b6fb7f9490cb6f41000061","title":"家常菜 | 蒜头饭酿烧汁鱿鱼筒","date":"","auther_name":"日日煮DayDayCook","weburl":"http://iphone.myzaker.com/l.php?l=57b6fb7f9490cb6f41000061","thumbnail_pic":"http://zkres.myzaker.com/201608/57b6a4377f52e9e91a00017c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b6a4377f52e9e91a00017c_320.jpg","thumbnail_picsize":"1000,750","media_count":"20","thumbnail_medias":[{"type":"image","id":"57b6a4377f52e9e91a00017c","url":"http://zkres.myzaker.com/201608/57b6a4377f52e9e91a00017c_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b6a4377f52e9e91a00017c_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b6a4377f52e9e91a00017c_640.jpg","w":"1000","h":"750"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b6fb7f9490cb6f41000061&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b6fb7f9490cb6f41000061%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b6fb7f9490cb6f41000061&m=1471735729","list_dtime":""},{"pk":"57b2867c9490cbb863000007","title":"家常菜 | 巴西椰香鸡，椰香微辣，热情如火","date":"","auther_name":"微体社区","weburl":"http://iphone.myzaker.com/l.php?l=57b2867c9490cbb863000007","thumbnail_pic":"http://zkres.myzaker.com/201608/57b12de97f52e9f016000150_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b12de97f52e9f016000150_320.jpg","thumbnail_picsize":"500,284","media_count":"12","thumbnail_medias":[{"type":"image","id":"57b12de97f52e9f016000150","url":"http://zkres.myzaker.com/201608/57b12de97f52e9f016000150_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b12de97f52e9f016000150_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b12de97f52e9f016000150_640.jpg","w":"500","h":"284"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b2867c9490cbb863000007&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b2867c9490cbb863000007%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b2867c9490cbb863000007&m=1471645230","list_dtime":""},{"pk":"57b674b69490cb3f41000036","title":"家常菜 | 清蒸，是对鲈鱼的最高赞礼","date":"","auther_name":"美食杰","weburl":"http://iphone.myzaker.com/l.php?l=57b674b69490cb3f41000036","thumbnail_pic":"http://zkres.myzaker.com/201608/57b674c49490cbae41000019_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b674c49490cbae41000019_320.jpg","thumbnail_picsize":"1280,719","media_count":"12","thumbnail_medias":[{"type":"image","id":"57b674c49490cbae41000019","url":"http://zkres.myzaker.com/201608/57b674c49490cbae41000019_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b674c49490cbae41000019_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57b674c49490cbae41000019_640.jpg","w":"1280","h":"719"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b674b69490cb3f41000036&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b674b69490cb3f41000036%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b674b69490cb3f41000036&m=1471575239","list_dtime":""},{"pk":"57b1235b9490cbea36000037","title":"零嘴杂食 | 自己做的猪肉脯，才敢放心大胆地吃","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57b1235b9490cbea36000037","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MTgvdXBfMTQ3MTQ4Nzk5MF81NTM0X1c2NDBIMzAwUzY3MTk5LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MTgvdXBfMTQ3MTQ4Nzk5MF81NTM0X1c2NDBIMzAwUzY3MTk5LmpwZw==_1242.jpg","thumbnail_picsize":"640,300","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MTgvdXBfMTQ3MTQ4Nzk5MF81NTM0X1c2NDBIMzAwUzY3MTk5LmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MTgvdXBfMTQ3MTQ4Nzk5MF81NTM0X1c2NDBIMzAwUzY3MTk5LmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MTgvdXBfMTQ3MTQ4Nzk5MF81NTM0X1c2NDBIMzAwUzY3MTk5LmpwZw==_1242.jpg","w":"640","h":"300"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b1235b9490cbea36000037&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b1235b9490cbea36000037%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b1235b9490cbea36000037&m=1471605269","list_dtime":""},{"pk":"57b51f6b9490cb130d00003c","title":"特产学院 | 云南人告诉你，松茸怎么烧最好吃","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57b51f6b9490cb130d00003c","thumbnail_pic":"http://zkres.myzaker.com/201608/57a6bdf07f52e92021000182_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57a6bdf07f52e92021000182_320.jpg","thumbnail_picsize":"640,427","media_count":"16","thumbnail_medias":[{"type":"image","id":"57a6bdf07f52e92021000182","url":"http://zkres.myzaker.com/201608/57a6bdf07f52e92021000182_640.jpg","m_url":"http://zkres.myzaker.com/201608/57a6bdf07f52e92021000182_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57a6bdf07f52e92021000182_640.jpg","w":"640","h":"427"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b51f6b9490cb130d00003c&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b51f6b9490cb130d00003c%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b51f6b9490cb130d00003c&m=1471488083","list_dtime":""},{"pk":"57b1235b9490cbea36000038","title":"甜在心 | 酥软香脆的炸牛奶是怎么做出来的？","date":"","auther_name":"美食台","weburl":"http://iphone.myzaker.com/l.php?l=57b1235b9490cbea36000038","thumbnail_pic":"http://zkres.myzaker.com/201608/57aea26d7f52e94679000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57aea26d7f52e94679000007_320.jpg","thumbnail_picsize":"640,360","media_count":"13","thumbnail_medias":[{"type":"image","id":"57aea26d7f52e94679000007","url":"http://zkres.myzaker.com/201608/57aea26d7f52e94679000007_640.jpg","m_url":"http://zkres.myzaker.com/201608/57aea26d7f52e94679000007_320.jpg","min_url":"http://zkres.myzaker.com/201608/57aea26d7f52e94679000007_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/zumoRrmgk7n9k5iadWMvfP3HQF9pFPUZiaEqXHYdAyLsY9WbjdTxXEhO3DFOj4dXldTRicNIJpf33FrYUjKt1XKMA/640?wx_fmt=jpeg","w":"640","h":"360"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b1235b9490cbea36000038&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b1235b9490cbea36000038%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b1235b9490cbea36000038&m=1471508205","list_dtime":""},{"pk":"57b3c1c19490cb1e5b00001e","title":"简美一餐 | 天呐！这花甲粉连锅碗都省了","date":"","auther_name":"厨娘物语","weburl":"http://iphone.myzaker.com/l.php?l=57b3c1c19490cb1e5b00001e","thumbnail_pic":"http://zkres.myzaker.com/201608/57a2c9d87f52e9251f000074_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57a2c9d87f52e9251f000074_320.jpg","thumbnail_picsize":"1280,720","media_count":"15","thumbnail_medias":[{"type":"image","id":"57a2c9d87f52e9251f000074","url":"http://zkres.myzaker.com/201608/57a2c9d87f52e9251f000074_640.jpg","m_url":"http://zkres.myzaker.com/201608/57a2c9d87f52e9251f000074_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57a2c9d87f52e9251f000074_640.jpg","w":"1280","h":"720"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b3c1c19490cb1e5b00001e&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b3c1c19490cb1e5b00001e%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b3c1c19490cb1e5b00001e&m=1471487607","list_dtime":""},{"pk":"57b3cfd59490cb7c5b000053","title":"家常菜 | 三款排骨独创做法","date":"","auther_name":"香哈菜谱","weburl":"http://iphone.myzaker.com/l.php?l=57b3cfd59490cb7c5b000053","thumbnail_pic":"http://zkres.myzaker.com/201608/57b407eca07aecba09041727_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b407eca07aecba09041727_320.jpg","thumbnail_picsize":"250,188","media_count":"21","thumbnail_medias":[{"type":"image","id":"57b407eca07aecba09041722","url":"http://zkres.myzaker.com/201608/57b407eca07aecba09041722_640.jpg","m_url":"http://zkres.myzaker.com/201608/57b407eca07aecba09041722_320.jpg","min_url":"http://zkres.myzaker.com/201608/57b407eca07aecba09041722_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/QsKLg00DzvteTbz1I7CBbNu45vibAyVT6a1UrbYKOdNNqiccUqUiaVrVaGGvHA7dn417rNMRSBviccXOCibLDMicB4cw/0?wx_fmt=jpeg","w":"250","h":"250"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b3cfd59490cb7c5b000053&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b3cfd59490cb7c5b000053%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b3cfd59490cb7c5b000053&m=1471416788","list_dtime":""},{"pk":"57b3c1c19490cb1e5b00001d","title":"家常菜 | 罐头凉菜的3+2种有爱吃法","date":"","auther_name":"厨娘物语","weburl":"http://iphone.myzaker.com/l.php?l=57b3c1c19490cb1e5b00001d","thumbnail_pic":"http://zkres.myzaker.com/201608/57ad66d47f52e9b53c000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57ad66d47f52e9b53c000011_320.jpg","thumbnail_picsize":"1280,718","media_count":"35","thumbnail_medias":[{"type":"image","id":"57ad66d47f52e9b53c000011","url":"http://zkres.myzaker.com/201608/57ad66d47f52e9b53c000011_640.jpg","m_url":"http://zkres.myzaker.com/201608/57ad66d47f52e9b53c000011_320.jpg","raw_url":"http://zkres.myzaker.com/201608/57ad66d47f52e9b53c000011_640.jpg","w":"1280","h":"718"}],"app_ids":"12289","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57b3c1c19490cb1e5b00001d&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57b3c1c19490cb1e5b00001d%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57b3c1c19490cb1e5b00001d&m=1471400793","list_dtime":""}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c4e7c49490cba013000024,57c7d83a9490cb902c000074,57c78fb09490cba02c000037,57c6376a9490cb194b000011,57c4e5f19490cb8713000010,57bff3ca9490cb4960000056","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c4e2f09490cb531300002e,57c4e7c49490cba013000028,57c3971b9490cb287300000d,57c392329490cbfc7200003c,57c17a619490cb1e3b000086,57c0100e9490cb736000005b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57bd00229490cb7456000021,57c014679490cb9860000062,57ba63b79490cb272200002b,57bcfc0d9490cb9f56000022,57bff3ca9490cb4960000054,57ba63b69490cb272200002a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57bd00229490cb7456000022,57bcfc0d9490cb9f56000021,57bd00229490cb7456000023,57ba5a9f9490cb3d22000024,57bab3319490cb2a2200006a,57bab3319490cb2a22000069","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57b6674b9490cb8e41000015,57bab3319490cb2a22000068,57b5700d9490cb050d00008e,57b6fb7f9490cb6f41000061,57b2867c9490cbb863000007,57b674b69490cb3f41000036","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57b1235b9490cbea36000037,57b51f6b9490cb130d00003c,57b1235b9490cbea36000038,57b3c1c19490cb1e5b00001e,57b3cfd59490cb7c5b000053,57b3c1c19490cb1e5b00001d","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}}],"article_block_colors":["#ff6f6f","#ff6f6f"],"only_text_page_bgcolors":["#ff6f6f","#ff6f6f"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12289.png?t=1467082733","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12289.png?t=1467082733","hidden_time":"24","need_userinfo":"NO","block_title":"美食视频","data_type":"rss","article_list_type":"rss","block_color":"#ff6f6f","desktop_color_number":"8","use_original_icon":"N"}
     * top_tab_info_url : http://iphone.myzaker.com/zaker/top_tab_info.php?app_id=12289&full_arg=_appid,_v,_version,_lbs_city
     * show_type : top_tab
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=12289&since_date=1471400792&nt=1&_appid=androidphone&top_tab_id=10386
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=12289&need_app_integration=1
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12289&ids=54f40b639490cb12100000da&k=201609011740
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/12289.png?t=1467082733
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/12289.png?t=1467082733
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 美食视频
         * data_type : rss
         * article_list_type : rss
         * block_color : #ff6f6f
         * desktop_color_number : 8
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        private String top_tab_info_url;
        private String show_type;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57c4e7c49490cba013000024
         * title : 食尚西餐 | 焗烤扇贝佐菠菜
         * date :
         * auther_name : 饭合
         * weburl : http://iphone.myzaker.com/l.php?l=57c4e7c49490cba013000024
         * thumbnail_pic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg
         * thumbnail_mpic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg
         * thumbnail_picsize : 640,360
         * media_count : 20
         * thumbnail_medias : [{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg","w":"640","h":"360"}]
         * app_ids : 12289
         * is_full : NO
         * content :
         * type : web3
         * special_info : {"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c4e7c49490cba013000024&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c4e7c49490cba013000024%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12289&pk=57c4e7c49490cba013000024&m=1472698368
         * list_dtime :
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public String getTop_tab_info_url() {
            return top_tab_info_url;
        }

        public void setTop_tab_info_url(String top_tab_info_url) {
            this.top_tab_info_url = top_tab_info_url;
        }

        public String getShow_type() {
            return show_type;
        }

        public void setShow_type(String show_type) {
            this.show_type = show_type;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 3
             * articles : 57c4e7c49490cba013000024,57c7d83a9490cb902c000074,57c78fb09490cba02c000037,57c6376a9490cb194b000011,57c4e5f19490cb8713000010,57bff3ca9490cb4960000056
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/12289.png?t=1467082733
                 * bgimage_frame : 0,0,320,44
                 * title_h : 44
                 * hide_title : YES
                 * open_type :
                 * bgimage_icon_style : 0
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;
                    private String bgimage_icon_style;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }

                    public String getBgimage_icon_style() {
                        return bgimage_icon_style;
                    }

                    public void setBgimage_icon_style(String bgimage_icon_style) {
                        this.bgimage_icon_style = bgimage_icon_style;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String data_type;
            private String article_list_type;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getData_type() {
                return data_type;
            }

            public void setData_type(String data_type) {
                this.data_type = data_type;
            }

            public String getArticle_list_type() {
                return article_list_type;
            }

            public void setArticle_list_type(String article_list_type) {
                this.article_list_type = article_list_type;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String app_ids;
            private String is_full;
            private String content;
            private String type;
            /**
             * open_type : web3
             * need_user_info : Y
             * web_url : http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12289&pk=57c4e7c49490cba013000024&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c4e7c49490cba013000024%26app_id%3D12289%26_appid%3Dandroidphone%26target%3Dweb3
             * show_jingcai : Y
             * item_type : 1_b
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;
            /**
             * type : image
             * url : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg
             * m_url : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg
             * raw_url : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JjNjczNzdmNTJlOTcyNGIwMDAwYTlfNjQwLmpwZw==_1242.jpg
             * w : 640
             * h : 360
             */

            private List<ThumbnailMediasBean> thumbnail_medias;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getApp_ids() {
                return app_ids;
            }

            public void setApp_ids(String app_ids) {
                this.app_ids = app_ids;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public List<ThumbnailMediasBean> getThumbnail_medias() {
                return thumbnail_medias;
            }

            public void setThumbnail_medias(List<ThumbnailMediasBean> thumbnail_medias) {
                this.thumbnail_medias = thumbnail_medias;
            }

            public static class SpecialInfoBean {
                private String open_type;
                private String need_user_info;
                private String web_url;
                private String show_jingcai;
                private String item_type;

                public String getOpen_type() {
                    return open_type;
                }

                public void setOpen_type(String open_type) {
                    this.open_type = open_type;
                }

                public String getNeed_user_info() {
                    return need_user_info;
                }

                public void setNeed_user_info(String need_user_info) {
                    this.need_user_info = need_user_info;
                }

                public String getWeb_url() {
                    return web_url;
                }

                public void setWeb_url(String web_url) {
                    this.web_url = web_url;
                }

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getItem_type() {
                    return item_type;
                }

                public void setItem_type(String item_type) {
                    this.item_type = item_type;
                }
            }

            public static class ThumbnailMediasBean {
                private String type;
                private String url;
                private String m_url;
                private String raw_url;
                private String w;
                private String h;

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public String getUrl() {
                    return url;
                }

                public void setUrl(String url) {
                    this.url = url;
                }

                public String getM_url() {
                    return m_url;
                }

                public void setM_url(String m_url) {
                    this.m_url = m_url;
                }

                public String getRaw_url() {
                    return raw_url;
                }

                public void setRaw_url(String raw_url) {
                    this.raw_url = raw_url;
                }

                public String getW() {
                    return w;
                }

                public void setW(String w) {
                    this.w = w;
                }

                public String getH() {
                    return h;
                }

                public void setH(String h) {
                    this.h = h;
                }
            }
        }
    }
}
