package com.example.dllo.zaker.hotspot.sec;

import com.example.dllo.zaker.R;
import com.example.dllo.zaker.base.BaseActivity;

/**
 * Created by dllo on 16/9/3.
 */
public class ImgUrlActivity extends BaseActivity {
    @Override
    protected int getLayout() {
        return R.layout.activity_hotspot_sec_img_url;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
