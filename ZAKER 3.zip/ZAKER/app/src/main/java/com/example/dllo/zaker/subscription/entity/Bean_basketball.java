package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class Bean_basketball {

    /**
     * stat : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=12084&since_date=1473039630&nt=1&_appid=androidphone&catalog_appid=8","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=12084&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12084&ids=51a7106381853df24c000138&k=201609051420"},"catalog":"","articles":[{"pk":"57cd089c9490cb3914000006","title":"宫帅：体测只为督促 不会长期存在","title_line_break":"宫帅：\n体测只为督促 不会长期存在","date":"2016-09-05 13:54:36","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd089c9490cb3914000006","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cd089c9490cb3914000006&m=1473054741","list_dtime":"2016-09-05 13:54:36"},{"pk":"57cd08929490cb217e000034","title":"劈扣+超远三分！詹皇两子天赋惊人","date":"2016-09-05 13:54:26","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd08929490cb217e000034","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDg1MV85NjcwMV9XNjQwSDM2MFM1ODQyNy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDg1MV85NjcwMV9XNjQwSDM2MFM1ODQyNy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cd08929490cb217e000034&m=1473054852","list_dtime":"2016-09-05 13:54:26"},{"pk":"57cd08929490cb217e000032","title":"新季最佳主帅预测：波波第3 科尔落选","title_line_break":"新季最佳主帅预测：\n波波第3 科尔落选","date":"2016-09-05 13:54:26","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd08929490cb217e000032","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTQ0MjFiYzhlMDA1NWYwMDAwMGVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTQ0MjFiYzhlMDA1NWYwMDAwMGVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,425","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cd08929490cb217e000032&m=1473054831","list_dtime":"2016-09-05 13:54:26"},{"pk":"57cd05d99490cb2b7e000036","title":"迪奥驱车从圣城赴犹他，咖啡机不离身","date":"2016-09-05 13:42:49","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57cd05d99490cb2b7e000036","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd03141bc8e0b678000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd03141bc8e0b678000003_320.jpg","thumbnail_picsize":"450,335","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cd05d99490cb2b7e000036&m=1473054135","list_dtime":"2016-09-05 13:42:49"},{"pk":"57ccece49490cb217e00002b","title":"感情深！波尔津吉斯晒照欢迎新援到来","date":"2016-09-05 11:56:20","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57ccece49490cb217e00002b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce5bd1bc8e0e763000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce5bd1bc8e0e763000002_320.jpg","thumbnail_picsize":"450,538","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccece49490cb217e00002b&m=1473047765","list_dtime":"2016-09-05 11:56:20"},{"pk":"57cceb209490cbfa7d000035","title":"身高臂长！戈塔特教你喂长颈鹿","date":"2016-09-05 11:48:48","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57cceb209490cbfa7d000035","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce5bc1bc8e0e763000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce5bc1bc8e0e763000000_320.jpg","thumbnail_picsize":"450,450","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cceb209490cbfa7d000035&m=1473047289","list_dtime":"2016-09-05 11:48:48"},{"pk":"57cceaac9490cb167e000030","title":"太火！加拿大民众疯抢勇士猛龙球票","date":"2016-09-05 11:46:52","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cceaac9490cb167e000030","thumbnail_pic":"http://zkres.myzaker.com/201609/57cceab2a07aecc52301eea6_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cceab2a07aecc52301eea6_320.jpg","thumbnail_picsize":"549,338","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cceaac9490cb167e000030&m=1473047295","list_dtime":"2016-09-05 11:46:52"},{"pk":"57ccea9e9490cbf27d000031","title":"库里谈薪水低：当时那是一种恩赐","title_line_break":"库里谈薪水低：\n当时那是一种恩赐","date":"2016-09-05 11:46:38","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccea9e9490cbf27d000031","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce7cc1bc8e0cc64000026_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce7cc1bc8e0cc64000026_320.jpg","thumbnail_picsize":"480,269","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccea9e9490cbf27d000031&m=1473047114","list_dtime":"2016-09-05 11:46:38"},{"pk":"57ccea9e9490cbf27d00002f","title":"4人超400场从未替补 詹皇为何缺席？","title_line_break":"4人超400场从未替补\n詹皇为何缺席？","date":"2016-09-05 11:46:38","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccea9e9490cbf27d00002f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTdkYjFiYzhlMGNjNjQwMDAwNGJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTdkYjFiYzhlMGNjNjQwMDAwNGJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"446,313","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccea9e9490cbf27d00002f&m=1473047188","list_dtime":"2016-09-05 11:46:38"},{"pk":"57cce6919490cb362200000d","title":"布莱克：大学时沃顿对我帮助很大","title_line_break":"布莱克：\n大学时沃顿对我帮助很大","date":"2016-09-05 11:29:21","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57cce6919490cb362200000d","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce6919490cb362200000d&m=1473046135","list_dtime":"2016-09-05 11:29:21"},{"pk":"57cce63c9490cbf07d000039","title":"十动然拒！周琦新赛季只能在CBA练级","date":"2016-09-05 11:27:56","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57cce63c9490cbf07d000039","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce1891bc8e0385e00002f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce1891bc8e0385e00002f_320.jpg","thumbnail_picsize":"450,300","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce63c9490cbf07d000039&m=1473046044","list_dtime":"2016-09-05 11:27:56"},{"pk":"57cce57c9490cb0e7e000042","title":"曾文鼎与女友结婚 结束16年爱情长跑","title_line_break":"曾文鼎与女友结婚\n结束16年爱情长跑","date":"2016-09-05 11:24:44","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce57c9490cb0e7e000042","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce588a07aecc52301eb74_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce588a07aecc52301eb74_320.jpg","thumbnail_picsize":"550,412","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce57c9490cb0e7e000042&m=1473045918","list_dtime":"2016-09-05 11:24:44"},{"pk":"57cce5769490cbfa7d000030","title":"美媒排5大MVP热门：詹皇居首库里第5","title_line_break":"美媒排5大MVP热门：\n詹皇居首库里第5","date":"2016-09-05 11:24:38","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce5769490cbfa7d000030","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdbb61bc8e0ef5d000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdbb61bc8e0ef5d000000_320.jpg","thumbnail_picsize":"369,220","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce5769490cbfa7d000030&m=1473045740","list_dtime":"2016-09-05 11:24:38"},{"pk":"57cce5769490cbfa7d00002e","title":"归期不定！鹈鹕大将休战照顾患病妻子","date":"2016-09-05 11:24:38","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce5769490cbfa7d00002e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb8cf1bc8e0e648000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb8cf1bc8e0e648000003_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce5769490cbfa7d00002e&m=1473045740","list_dtime":"2016-09-05 11:24:38"},{"pk":"57cce3f39490cb147e000051","title":"马努常与马刺队友聚餐 跟大加聊新季","title_line_break":"马努常与马刺队友聚餐\n跟大加聊新季","date":"2016-09-05 11:18:11","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce3f39490cb147e000051","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce3dea07aecc52301e913_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce3dea07aecc52301e913_320.jpg","thumbnail_picsize":"529,402","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce3f39490cb147e000051&m=1473045483","list_dtime":"2016-09-05 11:18:11"},{"pk":"57cce3d39490cb0f7e000036","title":"两大帮手缺席 浓眉开季怎么玩？","title_line_break":"两大帮手缺席\n浓眉开季怎么玩？","date":"2016-09-05 11:17:39","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57cce3d39490cb0f7e000036","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd07a1bc8e0c055000032_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd07a1bc8e0c055000032_320.jpg","thumbnail_picsize":"464,255","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce3d39490cb0f7e000036&m=1473045439","list_dtime":"2016-09-05 11:17:39"},{"pk":"57cce2f99490cb4d7e000028","title":"热火能拿50胜？美媒献策：防守+团队","title_line_break":"热火能拿50胜？美媒献策：\n防守+团队","date":"2016-09-05 11:14:01","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce2f99490cb4d7e000028","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd34d1bc8e0385900001f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd34d1bc8e0385900001f_320.jpg","thumbnail_picsize":"549,349","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce2f99490cb4d7e000028&m=1473045197","list_dtime":"2016-09-05 11:14:01"},{"pk":"57cce2ee9490cb0e7e000040","title":"威少：重要的是当好领袖 不在乎对KD","title_line_break":"威少：\n重要的是当好领袖 不在乎对KD","date":"2016-09-05 11:13:50","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce2ee9490cb0e7e000040","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccaac1bc8e0235200005b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccaac1bc8e0235200005b_320.jpg","thumbnail_picsize":"332,220","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce2ee9490cb0e7e000040&m=1473045197","list_dtime":"2016-09-05 11:13:50"},{"pk":"57cce2e29490cbf57d000025","title":"告吹？曝火箭已决定今年不签周琦","date":"2016-09-05 11:13:38","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce2e29490cbf57d000025","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc4c51bc8e01e51000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc4c51bc8e01e51000002_320.jpg","thumbnail_picsize":"485,412","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce2e29490cbf57d000025&m=1473045197","list_dtime":"2016-09-05 11:13:38"},{"pk":"57cce0c19490cb097e00002f","title":"盖尔雄望能偷师姚明 助球队进季后赛","title_line_break":"盖尔雄望能偷师姚明\n助球队进季后赛","date":"2016-09-05 11:04:33","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce0c19490cb097e00002f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce0bda07aecc52301e638_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce0bda07aecc52301e638_320.jpg","thumbnail_picsize":"550,361","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce0c19490cb097e00002f&m=1473044801","list_dtime":"2016-09-05 11:04:33"},{"pk":"57cce0219490cb117e00003f","title":"上海男篮大外援抵沪 季前赛将战火箭","title_line_break":"上海男篮大外援抵沪\n季前赛将战火箭","date":"2016-09-05 11:01:53","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce0219490cb117e00003f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce013a07aecc52301e569_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce013a07aecc52301e569_320.jpg","thumbnail_picsize":"541,304","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce0219490cb117e00003f&m=1473044551","list_dtime":"2016-09-05 11:01:53"},{"pk":"57ccdf9d9490cb037e00003d","title":"胡卫东任同曦新帅 将和唐正东再合作","title_line_break":"胡卫东任同曦新帅\n将和唐正东再合作","date":"2016-09-05 10:59:41","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdf9d9490cb037e00003d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDM3MV82NzI1MF9XNjQwSDM2MFM1MDQzMy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDM3MV82NzI1MF9XNjQwSDM2MFM1MDQzMy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccdf9d9490cb037e00003d&m=1473044372","list_dtime":"2016-09-05 10:59:41"},{"pk":"57ccdeb09490cbf87d00002d","title":"大器晚成！洛瑞明夏有望拿1.5亿","date":"2016-09-05 10:55:44","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdeb09490cbf87d00002d","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdea0a07aecc52301e2a5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdea0a07aecc52301e2a5_320.jpg","thumbnail_picsize":"600,446","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccdeb09490cbf87d00002d&m=1473045590","list_dtime":"2016-09-05 10:55:44"},{"pk":"57ccddd79490cb297e00001c","title":"姚明笑谈和贝爷做节目：不知会吃到啥","title_line_break":"姚明笑谈和贝爷做节目：\n不知会吃到啥","date":"2016-09-05 10:52:07","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57ccddd79490cb297e00001c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd0101bc8e0e757000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd0101bc8e0e757000002_320.jpg","thumbnail_picsize":"200,134","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccddd79490cb297e00001c&m=1473043919","list_dtime":"2016-09-05 10:52:07"},{"pk":"57ccdd919490cb037e000037","title":"科总裁揭示经商原因：要鼓励下一代","title_line_break":"科总裁揭示经商原因：\n要鼓励下一代","date":"2016-09-05 10:50:57","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd919490cb037e000037","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd34c1bc8e0385900001d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd34c1bc8e0385900001d_320.jpg","thumbnail_picsize":"453,306","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccdd919490cb037e000037&m=1473043839","list_dtime":"2016-09-05 10:50:57"},{"pk":"57ccdd919490cb037e000035","title":"曝火箭欲交易盖伊 这么换能行吗？","title_line_break":"曝火箭欲交易盖伊\n这么换能行吗？","date":"2016-09-05 10:50:57","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd919490cb037e000035","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccdd919490cb037e000035&m=1473043839","list_dtime":"2016-09-05 10:50:57"},{"pk":"57ccda2c9490cb0d7e000027","title":"火箭关注周琦已多年 今年放弃因两点","title_line_break":"火箭关注周琦已多年\n今年放弃因两点","date":"2016-09-05 10:36:28","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccda2c9490cb0d7e000027","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccda0ba07aecc52301dbe6_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccda0ba07aecc52301dbe6_320.jpg","thumbnail_picsize":"550,415","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccda2c9490cb0d7e000027&m=1473042970","list_dtime":"2016-09-05 10:36:28"},{"pk":"57ccd8839490cbd77d00001d","title":"妈妈，别问我为什么跪着看手机！","date":"2016-09-05 10:29:23","auther_name":"壹球ONEBALL","weburl":"http://iphone.myzaker.com/l.php?l=57ccd8839490cbd77d00001d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZDg1Y2EwN2FlY2M1MjMwMWRhYTRfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZDg1Y2EwN2FlY2M1MjMwMWRhYTRfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,300","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccd8839490cbd77d00001d&m=1473042555","list_dtime":"2016-09-05 10:29:23"},{"pk":"57ccd5a49490cb287e000036","title":"冠军花落安徽 NBL崛起之路已起步","title_line_break":"冠军花落安徽\nNBL崛起之路已起步","date":"2016-09-05 10:17:08","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd5a49490cb287e000036","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd586a07aecc52301d83e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd586a07aecc52301d83e_320.jpg","thumbnail_picsize":"550,367","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccd5a49490cb287e000036&m=1473041905","list_dtime":"2016-09-05 10:17:08"},{"pk":"57ccd2859490cb067e00001a","title":"安徽男篮：夺冠因球迷，下季继续努力","title_line_break":"安徽男篮：\n夺冠因球迷，下季继续努力","date":"2016-09-05 10:03:49","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd2859490cb067e00001a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd288a07aecc52301d606_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd288a07aecc52301d606_320.jpg","thumbnail_picsize":"550,347","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccd2859490cb067e00001a&m=1473041078","list_dtime":"2016-09-05 10:03:49"},{"pk":"57ccd2079490cbe67d00001b","title":"魔兽已纠正罚球 制霸篮下优于中投","title_line_break":"魔兽已纠正罚球\n制霸篮下优于中投","date":"2016-09-05 10:01:43","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd2079490cbe67d00001b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MDg4OV8zMTM1N19XNjQwSDM2MFM1NTkwMC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MDg4OV8zMTM1N19XNjQwSDM2MFM1NTkwMC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccd2079490cbe67d00001b&m=1473043423","list_dtime":"2016-09-05 10:01:43"},{"pk":"57ccd0a69490cb3d7e00002e","title":"打够20年！卡特称不退役因热爱比赛","date":"2016-09-05 09:55:50","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd0a69490cb3d7e00002e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd099a07aecc52301d556_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd099a07aecc52301d556_320.jpg","thumbnail_picsize":"549,309","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccd0a69490cb3d7e00002e&m=1473040594","list_dtime":"2016-09-05 09:55:50"},{"pk":"57ccd0179490cb087e000024","title":"若读大学将如何择校？科比卡特或同队","date":"2016-09-05 09:53:27","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd0179490cb087e000024","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccfa4a07aecc52301d47d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccfa4a07aecc52301d47d_320.jpg","thumbnail_picsize":"600,338","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccd0179490cb087e000024&m=1473040551","list_dtime":"2016-09-05 09:53:27"},{"pk":"57ccce269490cb357e00002a","title":"只因热爱！加里纳利称自己曾拒绝交易","date":"2016-09-05 09:45:10","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57ccce269490cb357e00002a","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccce269490cb357e00002a&m=1473039900","list_dtime":"2016-09-05 09:45:10"},{"pk":"57cccd809490cb3622000002","title":"韦德：为霍勒迪和他的妻子祈祷","title_line_break":"韦德：\n为霍勒迪和他的妻子祈祷","date":"2016-09-05 09:42:24","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57cccd809490cb3622000002","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cccd809490cb3622000002&m=1473039724","list_dtime":"2016-09-05 09:42:24"},{"pk":"57cccd0e9490cb227e00001a","title":"曝掘金接近签下发展联盟MVP","date":"2016-09-05 09:40:30","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57cccd0e9490cb227e00001a","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cccd0e9490cb227e00001a&m=1473039621","list_dtime":"2016-09-05 09:40:30"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cd08929490cb217e000034,57cd089c9490cb3914000006,57cd08929490cb217e000032,57cd05d99490cb2b7e000036,57ccece49490cb217e00002b,57cceb209490cbfa7d000035","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ccea9e9490cbf27d000031,57cceaac9490cb167e000030,57ccea9e9490cbf27d00002f,57cce6919490cb362200000d,57cce63c9490cbf07d000039,57cce57c9490cb0e7e000042","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57cce5769490cbfa7d00002e,57cce5769490cbfa7d000030,57cce3f39490cb147e000051,57cce3d39490cb0f7e000036,57cce2f99490cb4d7e000028,57cce2ee9490cb0e7e000040","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cce0c19490cb097e00002f,57cce2e29490cbf57d000025,57cce0219490cb117e00003f,57ccdf9d9490cb037e00003d,57ccdeb09490cbf87d00002d,57ccddd79490cb297e00001c","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57ccda2c9490cb0d7e000027,57ccdd919490cb037e000035,57ccdd919490cb037e000037,57ccd8839490cbd77d00001d,57ccd5a49490cb287e000036,57ccd2859490cb067e00001a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57ccd0a69490cb3d7e00002e,57ccd2079490cbe67d00001b,57ccd0179490cb087e000024,57ccce269490cb357e00002a,57cccd809490cb3622000002,57cccd0e9490cb227e00001a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}}],"article_block_colors":["#d85847","#d85847"],"only_text_page_bgcolors":["#d85847","#d85847"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12084.png?t=1441781412","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12084.png?t=1441781412","hidden_time":"24","need_userinfo":"NO","block_title":"篮球","block_color":"#d85847","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_40519704449fae7b8083638fd98f70d4","selected_index":"2","list":[{"pk":"zk_app_column_8","title":"头条","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12083","title":"足球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12083_zk_app_column_block_8","title":"足球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12083&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12084","title":"篮球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12084_zk_app_column_block_8","title":"篮球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12084&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_11610","title":"综合","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11610_zk_app_column_block_8","title":"综合体育","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11610&catalog_appid=8","data_type":"news"}}]}}
     */

    private String stat;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=12084&since_date=1473039630&nt=1&_appid=androidphone&catalog_appid=8","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=12084&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12084&ids=51a7106381853df24c000138&k=201609051420"}
     * catalog :
     * articles : [{"pk":"57cd089c9490cb3914000006","title":"宫帅：体测只为督促 不会长期存在","title_line_break":"宫帅：\n体测只为督促 不会长期存在","date":"2016-09-05 13:54:36","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd089c9490cb3914000006","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cd089c9490cb3914000006&m=1473054741","list_dtime":"2016-09-05 13:54:36"},{"pk":"57cd08929490cb217e000034","title":"劈扣+超远三分！詹皇两子天赋惊人","date":"2016-09-05 13:54:26","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd08929490cb217e000034","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDg1MV85NjcwMV9XNjQwSDM2MFM1ODQyNy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDg1MV85NjcwMV9XNjQwSDM2MFM1ODQyNy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cd08929490cb217e000034&m=1473054852","list_dtime":"2016-09-05 13:54:26"},{"pk":"57cd08929490cb217e000032","title":"新季最佳主帅预测：波波第3 科尔落选","title_line_break":"新季最佳主帅预测：\n波波第3 科尔落选","date":"2016-09-05 13:54:26","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd08929490cb217e000032","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTQ0MjFiYzhlMDA1NWYwMDAwMGVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTQ0MjFiYzhlMDA1NWYwMDAwMGVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,425","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cd08929490cb217e000032&m=1473054831","list_dtime":"2016-09-05 13:54:26"},{"pk":"57cd05d99490cb2b7e000036","title":"迪奥驱车从圣城赴犹他，咖啡机不离身","date":"2016-09-05 13:42:49","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57cd05d99490cb2b7e000036","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd03141bc8e0b678000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd03141bc8e0b678000003_320.jpg","thumbnail_picsize":"450,335","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cd05d99490cb2b7e000036&m=1473054135","list_dtime":"2016-09-05 13:42:49"},{"pk":"57ccece49490cb217e00002b","title":"感情深！波尔津吉斯晒照欢迎新援到来","date":"2016-09-05 11:56:20","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57ccece49490cb217e00002b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce5bd1bc8e0e763000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce5bd1bc8e0e763000002_320.jpg","thumbnail_picsize":"450,538","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccece49490cb217e00002b&m=1473047765","list_dtime":"2016-09-05 11:56:20"},{"pk":"57cceb209490cbfa7d000035","title":"身高臂长！戈塔特教你喂长颈鹿","date":"2016-09-05 11:48:48","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57cceb209490cbfa7d000035","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce5bc1bc8e0e763000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce5bc1bc8e0e763000000_320.jpg","thumbnail_picsize":"450,450","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cceb209490cbfa7d000035&m=1473047289","list_dtime":"2016-09-05 11:48:48"},{"pk":"57cceaac9490cb167e000030","title":"太火！加拿大民众疯抢勇士猛龙球票","date":"2016-09-05 11:46:52","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cceaac9490cb167e000030","thumbnail_pic":"http://zkres.myzaker.com/201609/57cceab2a07aecc52301eea6_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cceab2a07aecc52301eea6_320.jpg","thumbnail_picsize":"549,338","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cceaac9490cb167e000030&m=1473047295","list_dtime":"2016-09-05 11:46:52"},{"pk":"57ccea9e9490cbf27d000031","title":"库里谈薪水低：当时那是一种恩赐","title_line_break":"库里谈薪水低：\n当时那是一种恩赐","date":"2016-09-05 11:46:38","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccea9e9490cbf27d000031","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce7cc1bc8e0cc64000026_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce7cc1bc8e0cc64000026_320.jpg","thumbnail_picsize":"480,269","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccea9e9490cbf27d000031&m=1473047114","list_dtime":"2016-09-05 11:46:38"},{"pk":"57ccea9e9490cbf27d00002f","title":"4人超400场从未替补 詹皇为何缺席？","title_line_break":"4人超400场从未替补\n詹皇为何缺席？","date":"2016-09-05 11:46:38","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccea9e9490cbf27d00002f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTdkYjFiYzhlMGNjNjQwMDAwNGJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTdkYjFiYzhlMGNjNjQwMDAwNGJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"446,313","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccea9e9490cbf27d00002f&m=1473047188","list_dtime":"2016-09-05 11:46:38"},{"pk":"57cce6919490cb362200000d","title":"布莱克：大学时沃顿对我帮助很大","title_line_break":"布莱克：\n大学时沃顿对我帮助很大","date":"2016-09-05 11:29:21","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57cce6919490cb362200000d","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce6919490cb362200000d&m=1473046135","list_dtime":"2016-09-05 11:29:21"},{"pk":"57cce63c9490cbf07d000039","title":"十动然拒！周琦新赛季只能在CBA练级","date":"2016-09-05 11:27:56","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57cce63c9490cbf07d000039","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce1891bc8e0385e00002f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce1891bc8e0385e00002f_320.jpg","thumbnail_picsize":"450,300","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce63c9490cbf07d000039&m=1473046044","list_dtime":"2016-09-05 11:27:56"},{"pk":"57cce57c9490cb0e7e000042","title":"曾文鼎与女友结婚 结束16年爱情长跑","title_line_break":"曾文鼎与女友结婚\n结束16年爱情长跑","date":"2016-09-05 11:24:44","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce57c9490cb0e7e000042","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce588a07aecc52301eb74_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce588a07aecc52301eb74_320.jpg","thumbnail_picsize":"550,412","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce57c9490cb0e7e000042&m=1473045918","list_dtime":"2016-09-05 11:24:44"},{"pk":"57cce5769490cbfa7d000030","title":"美媒排5大MVP热门：詹皇居首库里第5","title_line_break":"美媒排5大MVP热门：\n詹皇居首库里第5","date":"2016-09-05 11:24:38","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce5769490cbfa7d000030","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdbb61bc8e0ef5d000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdbb61bc8e0ef5d000000_320.jpg","thumbnail_picsize":"369,220","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce5769490cbfa7d000030&m=1473045740","list_dtime":"2016-09-05 11:24:38"},{"pk":"57cce5769490cbfa7d00002e","title":"归期不定！鹈鹕大将休战照顾患病妻子","date":"2016-09-05 11:24:38","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce5769490cbfa7d00002e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb8cf1bc8e0e648000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb8cf1bc8e0e648000003_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce5769490cbfa7d00002e&m=1473045740","list_dtime":"2016-09-05 11:24:38"},{"pk":"57cce3f39490cb147e000051","title":"马努常与马刺队友聚餐 跟大加聊新季","title_line_break":"马努常与马刺队友聚餐\n跟大加聊新季","date":"2016-09-05 11:18:11","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce3f39490cb147e000051","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce3dea07aecc52301e913_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce3dea07aecc52301e913_320.jpg","thumbnail_picsize":"529,402","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce3f39490cb147e000051&m=1473045483","list_dtime":"2016-09-05 11:18:11"},{"pk":"57cce3d39490cb0f7e000036","title":"两大帮手缺席 浓眉开季怎么玩？","title_line_break":"两大帮手缺席\n浓眉开季怎么玩？","date":"2016-09-05 11:17:39","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57cce3d39490cb0f7e000036","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd07a1bc8e0c055000032_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd07a1bc8e0c055000032_320.jpg","thumbnail_picsize":"464,255","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce3d39490cb0f7e000036&m=1473045439","list_dtime":"2016-09-05 11:17:39"},{"pk":"57cce2f99490cb4d7e000028","title":"热火能拿50胜？美媒献策：防守+团队","title_line_break":"热火能拿50胜？美媒献策：\n防守+团队","date":"2016-09-05 11:14:01","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce2f99490cb4d7e000028","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd34d1bc8e0385900001f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd34d1bc8e0385900001f_320.jpg","thumbnail_picsize":"549,349","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce2f99490cb4d7e000028&m=1473045197","list_dtime":"2016-09-05 11:14:01"},{"pk":"57cce2ee9490cb0e7e000040","title":"威少：重要的是当好领袖 不在乎对KD","title_line_break":"威少：\n重要的是当好领袖 不在乎对KD","date":"2016-09-05 11:13:50","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce2ee9490cb0e7e000040","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccaac1bc8e0235200005b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccaac1bc8e0235200005b_320.jpg","thumbnail_picsize":"332,220","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce2ee9490cb0e7e000040&m=1473045197","list_dtime":"2016-09-05 11:13:50"},{"pk":"57cce2e29490cbf57d000025","title":"告吹？曝火箭已决定今年不签周琦","date":"2016-09-05 11:13:38","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce2e29490cbf57d000025","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc4c51bc8e01e51000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc4c51bc8e01e51000002_320.jpg","thumbnail_picsize":"485,412","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce2e29490cbf57d000025&m=1473045197","list_dtime":"2016-09-05 11:13:38"},{"pk":"57cce0c19490cb097e00002f","title":"盖尔雄望能偷师姚明 助球队进季后赛","title_line_break":"盖尔雄望能偷师姚明\n助球队进季后赛","date":"2016-09-05 11:04:33","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce0c19490cb097e00002f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce0bda07aecc52301e638_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce0bda07aecc52301e638_320.jpg","thumbnail_picsize":"550,361","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce0c19490cb097e00002f&m=1473044801","list_dtime":"2016-09-05 11:04:33"},{"pk":"57cce0219490cb117e00003f","title":"上海男篮大外援抵沪 季前赛将战火箭","title_line_break":"上海男篮大外援抵沪\n季前赛将战火箭","date":"2016-09-05 11:01:53","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce0219490cb117e00003f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce013a07aecc52301e569_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce013a07aecc52301e569_320.jpg","thumbnail_picsize":"541,304","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cce0219490cb117e00003f&m=1473044551","list_dtime":"2016-09-05 11:01:53"},{"pk":"57ccdf9d9490cb037e00003d","title":"胡卫东任同曦新帅 将和唐正东再合作","title_line_break":"胡卫东任同曦新帅\n将和唐正东再合作","date":"2016-09-05 10:59:41","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdf9d9490cb037e00003d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDM3MV82NzI1MF9XNjQwSDM2MFM1MDQzMy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDM3MV82NzI1MF9XNjQwSDM2MFM1MDQzMy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccdf9d9490cb037e00003d&m=1473044372","list_dtime":"2016-09-05 10:59:41"},{"pk":"57ccdeb09490cbf87d00002d","title":"大器晚成！洛瑞明夏有望拿1.5亿","date":"2016-09-05 10:55:44","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdeb09490cbf87d00002d","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdea0a07aecc52301e2a5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdea0a07aecc52301e2a5_320.jpg","thumbnail_picsize":"600,446","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccdeb09490cbf87d00002d&m=1473045590","list_dtime":"2016-09-05 10:55:44"},{"pk":"57ccddd79490cb297e00001c","title":"姚明笑谈和贝爷做节目：不知会吃到啥","title_line_break":"姚明笑谈和贝爷做节目：\n不知会吃到啥","date":"2016-09-05 10:52:07","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57ccddd79490cb297e00001c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd0101bc8e0e757000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd0101bc8e0e757000002_320.jpg","thumbnail_picsize":"200,134","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccddd79490cb297e00001c&m=1473043919","list_dtime":"2016-09-05 10:52:07"},{"pk":"57ccdd919490cb037e000037","title":"科总裁揭示经商原因：要鼓励下一代","title_line_break":"科总裁揭示经商原因：\n要鼓励下一代","date":"2016-09-05 10:50:57","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd919490cb037e000037","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd34c1bc8e0385900001d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd34c1bc8e0385900001d_320.jpg","thumbnail_picsize":"453,306","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccdd919490cb037e000037&m=1473043839","list_dtime":"2016-09-05 10:50:57"},{"pk":"57ccdd919490cb037e000035","title":"曝火箭欲交易盖伊 这么换能行吗？","title_line_break":"曝火箭欲交易盖伊\n这么换能行吗？","date":"2016-09-05 10:50:57","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd919490cb037e000035","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccdd919490cb037e000035&m=1473043839","list_dtime":"2016-09-05 10:50:57"},{"pk":"57ccda2c9490cb0d7e000027","title":"火箭关注周琦已多年 今年放弃因两点","title_line_break":"火箭关注周琦已多年\n今年放弃因两点","date":"2016-09-05 10:36:28","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccda2c9490cb0d7e000027","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccda0ba07aecc52301dbe6_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccda0ba07aecc52301dbe6_320.jpg","thumbnail_picsize":"550,415","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccda2c9490cb0d7e000027&m=1473042970","list_dtime":"2016-09-05 10:36:28"},{"pk":"57ccd8839490cbd77d00001d","title":"妈妈，别问我为什么跪着看手机！","date":"2016-09-05 10:29:23","auther_name":"壹球ONEBALL","weburl":"http://iphone.myzaker.com/l.php?l=57ccd8839490cbd77d00001d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZDg1Y2EwN2FlY2M1MjMwMWRhYTRfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZDg1Y2EwN2FlY2M1MjMwMWRhYTRfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,300","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccd8839490cbd77d00001d&m=1473042555","list_dtime":"2016-09-05 10:29:23"},{"pk":"57ccd5a49490cb287e000036","title":"冠军花落安徽 NBL崛起之路已起步","title_line_break":"冠军花落安徽\nNBL崛起之路已起步","date":"2016-09-05 10:17:08","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd5a49490cb287e000036","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd586a07aecc52301d83e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd586a07aecc52301d83e_320.jpg","thumbnail_picsize":"550,367","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccd5a49490cb287e000036&m=1473041905","list_dtime":"2016-09-05 10:17:08"},{"pk":"57ccd2859490cb067e00001a","title":"安徽男篮：夺冠因球迷，下季继续努力","title_line_break":"安徽男篮：\n夺冠因球迷，下季继续努力","date":"2016-09-05 10:03:49","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd2859490cb067e00001a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd288a07aecc52301d606_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd288a07aecc52301d606_320.jpg","thumbnail_picsize":"550,347","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccd2859490cb067e00001a&m=1473041078","list_dtime":"2016-09-05 10:03:49"},{"pk":"57ccd2079490cbe67d00001b","title":"魔兽已纠正罚球 制霸篮下优于中投","title_line_break":"魔兽已纠正罚球\n制霸篮下优于中投","date":"2016-09-05 10:01:43","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd2079490cbe67d00001b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MDg4OV8zMTM1N19XNjQwSDM2MFM1NTkwMC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MDg4OV8zMTM1N19XNjQwSDM2MFM1NTkwMC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccd2079490cbe67d00001b&m=1473043423","list_dtime":"2016-09-05 10:01:43"},{"pk":"57ccd0a69490cb3d7e00002e","title":"打够20年！卡特称不退役因热爱比赛","date":"2016-09-05 09:55:50","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd0a69490cb3d7e00002e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd099a07aecc52301d556_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd099a07aecc52301d556_320.jpg","thumbnail_picsize":"549,309","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccd0a69490cb3d7e00002e&m=1473040594","list_dtime":"2016-09-05 09:55:50"},{"pk":"57ccd0179490cb087e000024","title":"若读大学将如何择校？科比卡特或同队","date":"2016-09-05 09:53:27","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd0179490cb087e000024","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccfa4a07aecc52301d47d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccfa4a07aecc52301d47d_320.jpg","thumbnail_picsize":"600,338","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccd0179490cb087e000024&m=1473040551","list_dtime":"2016-09-05 09:53:27"},{"pk":"57ccce269490cb357e00002a","title":"只因热爱！加里纳利称自己曾拒绝交易","date":"2016-09-05 09:45:10","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57ccce269490cb357e00002a","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57ccce269490cb357e00002a&m=1473039900","list_dtime":"2016-09-05 09:45:10"},{"pk":"57cccd809490cb3622000002","title":"韦德：为霍勒迪和他的妻子祈祷","title_line_break":"韦德：\n为霍勒迪和他的妻子祈祷","date":"2016-09-05 09:42:24","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57cccd809490cb3622000002","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cccd809490cb3622000002&m=1473039724","list_dtime":"2016-09-05 09:42:24"},{"pk":"57cccd0e9490cb227e00001a","title":"曝掘金接近签下发展联盟MVP","date":"2016-09-05 09:40:30","auther_name":"虎扑篮球","weburl":"http://iphone.myzaker.com/l.php?l=57cccd0e9490cb227e00001a","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cccd0e9490cb227e00001a&m=1473039621","list_dtime":"2016-09-05 09:40:30"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cd08929490cb217e000034,57cd089c9490cb3914000006,57cd08929490cb217e000032,57cd05d99490cb2b7e000036,57ccece49490cb217e00002b,57cceb209490cbfa7d000035","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ccea9e9490cbf27d000031,57cceaac9490cb167e000030,57ccea9e9490cbf27d00002f,57cce6919490cb362200000d,57cce63c9490cbf07d000039,57cce57c9490cb0e7e000042","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57cce5769490cbfa7d00002e,57cce5769490cbfa7d000030,57cce3f39490cb147e000051,57cce3d39490cb0f7e000036,57cce2f99490cb4d7e000028,57cce2ee9490cb0e7e000040","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cce0c19490cb097e00002f,57cce2e29490cbf57d000025,57cce0219490cb117e00003f,57ccdf9d9490cb037e00003d,57ccdeb09490cbf87d00002d,57ccddd79490cb297e00001c","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57ccda2c9490cb0d7e000027,57ccdd919490cb037e000035,57ccdd919490cb037e000037,57ccd8839490cbd77d00001d,57ccd5a49490cb287e000036,57ccd2859490cb067e00001a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57ccd0a69490cb3d7e00002e,57ccd2079490cbe67d00001b,57ccd0179490cb087e000024,57ccce269490cb357e00002a,57cccd809490cb3622000002,57cccd0e9490cb227e00001a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}}],"article_block_colors":["#d85847","#d85847"],"only_text_page_bgcolors":["#d85847","#d85847"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12084.png?t=1441781412","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12084.png?t=1441781412","hidden_time":"24","need_userinfo":"NO","block_title":"篮球","block_color":"#d85847","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_40519704449fae7b8083638fd98f70d4","selected_index":"2","list":[{"pk":"zk_app_column_8","title":"头条","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12083","title":"足球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12083_zk_app_column_block_8","title":"足球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12083&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12084","title":"篮球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12084_zk_app_column_block_8","title":"篮球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12084&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_11610","title":"综合","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11610_zk_app_column_block_8","title":"综合体育","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11610&catalog_appid=8","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=12084&since_date=1473039630&nt=1&_appid=androidphone&catalog_appid=8
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=12084&need_app_integration=
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12084&ids=51a7106381853df24c000138&k=201609051420
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/12084.png?t=1441781412
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/12084.png?t=1441781412
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 篮球
         * block_color : #d85847
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_40519704449fae7b8083638fd98f70d4
         * selected_index : 2
         * list : [{"pk":"zk_app_column_8","title":"头条","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12083","title":"足球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12083_zk_app_column_block_8","title":"足球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12083&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12084","title":"篮球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12084_zk_app_column_block_8","title":"篮球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12084&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_11610","title":"综合","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11610_zk_app_column_block_8","title":"综合体育","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11610&catalog_appid=8","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57cd089c9490cb3914000006
         * title : 宫帅：体测只为督促 不会长期存在
         * title_line_break : 宫帅：
         体测只为督促 不会长期存在
         * date : 2016-09-05 13:54:36
         * auther_name : 凤凰体育
         * weburl : http://iphone.myzaker.com/l.php?l=57cd089c9490cb3914000006
         * media_count : 1
         * is_full : NO
         * content :
         * special_info : {"show_jingcai":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12084&pk=57cd089c9490cb3914000006&m=1473054741
         * list_dtime : 2016-09-05 13:54:36
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 3
             * articles : 57cd08929490cb217e000034,57cd089c9490cb3914000006,57cd08929490cb217e000032,57cd05d99490cb2b7e000036,57ccece49490cb217e00002b,57cceb209490cbfa7d000035
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * open_type :
                 * bgimage_icon_style : 0
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;
                    private String bgimage_icon_style;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }

                    public String getBgimage_icon_style() {
                        return bgimage_icon_style;
                    }

                    public void setBgimage_icon_style(String bgimage_icon_style) {
                        this.bgimage_icon_style = bgimage_icon_style;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_8
             * title : 头条
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 8
                 * title : 体育新闻
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8
                 * data_type : news
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String title_line_break;
            private String date;
            private String auther_name;
            private String weburl;
            private String media_count;
            private String is_full;
            private String content,thumbnail_pic;

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            /**
             * show_jingcai : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getTitle_line_break() {
                return title_line_break;
            }

            public void setTitle_line_break(String title_line_break) {
                this.title_line_break = title_line_break;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String show_jingcai;

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }
            }
        }
    }
}
