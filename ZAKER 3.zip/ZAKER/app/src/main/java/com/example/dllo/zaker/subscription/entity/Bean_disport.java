package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class Bean_disport {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=9&since_date=1472951978&nt=1&next_aticle_id=57cc8a2a9490cb5f59000007&_appid=androidphone&opage=2&otimestamp=177","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=9&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=9&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,5472a9b69490cb48180000f9,51a7104681853dec4d00012f&k=201609051440"},"catalog":"","articles":[{"pk":"571f28429490cbe70b000044","title":"2016《超级女声》正在进行中","date":"2016-04-26 16:34:15","auther_name":"ZAKER娱乐","page":"6","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=571f28429490cbe70b000044","media_count":"0","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"571874639490cb8c50000003","block_title":"2016超级女声","title":"2016超级女声","block_in_title":"2016《超级女声》正在进行中","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=9&topic_id=571874639490cb8c50000003&updated=1472807552"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=571f28429490cbe70b000044&m=1473057304","list_dtime":"2016-04-26 16:34:15"},{"pk":"57ccf4c89490cb117e00004c","title":"张艺谋为了G20晚会到底有多拼","date":"2016-09-05 12:30:00","auther_name":"艺非凡","weburl":"http://iphone.myzaker.com/l.php?l=57ccf4c89490cb117e00004c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYzdkN2EwN2FlY2M1MjMwMWQwZDZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYzdkN2EwN2FlY2M1MjMwMWQwZDZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,300","media_count":"39","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccf4c89490cb117e00004c&m=1473057210","list_dtime":"2016-09-05 12:30:00"},{"pk":"57cce3a09490cb3e7e000028","title":"关晓彤代表新生发言 白衣牛仔青春洋溢","title_line_break":"关晓彤代表新生发言\n白衣牛仔青春洋溢","date":"2016-09-05 11:16:12","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cce3a09490cb3e7e000028","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NzAyNl8xMDkwNl9XNjQwSDM2MFM0MDEwMC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NzAyNl8xMDkwNl9XNjQwSDM2MFM0MDEwMC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cce3a09490cb3e7e000028&m=1473057210","list_dtime":"2016-09-05 11:16:12"},{"pk":"57cd02e09490cb227e000033","title":"原来漂亮的女人都演过潘金莲","date":"2016-09-05 13:30:08","auther_name":"毒舌电影","weburl":"http://iphone.myzaker.com/l.php?l=57cd02e09490cb227e000033","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjNDk0YjdmNTJlOWViNzkwMDAxNmFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjNDk0YjdmNTJlOWViNzkwMDAxNmFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,337","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cd02e09490cb227e000033&m=1473057210","list_dtime":"2016-09-05 13:30:08"},{"pk":"57ccc35a7f52e96e690000a1","title":"孙俪单手抱娃又搬箱 邓超似跟班紧随","title_line_break":"孙俪单手抱娃又搬箱\n邓超似跟班紧随","date":"2016-09-05 09:57:08","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccc35a7f52e96e690000a1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzkzN18zMDI1OV9XNjQwSDM2MFM1ODY1NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzkzN18zMDI1OV9XNjQwSDM2MFM1ODY1NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc35a7f52e96e690000a1&m=1473057210","list_dtime":"2016-09-05 09:57:08"},{"pk":"57cce4649490cb3c3e000008","title":"张继科最新写真被拍成了1米6","date":"2016-09-05 11:20:04","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cce4649490cb3c3e000008","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NjU1M185NDg0X1c2NDBIMzYwUzE5OTA5LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NjU1M185NDg0X1c2NDBIMzYwUzE5OTA5LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"19","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cce4649490cb3c3e000008&m=1473057210","list_dtime":"2016-09-05 11:20:04"},{"pk":"57cc56309490cbe07d000000","title":"看柯震东这副样子 毁的不仅是颜值","title_line_break":"看柯震东这副样子\n毁的不仅是颜值","date":"2016-09-05 08:53:20","auther_name":"深八影视圈","weburl":"http://iphone.myzaker.com/l.php?l=57cc56309490cbe07d000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNjc5M181NzUxMF9XNjQwSDM2MFM0ODI5Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNjc5M181NzUxMF9XNjQwSDM2MFM0ODI5Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"38","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cc56309490cbe07d000000&m=1473057211","list_dtime":"2016-09-05 08:53:20"},{"pk":"57ccb32b9490cb7a38000002","title":"当年香港最红童星 如今选择做普通人","title_line_break":"当年香港最红童星\n如今选择做普通人","date":"2016-09-05 09:20:46","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccb32b9490cb7a38000002","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYWMyYTFiYzhlMDI4NDAwMDAwMGNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYWMyYTFiYzhlMDI4NDAwMDAwMGNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"490,297","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccb32b9490cb7a38000002&m=1473057211","list_dtime":"2016-09-05 09:20:46"},{"pk":"57ccbeab7f52e9480900006c","title":"那英素颜带女儿现身 小姑娘大长腿抢镜","title_line_break":"那英素颜带女儿现身\n小姑娘大长腿抢镜","date":"2016-09-05 09:00:16","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbeab7f52e9480900006c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzk3M181ODE4MV9XNjQwSDM2MFM0MTgyNS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzk3M181ODE4MV9XNjQwSDM2MFM0MTgyNS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbeab7f52e9480900006c&m=1473057211","list_dtime":"2016-09-05 09:00:16"},{"pk":"57cd05a61bc8e0180c000025","title":"岳云鹏力挺郭德纲：一切都是师父给的","title_line_break":"岳云鹏力挺郭德纲：\n一切都是师父给的","date":"2016-09-05 13:41:58","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cd05a61bc8e0180c000025","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NkMDJlZmEwN2FlY2M1MjMwMWZhNzBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NkMDJlZmEwN2FlY2M1MjMwMWZhNzBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,483","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cd05a61bc8e0180c000025&m=1473057210","list_dtime":"2016-09-05 13:41:58"},{"pk":"57cce8239490cb3a7e00002e","title":"姚晨贝嫂获评\u201c全球最具影响力母亲\u201d","date":"2016-09-05 11:35:02","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cce8239490cb3a7e00002e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NzIwNl85Mjc2MV9XNjQwSDM2MFM0MzIyMC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NzIwNl85Mjc2MV9XNjQwSDM2MFM0MzIyMC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cce8239490cb3a7e00002e&m=1473057210","list_dtime":"2016-09-05 11:35:02"},{"pk":"57ccbea97f52e94809000067","title":"董洁白裙淡雅，又美成了\u201c冷清秋\u201d！","date":"2016-09-05 09:09:33","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbea97f52e94809000067","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzkwM183ODY5OF9XNjQwSDM2MFMzMjI4NC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzkwM183ODY5OF9XNjQwSDM2MFMzMjI4NC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbea97f52e94809000067&m=1473057211","list_dtime":"2016-09-05 09:09:33"},{"pk":"57ccc9b11bc8e0240c000017","title":"焦恩俊为女儿庆生 大眼美女酷似高圆圆","title_line_break":"焦恩俊为女儿庆生\n大眼美女酷似高圆圆","date":"2016-09-05 09:29:44","auther_name":"网易图片","weburl":"http://iphone.myzaker.com/l.php?l=57ccc9b11bc8e0240c000017","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTAwNV80OTAzOF9XNjQwSDM2MFM0NjE1Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTAwNV80OTAzOF9XNjQwSDM2MFM0NjE1Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc9b11bc8e0240c000017&m=1473057211","list_dtime":"2016-09-05 09:29:44"},{"pk":"57ccbb5f9490cb6962000002","title":"路人撞脸明星 最后一张确定不是本人？","title_line_break":"路人撞脸明星\n最后一张确定不是本人？","date":"2016-09-05 09:15:47","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbb5f9490cb6962000002","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzODY4M182NzIzN19XNjQwSDM2MFMyOTA3Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzODY4M182NzIzN19XNjQwSDM2MFMyOTA3Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbb5f9490cb6962000002&m=1473057211","list_dtime":"2016-09-05 09:15:47"},{"pk":"57ccc9371bc8e0140c00000f","title":"好莱坞影业大佬向中国美女主播求婚","date":"2016-09-05 09:30:25","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccc9371bc8e0140c00000f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTA1MV82MDM4NV9XNjQwSDM2MFM2ODg5Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTA1MV82MDM4NV9XNjQwSDM2MFM2ODg5Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc9371bc8e0140c00000f&m=1473057210","list_dtime":"2016-09-05 09:30:25"},{"pk":"57cc925b9490cb1b09000000","title":"郭德纲回应曹云金：你不死我有什么办法","title_line_break":"郭德纲回应曹云金：\n你不死我有什么办法","date":"2016-09-05 07:51:52","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cc925b9490cb1b09000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbfe831bc8e08254000005_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbfe831bc8e08254000005_320.jpg","thumbnail_picsize":"500,497","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cc925b9490cb1b09000000&m=1473057211","list_dtime":"2016-09-05 07:51:52"},{"pk":"57cccbc79490cb6338000005","title":"吴彦祖和吴亦凡撞衫 该看哪个好？","title_line_break":"吴彦祖和吴亦凡撞衫\n该看哪个好？","date":"2016-09-05 09:38:47","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cccbc79490cb6338000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTYxOV81NDk3MV9XNjQwSDM2MFM4MzYzNy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTYxOV81NDk3MV9XNjQwSDM2MFM4MzYzNy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cccbc79490cb6338000005&m=1473057210","list_dtime":"2016-09-05 09:38:47"},{"pk":"57cccbc79490cb6338000008","title":"冉莹颖为袁咏仪庆生 轩轩带弟弟来祝福","title_line_break":"冉莹颖为袁咏仪庆生\n轩轩带弟弟来祝福","date":"2016-09-05 09:39:19","auther_name":"中国娱乐网","weburl":"http://iphone.myzaker.com/l.php?l=57cccbc79490cb6338000008","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTY1Nl82ODcxOV9XNjQwSDM2MFM2MTY2OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTY1Nl82ODcxOV9XNjQwSDM2MFM2MTY2OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cccbc79490cb6338000008&m=1473057210","list_dtime":"2016-09-05 09:39:19"},{"pk":"57ccc3949490cb050e000005","title":"王心凌又变脸了？无所谓，青春歌曲没变","date":"2016-09-05 09:03:45","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccc3949490cb050e000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzk2MF8yNjI5OV9XNjQwSDM2MFMzNzAyOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzk2MF8yNjI5OV9XNjQwSDM2MFMzNzAyOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc3949490cb050e000005&m=1473057211","list_dtime":"2016-09-05 09:03:45"},{"pk":"57ccc09a1bc8e02c0c000009","title":"林志玲言承旭共用经纪人 粉丝：舒淇婚了","title_line_break":"林志玲言承旭共用经纪人 粉丝：\n舒淇婚了","date":"2016-09-05 09:06:25","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccc09a1bc8e02c0c000009","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc0d7a07aecc52301cd0d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc0d7a07aecc52301cd0d_320.jpg","thumbnail_picsize":"587,430","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc09a1bc8e02c0c000009&m=1473057211","list_dtime":"2016-09-05 09:06:25"},{"pk":"57cc8a2a9490cb5f59000003","title":"杨钰莹近照化身美人鱼 装束大胆 ","date":"2016-09-05 09:22:08","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cc8a2a9490cb5f59000003","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzODYxN18yMjY5MF9XNjQwSDM2MFMzNTU2Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzODYxN18yMjY5MF9XNjQwSDM2MFMzNTU2Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cc8a2a9490cb5f59000003&m=1473057211","list_dtime":"2016-09-05 09:22:08"},{"pk":"57cc50bb9490cbec3d000000","title":"余文乐自爆心中女神 居然是她！","title_line_break":"余文乐自爆心中女神\n居然是她！","date":"2016-09-05 07:43:17","auther_name":"Yes娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cc50bb9490cbec3d000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc50781bc8e03b1500000a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc50781bc8e03b1500000a_320.jpg","thumbnail_picsize":"1289,884","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cc50bb9490cbec3d000000&m=1473057211","list_dtime":"2016-09-05 07:43:17"},{"pk":"57ccbb5f9490cb6962000006","title":"\u201c小白龙\u201d曝近照 曾遭张卫健\u201c痛打\u201d","title_line_break":"\u201c小白龙\u201d曝近照\n曾遭张卫健\u201c痛打\u201d","date":"2016-09-05 09:13:46","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbb5f9490cb6962000006","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYjkxYTFiYzhlMDc1NDkwMDAwMDFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYjkxYTFiYzhlMDc1NDkwMDAwMDFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,349","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbb5f9490cb6962000006&m=1473057211","list_dtime":"2016-09-05 09:13:46"},{"pk":"57ccd3fc9490cb8c64000000","title":"林志玲看到范冰冰超兴奋 大呼\u201c女神\u201d","title_line_break":"林志玲看到范冰冰超兴奋\n大呼\u201c女神\u201d","date":"2016-09-05 10:10:04","auther_name":"19楼娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd3fc9490cb8c64000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd0e61bc8e0c75700003a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd0e61bc8e0c75700003a_320.jpg","thumbnail_picsize":"600,339","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccd3fc9490cb8c64000000&m=1473057210","list_dtime":"2016-09-05 10:10:04"},{"pk":"57ccbeab7f52e96e6900004b","title":"袁咏仪过生日超幸福 老公送包儿子送抱","title_line_break":"袁咏仪过生日超幸福\n老公送包儿子送抱","date":"2016-09-05 09:10:28","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbeab7f52e96e6900004b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzg3MV84MzAzMV9XNjQwSDM2MFM2MzAxMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzg3MV84MzAzMV9XNjQwSDM2MFM2MzAxMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbeab7f52e96e6900004b&m=1473057211","list_dtime":"2016-09-05 09:10:28"},{"pk":"57cccc381bc8e0160c000023","title":"还是要相信爱情啊！混蛋们","date":"2016-09-05 10:36:56","auther_name":"新周刊","weburl":"http://iphone.myzaker.com/l.php?l=57cccc381bc8e0160c000023","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NzE4MV83NTU0Nl9XNjQwSDM2MFM1NjMyNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NzE4MV83NTU0Nl9XNjQwSDM2MFM1NjMyNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cccc381bc8e0160c000023&m=1473057210","list_dtime":"2016-09-05 10:36:56"},{"pk":"57cca82aa07aece76f00003d","title":"曝张艺兴抱鞠婧祎下腰11次引粉丝不满","date":"2016-09-05 07:33:22","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cca82aa07aece76f00003d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzMzIxOV85NDc5M19XNjQwSDM2MFM3MTc5NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzMzIxOV85NDc5M19XNjQwSDM2MFM3MTc5NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cca82aa07aece76f00003d&m=1473057211","list_dtime":"2016-09-05 07:33:22"},{"pk":"57ccbeab7f52e9480900006f","title":"张艺谋导G20晚会获赞 妻子发文祝贺","title_line_break":"张艺谋导G20晚会获赞\n妻子发文祝贺","date":"2016-09-05 09:07:39","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbeab7f52e9480900006f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzkyMl84MTgxMV9XNjQwSDM2MFM0ODgzNi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzkyMl84MTgxMV9XNjQwSDM2MFM0ODgzNi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbeab7f52e9480900006f&m=1473057211","list_dtime":"2016-09-05 09:07:39"},{"pk":"57cc40539490cb7864000006","title":"李孝利：嫁给爱情的她把日子过成诗","title_line_break":"李孝利：\n嫁给爱情的她把日子过成诗","date":"2016-09-05 07:53:48","auther_name":"芭莎娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cc40539490cb7864000006","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NiZGZmOTdmNTJlOTJjMDgwMDAwZjBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NiZGZmOTdmNTJlOTJjMDgwMDAwZjBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,346","media_count":"20","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cc40539490cb7864000006&m=1473057211","list_dtime":"2016-09-05 07:53:48"},{"pk":"57ccc3949490cb050e000000","title":"娱乐圈腿精明星 逆天长腿堪比模特","title_line_break":"娱乐圈腿精明星\n逆天长腿堪比模特","date":"2016-09-05 09:01:25","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccc3949490cb050e000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzM3N184ODUxX1c2NDBIMzYwUzQ5MTU3LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzM3N184ODUxX1c2NDBIMzYwUzQ5MTU3LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc3949490cb050e000000&m=1473057211","list_dtime":"2016-09-05 09:01:25"},{"pk":"57cc2fec9490cbc513000003","title":"惊！日本偶像男团玩4P致少女怀孕","date":"2016-09-05 07:46:01","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cc2fec9490cbc513000003","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjMjAwZjFiYzhlMDk5NmIwMDAwMzNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjMjAwZjFiYzhlMDk5NmIwMDAwMzNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,375","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cc2fec9490cbc513000003&m=1473057211","list_dtime":"2016-09-05 07:46:01"},{"pk":"57ccba347f52e94809000023","title":"王思聪炮轰大张伟抄袭：硬着头皮不承认","title_line_break":"王思聪炮轰大张伟抄袭：\n硬着头皮不承认","date":"2016-09-05 09:16:29","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccba347f52e94809000023","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccba337f52e94809000021_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccba337f52e94809000021_320.jpg","thumbnail_picsize":"598,597","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccba347f52e94809000023&m=1473057211","list_dtime":"2016-09-05 09:16:29"},{"pk":"57cd0c569490cbb94d000005","title":"辰亦儒自曝情史：与女友相聚无人发现","title_line_break":"辰亦儒自曝情史：\n与女友相聚无人发现","date":"2016-09-05 14:09:42","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cd0c569490cbb94d000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NjE3Nl81Nzk5OF9XNjQwSDM2MFM1MzY0My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NjE3Nl81Nzk5OF9XNjQwSDM2MFM1MzY0My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cd0c569490cbb94d000005&m=1473057210","list_dtime":"2016-09-05 14:09:42"},{"pk":"57ccc35a7f52e964090000f0","title":"陈意涵告白张钧甯：牵你手睡觉好满足！","title_line_break":"陈意涵告白张钧甯：\n牵你手睡觉好满足！","date":"2016-09-05 09:04:21","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccc35a7f52e964090000f0","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzk1NF8zOTA5NF9XNjQwSDM2MFM1MDUxNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzk1NF8zOTA5NF9XNjQwSDM2MFM1MDUxNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc35a7f52e964090000f0&m=1473057211","list_dtime":"2016-09-05 09:04:21"},{"pk":"57cca3ee7f52e944050000d4","title":"小S听闻舒淇结婚：跟大S还蛮像的","title_line_break":"小S听闻舒淇结婚：\n跟大S还蛮像的","date":"2016-09-05 07:31:52","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cca3ee7f52e944050000d4","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYTNlZDdmNTJlOTQ0MDUwMDAwZDJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYTNlZDdmNTJlOTQ0MDUwMDAwZDJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"619,401","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cca3ee7f52e944050000d4&m=1473057211","list_dtime":"2016-09-05 07:31:52"},{"pk":"57ccbb5f9490cb6962000000","title":"当红明星素颜照 你也可以很美","title_line_break":"当红明星素颜照\n你也可以很美","date":"2016-09-05 09:15:05","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbb5f9490cb6962000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzODc1OF8yMDEyNF9XNjQwSDM2MFMyNDU4Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzODc1OF8yMDEyNF9XNjQwSDM2MFMyNDU4Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"20","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbb5f9490cb6962000000&m=1473057211","list_dtime":"2016-09-05 09:15:05"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cce3a09490cb3e7e000028,57ccf4c89490cb117e00004c,57cd02e09490cb227e000033,57ccc35a7f52e96e690000a1,57cce4649490cb3c3e000008,57cc56309490cbe07d000000","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ccbeab7f52e9480900006c,57ccb32b9490cb7a38000002,57cd05a61bc8e0180c000025,57cce8239490cb3a7e00002e,57ccbea97f52e94809000067,57ccc9b11bc8e0240c000017","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ccc9371bc8e0140c00000f,57ccbb5f9490cb6962000002,57cc925b9490cb1b09000000,57cccbc79490cb6338000005,57cccbc79490cb6338000008,57ccc3949490cb050e000005","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57cc8a2a9490cb5f59000003,57ccc09a1bc8e02c0c000009,57cc50bb9490cbec3d000000,57ccbb5f9490cb6962000006,57ccd3fc9490cb8c64000000,57ccbeab7f52e96e6900004b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57cca82aa07aece76f00003d,57cccc381bc8e0160c000023,57ccbeab7f52e9480900006f,57cc40539490cb7864000006,57ccc3949490cb050e000000,57cc2fec9490cbc513000003","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cd0c569490cbb94d000005,57ccba347f52e94809000023,57ccc35a7f52e964090000f0,57cca3ee7f52e944050000d4,571f28429490cbe70b000044,57ccbb5f9490cb6962000000","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#5700b9","#5700b9"],"only_text_page_bgcolors":["#5700b9","#5700b9"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/9.png?t=1457432249","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/9.png?t=1457432249","hidden_time":"24","need_userinfo":"NO","block_title":"娱乐八卦","block_color":"#5700b9","desktop_color_number":"20","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_e693be4a623b0f3966d75d6a4e67a749","selected_index":"0","list":[{"pk":"zk_app_column_9","title":"娱乐","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_10530","title":"电影","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"10530_zk_app_column_block_9","title":"电影资讯","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=10530&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_11698","title":"电视","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11698_zk_app_column_block_9","title":"电视","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11698&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_12348","title":"明星","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12348_zk_app_column_block_9","title":"明星","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12348&catalog_appid=9","data_type":"news"}}]}}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=9&since_date=1472951978&nt=1&next_aticle_id=57cc8a2a9490cb5f59000007&_appid=androidphone&opage=2&otimestamp=177","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=9&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=9&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,5472a9b69490cb48180000f9,51a7104681853dec4d00012f&k=201609051440"}
     * catalog :
     * articles : [{"pk":"571f28429490cbe70b000044","title":"2016《超级女声》正在进行中","date":"2016-04-26 16:34:15","auther_name":"ZAKER娱乐","page":"6","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=571f28429490cbe70b000044","media_count":"0","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"571874639490cb8c50000003","block_title":"2016超级女声","title":"2016超级女声","block_in_title":"2016《超级女声》正在进行中","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=9&topic_id=571874639490cb8c50000003&updated=1472807552"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=571f28429490cbe70b000044&m=1473057304","list_dtime":"2016-04-26 16:34:15"},{"pk":"57ccf4c89490cb117e00004c","title":"张艺谋为了G20晚会到底有多拼","date":"2016-09-05 12:30:00","auther_name":"艺非凡","weburl":"http://iphone.myzaker.com/l.php?l=57ccf4c89490cb117e00004c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYzdkN2EwN2FlY2M1MjMwMWQwZDZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYzdkN2EwN2FlY2M1MjMwMWQwZDZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,300","media_count":"39","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccf4c89490cb117e00004c&m=1473057210","list_dtime":"2016-09-05 12:30:00"},{"pk":"57cce3a09490cb3e7e000028","title":"关晓彤代表新生发言 白衣牛仔青春洋溢","title_line_break":"关晓彤代表新生发言\n白衣牛仔青春洋溢","date":"2016-09-05 11:16:12","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cce3a09490cb3e7e000028","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NzAyNl8xMDkwNl9XNjQwSDM2MFM0MDEwMC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NzAyNl8xMDkwNl9XNjQwSDM2MFM0MDEwMC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cce3a09490cb3e7e000028&m=1473057210","list_dtime":"2016-09-05 11:16:12"},{"pk":"57cd02e09490cb227e000033","title":"原来漂亮的女人都演过潘金莲","date":"2016-09-05 13:30:08","auther_name":"毒舌电影","weburl":"http://iphone.myzaker.com/l.php?l=57cd02e09490cb227e000033","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjNDk0YjdmNTJlOWViNzkwMDAxNmFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjNDk0YjdmNTJlOWViNzkwMDAxNmFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,337","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cd02e09490cb227e000033&m=1473057210","list_dtime":"2016-09-05 13:30:08"},{"pk":"57ccc35a7f52e96e690000a1","title":"孙俪单手抱娃又搬箱 邓超似跟班紧随","title_line_break":"孙俪单手抱娃又搬箱\n邓超似跟班紧随","date":"2016-09-05 09:57:08","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccc35a7f52e96e690000a1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzkzN18zMDI1OV9XNjQwSDM2MFM1ODY1NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzkzN18zMDI1OV9XNjQwSDM2MFM1ODY1NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc35a7f52e96e690000a1&m=1473057210","list_dtime":"2016-09-05 09:57:08"},{"pk":"57cce4649490cb3c3e000008","title":"张继科最新写真被拍成了1米6","date":"2016-09-05 11:20:04","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cce4649490cb3c3e000008","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NjU1M185NDg0X1c2NDBIMzYwUzE5OTA5LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NjU1M185NDg0X1c2NDBIMzYwUzE5OTA5LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"19","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cce4649490cb3c3e000008&m=1473057210","list_dtime":"2016-09-05 11:20:04"},{"pk":"57cc56309490cbe07d000000","title":"看柯震东这副样子 毁的不仅是颜值","title_line_break":"看柯震东这副样子\n毁的不仅是颜值","date":"2016-09-05 08:53:20","auther_name":"深八影视圈","weburl":"http://iphone.myzaker.com/l.php?l=57cc56309490cbe07d000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNjc5M181NzUxMF9XNjQwSDM2MFM0ODI5Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNjc5M181NzUxMF9XNjQwSDM2MFM0ODI5Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"38","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cc56309490cbe07d000000&m=1473057211","list_dtime":"2016-09-05 08:53:20"},{"pk":"57ccb32b9490cb7a38000002","title":"当年香港最红童星 如今选择做普通人","title_line_break":"当年香港最红童星\n如今选择做普通人","date":"2016-09-05 09:20:46","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccb32b9490cb7a38000002","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYWMyYTFiYzhlMDI4NDAwMDAwMGNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYWMyYTFiYzhlMDI4NDAwMDAwMGNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"490,297","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccb32b9490cb7a38000002&m=1473057211","list_dtime":"2016-09-05 09:20:46"},{"pk":"57ccbeab7f52e9480900006c","title":"那英素颜带女儿现身 小姑娘大长腿抢镜","title_line_break":"那英素颜带女儿现身\n小姑娘大长腿抢镜","date":"2016-09-05 09:00:16","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbeab7f52e9480900006c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzk3M181ODE4MV9XNjQwSDM2MFM0MTgyNS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzk3M181ODE4MV9XNjQwSDM2MFM0MTgyNS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbeab7f52e9480900006c&m=1473057211","list_dtime":"2016-09-05 09:00:16"},{"pk":"57cd05a61bc8e0180c000025","title":"岳云鹏力挺郭德纲：一切都是师父给的","title_line_break":"岳云鹏力挺郭德纲：\n一切都是师父给的","date":"2016-09-05 13:41:58","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cd05a61bc8e0180c000025","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NkMDJlZmEwN2FlY2M1MjMwMWZhNzBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NkMDJlZmEwN2FlY2M1MjMwMWZhNzBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,483","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cd05a61bc8e0180c000025&m=1473057210","list_dtime":"2016-09-05 13:41:58"},{"pk":"57cce8239490cb3a7e00002e","title":"姚晨贝嫂获评\u201c全球最具影响力母亲\u201d","date":"2016-09-05 11:35:02","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cce8239490cb3a7e00002e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NzIwNl85Mjc2MV9XNjQwSDM2MFM0MzIyMC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NzIwNl85Mjc2MV9XNjQwSDM2MFM0MzIyMC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cce8239490cb3a7e00002e&m=1473057210","list_dtime":"2016-09-05 11:35:02"},{"pk":"57ccbea97f52e94809000067","title":"董洁白裙淡雅，又美成了\u201c冷清秋\u201d！","date":"2016-09-05 09:09:33","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbea97f52e94809000067","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzkwM183ODY5OF9XNjQwSDM2MFMzMjI4NC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzkwM183ODY5OF9XNjQwSDM2MFMzMjI4NC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbea97f52e94809000067&m=1473057211","list_dtime":"2016-09-05 09:09:33"},{"pk":"57ccc9b11bc8e0240c000017","title":"焦恩俊为女儿庆生 大眼美女酷似高圆圆","title_line_break":"焦恩俊为女儿庆生\n大眼美女酷似高圆圆","date":"2016-09-05 09:29:44","auther_name":"网易图片","weburl":"http://iphone.myzaker.com/l.php?l=57ccc9b11bc8e0240c000017","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTAwNV80OTAzOF9XNjQwSDM2MFM0NjE1Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTAwNV80OTAzOF9XNjQwSDM2MFM0NjE1Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc9b11bc8e0240c000017&m=1473057211","list_dtime":"2016-09-05 09:29:44"},{"pk":"57ccbb5f9490cb6962000002","title":"路人撞脸明星 最后一张确定不是本人？","title_line_break":"路人撞脸明星\n最后一张确定不是本人？","date":"2016-09-05 09:15:47","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbb5f9490cb6962000002","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzODY4M182NzIzN19XNjQwSDM2MFMyOTA3Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzODY4M182NzIzN19XNjQwSDM2MFMyOTA3Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbb5f9490cb6962000002&m=1473057211","list_dtime":"2016-09-05 09:15:47"},{"pk":"57ccc9371bc8e0140c00000f","title":"好莱坞影业大佬向中国美女主播求婚","date":"2016-09-05 09:30:25","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccc9371bc8e0140c00000f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTA1MV82MDM4NV9XNjQwSDM2MFM2ODg5Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTA1MV82MDM4NV9XNjQwSDM2MFM2ODg5Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc9371bc8e0140c00000f&m=1473057210","list_dtime":"2016-09-05 09:30:25"},{"pk":"57cc925b9490cb1b09000000","title":"郭德纲回应曹云金：你不死我有什么办法","title_line_break":"郭德纲回应曹云金：\n你不死我有什么办法","date":"2016-09-05 07:51:52","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cc925b9490cb1b09000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbfe831bc8e08254000005_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbfe831bc8e08254000005_320.jpg","thumbnail_picsize":"500,497","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cc925b9490cb1b09000000&m=1473057211","list_dtime":"2016-09-05 07:51:52"},{"pk":"57cccbc79490cb6338000005","title":"吴彦祖和吴亦凡撞衫 该看哪个好？","title_line_break":"吴彦祖和吴亦凡撞衫\n该看哪个好？","date":"2016-09-05 09:38:47","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cccbc79490cb6338000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTYxOV81NDk3MV9XNjQwSDM2MFM4MzYzNy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTYxOV81NDk3MV9XNjQwSDM2MFM4MzYzNy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cccbc79490cb6338000005&m=1473057210","list_dtime":"2016-09-05 09:38:47"},{"pk":"57cccbc79490cb6338000008","title":"冉莹颖为袁咏仪庆生 轩轩带弟弟来祝福","title_line_break":"冉莹颖为袁咏仪庆生\n轩轩带弟弟来祝福","date":"2016-09-05 09:39:19","auther_name":"中国娱乐网","weburl":"http://iphone.myzaker.com/l.php?l=57cccbc79490cb6338000008","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTY1Nl82ODcxOV9XNjQwSDM2MFM2MTY2OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzOTY1Nl82ODcxOV9XNjQwSDM2MFM2MTY2OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cccbc79490cb6338000008&m=1473057210","list_dtime":"2016-09-05 09:39:19"},{"pk":"57ccc3949490cb050e000005","title":"王心凌又变脸了？无所谓，青春歌曲没变","date":"2016-09-05 09:03:45","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccc3949490cb050e000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzk2MF8yNjI5OV9XNjQwSDM2MFMzNzAyOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzk2MF8yNjI5OV9XNjQwSDM2MFMzNzAyOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc3949490cb050e000005&m=1473057211","list_dtime":"2016-09-05 09:03:45"},{"pk":"57ccc09a1bc8e02c0c000009","title":"林志玲言承旭共用经纪人 粉丝：舒淇婚了","title_line_break":"林志玲言承旭共用经纪人 粉丝：\n舒淇婚了","date":"2016-09-05 09:06:25","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccc09a1bc8e02c0c000009","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc0d7a07aecc52301cd0d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc0d7a07aecc52301cd0d_320.jpg","thumbnail_picsize":"587,430","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc09a1bc8e02c0c000009&m=1473057211","list_dtime":"2016-09-05 09:06:25"},{"pk":"57cc8a2a9490cb5f59000003","title":"杨钰莹近照化身美人鱼 装束大胆 ","date":"2016-09-05 09:22:08","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cc8a2a9490cb5f59000003","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzODYxN18yMjY5MF9XNjQwSDM2MFMzNTU2Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzODYxN18yMjY5MF9XNjQwSDM2MFMzNTU2Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cc8a2a9490cb5f59000003&m=1473057211","list_dtime":"2016-09-05 09:22:08"},{"pk":"57cc50bb9490cbec3d000000","title":"余文乐自爆心中女神 居然是她！","title_line_break":"余文乐自爆心中女神\n居然是她！","date":"2016-09-05 07:43:17","auther_name":"Yes娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cc50bb9490cbec3d000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc50781bc8e03b1500000a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc50781bc8e03b1500000a_320.jpg","thumbnail_picsize":"1289,884","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cc50bb9490cbec3d000000&m=1473057211","list_dtime":"2016-09-05 07:43:17"},{"pk":"57ccbb5f9490cb6962000006","title":"\u201c小白龙\u201d曝近照 曾遭张卫健\u201c痛打\u201d","title_line_break":"\u201c小白龙\u201d曝近照\n曾遭张卫健\u201c痛打\u201d","date":"2016-09-05 09:13:46","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbb5f9490cb6962000006","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYjkxYTFiYzhlMDc1NDkwMDAwMDFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYjkxYTFiYzhlMDc1NDkwMDAwMDFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,349","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbb5f9490cb6962000006&m=1473057211","list_dtime":"2016-09-05 09:13:46"},{"pk":"57ccd3fc9490cb8c64000000","title":"林志玲看到范冰冰超兴奋 大呼\u201c女神\u201d","title_line_break":"林志玲看到范冰冰超兴奋\n大呼\u201c女神\u201d","date":"2016-09-05 10:10:04","auther_name":"19楼娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd3fc9490cb8c64000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd0e61bc8e0c75700003a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd0e61bc8e0c75700003a_320.jpg","thumbnail_picsize":"600,339","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccd3fc9490cb8c64000000&m=1473057210","list_dtime":"2016-09-05 10:10:04"},{"pk":"57ccbeab7f52e96e6900004b","title":"袁咏仪过生日超幸福 老公送包儿子送抱","title_line_break":"袁咏仪过生日超幸福\n老公送包儿子送抱","date":"2016-09-05 09:10:28","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbeab7f52e96e6900004b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzg3MV84MzAzMV9XNjQwSDM2MFM2MzAxMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzg3MV84MzAzMV9XNjQwSDM2MFM2MzAxMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbeab7f52e96e6900004b&m=1473057211","list_dtime":"2016-09-05 09:10:28"},{"pk":"57cccc381bc8e0160c000023","title":"还是要相信爱情啊！混蛋们","date":"2016-09-05 10:36:56","auther_name":"新周刊","weburl":"http://iphone.myzaker.com/l.php?l=57cccc381bc8e0160c000023","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NzE4MV83NTU0Nl9XNjQwSDM2MFM1NjMyNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NzE4MV83NTU0Nl9XNjQwSDM2MFM1NjMyNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cccc381bc8e0160c000023&m=1473057210","list_dtime":"2016-09-05 10:36:56"},{"pk":"57cca82aa07aece76f00003d","title":"曝张艺兴抱鞠婧祎下腰11次引粉丝不满","date":"2016-09-05 07:33:22","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cca82aa07aece76f00003d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzMzIxOV85NDc5M19XNjQwSDM2MFM3MTc5NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzMzIxOV85NDc5M19XNjQwSDM2MFM3MTc5NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cca82aa07aece76f00003d&m=1473057211","list_dtime":"2016-09-05 07:33:22"},{"pk":"57ccbeab7f52e9480900006f","title":"张艺谋导G20晚会获赞 妻子发文祝贺","title_line_break":"张艺谋导G20晚会获赞\n妻子发文祝贺","date":"2016-09-05 09:07:39","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbeab7f52e9480900006f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzkyMl84MTgxMV9XNjQwSDM2MFM0ODgzNi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzkyMl84MTgxMV9XNjQwSDM2MFM0ODgzNi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbeab7f52e9480900006f&m=1473057211","list_dtime":"2016-09-05 09:07:39"},{"pk":"57cc40539490cb7864000006","title":"李孝利：嫁给爱情的她把日子过成诗","title_line_break":"李孝利：\n嫁给爱情的她把日子过成诗","date":"2016-09-05 07:53:48","auther_name":"芭莎娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cc40539490cb7864000006","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NiZGZmOTdmNTJlOTJjMDgwMDAwZjBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NiZGZmOTdmNTJlOTJjMDgwMDAwZjBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,346","media_count":"20","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cc40539490cb7864000006&m=1473057211","list_dtime":"2016-09-05 07:53:48"},{"pk":"57ccc3949490cb050e000000","title":"娱乐圈腿精明星 逆天长腿堪比模特","title_line_break":"娱乐圈腿精明星\n逆天长腿堪比模特","date":"2016-09-05 09:01:25","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccc3949490cb050e000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzM3N184ODUxX1c2NDBIMzYwUzQ5MTU3LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzNzM3N184ODUxX1c2NDBIMzYwUzQ5MTU3LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc3949490cb050e000000&m=1473057211","list_dtime":"2016-09-05 09:01:25"},{"pk":"57cc2fec9490cbc513000003","title":"惊！日本偶像男团玩4P致少女怀孕","date":"2016-09-05 07:46:01","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cc2fec9490cbc513000003","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjMjAwZjFiYzhlMDk5NmIwMDAwMzNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjMjAwZjFiYzhlMDk5NmIwMDAwMzNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,375","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cc2fec9490cbc513000003&m=1473057211","list_dtime":"2016-09-05 07:46:01"},{"pk":"57ccba347f52e94809000023","title":"王思聪炮轰大张伟抄袭：硬着头皮不承认","title_line_break":"王思聪炮轰大张伟抄袭：\n硬着头皮不承认","date":"2016-09-05 09:16:29","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccba347f52e94809000023","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccba337f52e94809000021_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccba337f52e94809000021_320.jpg","thumbnail_picsize":"598,597","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccba347f52e94809000023&m=1473057211","list_dtime":"2016-09-05 09:16:29"},{"pk":"57cd0c569490cbb94d000005","title":"辰亦儒自曝情史：与女友相聚无人发现","title_line_break":"辰亦儒自曝情史：\n与女友相聚无人发现","date":"2016-09-05 14:09:42","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cd0c569490cbb94d000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NjE3Nl81Nzk5OF9XNjQwSDM2MFM1MzY0My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NjE3Nl81Nzk5OF9XNjQwSDM2MFM1MzY0My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cd0c569490cbb94d000005&m=1473057210","list_dtime":"2016-09-05 14:09:42"},{"pk":"57ccc35a7f52e964090000f0","title":"陈意涵告白张钧甯：牵你手睡觉好满足！","title_line_break":"陈意涵告白张钧甯：\n牵你手睡觉好满足！","date":"2016-09-05 09:04:21","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccc35a7f52e964090000f0","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzk1NF8zOTA5NF9XNjQwSDM2MFM1MDUxNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzk1NF8zOTA5NF9XNjQwSDM2MFM1MDUxNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccc35a7f52e964090000f0&m=1473057211","list_dtime":"2016-09-05 09:04:21"},{"pk":"57cca3ee7f52e944050000d4","title":"小S听闻舒淇结婚：跟大S还蛮像的","title_line_break":"小S听闻舒淇结婚：\n跟大S还蛮像的","date":"2016-09-05 07:31:52","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cca3ee7f52e944050000d4","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYTNlZDdmNTJlOTQ0MDUwMDAwZDJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYTNlZDdmNTJlOTQ0MDUwMDAwZDJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"619,401","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57cca3ee7f52e944050000d4&m=1473057211","list_dtime":"2016-09-05 07:31:52"},{"pk":"57ccbb5f9490cb6962000000","title":"当红明星素颜照 你也可以很美","title_line_break":"当红明星素颜照\n你也可以很美","date":"2016-09-05 09:15:05","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccbb5f9490cb6962000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzODc1OF8yMDEyNF9XNjQwSDM2MFMyNDU4Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzAzODc1OF8yMDEyNF9XNjQwSDM2MFMyNDU4Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"20","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=57ccbb5f9490cb6962000000&m=1473057211","list_dtime":"2016-09-05 09:15:05"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cce3a09490cb3e7e000028,57ccf4c89490cb117e00004c,57cd02e09490cb227e000033,57ccc35a7f52e96e690000a1,57cce4649490cb3c3e000008,57cc56309490cbe07d000000","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ccbeab7f52e9480900006c,57ccb32b9490cb7a38000002,57cd05a61bc8e0180c000025,57cce8239490cb3a7e00002e,57ccbea97f52e94809000067,57ccc9b11bc8e0240c000017","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ccc9371bc8e0140c00000f,57ccbb5f9490cb6962000002,57cc925b9490cb1b09000000,57cccbc79490cb6338000005,57cccbc79490cb6338000008,57ccc3949490cb050e000005","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57cc8a2a9490cb5f59000003,57ccc09a1bc8e02c0c000009,57cc50bb9490cbec3d000000,57ccbb5f9490cb6962000006,57ccd3fc9490cb8c64000000,57ccbeab7f52e96e6900004b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57cca82aa07aece76f00003d,57cccc381bc8e0160c000023,57ccbeab7f52e9480900006f,57cc40539490cb7864000006,57ccc3949490cb050e000000,57cc2fec9490cbc513000003","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cd0c569490cbb94d000005,57ccba347f52e94809000023,57ccc35a7f52e964090000f0,57cca3ee7f52e944050000d4,571f28429490cbe70b000044,57ccbb5f9490cb6962000000","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#5700b9","#5700b9"],"only_text_page_bgcolors":["#5700b9","#5700b9"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/9.png?t=1457432249","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/9.png?t=1457432249","hidden_time":"24","need_userinfo":"NO","block_title":"娱乐八卦","block_color":"#5700b9","desktop_color_number":"20","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_e693be4a623b0f3966d75d6a4e67a749","selected_index":"0","list":[{"pk":"zk_app_column_9","title":"娱乐","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_10530","title":"电影","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"10530_zk_app_column_block_9","title":"电影资讯","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=10530&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_11698","title":"电视","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11698_zk_app_column_block_9","title":"电视","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11698&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_12348","title":"明星","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12348_zk_app_column_block_9","title":"明星","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12348&catalog_appid=9","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=9&since_date=1472951978&nt=1&next_aticle_id=57cc8a2a9490cb5f59000007&_appid=androidphone&opage=2&otimestamp=177
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=9&need_app_integration=0
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=9&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,5472a9b69490cb48180000f9,51a7104681853dec4d00012f&k=201609051440
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/9.png?t=1457432249
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/9.png?t=1457432249
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 娱乐八卦
         * block_color : #5700b9
         * desktop_color_number : 20
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_e693be4a623b0f3966d75d6a4e67a749
         * selected_index : 0
         * list : [{"pk":"zk_app_column_9","title":"娱乐","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_10530","title":"电影","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"10530_zk_app_column_block_9","title":"电影资讯","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=10530&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_11698","title":"电视","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11698_zk_app_column_block_9","title":"电视","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11698&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_12348","title":"明星","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12348_zk_app_column_block_9","title":"明星","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12348&catalog_appid=9","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 571f28429490cbe70b000044
         * title : 2016《超级女声》正在进行中
         * date : 2016-04-26 16:34:15
         * auther_name : ZAKER娱乐
         * page : 6
         * index : 5
         * weburl : http://iphone.myzaker.com/l.php?l=571f28429490cbe70b000044
         * media_count : 0
         * is_full : NO
         * content :
         * special_type : topic
         * special_info : {"icon_type":"1","block_info":{"pk":"571874639490cb8c50000003","block_title":"2016超级女声","title":"2016超级女声","block_in_title":"2016《超级女声》正在进行中","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=9&topic_id=571874639490cb8c50000003&updated=1472807552"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=9&pk=571f28429490cbe70b000044&m=1473057304
         * list_dtime : 2016-04-26 16:34:15
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;


            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 1
             * articles : 57cce3a09490cb3e7e000028,57ccf4c89490cb117e00004c,57cd02e09490cb227e000033,57ccc35a7f52e96e690000a1,57cce4649490cb3c3e000008,57cc56309490cbe07d000000
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * open_type :
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_9
             * title : 娱乐
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 9
                 * title : 娱乐八卦
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9
                 * data_type : news
                 * skey : eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;
                    private String skey;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }

                    public String getSkey() {
                        return skey;
                    }

                    public void setSkey(String skey) {
                        this.skey = skey;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String media_count;
            private String is_full;
            private String content;
            private String special_type,thumbnail_pic;

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            /**
             * icon_type : 1
             * block_info : {"pk":"571874639490cb8c50000003","block_title":"2016超级女声","title":"2016超级女声","block_in_title":"2016《超级女声》正在进行中","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=9&topic_id=571874639490cb8c50000003&updated=1472807552"}
             * icon_url : http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getSpecial_type() {
                return special_type;
            }

            public void setSpecial_type(String special_type) {
                this.special_type = special_type;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String icon_type;
                /**
                 * pk : 571874639490cb8c50000003
                 * block_title : 2016超级女声
                 * title : 2016超级女声
                 * block_in_title : 2016《超级女声》正在进行中
                 * type : user
                 * need_userinfo : NO
                 * skey :
                 * api_url : http://iphone.myzaker.com/zaker/topic.php?app_id=9&topic_id=571874639490cb8c50000003&updated=1472807552
                 */

                private BlockInfoBean block_info;
                private String icon_url;
                private String show_jingcai;
                private String list_nodsp;

                public String getIcon_type() {
                    return icon_type;
                }

                public void setIcon_type(String icon_type) {
                    this.icon_type = icon_type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public String getIcon_url() {
                    return icon_url;
                }

                public void setIcon_url(String icon_url) {
                    this.icon_url = icon_url;
                }

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }

                public static class BlockInfoBean {
                    private String pk;
                    private String block_title;
                    private String title;
                    private String block_in_title;
                    private String type;
                    private String need_userinfo;
                    private String skey;
                    private String api_url;

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getBlock_title() {
                        return block_title;
                    }

                    public void setBlock_title(String block_title) {
                        this.block_title = block_title;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getBlock_in_title() {
                        return block_in_title;
                    }

                    public void setBlock_in_title(String block_in_title) {
                        this.block_in_title = block_in_title;
                    }

                    public String getType() {
                        return type;
                    }

                    public void setType(String type) {
                        this.type = type;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getSkey() {
                        return skey;
                    }

                    public void setSkey(String skey) {
                        this.skey = skey;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }
                }
            }
        }
    }
}
