package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/3.
 */
public class Bean_fashion {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=12&since_date=1472680800&nt=1&next_aticle_id=57c58a307f780be067005e0f&_appid=androidphone&opage=2&otimestamp=180","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=12&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,51a7104681853dec4d00012f&k=201609031450"},"catalog":"","articles":[{"pk":"57c7e7aa9490cbab2c000073","title":"最新鲜热辣的明星街拍，在这你都找得到","date":"2016-09-01 16:32:00","auther_name":"海报时尚网","page":"4","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c7e7aa9490cbab2c000073","tpl_group":"titleCenter","tpl_style":"1","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"block","block_info":{"pk":"11316","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=11316","data_type":"rss"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=12&app_ids=12&pk=57c7e7aa9490cbab2c000073&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c7e7aa9490cbab2c000073","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c7e7aa9490cbab2c000073&m=1472885403","list_dtime":"2016-09-01 16:32:00"},{"pk":"57c94bea9490cbf717000077","title":"如何挑选牛仔裤？有关牛仔裤的6条迷思","date":"2016-09-03 06:00:00","auther_name":"ELLE时尚","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c94bea9490cbf717000077","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWY5ZmEwN2FlYzEzNTIwMDMxMDNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWY5ZmEwN2FlYzEzNTIwMDMxMDNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,351","media_count":"23","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c94bea9490cbf717000077&m=1472885633","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c54f419490cb8b13000076","title":"是时候买买买了！好看的包包这里全都有","date":"2016-09-03 06:00:00","auther_name":"VOGUE时尚","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c54f419490cb8b13000076","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MDYwOF83NjM1MF9XNjQwSDM2MFM2MjE5NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MDYwOF83NjM1MF9XNjQwSDM2MFM2MjE5NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"57","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c54f419490cb8b13000076&m=1472885633","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c694cf1bc8e0b61700003b","title":"500块的鞋穿到烂，刘诗诗的爱很专一","date":"2016-09-03 06:00:00","auther_name":"时尚芭莎","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c694cf1bc8e0b61700003b","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3MjgzMjA5MF82ODkzNl9XNjQwSDM2MFM2MDg0Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3MjgzMjA5MF82ODkzNl9XNjQwSDM2MFM2MDg0Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"52","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c694cf1bc8e0b61700003b&m=1472885633","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57ca4a789490cbe13e000032","title":"娜扎直播被批丑 女星直播画风大不同","title_line_break":"娜扎直播被批丑\n女星直播画风大不同","date":"2016-09-03 11:58:01","auther_name":"乱弹时尚圈 ","weburl":"http://iphone.myzaker.com/l.php?l=57ca4a789490cbe13e000032","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca4a81a07aecc5230081c7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca4a81a07aecc5230081c7_320.jpg","thumbnail_picsize":"670,850","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca4a789490cbe13e000032&m=1472885371","list_dtime":"2016-09-03 11:58:01"},{"pk":"57ca4e469490cb1a3f000045","title":"闺蜜抢我男人，我睡闺蜜儿子","date":"2016-09-03 12:13:05","auther_name":"新氧","weburl":"http://iphone.myzaker.com/l.php?l=57ca4e469490cb1a3f000045","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca4e4ca07aecc523008407_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca4e4ca07aecc523008407_320.jpg","thumbnail_picsize":"494,289","media_count":"56","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca4e469490cb1a3f000045&m=1472885371","list_dtime":"2016-09-03 12:13:05"},{"pk":"57ca4a3f9490cbd93e00003e","title":"她们一家剪衣服露bra成瘾！","date":"2016-09-03 11:56:50","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ca4a3f9490cbd93e00003e","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca4a4fa07aecc5230081bc_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca4a4fa07aecc5230081bc_320.jpg","thumbnail_picsize":"600,902","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca4a3f9490cbd93e00003e&m=1472885371","list_dtime":"2016-09-03 11:56:50"},{"pk":"57c9782c7f780bf00f00102e","title":"蹭红毯蹭得这么脱俗，张雨绮是第一个","date":"2016-09-03 08:03:58","auther_name":"时尚怪谈","weburl":"http://iphone.myzaker.com/l.php?l=57c9782c7f780bf00f00102e","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c921d7a07aecc5230004f8_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c921d7a07aecc5230004f8_320.jpg","thumbnail_picsize":"1024,1538","media_count":"30","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c9782c7f780bf00f00102e&m=1472885371","list_dtime":"2016-09-03 08:03:58"},{"pk":"57c9dc7f7f780b14110002b8","title":"我才不是因为颜值高而喜欢她","date":"2016-09-03 11:41:51","auther_name":"FashionWeek","weburl":"http://iphone.myzaker.com/l.php?l=57c9dc7f7f780b14110002b8","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9dc817f52e9d13b000058_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9dc817f52e9d13b000058_320.jpg","thumbnail_picsize":"700,1050","media_count":"35","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c9dc7f7f780b14110002b8&m=1472885371","list_dtime":"2016-09-03 11:41:51"},{"pk":"57c92cc19490cb3818000056","title":"黄奕面部僵硬似蜡像，还真美不过金星！","date":"2016-09-03 06:00:00","auther_name":"辣妈时尚范","weburl":"http://iphone.myzaker.com/l.php?l=57c92cc19490cb3818000056","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c92cd07f52e9ee1e0000b4_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c92cd07f52e9ee1e0000b4_320.jpg","thumbnail_picsize":"640,909","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c92cc19490cb3818000056&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c99b6d1bc8e04975000019","title":"阿娇却告诉你胖还可以很美","date":"2016-09-03 07:59:59","auther_name":"YOKA服饰美容","weburl":"http://iphone.myzaker.com/l.php?l=57c99b6d1bc8e04975000019","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c99b6c1bc8e04975000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c99b6c1bc8e04975000000_320.jpg","thumbnail_picsize":"500,750","media_count":"25","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c99b6d1bc8e04975000019&m=1472885372","list_dtime":"2016-09-03 07:59:59"},{"pk":"57c92a389490cbe41700004d","title":"这样的柳岩，我用流量也要看完！","date":"2016-09-03 06:00:00","auther_name":"海报时尚网","weburl":"http://iphone.myzaker.com/l.php?l=57c92a389490cbe41700004d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c92a497f52e9d11f000056_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c92a497f52e9d11f000056_320.jpg","thumbnail_picsize":"485,313","media_count":"21","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12&pk=57c92a389490cbe41700004d&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c92a389490cbe41700004d%26app_id%3D12%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c92a389490cbe41700004d&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57ca4b169490cb003f000048","title":"我平胸我骄傲我穿衣服也有料！ ","title_line_break":"我平胸我骄傲我穿衣服也有料！\n","date":"2016-09-03 12:00:06","auther_name":"小红书App","weburl":"http://iphone.myzaker.com/l.php?l=57ca4b169490cb003f000048","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca4b1da07aecc523008322_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca4b1da07aecc523008322_320.jpg","thumbnail_picsize":"554,527","media_count":"30","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca4b169490cb003f000048&m=1472885371","list_dtime":"2016-09-03 12:00:06"},{"pk":"57ca49fc9490cb063f000020","title":"天使超模可儿泳装造型秀身材","date":"2016-09-03 11:56:14","auther_name":"腾讯时尚","weburl":"http://iphone.myzaker.com/l.php?l=57ca49fc9490cb063f000020","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca4a04a07aecc52300819c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca4a04a07aecc52300819c_320.jpg","thumbnail_picsize":"800,1200","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca49fc9490cb063f000020&m=1472885371","list_dtime":"2016-09-03 11:56:14"},{"pk":"57c803cb9490cbd52c000060","title":"刘诗诗换锁骨发时髦到飞起，快get！","date":"2016-09-03 06:00:00","auther_name":"新氧APP","weburl":"http://iphone.myzaker.com/l.php?l=57c803cb9490cbd52c000060","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c803df7f52e95556000124_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c803df7f52e95556000124_320.jpg","thumbnail_picsize":"700,432","media_count":"67","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c803cb9490cbd52c000060&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57ca19241bc8e04237000011","title":"2016年人气最高10大唇色","date":"2016-09-03 09:34:52","auther_name":"YOKA服饰美容","weburl":"http://iphone.myzaker.com/l.php?l=57ca19241bc8e04237000011","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca19221bc8e04237000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca19221bc8e04237000000_320.jpg","thumbnail_picsize":"600,775","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca19241bc8e04237000011&m=1472885371","list_dtime":"2016-09-03 09:34:52"},{"pk":"57ca199e7f780b14110003db","title":"带你走进北欧的小众又时髦的品牌","date":"2016-09-03 09:35:29","auther_name":"买手客Buyerkey","weburl":"http://iphone.myzaker.com/l.php?l=57ca199e7f780b14110003db","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca19a07f52e96837000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca19a07f52e96837000001_320.jpg","thumbnail_picsize":"640,420","media_count":"66","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca199e7f780b14110003db&m=1472885371","list_dtime":"2016-09-03 09:35:29"},{"pk":"57c98b457f780b1411000024","title":"这样的重口味美妆你会在秋天里来一发么","date":"2016-09-03 11:43:35","auther_name":"TOPWOMEN","weburl":"http://iphone.myzaker.com/l.php?l=57c98b457f780b1411000024","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c98b467f52e90908000075_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c98b467f52e90908000075_320.jpg","thumbnail_picsize":"638,956","media_count":"22","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c98b457f780b1411000024&m=1472885371","list_dtime":"2016-09-03 11:43:35"},{"pk":"57c55e469490cb5b27000070","title":"大S把500双高跟鞋打入冷宫变美百倍","date":"2016-09-03 06:00:00","auther_name":"她刊","weburl":"http://iphone.myzaker.com/l.php?l=57c55e469490cb5b27000070","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c55e577f52e93742000367_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c55e577f52e93742000367_320.jpg","thumbnail_picsize":"480,324","media_count":"47","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c55e469490cb5b27000070&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c838577f780bf00f0008a5","title":"年度收入最高女演员竟然是个90后？！","date":"2016-09-03 06:00:00","auther_name":"网易时尚","weburl":"http://iphone.myzaker.com/l.php?l=57c838577f780bf00f0008a5","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c838587f52e92f0a000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c838587f52e92f0a000000_320.jpg","thumbnail_picsize":"550,404","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c838577f780bf00f0008a5&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c7a28f1bc8e05f3400004d","title":"送你甜蜜百倍的情侣装套路，去约会吧！","date":"2016-09-03 06:00:00","auther_name":"YOKA服饰美容","weburl":"http://iphone.myzaker.com/l.php?l=57c7a28f1bc8e05f3400004d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a28d1bc8e05f3400002d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a28d1bc8e05f3400002d_320.jpg","thumbnail_picsize":"350,201","media_count":"32","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c7a28f1bc8e05f3400004d&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c970c81bc8e09158000050","title":"2017年最值得期待的年历\u201c抢钱\u201d预告","date":"2016-09-03 11:42:18","auther_name":"海报时尚网","weburl":"http://iphone.myzaker.com/l.php?l=57c970c81bc8e09158000050","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c970c61bc8e0915800001c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c970c61bc8e0915800001c_320.jpg","thumbnail_picsize":"600,579","media_count":"53","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c970c81bc8e09158000050&m=1472885371","list_dtime":"2016-09-03 11:42:18"},{"pk":"57c6416b1bc8e0b45d00002c","title":"你见哪个姑娘约会男神不穿条连衣裙？","date":"2016-09-03 06:00:00","auther_name":"凤凰时尚识装","weburl":"http://iphone.myzaker.com/l.php?l=57c6416b1bc8e0b45d00002c","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6416a1bc8e0b45d000010_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6416a1bc8e0b45d000010_320.jpg","thumbnail_picsize":"2731,4096","media_count":"27","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c6416b1bc8e0b45d00002c&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c92ac59490cbd617000049","title":"范爷会穿都知道，可她耳朵还能72变","date":"2016-09-03 06:00:00","auther_name":"ELLE时尚","weburl":"http://iphone.myzaker.com/l.php?l=57c92ac59490cbd617000049","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c92ad77f52e9e81f000055_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c92ad77f52e9e81f000055_320.jpg","thumbnail_picsize":"523,800","media_count":"37","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c92ac59490cbd617000049&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c63f251bc8e0b65e000000","title":"要减肥又停不住嘴？这些好吃还不贴秋膘","date":"2016-09-03 06:00:00","auther_name":"时尚芭莎","weburl":"http://iphone.myzaker.com/l.php?l=57c63f251bc8e0b65e000000","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c63b351bc8e0bc5b000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c63b351bc8e0bc5b000000_320.jpg","thumbnail_picsize":"208,139","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c63f251bc8e0b65e000000&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c7c0e69490cbdc2c000053","title":"过期化妆品如毒药，快检查一下梳妆台！","date":"2016-09-03 06:00:00","auther_name":"Twippo法国时尚","weburl":"http://iphone.myzaker.com/l.php?l=57c7c0e69490cbdc2c000053","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a6e4a07aecf77e044d24_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a6e4a07aecf77e044d24_320.jpg","thumbnail_picsize":"592,439","media_count":"37","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c7c0e69490cbdc2c000053&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c54d649490cbb11300007a","title":"这么拼的\u201c唇诱\u201d试色，掌声在哪里？！","date":"2016-09-03 06:00:00","auther_name":"美芽","weburl":"http://iphone.myzaker.com/l.php?l=57c54d649490cbb11300007a","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c54d727f52e93742000216_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c54d727f52e93742000216_320.jpg","thumbnail_picsize":"600,400","media_count":"19","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c54d649490cbb11300007a&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c916b69490cbf51700004d","title":"刘天仙露背尴尬，女神真的不能只看脸！","date":"2016-09-02 17:00:00","auther_name":"抹茶美妆","weburl":"http://iphone.myzaker.com/l.php?l=57c916b69490cbf51700004d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8ed047f52e9f77d000307_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8ed047f52e9f77d000307_320.jpg","thumbnail_picsize":"597,684","media_count":"18","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12&pk=57c916b69490cbf51700004d&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c916b69490cbf51700004d%26app_id%3D12%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c916b69490cbf51700004d&m=1472806953","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c7cd591bc8e0d853000005","title":"明天穿什么 | 你的连衣裙该配短靴啦","date":"2016-09-02 20:00:00","auther_name":"YOKA服饰美容","weburl":"http://iphone.myzaker.com/l.php?l=57c7cd591bc8e0d853000005","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7ca761bc8e05552000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7ca761bc8e05552000000_320.jpg","thumbnail_picsize":"600,901","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c7cd591bc8e0d853000005&m=1472885372","list_dtime":"2016-09-02 20:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c9213f9490cb0c1800003f","title":"这次张天爱用满满文艺范儿轰炸你的心！","date":"2016-09-02 17:00:00","auther_name":"凤凰时尚","weburl":"http://iphone.myzaker.com/l.php?l=57c9213f9490cb0c1800003f","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwMDE0NV8zMjQ5Ml9XNjQwSDM2MFM1MDUwMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwMDE0NV8zMjQ5Ml9XNjQwSDM2MFM1MDUwMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"30","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12&pk=57c9213f9490cb0c1800003f&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c9213f9490cb0c1800003f%26app_id%3D12%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c9213f9490cb0c1800003f&m=1472885372","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c8d9131bc8e0c17200004a","title":"从古装美人到清纯学妹，李沁从小美到大","date":"2016-09-02 17:00:00","auther_name":"凤凰时尚识装","weburl":"http://iphone.myzaker.com/l.php?l=57c8d9131bc8e0c17200004a","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d9121bc8e0c17200000c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d9121bc8e0c17200000c_320.jpg","thumbnail_picsize":"500,382","media_count":"32","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c8d9131bc8e0c17200004a&m=1472781143","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c800ae9490cbf12c000072","title":"这些化妆品都好羞耻，但是我好喜欢！","date":"2016-09-02 17:00:00","auther_name":"深夜发媸","weburl":"http://iphone.myzaker.com/l.php?l=57c800ae9490cbf12c000072","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwODM0Nl82NTQxN19XNjQwSDM2MFM0NzUyMi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwODM0Nl82NTQxN19XNjQwSDM2MFM0NzUyMi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"46","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c800ae9490cbf12c000072&m=1472808217","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c915aa9490cb3518000048","title":"藏肉手册：比你胖的姑娘穿衣可比你显瘦","title_line_break":"藏肉手册：\n比你胖的姑娘穿衣可比你显瘦","date":"2016-09-02 17:00:00","auther_name":"服装搭配","weburl":"http://iphone.myzaker.com/l.php?l=57c915aa9490cb3518000048","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c905b7a07aec1352003ded_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c905b7a07aec1352003ded_320.jpg","thumbnail_picsize":"600,807","media_count":"16","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c915aa9490cb3518000048&m=1472806951","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c95a7c9490cb1679000012","title":"好物：专治痘痘肌三十年，谁用谁知道","title_line_break":"好物：\n专治痘痘肌三十年，谁用谁知道","date":"2016-09-02 18:52:55","auther_name":"ZAKER","weburl":"http://iphone.myzaker.com/l.php?l=57c95a7c9490cb1679000012","tpl_group":"titleCenter","tpl_style":"1","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"post","post":{"pk":"57c83c881716cf0d190000ac","discussion_id":"181","auther":{"name":"二十三姨","uid":"10967830","user_flag":[{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user.png"}],"icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5484/10967830_1446456066.jpg.210.jpg"},"title":"","date":"2016-09-01 22:34:48","comment_count":"40","hot_num":"165","post_tag":[],"content":"今晚来讲讲我下巴烂掉（痘痘炸开了花）后的治疗方法🙈🙈\n\n肤质：敏感肌，夏季偏油，秋冬干巴巴\n\n爆痘痘原因：用了爱丽小屋的101高光以后就连环爆痘痘，没停过🙄🙄真的是和韩妆没办法好好相处了\n\n治疗爆痘的产品：\n悦诗风吟小绿瓶，科颜氏金盏花爽肤水，杜克色修，紫根油，miacare祛痘贴，美丽诺芦荟胶","medias":[{"type":"image","id":"57c83c8735a324af0f000277","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8735a324af0f000277.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8735a324af0f000277.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8735a324af0f000277.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8735a324af0f000277.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8735a324af0f000277.jpg"},{"type":"image","id":"57c83c8835a324770f0002d7","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8835a324770f0002d7.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8835a324770f0002d7.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8835a324770f0002d7.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8835a324770f0002d7.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8835a324770f0002d7.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=181&post_id=57c83c881716cf0d190000ac","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=181&post_id=57c83c881716cf0d190000ac&_appid=&_version=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=181&post_id=57c83c881716cf0d190000ac","discussion":{"pk":"181","title":"我们都爱化妆品","stitle":"化妆护肤不分贵贱，效果是王道！","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd425b9490cb107b0000ee.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd425b9490cb107b0000ee.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=181","block_color":"","subscribe_count":"210634","post_count":"11459"},"need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=12&app_ids=12&pk=57c95a7c9490cb1679000012&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c95a7c9490cb1679000012","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c95a7c9490cb1679000012&m=1472885372","list_dtime":"2016-09-02 18:52:55"},{"pk":"57c912f49490cb1818000033","title":"想要留住少女脸，就别对这个世界太走心","date":"2016-09-02 17:00:00","auther_name":" 她生活","weburl":"http://iphone.myzaker.com/l.php?l=57c912f49490cb1818000033","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6cc077f52e9d64600023a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6cc077f52e9d64600023a_320.jpg","thumbnail_picsize":"463,348","media_count":"13","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c912f49490cb1818000033&m=1472806952","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c7c2c99490cb8b2c000032","title":"漂亮的请都靠边儿站！丑萌鞋子再度来袭","date":"2016-09-02 17:00:00","auther_name":"BOMODA","weburl":"http://iphone.myzaker.com/l.php?l=57c7c2c99490cb8b2c000032","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNzMxMl82MTM3NV9XNjQwSDM2MFM0Mjk3OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNzMxMl82MTM3NV9XNjQwSDM2MFM0Mjk3OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"49","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c7c2c99490cb8b2c000032&m=1472807366","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c694cf1bc8e0b61700003b,57ca4a789490cbe13e000032,57ca4e469490cb1a3f000045,57ca4a3f9490cbd93e00003e,57c9782c7f780bf00f00102e,57c9dc7f7f780b14110002b8","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c94bea9490cbf717000077,57c92cc19490cb3818000056,57c99b6d1bc8e04975000019,57c92a389490cbe41700004d,57ca4b169490cb003f000048,57ca49fc9490cb063f000020","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c54f419490cb8b13000076,57c803cb9490cbd52c000060,57ca19241bc8e04237000011,57ca199e7f780b14110003db,57c98b457f780b1411000024,57c55e469490cb5b27000070","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c7a28f1bc8e05f3400004d,57c838577f780bf00f0008a5,57c970c81bc8e09158000050,57c6416b1bc8e0b45d00002c,57c92ac59490cbd617000049,57c7e7aa9490cbab2c000073","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c7c0e69490cbdc2c000053,57c63f251bc8e0b65e000000,57c54d649490cbb11300007a,57c916b69490cbf51700004d,57c7cd591bc8e0d853000005,57c9213f9490cb0c1800003f","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c800ae9490cbf12c000072,57c8d9131bc8e0c17200004a,57c915aa9490cb3518000048,57c95a7c9490cb1679000012,57c912f49490cb1818000033,57c7c2c99490cb8b2c000032","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}}],"article_block_colors":["#1d1d1d","#1d1d1d"],"only_text_page_bgcolors":["#1d1d1d","#1d1d1d"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12.png?1383291556","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12.png?1383291556","hidden_time":"24","need_userinfo":"NO","block_title":"时尚频道","block_color":"#1d1d1d","desktop_color_number":"12","use_original_icon":"N"}}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=12&since_date=1472680800&nt=1&next_aticle_id=57c58a307f780be067005e0f&_appid=androidphone&opage=2&otimestamp=180","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=12&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,51a7104681853dec4d00012f&k=201609031450"}
     * catalog :
     * articles : [{"pk":"57c7e7aa9490cbab2c000073","title":"最新鲜热辣的明星街拍，在这你都找得到","date":"2016-09-01 16:32:00","auther_name":"海报时尚网","page":"4","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c7e7aa9490cbab2c000073","tpl_group":"titleCenter","tpl_style":"1","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"block","block_info":{"pk":"11316","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=11316","data_type":"rss"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=12&app_ids=12&pk=57c7e7aa9490cbab2c000073&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c7e7aa9490cbab2c000073","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c7e7aa9490cbab2c000073&m=1472885403","list_dtime":"2016-09-01 16:32:00"},{"pk":"57c94bea9490cbf717000077","title":"如何挑选牛仔裤？有关牛仔裤的6条迷思","date":"2016-09-03 06:00:00","auther_name":"ELLE时尚","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c94bea9490cbf717000077","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWY5ZmEwN2FlYzEzNTIwMDMxMDNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWY5ZmEwN2FlYzEzNTIwMDMxMDNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,351","media_count":"23","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c94bea9490cbf717000077&m=1472885633","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c54f419490cb8b13000076","title":"是时候买买买了！好看的包包这里全都有","date":"2016-09-03 06:00:00","auther_name":"VOGUE时尚","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c54f419490cb8b13000076","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MDYwOF83NjM1MF9XNjQwSDM2MFM2MjE5NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MDYwOF83NjM1MF9XNjQwSDM2MFM2MjE5NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"57","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c54f419490cb8b13000076&m=1472885633","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c694cf1bc8e0b61700003b","title":"500块的鞋穿到烂，刘诗诗的爱很专一","date":"2016-09-03 06:00:00","auther_name":"时尚芭莎","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c694cf1bc8e0b61700003b","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3MjgzMjA5MF82ODkzNl9XNjQwSDM2MFM2MDg0Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3MjgzMjA5MF82ODkzNl9XNjQwSDM2MFM2MDg0Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"52","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c694cf1bc8e0b61700003b&m=1472885633","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57ca4a789490cbe13e000032","title":"娜扎直播被批丑 女星直播画风大不同","title_line_break":"娜扎直播被批丑\n女星直播画风大不同","date":"2016-09-03 11:58:01","auther_name":"乱弹时尚圈 ","weburl":"http://iphone.myzaker.com/l.php?l=57ca4a789490cbe13e000032","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca4a81a07aecc5230081c7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca4a81a07aecc5230081c7_320.jpg","thumbnail_picsize":"670,850","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca4a789490cbe13e000032&m=1472885371","list_dtime":"2016-09-03 11:58:01"},{"pk":"57ca4e469490cb1a3f000045","title":"闺蜜抢我男人，我睡闺蜜儿子","date":"2016-09-03 12:13:05","auther_name":"新氧","weburl":"http://iphone.myzaker.com/l.php?l=57ca4e469490cb1a3f000045","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca4e4ca07aecc523008407_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca4e4ca07aecc523008407_320.jpg","thumbnail_picsize":"494,289","media_count":"56","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca4e469490cb1a3f000045&m=1472885371","list_dtime":"2016-09-03 12:13:05"},{"pk":"57ca4a3f9490cbd93e00003e","title":"她们一家剪衣服露bra成瘾！","date":"2016-09-03 11:56:50","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ca4a3f9490cbd93e00003e","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca4a4fa07aecc5230081bc_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca4a4fa07aecc5230081bc_320.jpg","thumbnail_picsize":"600,902","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca4a3f9490cbd93e00003e&m=1472885371","list_dtime":"2016-09-03 11:56:50"},{"pk":"57c9782c7f780bf00f00102e","title":"蹭红毯蹭得这么脱俗，张雨绮是第一个","date":"2016-09-03 08:03:58","auther_name":"时尚怪谈","weburl":"http://iphone.myzaker.com/l.php?l=57c9782c7f780bf00f00102e","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c921d7a07aecc5230004f8_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c921d7a07aecc5230004f8_320.jpg","thumbnail_picsize":"1024,1538","media_count":"30","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c9782c7f780bf00f00102e&m=1472885371","list_dtime":"2016-09-03 08:03:58"},{"pk":"57c9dc7f7f780b14110002b8","title":"我才不是因为颜值高而喜欢她","date":"2016-09-03 11:41:51","auther_name":"FashionWeek","weburl":"http://iphone.myzaker.com/l.php?l=57c9dc7f7f780b14110002b8","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9dc817f52e9d13b000058_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9dc817f52e9d13b000058_320.jpg","thumbnail_picsize":"700,1050","media_count":"35","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c9dc7f7f780b14110002b8&m=1472885371","list_dtime":"2016-09-03 11:41:51"},{"pk":"57c92cc19490cb3818000056","title":"黄奕面部僵硬似蜡像，还真美不过金星！","date":"2016-09-03 06:00:00","auther_name":"辣妈时尚范","weburl":"http://iphone.myzaker.com/l.php?l=57c92cc19490cb3818000056","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c92cd07f52e9ee1e0000b4_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c92cd07f52e9ee1e0000b4_320.jpg","thumbnail_picsize":"640,909","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c92cc19490cb3818000056&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c99b6d1bc8e04975000019","title":"阿娇却告诉你胖还可以很美","date":"2016-09-03 07:59:59","auther_name":"YOKA服饰美容","weburl":"http://iphone.myzaker.com/l.php?l=57c99b6d1bc8e04975000019","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c99b6c1bc8e04975000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c99b6c1bc8e04975000000_320.jpg","thumbnail_picsize":"500,750","media_count":"25","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c99b6d1bc8e04975000019&m=1472885372","list_dtime":"2016-09-03 07:59:59"},{"pk":"57c92a389490cbe41700004d","title":"这样的柳岩，我用流量也要看完！","date":"2016-09-03 06:00:00","auther_name":"海报时尚网","weburl":"http://iphone.myzaker.com/l.php?l=57c92a389490cbe41700004d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c92a497f52e9d11f000056_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c92a497f52e9d11f000056_320.jpg","thumbnail_picsize":"485,313","media_count":"21","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12&pk=57c92a389490cbe41700004d&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c92a389490cbe41700004d%26app_id%3D12%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c92a389490cbe41700004d&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57ca4b169490cb003f000048","title":"我平胸我骄傲我穿衣服也有料！ ","title_line_break":"我平胸我骄傲我穿衣服也有料！\n","date":"2016-09-03 12:00:06","auther_name":"小红书App","weburl":"http://iphone.myzaker.com/l.php?l=57ca4b169490cb003f000048","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca4b1da07aecc523008322_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca4b1da07aecc523008322_320.jpg","thumbnail_picsize":"554,527","media_count":"30","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca4b169490cb003f000048&m=1472885371","list_dtime":"2016-09-03 12:00:06"},{"pk":"57ca49fc9490cb063f000020","title":"天使超模可儿泳装造型秀身材","date":"2016-09-03 11:56:14","auther_name":"腾讯时尚","weburl":"http://iphone.myzaker.com/l.php?l=57ca49fc9490cb063f000020","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca4a04a07aecc52300819c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca4a04a07aecc52300819c_320.jpg","thumbnail_picsize":"800,1200","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca49fc9490cb063f000020&m=1472885371","list_dtime":"2016-09-03 11:56:14"},{"pk":"57c803cb9490cbd52c000060","title":"刘诗诗换锁骨发时髦到飞起，快get！","date":"2016-09-03 06:00:00","auther_name":"新氧APP","weburl":"http://iphone.myzaker.com/l.php?l=57c803cb9490cbd52c000060","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c803df7f52e95556000124_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c803df7f52e95556000124_320.jpg","thumbnail_picsize":"700,432","media_count":"67","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c803cb9490cbd52c000060&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57ca19241bc8e04237000011","title":"2016年人气最高10大唇色","date":"2016-09-03 09:34:52","auther_name":"YOKA服饰美容","weburl":"http://iphone.myzaker.com/l.php?l=57ca19241bc8e04237000011","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca19221bc8e04237000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca19221bc8e04237000000_320.jpg","thumbnail_picsize":"600,775","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca19241bc8e04237000011&m=1472885371","list_dtime":"2016-09-03 09:34:52"},{"pk":"57ca199e7f780b14110003db","title":"带你走进北欧的小众又时髦的品牌","date":"2016-09-03 09:35:29","auther_name":"买手客Buyerkey","weburl":"http://iphone.myzaker.com/l.php?l=57ca199e7f780b14110003db","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca19a07f52e96837000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca19a07f52e96837000001_320.jpg","thumbnail_picsize":"640,420","media_count":"66","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57ca199e7f780b14110003db&m=1472885371","list_dtime":"2016-09-03 09:35:29"},{"pk":"57c98b457f780b1411000024","title":"这样的重口味美妆你会在秋天里来一发么","date":"2016-09-03 11:43:35","auther_name":"TOPWOMEN","weburl":"http://iphone.myzaker.com/l.php?l=57c98b457f780b1411000024","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c98b467f52e90908000075_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c98b467f52e90908000075_320.jpg","thumbnail_picsize":"638,956","media_count":"22","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c98b457f780b1411000024&m=1472885371","list_dtime":"2016-09-03 11:43:35"},{"pk":"57c55e469490cb5b27000070","title":"大S把500双高跟鞋打入冷宫变美百倍","date":"2016-09-03 06:00:00","auther_name":"她刊","weburl":"http://iphone.myzaker.com/l.php?l=57c55e469490cb5b27000070","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c55e577f52e93742000367_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c55e577f52e93742000367_320.jpg","thumbnail_picsize":"480,324","media_count":"47","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c55e469490cb5b27000070&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c838577f780bf00f0008a5","title":"年度收入最高女演员竟然是个90后？！","date":"2016-09-03 06:00:00","auther_name":"网易时尚","weburl":"http://iphone.myzaker.com/l.php?l=57c838577f780bf00f0008a5","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c838587f52e92f0a000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c838587f52e92f0a000000_320.jpg","thumbnail_picsize":"550,404","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c838577f780bf00f0008a5&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c7a28f1bc8e05f3400004d","title":"送你甜蜜百倍的情侣装套路，去约会吧！","date":"2016-09-03 06:00:00","auther_name":"YOKA服饰美容","weburl":"http://iphone.myzaker.com/l.php?l=57c7a28f1bc8e05f3400004d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a28d1bc8e05f3400002d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a28d1bc8e05f3400002d_320.jpg","thumbnail_picsize":"350,201","media_count":"32","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c7a28f1bc8e05f3400004d&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c970c81bc8e09158000050","title":"2017年最值得期待的年历\u201c抢钱\u201d预告","date":"2016-09-03 11:42:18","auther_name":"海报时尚网","weburl":"http://iphone.myzaker.com/l.php?l=57c970c81bc8e09158000050","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c970c61bc8e0915800001c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c970c61bc8e0915800001c_320.jpg","thumbnail_picsize":"600,579","media_count":"53","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c970c81bc8e09158000050&m=1472885371","list_dtime":"2016-09-03 11:42:18"},{"pk":"57c6416b1bc8e0b45d00002c","title":"你见哪个姑娘约会男神不穿条连衣裙？","date":"2016-09-03 06:00:00","auther_name":"凤凰时尚识装","weburl":"http://iphone.myzaker.com/l.php?l=57c6416b1bc8e0b45d00002c","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6416a1bc8e0b45d000010_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6416a1bc8e0b45d000010_320.jpg","thumbnail_picsize":"2731,4096","media_count":"27","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c6416b1bc8e0b45d00002c&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c92ac59490cbd617000049","title":"范爷会穿都知道，可她耳朵还能72变","date":"2016-09-03 06:00:00","auther_name":"ELLE时尚","weburl":"http://iphone.myzaker.com/l.php?l=57c92ac59490cbd617000049","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c92ad77f52e9e81f000055_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c92ad77f52e9e81f000055_320.jpg","thumbnail_picsize":"523,800","media_count":"37","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c92ac59490cbd617000049&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c63f251bc8e0b65e000000","title":"要减肥又停不住嘴？这些好吃还不贴秋膘","date":"2016-09-03 06:00:00","auther_name":"时尚芭莎","weburl":"http://iphone.myzaker.com/l.php?l=57c63f251bc8e0b65e000000","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c63b351bc8e0bc5b000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c63b351bc8e0bc5b000000_320.jpg","thumbnail_picsize":"208,139","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c63f251bc8e0b65e000000&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c7c0e69490cbdc2c000053","title":"过期化妆品如毒药，快检查一下梳妆台！","date":"2016-09-03 06:00:00","auther_name":"Twippo法国时尚","weburl":"http://iphone.myzaker.com/l.php?l=57c7c0e69490cbdc2c000053","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a6e4a07aecf77e044d24_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a6e4a07aecf77e044d24_320.jpg","thumbnail_picsize":"592,439","media_count":"37","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c7c0e69490cbdc2c000053&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c54d649490cbb11300007a","title":"这么拼的\u201c唇诱\u201d试色，掌声在哪里？！","date":"2016-09-03 06:00:00","auther_name":"美芽","weburl":"http://iphone.myzaker.com/l.php?l=57c54d649490cbb11300007a","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c54d727f52e93742000216_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c54d727f52e93742000216_320.jpg","thumbnail_picsize":"600,400","media_count":"19","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c54d649490cbb11300007a&m=1472885372","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c916b69490cbf51700004d","title":"刘天仙露背尴尬，女神真的不能只看脸！","date":"2016-09-02 17:00:00","auther_name":"抹茶美妆","weburl":"http://iphone.myzaker.com/l.php?l=57c916b69490cbf51700004d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8ed047f52e9f77d000307_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8ed047f52e9f77d000307_320.jpg","thumbnail_picsize":"597,684","media_count":"18","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12&pk=57c916b69490cbf51700004d&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c916b69490cbf51700004d%26app_id%3D12%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c916b69490cbf51700004d&m=1472806953","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c7cd591bc8e0d853000005","title":"明天穿什么 | 你的连衣裙该配短靴啦","date":"2016-09-02 20:00:00","auther_name":"YOKA服饰美容","weburl":"http://iphone.myzaker.com/l.php?l=57c7cd591bc8e0d853000005","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7ca761bc8e05552000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7ca761bc8e05552000000_320.jpg","thumbnail_picsize":"600,901","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c7cd591bc8e0d853000005&m=1472885372","list_dtime":"2016-09-02 20:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c9213f9490cb0c1800003f","title":"这次张天爱用满满文艺范儿轰炸你的心！","date":"2016-09-02 17:00:00","auther_name":"凤凰时尚","weburl":"http://iphone.myzaker.com/l.php?l=57c9213f9490cb0c1800003f","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwMDE0NV8zMjQ5Ml9XNjQwSDM2MFM1MDUwMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwMDE0NV8zMjQ5Ml9XNjQwSDM2MFM1MDUwMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"30","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=12&pk=57c9213f9490cb0c1800003f&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c9213f9490cb0c1800003f%26app_id%3D12%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c9213f9490cb0c1800003f&m=1472885372","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c8d9131bc8e0c17200004a","title":"从古装美人到清纯学妹，李沁从小美到大","date":"2016-09-02 17:00:00","auther_name":"凤凰时尚识装","weburl":"http://iphone.myzaker.com/l.php?l=57c8d9131bc8e0c17200004a","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d9121bc8e0c17200000c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d9121bc8e0c17200000c_320.jpg","thumbnail_picsize":"500,382","media_count":"32","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c8d9131bc8e0c17200004a&m=1472781143","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c800ae9490cbf12c000072","title":"这些化妆品都好羞耻，但是我好喜欢！","date":"2016-09-02 17:00:00","auther_name":"深夜发媸","weburl":"http://iphone.myzaker.com/l.php?l=57c800ae9490cbf12c000072","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwODM0Nl82NTQxN19XNjQwSDM2MFM0NzUyMi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwODM0Nl82NTQxN19XNjQwSDM2MFM0NzUyMi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"46","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c800ae9490cbf12c000072&m=1472808217","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c915aa9490cb3518000048","title":"藏肉手册：比你胖的姑娘穿衣可比你显瘦","title_line_break":"藏肉手册：\n比你胖的姑娘穿衣可比你显瘦","date":"2016-09-02 17:00:00","auther_name":"服装搭配","weburl":"http://iphone.myzaker.com/l.php?l=57c915aa9490cb3518000048","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c905b7a07aec1352003ded_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c905b7a07aec1352003ded_320.jpg","thumbnail_picsize":"600,807","media_count":"16","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c915aa9490cb3518000048&m=1472806951","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c95a7c9490cb1679000012","title":"好物：专治痘痘肌三十年，谁用谁知道","title_line_break":"好物：\n专治痘痘肌三十年，谁用谁知道","date":"2016-09-02 18:52:55","auther_name":"ZAKER","weburl":"http://iphone.myzaker.com/l.php?l=57c95a7c9490cb1679000012","tpl_group":"titleCenter","tpl_style":"1","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"post","post":{"pk":"57c83c881716cf0d190000ac","discussion_id":"181","auther":{"name":"二十三姨","uid":"10967830","user_flag":[{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user.png"}],"icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5484/10967830_1446456066.jpg.210.jpg"},"title":"","date":"2016-09-01 22:34:48","comment_count":"40","hot_num":"165","post_tag":[],"content":"今晚来讲讲我下巴烂掉（痘痘炸开了花）后的治疗方法🙈🙈\n\n肤质：敏感肌，夏季偏油，秋冬干巴巴\n\n爆痘痘原因：用了爱丽小屋的101高光以后就连环爆痘痘，没停过🙄🙄真的是和韩妆没办法好好相处了\n\n治疗爆痘的产品：\n悦诗风吟小绿瓶，科颜氏金盏花爽肤水，杜克色修，紫根油，miacare祛痘贴，美丽诺芦荟胶","medias":[{"type":"image","id":"57c83c8735a324af0f000277","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8735a324af0f000277.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8735a324af0f000277.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8735a324af0f000277.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8735a324af0f000277.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8735a324af0f000277.jpg"},{"type":"image","id":"57c83c8835a324770f0002d7","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8835a324770f0002d7.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8835a324770f0002d7.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8835a324770f0002d7.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8835a324770f0002d7.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c8835a324770f0002d7.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=181&post_id=57c83c881716cf0d190000ac","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=181&post_id=57c83c881716cf0d190000ac&_appid=&_version=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=181&post_id=57c83c881716cf0d190000ac","discussion":{"pk":"181","title":"我们都爱化妆品","stitle":"化妆护肤不分贵贱，效果是王道！","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd425b9490cb107b0000ee.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd425b9490cb107b0000ee.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=181","block_color":"","subscribe_count":"210634","post_count":"11459"},"need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=12&app_ids=12&pk=57c95a7c9490cb1679000012&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c95a7c9490cb1679000012","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c95a7c9490cb1679000012&m=1472885372","list_dtime":"2016-09-02 18:52:55"},{"pk":"57c912f49490cb1818000033","title":"想要留住少女脸，就别对这个世界太走心","date":"2016-09-02 17:00:00","auther_name":" 她生活","weburl":"http://iphone.myzaker.com/l.php?l=57c912f49490cb1818000033","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6cc077f52e9d64600023a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6cc077f52e9d64600023a_320.jpg","thumbnail_picsize":"463,348","media_count":"13","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c912f49490cb1818000033&m=1472806952","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c7c2c99490cb8b2c000032","title":"漂亮的请都靠边儿站！丑萌鞋子再度来袭","date":"2016-09-02 17:00:00","auther_name":"BOMODA","weburl":"http://iphone.myzaker.com/l.php?l=57c7c2c99490cb8b2c000032","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNzMxMl82MTM3NV9XNjQwSDM2MFM0Mjk3OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNzMxMl82MTM3NV9XNjQwSDM2MFM0Mjk3OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"49","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c7c2c99490cb8b2c000032&m=1472807366","list_dtime":"2016-09-02 17:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c694cf1bc8e0b61700003b,57ca4a789490cbe13e000032,57ca4e469490cb1a3f000045,57ca4a3f9490cbd93e00003e,57c9782c7f780bf00f00102e,57c9dc7f7f780b14110002b8","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c94bea9490cbf717000077,57c92cc19490cb3818000056,57c99b6d1bc8e04975000019,57c92a389490cbe41700004d,57ca4b169490cb003f000048,57ca49fc9490cb063f000020","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c54f419490cb8b13000076,57c803cb9490cbd52c000060,57ca19241bc8e04237000011,57ca199e7f780b14110003db,57c98b457f780b1411000024,57c55e469490cb5b27000070","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c7a28f1bc8e05f3400004d,57c838577f780bf00f0008a5,57c970c81bc8e09158000050,57c6416b1bc8e0b45d00002c,57c92ac59490cbd617000049,57c7e7aa9490cbab2c000073","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c7c0e69490cbdc2c000053,57c63f251bc8e0b65e000000,57c54d649490cbb11300007a,57c916b69490cbf51700004d,57c7cd591bc8e0d853000005,57c9213f9490cb0c1800003f","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c800ae9490cbf12c000072,57c8d9131bc8e0c17200004a,57c915aa9490cb3518000048,57c95a7c9490cb1679000012,57c912f49490cb1818000033,57c7c2c99490cb8b2c000032","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}}],"article_block_colors":["#1d1d1d","#1d1d1d"],"only_text_page_bgcolors":["#1d1d1d","#1d1d1d"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12.png?1383291556","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12.png?1383291556","hidden_time":"24","need_userinfo":"NO","block_title":"时尚频道","block_color":"#1d1d1d","desktop_color_number":"12","use_original_icon":"N"}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=12&since_date=1472680800&nt=1&next_aticle_id=57c58a307f780be067005e0f&_appid=androidphone&opage=2&otimestamp=180
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=12&need_app_integration=0
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,51a7104681853dec4d00012f&k=201609031450
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/12.png?1383291556
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/12.png?1383291556
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 时尚频道
         * block_color : #1d1d1d
         * desktop_color_number : 12
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57c7e7aa9490cbab2c000073
         * title : 最新鲜热辣的明星街拍，在这你都找得到
         * date : 2016-09-01 16:32:00
         * auther_name : 海报时尚网
         * page : 4
         * index : 6
         * weburl : http://iphone.myzaker.com/l.php?l=57c7e7aa9490cbab2c000073
         * tpl_group : titleCenter
         * tpl_style : 1
         * media_count : 0
         * is_full : NO
         * content :
         * type : other
         * special_info : {"open_type":"block","block_info":{"pk":"11316","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=11316","data_type":"rss"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=12&app_ids=12&pk=57c7e7aa9490cbab2c000073&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c7e7aa9490cbab2c000073","show_jingcai":"Y","list_nodsp":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12&pk=57c7e7aa9490cbab2c000073&m=1472885403
         * list_dtime : 2016-09-01 16:32:00
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 1
             * articles : 57c694cf1bc8e0b61700003b,57ca4a789490cbe13e000032,57ca4e469490cb1a3f000045,57ca4a3f9490cbd93e00003e,57c9782c7f780bf00f00102e,57c9dc7f7f780b14110002b8
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/12.png?1418971244
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String tpl_group;
            private String tpl_style;
            private String media_count;
            private String is_full;
            private String content;
            private String type,thumbnail_pic;

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            /**
             * open_type : block
             * block_info : {"pk":"11316","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=11316","data_type":"rss"}
             * stat_click_url : http://stat.myzaker.com/stat.php?app_id=12&app_ids=12&pk=57c7e7aa9490cbab2c000073&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c7e7aa9490cbab2c000073
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getTpl_group() {
                return tpl_group;
            }

            public void setTpl_group(String tpl_group) {
                this.tpl_group = tpl_group;
            }

            public String getTpl_style() {
                return tpl_style;
            }

            public void setTpl_style(String tpl_style) {
                this.tpl_style = tpl_style;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String open_type;
                /**
                 * pk : 11316
                 * api_url : http://iphone.myzaker.com/zaker/news.php?app_id=11316
                 * data_type : rss
                 */

                private BlockInfoBean block_info;
                private String stat_click_url;
                private String show_jingcai;
                private String list_nodsp;

                public String getOpen_type() {
                    return open_type;
                }

                public void setOpen_type(String open_type) {
                    this.open_type = open_type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public String getStat_click_url() {
                    return stat_click_url;
                }

                public void setStat_click_url(String stat_click_url) {
                    this.stat_click_url = stat_click_url;
                }

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }

                public static class BlockInfoBean {
                    private String pk;
                    private String api_url;
                    private String data_type;

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }
                }
            }
        }
    }
}
