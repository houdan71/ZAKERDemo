package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/2.
 */
public class Bean_foodie {

    /**
     * stat : 1
     * msg : ok
     * data : {"discussion_info":{"pk":"2","title":"颤抖吧，吃货！","stitle":"拥抱美食和吃货!","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2015/06/04/55700ba69490cbc01a00008b.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2015/06/04/55700ba69490cbc01a00008b.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=2","block_color":"","subscribe_count":"575724","post_count":"24874"},"info":{"pre_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=2&timestamp=1472781243.6755&order=111&act=pre&order_type=last_comment","next_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=2&timestamp=1472783849.7720&order=0&act=next&order_type=last_comment"},"posts":[{"pk":"57c78e101716cf62030000c8","discussion_id":"2","auther":{"name":"小左撇仔","uid":"10686883","user_flag":[{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user_flag.png"}],"icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5344/10686883_1467165266.jpg.210.jpg"},"title":"","date":"2016-09-01 10:10:24","content":"#处女月# ☀️🎏调和剂～～～","comment_count":"80","hot_num":"4341","like_num":"65","post_tag":[{"name":"置顶","icon":"http://zkres.myzaker.com/data/image/mark2/stick3_2x.png"}],"list_tip":["247 热度","80 回复"],"list_date":"2016-09-02 09:54:03","thumbnail_medias":[{"type":"image","id":"57c78e101716cf63030000d0","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg"},{"type":"image","id":"57c78e101716cf18030000e3","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg"},{"type":"image","id":"57c78e101716cf4a030000cd","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg"}],"medias":[{"type":"image","id":"57c78e101716cf63030000d0","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg"},{"type":"image","id":"57c78e101716cf18030000e3","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg"},{"type":"image","id":"57c78e101716cf4a030000cd","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c78e101716cf62030000c8","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c78e101716cf62030000c8&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c78e101716cf62030000c8","is_top":"1","special_info":{"item_type":"3","medias_count":"3"},"is_liked":"0"},{"pk":"57c85f5935a324281200022d","discussion_id":"2","auther":{"name":"Χ . 小冉 .","uid":"10470708","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5236/10470708_1445488234.jpg.210.jpg"},"title":"","date":"2016-09-02 01:03:21","content":"第一次做月饼，刚烤好的，等两天后回油，再看怎样\u2026","comment_count":"8","hot_num":"424","like_num":"4","post_tag":[],"list_tip":["34 热度","8 回复"],"list_date":"2016-09-02 10:44:23","thumbnail_medias":[{"type":"image","id":"57c85f5935a324ee110001d4","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg"},{"type":"image","id":"57c85f591716cf681a0001cb","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg"}],"medias":[{"type":"image","id":"57c85f5935a324ee110001d4","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg"},{"type":"image","id":"57c85f591716cf681a0001cb","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c85f5935a324281200022d","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c85f5935a324281200022d&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c85f5935a324281200022d","special_info":{"item_type":"2","medias_count":"2"},"is_liked":"0"},{"pk":"57c8e73f1716cfaf3600032d","discussion_id":"2","auther":{"name":"风一样的oba","uid":"684754","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2014/343/684754_1419302092.jpg.210.jpg"},"title":"","date":"2016-09-02 10:43:11","content":"吃吃吃，能吃是福😁😁😁","comment_count":"0","hot_num":"5","like_num":"0","post_tag":[],"list_tip":["1 热度","0 回复"],"list_date":"2016-09-02 10:43:11","thumbnail_medias":[{"type":"image","id":"57c8e73e35a324e51700039f","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg"},{"type":"image","id":"57c8e73e1716cf6e3600031e","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg"},{"type":"image","id":"57c8e73f1716cf9c36000373","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg"},{"type":"image","id":"57c8e73f1716cfcb36000358","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg"}],"medias":[{"type":"image","id":"57c8e73e35a324e51700039f","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg"},{"type":"image","id":"57c8e73e1716cf6e3600031e","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg"},{"type":"image","id":"57c8e73f1716cf9c36000373","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg"},{"type":"image","id":"57c8e73f1716cfcb36000358","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c8e73f1716cfaf3600032d","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c8e73f1716cfaf3600032d&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c8e73f1716cfaf3600032d","special_info":{"item_type":"1","medias_count":"4"},"is_liked":"0"},{"pk":"57c8448735a324ea100000d0","discussion_id":"2","auther":{"name":"~宠兒~","uid":"2064785","icon":"http://q.qlogo.cn/qqapp/100318686/37E27E60DB031E052FCE1F33925BA3CB/40"},"title":"","date":"2016-09-01 23:08:55","content":"海鲜锅。。。来点毒。。。","comment_count":"5","hot_num":"410","like_num":"6","post_tag":[],"list_tip":["43 热度","5 回复"],"list_date":"2016-09-02 10:42:52","thumbnail_medias":[{"type":"image","id":"57c8448635a324ec100000f5","w":"1280","h":"960","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg"},{"type":"image","id":"57c844871716cfb0180001e7","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg"}],"medias":[{"type":"image","id":"57c8448635a324ec100000f5","w":"1280","h":"960","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg"},{"type":"image","id":"57c844871716cfb0180001e7","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c8448735a324ea100000d0","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c8448735a324ea100000d0&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c8448735a324ea100000d0","special_info":{"item_type":"2","medias_count":"2"},"is_liked":"0"},{"pk":"57c8d4a235a324be17000099","discussion_id":"2","auther":{"name":"M元寳","uid":"11670384","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5836/11670384_1472438988.jpg.210.jpg"},"title":"","date":"2016-09-02 09:23:46","content":"早，好吃的肉桂香橙卷，不熟悉新烤箱被烤得太黑，还好很好吃","comment_count":"2","hot_num":"117","like_num":"3","post_tag":[],"list_tip":["10 热度","2 回复"],"list_date":"2016-09-02 10:42:21","thumbnail_medias":[{"type":"image","id":"57c8d4a235a324ab170000c8","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg"}],"medias":[{"type":"image","id":"57c8d4a235a324ab170000c8","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c8d4a235a324be17000099","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c8d4a235a324be17000099&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c8d4a235a324be17000099","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c83c361716cf0c19000087","discussion_id":"2","auther":{"name":"幸幸人","uid":"10676370","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5339/10676370_1471331772.jpg.210.jpg"},"title":"","date":"2016-09-01 22:33:26","content":"用一顿饭的味蕾来感慨十年的青葱岁月。","comment_count":"5","hot_num":"370","like_num":"3","post_tag":[],"list_tip":["37 热度","5 回复"],"list_date":"2016-09-02 10:41:57","thumbnail_medias":[{"type":"image","id":"57c83c351716cf12190000c1","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg"},{"type":"image","id":"57c83c351716cfb8180000b8","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg"},{"type":"image","id":"57c83c3535a324a10f000260","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg"},{"type":"image","id":"57c83c361716cfcb180000d2","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg"}],"medias":[{"type":"image","id":"57c83c351716cf12190000c1","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg"},{"type":"image","id":"57c83c351716cfb8180000b8","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg"},{"type":"image","id":"57c83c3535a324a10f000260","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg"},{"type":"image","id":"57c83c361716cfcb180000d2","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c83c361716cf0c19000087","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c83c361716cf0c19000087&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c83c361716cf0c19000087","special_info":{"item_type":"1","medias_count":"4"},"is_liked":"0"},{"pk":"57c8d8e635a324bb17000154","discussion_id":"2","auther":{"name":"调羹是勺子","uid":"10154186","icon":"http://tp1.sinaimg.cn/1795606284/50/5725116085/0"},"title":"","date":"2016-09-02 09:41:58","content":"自己做的 量大份足👍🏻","comment_count":"2","hot_num":"96","like_num":"2","post_tag":[],"list_tip":["9 热度","2 回复"],"list_date":"2016-09-02 10:41:14","thumbnail_medias":[{"type":"image","id":"57c8d8e635a3241418000182","w":"1616","h":"1080","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg"},{"type":"image","id":"57c8d8e61716cfa9360001b3","w":"1616","h":"1080","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg"}],"medias":[{"type":"image","id":"57c8d8e635a3241418000182","w":"1616","h":"1080","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg"},{"type":"image","id":"57c8d8e61716cfa9360001b3","w":"1616","h":"1080","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c8d8e635a324bb17000154","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c8d8e635a324bb17000154&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c8d8e635a324bb17000154","special_info":{"item_type":"2","medias_count":"2"},"is_liked":"0"},{"pk":"57c8c25c35a324af16000116","discussion_id":"2","auther":{"name":"zcl1528816","uid":"863744","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/432/863744_1425039589.jpg.210.jpg"},"title":"","date":"2016-09-02 08:05:48","content":"把酸奶放进冷冻室需要几个步骤😄","comment_count":"3","hot_num":"169","like_num":"1","post_tag":[],"list_tip":["19 热度","3 回复"],"list_date":"2016-09-02 10:40:16","thumbnail_medias":[{"type":"image","id":"57c8c25c1716cfaf340002e5","w":"900","h":"1600","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg"}],"medias":[{"type":"image","id":"57c8c25c1716cfaf340002e5","w":"900","h":"1600","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c8c25c35a324af16000116","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c8c25c35a324af16000116&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c8c25c35a324af16000116","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c8e13f1716cfc136000293","discussion_id":"2","auther":{"name":"异乡的赌徒","uid":"10096787","icon":"http://q.qlogo.cn/qqapp/100318686/4495EFC76D288C02491DC012224BC2E6/40"},"title":"","date":"2016-09-02 10:17:35","content":"听说你想吃啤酒鸭～","comment_count":"1","hot_num":"61","like_num":"1","post_tag":[],"list_tip":["4 热度","1 回复"],"list_date":"2016-09-02 10:39:54","thumbnail_medias":[{"type":"image","id":"57c8e13f1716cfb03600024b","w":"1722","h":"1423","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg"}],"medias":[{"type":"image","id":"57c8e13f1716cfb03600024b","w":"1722","h":"1423","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c8e13f1716cfc136000293","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c8e13f1716cfc136000293&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c8e13f1716cfc136000293","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c7bcfd1716cf3008000070","discussion_id":"2","auther":{"name":"-木子。","uid":"11488972","icon":"http://zkres.myzaker.com/data/image/discussion/img/anonymous_avatar.png"},"title":"","date":"2016-09-01 13:30:37","content":"#每天一些事# 有些东西只仅限于好看，","comment_count":"4","hot_num":"779","like_num":"5","post_tag":[],"list_tip":["40 热度","4 回复"],"list_date":"2016-09-02 10:37:29","thumbnail_medias":[{"type":"image","id":"57c7bcfd1716cf710800008d","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg"}],"medias":[{"type":"image","id":"57c7bcfd1716cf710800008d","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c7bcfd1716cf3008000070","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c7bcfd1716cf3008000070&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c7bcfd1716cf3008000070","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"}]}
     */

    private String stat;
    private String msg;
    /**
     * discussion_info : {"pk":"2","title":"颤抖吧，吃货！","stitle":"拥抱美食和吃货!","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2015/06/04/55700ba69490cbc01a00008b.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2015/06/04/55700ba69490cbc01a00008b.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=2","block_color":"","subscribe_count":"575724","post_count":"24874"}
     * info : {"pre_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=2&timestamp=1472781243.6755&order=111&act=pre&order_type=last_comment","next_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=2&timestamp=1472783849.7720&order=0&act=next&order_type=last_comment"}
     * posts : [{"pk":"57c78e101716cf62030000c8","discussion_id":"2","auther":{"name":"小左撇仔","uid":"10686883","user_flag":[{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user_flag.png"}],"icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5344/10686883_1467165266.jpg.210.jpg"},"title":"","date":"2016-09-01 10:10:24","content":"#处女月# ☀️🎏调和剂～～～","comment_count":"80","hot_num":"4341","like_num":"65","post_tag":[{"name":"置顶","icon":"http://zkres.myzaker.com/data/image/mark2/stick3_2x.png"}],"list_tip":["247 热度","80 回复"],"list_date":"2016-09-02 09:54:03","thumbnail_medias":[{"type":"image","id":"57c78e101716cf63030000d0","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg"},{"type":"image","id":"57c78e101716cf18030000e3","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg"},{"type":"image","id":"57c78e101716cf4a030000cd","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg"}],"medias":[{"type":"image","id":"57c78e101716cf63030000d0","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg"},{"type":"image","id":"57c78e101716cf18030000e3","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg"},{"type":"image","id":"57c78e101716cf4a030000cd","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c78e101716cf62030000c8","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c78e101716cf62030000c8&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c78e101716cf62030000c8","is_top":"1","special_info":{"item_type":"3","medias_count":"3"},"is_liked":"0"},{"pk":"57c85f5935a324281200022d","discussion_id":"2","auther":{"name":"Χ . 小冉 .","uid":"10470708","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5236/10470708_1445488234.jpg.210.jpg"},"title":"","date":"2016-09-02 01:03:21","content":"第一次做月饼，刚烤好的，等两天后回油，再看怎样\u2026","comment_count":"8","hot_num":"424","like_num":"4","post_tag":[],"list_tip":["34 热度","8 回复"],"list_date":"2016-09-02 10:44:23","thumbnail_medias":[{"type":"image","id":"57c85f5935a324ee110001d4","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg"},{"type":"image","id":"57c85f591716cf681a0001cb","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg"}],"medias":[{"type":"image","id":"57c85f5935a324ee110001d4","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f5935a324ee110001d4.jpg"},{"type":"image","id":"57c85f591716cf681a0001cb","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c85f591716cf681a0001cb.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c85f5935a324281200022d","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c85f5935a324281200022d&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c85f5935a324281200022d","special_info":{"item_type":"2","medias_count":"2"},"is_liked":"0"},{"pk":"57c8e73f1716cfaf3600032d","discussion_id":"2","auther":{"name":"风一样的oba","uid":"684754","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2014/343/684754_1419302092.jpg.210.jpg"},"title":"","date":"2016-09-02 10:43:11","content":"吃吃吃，能吃是福😁😁😁","comment_count":"0","hot_num":"5","like_num":"0","post_tag":[],"list_tip":["1 热度","0 回复"],"list_date":"2016-09-02 10:43:11","thumbnail_medias":[{"type":"image","id":"57c8e73e35a324e51700039f","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg"},{"type":"image","id":"57c8e73e1716cf6e3600031e","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg"},{"type":"image","id":"57c8e73f1716cf9c36000373","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg"},{"type":"image","id":"57c8e73f1716cfcb36000358","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg"}],"medias":[{"type":"image","id":"57c8e73e35a324e51700039f","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e35a324e51700039f.jpg"},{"type":"image","id":"57c8e73e1716cf6e3600031e","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73e1716cf6e3600031e.jpg"},{"type":"image","id":"57c8e73f1716cf9c36000373","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cf9c36000373.jpg"},{"type":"image","id":"57c8e73f1716cfcb36000358","w":"972","h":"1728","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e73f1716cfcb36000358.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c8e73f1716cfaf3600032d","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c8e73f1716cfaf3600032d&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c8e73f1716cfaf3600032d","special_info":{"item_type":"1","medias_count":"4"},"is_liked":"0"},{"pk":"57c8448735a324ea100000d0","discussion_id":"2","auther":{"name":"~宠兒~","uid":"2064785","icon":"http://q.qlogo.cn/qqapp/100318686/37E27E60DB031E052FCE1F33925BA3CB/40"},"title":"","date":"2016-09-01 23:08:55","content":"海鲜锅。。。来点毒。。。","comment_count":"5","hot_num":"410","like_num":"6","post_tag":[],"list_tip":["43 热度","5 回复"],"list_date":"2016-09-02 10:42:52","thumbnail_medias":[{"type":"image","id":"57c8448635a324ec100000f5","w":"1280","h":"960","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg"},{"type":"image","id":"57c844871716cfb0180001e7","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg"}],"medias":[{"type":"image","id":"57c8448635a324ec100000f5","w":"1280","h":"960","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8448635a324ec100000f5.jpg"},{"type":"image","id":"57c844871716cfb0180001e7","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c844871716cfb0180001e7.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c8448735a324ea100000d0","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c8448735a324ea100000d0&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c8448735a324ea100000d0","special_info":{"item_type":"2","medias_count":"2"},"is_liked":"0"},{"pk":"57c8d4a235a324be17000099","discussion_id":"2","auther":{"name":"M元寳","uid":"11670384","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5836/11670384_1472438988.jpg.210.jpg"},"title":"","date":"2016-09-02 09:23:46","content":"早，好吃的肉桂香橙卷，不熟悉新烤箱被烤得太黑，还好很好吃","comment_count":"2","hot_num":"117","like_num":"3","post_tag":[],"list_tip":["10 热度","2 回复"],"list_date":"2016-09-02 10:42:21","thumbnail_medias":[{"type":"image","id":"57c8d4a235a324ab170000c8","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg"}],"medias":[{"type":"image","id":"57c8d4a235a324ab170000c8","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d4a235a324ab170000c8.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c8d4a235a324be17000099","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c8d4a235a324be17000099&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c8d4a235a324be17000099","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c83c361716cf0c19000087","discussion_id":"2","auther":{"name":"幸幸人","uid":"10676370","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5339/10676370_1471331772.jpg.210.jpg"},"title":"","date":"2016-09-01 22:33:26","content":"用一顿饭的味蕾来感慨十年的青葱岁月。","comment_count":"5","hot_num":"370","like_num":"3","post_tag":[],"list_tip":["37 热度","5 回复"],"list_date":"2016-09-02 10:41:57","thumbnail_medias":[{"type":"image","id":"57c83c351716cf12190000c1","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg"},{"type":"image","id":"57c83c351716cfb8180000b8","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg"},{"type":"image","id":"57c83c3535a324a10f000260","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg"},{"type":"image","id":"57c83c361716cfcb180000d2","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg"}],"medias":[{"type":"image","id":"57c83c351716cf12190000c1","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cf12190000c1.jpg"},{"type":"image","id":"57c83c351716cfb8180000b8","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c351716cfb8180000b8.jpg"},{"type":"image","id":"57c83c3535a324a10f000260","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c3535a324a10f000260.jpg"},{"type":"image","id":"57c83c361716cfcb180000d2","w":"960","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c83c361716cfcb180000d2.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c83c361716cf0c19000087","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c83c361716cf0c19000087&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c83c361716cf0c19000087","special_info":{"item_type":"1","medias_count":"4"},"is_liked":"0"},{"pk":"57c8d8e635a324bb17000154","discussion_id":"2","auther":{"name":"调羹是勺子","uid":"10154186","icon":"http://tp1.sinaimg.cn/1795606284/50/5725116085/0"},"title":"","date":"2016-09-02 09:41:58","content":"自己做的 量大份足👍🏻","comment_count":"2","hot_num":"96","like_num":"2","post_tag":[],"list_tip":["9 热度","2 回复"],"list_date":"2016-09-02 10:41:14","thumbnail_medias":[{"type":"image","id":"57c8d8e635a3241418000182","w":"1616","h":"1080","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg"},{"type":"image","id":"57c8d8e61716cfa9360001b3","w":"1616","h":"1080","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg"}],"medias":[{"type":"image","id":"57c8d8e635a3241418000182","w":"1616","h":"1080","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e635a3241418000182.jpg"},{"type":"image","id":"57c8d8e61716cfa9360001b3","w":"1616","h":"1080","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8d8e61716cfa9360001b3.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c8d8e635a324bb17000154","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c8d8e635a324bb17000154&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c8d8e635a324bb17000154","special_info":{"item_type":"2","medias_count":"2"},"is_liked":"0"},{"pk":"57c8c25c35a324af16000116","discussion_id":"2","auther":{"name":"zcl1528816","uid":"863744","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/432/863744_1425039589.jpg.210.jpg"},"title":"","date":"2016-09-02 08:05:48","content":"把酸奶放进冷冻室需要几个步骤😄","comment_count":"3","hot_num":"169","like_num":"1","post_tag":[],"list_tip":["19 热度","3 回复"],"list_date":"2016-09-02 10:40:16","thumbnail_medias":[{"type":"image","id":"57c8c25c1716cfaf340002e5","w":"900","h":"1600","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg"}],"medias":[{"type":"image","id":"57c8c25c1716cfaf340002e5","w":"900","h":"1600","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8c25c1716cfaf340002e5.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c8c25c35a324af16000116","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c8c25c35a324af16000116&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c8c25c35a324af16000116","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c8e13f1716cfc136000293","discussion_id":"2","auther":{"name":"异乡的赌徒","uid":"10096787","icon":"http://q.qlogo.cn/qqapp/100318686/4495EFC76D288C02491DC012224BC2E6/40"},"title":"","date":"2016-09-02 10:17:35","content":"听说你想吃啤酒鸭～","comment_count":"1","hot_num":"61","like_num":"1","post_tag":[],"list_tip":["4 热度","1 回复"],"list_date":"2016-09-02 10:39:54","thumbnail_medias":[{"type":"image","id":"57c8e13f1716cfb03600024b","w":"1722","h":"1423","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg"}],"medias":[{"type":"image","id":"57c8e13f1716cfb03600024b","w":"1722","h":"1423","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e13f1716cfb03600024b.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c8e13f1716cfc136000293","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c8e13f1716cfc136000293&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c8e13f1716cfc136000293","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c7bcfd1716cf3008000070","discussion_id":"2","auther":{"name":"-木子。","uid":"11488972","icon":"http://zkres.myzaker.com/data/image/discussion/img/anonymous_avatar.png"},"title":"","date":"2016-09-01 13:30:37","content":"#每天一些事# 有些东西只仅限于好看，","comment_count":"4","hot_num":"779","like_num":"5","post_tag":[],"list_tip":["40 热度","4 回复"],"list_date":"2016-09-02 10:37:29","thumbnail_medias":[{"type":"image","id":"57c7bcfd1716cf710800008d","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg"}],"medias":[{"type":"image","id":"57c7bcfd1716cf710800008d","w":"1706","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7bcfd1716cf710800008d.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c7bcfd1716cf3008000070","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c7bcfd1716cf3008000070&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c7bcfd1716cf3008000070","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"}]
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * pk : 2
         * title : 颤抖吧，吃货！
         * stitle : 拥抱美食和吃货!
         * pic : http://disres.myzaker.com/img_upload/discussion/disicon/2015/06/04/55700ba69490cbc01a00008b.png
         * large_pic : http://disres.myzaker.com/img_upload/discussion/disicon/2015/06/04/55700ba69490cbc01a00008b.png
         * api_url : http://dis.myzaker.com/api/get_post.php?discussion_id=2
         * block_color :
         * subscribe_count : 575724
         * post_count : 24874
         */

        private DiscussionInfoBean discussion_info;
        /**
         * pre_url : http://dis.myzaker.com/api/get_post.php?discussion_id=2&timestamp=1472781243.6755&order=111&act=pre&order_type=last_comment
         * next_url : http://dis.myzaker.com/api/get_post.php?discussion_id=2&timestamp=1472783849.7720&order=0&act=next&order_type=last_comment
         */

        private InfoBean info;
        /**
         * pk : 57c78e101716cf62030000c8
         * discussion_id : 2
         * auther : {"name":"小左撇仔","uid":"10686883","user_flag":[{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user_flag.png"}],"icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5344/10686883_1467165266.jpg.210.jpg"}
         * title :
         * date : 2016-09-01 10:10:24
         * content : #处女月# ☀️🎏调和剂～～～
         * comment_count : 80
         * hot_num : 4341
         * like_num : 65
         * post_tag : [{"name":"置顶","icon":"http://zkres.myzaker.com/data/image/mark2/stick3_2x.png"}]
         * list_tip : ["247 热度","80 回复"]
         * list_date : 2016-09-02 09:54:03
         * thumbnail_medias : [{"type":"image","id":"57c78e101716cf63030000d0","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg"},{"type":"image","id":"57c78e101716cf18030000e3","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg"},{"type":"image","id":"57c78e101716cf4a030000cd","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg"}]
         * medias : [{"type":"image","id":"57c78e101716cf63030000d0","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg"},{"type":"image","id":"57c78e101716cf18030000e3","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf18030000e3.jpg"},{"type":"image","id":"57c78e101716cf4a030000cd","w":"1280","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf4a030000cd.jpg"}]
         * weburl : http://dis.myzaker.com/api/l.php?discussion_id=2&post_id=57c78e101716cf62030000c8
         * content_url : http://dis.myzaker.com/api/view_post.php?discussion_id=2&post_id=57c78e101716cf62030000c8&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=
         * comment_list_url : http://dis.myzaker.com/api/get_comment.php?discussion_id=2&post_id=57c78e101716cf62030000c8
         * is_top : 1
         * special_info : {"item_type":"3","medias_count":"3"}
         * is_liked : 0
         */

        private List<PostsBean> posts;

        public DiscussionInfoBean getDiscussion_info() {
            return discussion_info;
        }

        public void setDiscussion_info(DiscussionInfoBean discussion_info) {
            this.discussion_info = discussion_info;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public List<PostsBean> getPosts() {
            return posts;
        }

        public void setPosts(List<PostsBean> posts) {
            this.posts = posts;
        }

        public static class DiscussionInfoBean {
            private String pk;
            private String title;
            private String stitle;
            private String pic;
            private String large_pic;
            private String api_url;
            private String block_color;
            private String subscribe_count;
            private String post_count;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getApi_url() {
                return api_url;
            }

            public void setApi_url(String api_url) {
                this.api_url = api_url;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getSubscribe_count() {
                return subscribe_count;
            }

            public void setSubscribe_count(String subscribe_count) {
                this.subscribe_count = subscribe_count;
            }

            public String getPost_count() {
                return post_count;
            }

            public void setPost_count(String post_count) {
                this.post_count = post_count;
            }
        }

        public static class InfoBean {
            private String pre_url;
            private String next_url;

            public String getPre_url() {
                return pre_url;
            }

            public void setPre_url(String pre_url) {
                this.pre_url = pre_url;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }
        }

        public static class PostsBean {
            private String pk;
            private String discussion_id;
            /**
             * name : 小左撇仔
             * uid : 10686883
             * user_flag : [{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user_flag.png"}]
             * icon : http://ucres.myzaker.com/img_upload/user_avatar/2016/5344/10686883_1467165266.jpg.210.jpg
             */

            private AutherBean auther;
            private String title;
            private String date;
            private String content;
            private String comment_count;
            private String hot_num;
            private String like_num;
            private String list_date;
            private String weburl;
            private String content_url;
            private String comment_list_url;
            private String is_top;
            /**
             * item_type : 3
             * medias_count : 3
             */

            private SpecialInfoBean special_info;
            private String is_liked;
            /**
             * name : 置顶
             * icon : http://zkres.myzaker.com/data/image/mark2/stick3_2x.png
             */

            private List<PostTagBean> post_tag;
            private List<String> list_tip;
            /**
             * type : image
             * id : 57c78e101716cf63030000d0
             * w : 1280
             * h : 1280
             * url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h800.jpg
             * m_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h400.jpg
             * s_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h200.jpg
             * min_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h120.jpg
             * raw_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg
             */

            private List<ThumbnailMediasBean> thumbnail_medias;
            /**
             * type : image
             * id : 57c78e101716cf63030000d0
             * w : 1280
             * h : 1280
             * url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h800.jpg
             * m_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h400.jpg
             * s_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h200.jpg
             * min_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg.h120.jpg
             * raw_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c78e101716cf63030000d0.jpg
             */

            private List<MediasBean> medias;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getDiscussion_id() {
                return discussion_id;
            }

            public void setDiscussion_id(String discussion_id) {
                this.discussion_id = discussion_id;
            }

            public AutherBean getAuther() {
                return auther;
            }

            public void setAuther(AutherBean auther) {
                this.auther = auther;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getComment_count() {
                return comment_count;
            }

            public void setComment_count(String comment_count) {
                this.comment_count = comment_count;
            }

            public String getHot_num() {
                return hot_num;
            }

            public void setHot_num(String hot_num) {
                this.hot_num = hot_num;
            }

            public String getLike_num() {
                return like_num;
            }

            public void setLike_num(String like_num) {
                this.like_num = like_num;
            }

            public String getList_date() {
                return list_date;
            }

            public void setList_date(String list_date) {
                this.list_date = list_date;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getContent_url() {
                return content_url;
            }

            public void setContent_url(String content_url) {
                this.content_url = content_url;
            }

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getIs_top() {
                return is_top;
            }

            public void setIs_top(String is_top) {
                this.is_top = is_top;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getIs_liked() {
                return is_liked;
            }

            public void setIs_liked(String is_liked) {
                this.is_liked = is_liked;
            }

            public List<PostTagBean> getPost_tag() {
                return post_tag;
            }

            public void setPost_tag(List<PostTagBean> post_tag) {
                this.post_tag = post_tag;
            }

            public List<String> getList_tip() {
                return list_tip;
            }

            public void setList_tip(List<String> list_tip) {
                this.list_tip = list_tip;
            }

            public List<ThumbnailMediasBean> getThumbnail_medias() {
                return thumbnail_medias;
            }

            public void setThumbnail_medias(List<ThumbnailMediasBean> thumbnail_medias) {
                this.thumbnail_medias = thumbnail_medias;
            }

            public List<MediasBean> getMedias() {
                return medias;
            }

            public void setMedias(List<MediasBean> medias) {
                this.medias = medias;
            }

            public static class AutherBean {
                private String name;
                private String uid;
                private String icon;
                /**
                 * pic : http://zkres.myzaker.com/data/image/discussion/img/ic_official_user_flag.png
                 */

                private List<UserFlagBean> user_flag;

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public String getUid() {
                    return uid;
                }

                public void setUid(String uid) {
                    this.uid = uid;
                }

                public String getIcon() {
                    return icon;
                }

                public void setIcon(String icon) {
                    this.icon = icon;
                }

                public List<UserFlagBean> getUser_flag() {
                    return user_flag;
                }

                public void setUser_flag(List<UserFlagBean> user_flag) {
                    this.user_flag = user_flag;
                }

                public static class UserFlagBean {
                    private String pic;

                    public String getPic() {
                        return pic;
                    }

                    public void setPic(String pic) {
                        this.pic = pic;
                    }
                }
            }

            public static class SpecialInfoBean {
                private String item_type;
                private String medias_count;

                public String getItem_type() {
                    return item_type;
                }

                public void setItem_type(String item_type) {
                    this.item_type = item_type;
                }

                public String getMedias_count() {
                    return medias_count;
                }

                public void setMedias_count(String medias_count) {
                    this.medias_count = medias_count;
                }
            }

            public static class PostTagBean {
                private String name;
                private String icon;

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public String getIcon() {
                    return icon;
                }

                public void setIcon(String icon) {
                    this.icon = icon;
                }
            }

            public static class ThumbnailMediasBean {
                private String type;
                private String id;
                private String w;
                private String h;
                private String url;
                private String m_url;
                private String s_url;
                private String min_url;
                private String raw_url;

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public String getId() {
                    return id;
                }

                public void setId(String id) {
                    this.id = id;
                }

                public String getW() {
                    return w;
                }

                public void setW(String w) {
                    this.w = w;
                }

                public String getH() {
                    return h;
                }

                public void setH(String h) {
                    this.h = h;
                }

                public String getUrl() {
                    return url;
                }

                public void setUrl(String url) {
                    this.url = url;
                }

                public String getM_url() {
                    return m_url;
                }

                public void setM_url(String m_url) {
                    this.m_url = m_url;
                }

                public String getS_url() {
                    return s_url;
                }

                public void setS_url(String s_url) {
                    this.s_url = s_url;
                }

                public String getMin_url() {
                    return min_url;
                }

                public void setMin_url(String min_url) {
                    this.min_url = min_url;
                }

                public String getRaw_url() {
                    return raw_url;
                }

                public void setRaw_url(String raw_url) {
                    this.raw_url = raw_url;
                }
            }

            public static class MediasBean {
                private String type;
                private String id;
                private String w;
                private String h;
                private String url;
                private String m_url;
                private String s_url;
                private String min_url;
                private String raw_url;

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public String getId() {
                    return id;
                }

                public void setId(String id) {
                    this.id = id;
                }

                public String getW() {
                    return w;
                }

                public void setW(String w) {
                    this.w = w;
                }

                public String getH() {
                    return h;
                }

                public void setH(String h) {
                    this.h = h;
                }

                public String getUrl() {
                    return url;
                }

                public void setUrl(String url) {
                    this.url = url;
                }

                public String getM_url() {
                    return m_url;
                }

                public void setM_url(String m_url) {
                    this.m_url = m_url;
                }

                public String getS_url() {
                    return s_url;
                }

                public void setS_url(String s_url) {
                    this.s_url = s_url;
                }

                public String getMin_url() {
                    return min_url;
                }

                public void setMin_url(String min_url) {
                    this.min_url = min_url;
                }

                public String getRaw_url() {
                    return raw_url;
                }

                public void setRaw_url(String raw_url) {
                    this.raw_url = raw_url;
                }
            }
        }
    }
}
