package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class Bean_football {

    /**
     * stat : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=12083&since_date=1473042627&nt=1&_appid=androidphone&catalog_appid=8","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=12083&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12083&ids=51a7106381853df24c000138&k=201609051410"},"catalog":"","articles":[{"pk":"57cd0d579490cb0b7e000049","title":"让中国裁判走向世界，办法只有这个了","date":"2016-09-05 14:14:47","auther_name":"懂个球","weburl":"http://iphone.myzaker.com/l.php?l=57cd0d579490cb0b7e000049","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccf62e7f52e9c1410000c0_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccf62e7f52e9c1410000c0_320.jpg","thumbnail_picsize":"470,302","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0d579490cb0b7e000049&m=1473056076","list_dtime":"2016-09-05 14:14:47"},{"pk":"57cd0cbd9490cb317e000042","title":"细思极恐！前队员缘何总批瓜迪奥拉","date":"2016-09-05 14:12:13","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0cbd9490cb317e000042","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NTkyMV84NTA0NV9XNjQwSDM2MFM0NjMxOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NTkyMV84NTA0NV9XNjQwSDM2MFM0NjMxOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0cbd9490cb317e000042&m=1473055923","list_dtime":"2016-09-05 14:12:13"},{"pk":"57cd0b389490cb077e000033","title":"工作日不放弃 球迷被扣工资也看国足","title_line_break":"工作日不放弃\n球迷被扣工资也看国足","date":"2016-09-05 14:05:44","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0b389490cb077e000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd0b1ba07aecc52301fd99_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd0b1ba07aecc52301fd99_320.jpg","thumbnail_picsize":"580,400","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0b389490cb077e000033&m=1473055648","list_dtime":"2016-09-05 14:05:44"},{"pk":"57cd0acc9490cbda7d00002a","title":"皇马也挖死敌？65年首拥3名加泰球员","date":"2016-09-05 14:03:56","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0acc9490cbda7d00002a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc8db1bc8e03d51000023_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc8db1bc8e03d51000023_320.jpg","thumbnail_picsize":"640,405","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0acc9490cbda7d00002a&m=1473055419","list_dtime":"2016-09-05 14:03:56"},{"pk":"57cd0aaa9490cbe37d000039","title":"超贝克汉姆！英国门将半场任意球破门","date":"2016-09-05 14:03:22","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0aaa9490cbe37d000039","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc8dd1bc8e03d51000025_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc8dd1bc8e03d51000025_320.jpg","thumbnail_picsize":"634,357","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0aaa9490cbe37d000039&m=1473055380","list_dtime":"2016-09-05 14:03:22"},{"pk":"57cd0a889490cb087e00003c","title":"日本裁判界失话语权 中伊战也不公？","title_line_break":"日本裁判界失话语权\n中伊战也不公？","date":"2016-09-05 14:02:48","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0a889490cb087e00003c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd16a1bc8e06354000065_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd16a1bc8e06354000065_320.jpg","thumbnail_picsize":"355,421","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0a889490cb087e00003c&m=1473055358","list_dtime":"2016-09-05 14:02:48"},{"pk":"57cd0a349490cb377e000075","title":"马卢达：看穆帅执教曼联感觉很怪","title_line_break":"马卢达：\n看穆帅执教曼联感觉很怪","date":"2016-09-05 14:01:24","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0a349490cb377e000075","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd0a20a07aecc52301fd49_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd0a20a07aecc52301fd49_320.jpg","thumbnail_picsize":"386,281","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0a349490cb377e000075&m=1473055275","list_dtime":"2016-09-05 14:01:24"},{"pk":"57cd08a79490cb1e7e000049","title":"兄弟情！小白称伯纳乌大胜因小罗","date":"2016-09-05 13:54:47","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd08a79490cb1e7e000049","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd089fa07aecc52301fd35_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd089fa07aecc52301fd35_320.jpg","thumbnail_picsize":"550,391","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd08a79490cb1e7e000049&m=1473055084","list_dtime":"2016-09-05 13:54:47"},{"pk":"57cd08829490cb0e7e00004f","title":"国足需重整锋线 郜林强对抗性该领衔","title_line_break":"国足需重整锋线\n郜林强对抗性该领衔","date":"2016-09-05 13:54:10","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57cd08829490cb0e7e00004f","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccea081bc8e02c67000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccea081bc8e02c67000007_320.jpg","thumbnail_picsize":"600,400","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd08829490cb0e7e00004f&m=1473054833","list_dtime":"2016-09-05 13:54:10"},{"pk":"57cd084e9490cb3f7e00004d","title":"波斯铁骑今犹在 不见当年辱华人","title_line_break":"波斯铁骑今犹在\n不见当年辱华人","date":"2016-09-05 13:53:18","auther_name":"PPTV第1体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd084e9490cb3f7e00004d","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccf66b7f52e9c141000115_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccf66b7f52e9c141000115_320.jpg","thumbnail_picsize":"657,392","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd084e9490cb3f7e00004d&m=1473054758","list_dtime":"2016-09-05 13:53:18"},{"pk":"57cd08479490cbd87d000038","title":"前裁判爆料 阿Kun停赛背后有黑手？","title_line_break":"前裁判爆料\n阿Kun停赛背后有黑手？","date":"2016-09-05 13:53:11","auther_name":"PPTV第1体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd08479490cbd87d000038","thumbnail_pic":"http://zkres.myzaker.com/201608/57c50fad7f52e90e45000591_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c50fad7f52e90e45000591_320.jpg","thumbnail_picsize":"320,179","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd08479490cbd87d000038&m=1473054741","list_dtime":"2016-09-05 13:53:11"},{"pk":"57cd078d9490cb207e000038","title":"省钱？曝曼联禁止王牌球员交换球衣","date":"2016-09-05 13:50:05","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57cd078d9490cb207e000038","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccec0c1bc8e0b065000042_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccec0c1bc8e0b065000042_320.jpg","thumbnail_picsize":"450,307","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd078d9490cb207e000038&m=1473054591","list_dtime":"2016-09-05 13:50:05"},{"pk":"57cd06ed9490cbdc7d00003f","title":"迪马济奥：尤文或和利希施泰纳续约","title_line_break":"迪马济奥：\n尤文或和利希施泰纳续约","date":"2016-09-05 13:47:25","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57cd06ed9490cbdc7d00003f","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd06ed9490cbdc7d00003f&m=1473054432","list_dtime":"2016-09-05 13:47:25"},{"pk":"57cd05cd9490cb3b7e000029","title":"曝曼联欲引格子 穆帅钦定其接班鲁尼","title_line_break":"曝曼联欲引格子\n穆帅钦定其接班鲁尼","date":"2016-09-05 13:42:37","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd05cd9490cb3b7e000029","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccee771bc8e01067000015_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccee771bc8e01067000015_320.jpg","thumbnail_picsize":"960,607","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd05cd9490cb3b7e000029&m=1473055428","list_dtime":"2016-09-05 13:42:37"},{"pk":"57ccebfe9490cbd77d000024","title":"做备胎！曝切尔西签回昔日弃将内幕","date":"2016-09-05 11:52:30","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccebfe9490cbd77d000024","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccebc5a07aecc52301ef41_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccebc5a07aecc52301ef41_320.jpg","thumbnail_picsize":"480,314","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccebfe9490cbd77d000024&m=1473047504","list_dtime":"2016-09-05 11:52:30"},{"pk":"57cceb8d9490cb0f7e000044","title":"米兰中国老板承诺 冬季将砸1亿买人","title_line_break":"米兰中国老板承诺\n冬季将砸1亿买人","date":"2016-09-05 11:50:37","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57cceb8d9490cb0f7e000044","thumbnail_pic":"http://zkres.myzaker.com/201609/57cceb61a07aecc52301ef1b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cceb61a07aecc52301ef1b_320.jpg","thumbnail_picsize":"480,270","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cceb8d9490cb0f7e000044&m=1473047405","list_dtime":"2016-09-05 11:50:37"},{"pk":"57cce77a9490cb107e000022","title":"文图拉难改意大利防线 扎哈维有机会","title_line_break":"文图拉难改意大利防线\n扎哈维有机会","date":"2016-09-05 11:33:14","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57cce77a9490cb107e000022","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce18a1bc8e0385e000032_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce18a1bc8e0385e000032_320.jpg","thumbnail_picsize":"600,400","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cce77a9490cb107e000022&m=1473046383","list_dtime":"2016-09-05 11:33:14"},{"pk":"57cce4c09490cbf27d00002a","title":"伊恩-赖特：拉什福德会成为穆帅爱将","title_line_break":"伊恩-赖特：\n拉什福德会成为穆帅爱将","date":"2016-09-05 11:21:36","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57cce4c09490cbf27d00002a","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce0491bc8e05761000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce0491bc8e05761000000_320.jpg","thumbnail_picsize":"450,287","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cce4c09490cbf27d00002a&m=1473045672","list_dtime":"2016-09-05 11:21:36"},{"pk":"57cce4c09490cbf27d000028","title":"梅西伤势加重 称退国家队因当时崩溃","title_line_break":"梅西伤势加重\n称退国家队因当时崩溃","date":"2016-09-05 11:21:36","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce4c09490cbf27d000028","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cce4c09490cbf27d000028&m=1473045656","list_dtime":"2016-09-05 11:21:36"},{"pk":"57ccdd979490cbe67d000022","title":"旗开得胜穆勒破荒 德国队卫冕路开启","title_line_break":"旗开得胜穆勒破荒\n德国队卫冕路开启","date":"2016-09-05 10:51:03","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd979490cbe67d000022","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd0791bc8e0c055000030_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd0791bc8e0c055000030_320.jpg","thumbnail_picsize":"600,400","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdd979490cbe67d000022&m=1473043839","list_dtime":"2016-09-05 10:51:03"},{"pk":"57ccdd8f9490cb337e000048","title":"国足无伤病变四后卫 用张琳芃任航？","title_line_break":"国足无伤病变四后卫\n用张琳芃任航？","date":"2016-09-05 10:50:55","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd8f9490cb337e000048","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd8fc1bc8e0e85b00002d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd8fc1bc8e0e85b00002d_320.jpg","thumbnail_picsize":"450,291","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdd8f9490cb337e000048&m=1473043839","list_dtime":"2016-09-05 10:50:55"},{"pk":"57ccdd0c9490cb317e000033","title":"莱姆克：德甲上赛季经纪人佣金超一亿","title_line_break":"莱姆克：\n德甲上赛季经纪人佣金超一亿","date":"2016-09-05 10:48:44","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd0c9490cb317e000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd7c81bc8e0c65b000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd7c81bc8e0c65b000002_320.jpg","thumbnail_picsize":"450,253","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdd0c9490cb317e000033&m=1473043642","list_dtime":"2016-09-05 10:48:44"},{"pk":"57ccdd0c9490cb317e000035","title":"科斯塔库塔：意大利队未来一片光明","title_line_break":"科斯塔库塔：\n意大利队未来一片光明","date":"2016-09-05 10:48:44","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd0c9490cb317e000035","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdd0c9490cb317e000035&m=1473043654","list_dtime":"2016-09-05 10:48:44"},{"pk":"57ccdd0c9490cb317e000034","title":"巴拉克支持诺伊尔：具备队长一切素质","title_line_break":"巴拉克支持诺伊尔：\n具备队长一切素质","date":"2016-09-05 10:48:44","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd0c9490cb317e000034","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd7ca1bc8e0c65b000004_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd7ca1bc8e0c65b000004_320.jpg","thumbnail_picsize":"450,253","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdd0c9490cb317e000034&m=1473043620","list_dtime":"2016-09-05 10:48:44"},{"pk":"57ccdd0c9490cb317e000036","title":"斩获国家队首球！基米希：踢右路很棒","title_line_break":"斩获国家队首球！基米希：\n踢右路很棒","date":"2016-09-05 10:48:44","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd0c9490cb317e000036","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd7cb1bc8e0c65b000008_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd7cb1bc8e0c65b000008_320.jpg","thumbnail_picsize":"450,292","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdd0c9490cb317e000036&m=1473043697","list_dtime":"2016-09-05 10:48:44"},{"pk":"57ccdc829490cb157e000026","title":"中伊战主裁摸底：曾送武磊生涯首红","title_line_break":"中伊战主裁摸底：\n曾送武磊生涯首红","date":"2016-09-05 10:46:26","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdc829490cb157e000026","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdcaaa07aecc52301dd41_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdcaaa07aecc52301dd41_320.jpg","thumbnail_picsize":"480,296","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdc829490cb157e000026&m=1473043654","list_dtime":"2016-09-05 10:46:26"},{"pk":"57ccdc229490cb437e000024","title":"小贝为鲁尼送祝福：请留在国家队","title_line_break":"小贝为鲁尼送祝福：\n请留在国家队","date":"2016-09-05 10:44:50","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdc229490cb437e000024","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdc2ca07aecc52301dcfd_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdc2ca07aecc52301dcfd_320.jpg","thumbnail_picsize":"480,306","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdc229490cb437e000024&m=1473043513","list_dtime":"2016-09-05 10:44:50"},{"pk":"57ccdbbf9490cbf77d000025","title":"留核心！曝皇马将与克罗斯续约3年","date":"2016-09-05 10:43:11","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdbbf9490cbf77d000025","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdbb4a07aecc52301dcf7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdbb4a07aecc52301dcf7_320.jpg","thumbnail_picsize":"480,326","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdbbf9490cbf77d000025&m=1473043509","list_dtime":"2016-09-05 10:43:11"},{"pk":"57ccdbbf9490cbf77d000027","title":"分裂！贝尔高年薪引队内两大佬不满","date":"2016-09-05 10:43:11","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdbbf9490cbf77d000027","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccb66a07aecc52301d2c9_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdb87a07aecc52301dce8_320.jpg","thumbnail_picsize":"550,313","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdbbf9490cbf77d000027&m=1473043402","list_dtime":"2016-09-05 10:43:11"},{"pk":"57ccdb109490cb117e000039","title":"法国足协主席：国家队愿召回本泽马","title_line_break":"法国足协主席：\n国家队愿召回本泽马","date":"2016-09-05 10:40:16","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdb109490cb117e000039","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdb05a07aecc52301dc83_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdb05a07aecc52301dc83_320.jpg","thumbnail_picsize":"480,304","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdb109490cb117e000039&m=1473043234","list_dtime":"2016-09-05 10:40:16"},{"pk":"57ccdaca9490cbde7d000033","title":"伊朗阵容揭秘：锋线强劲后防存大漏洞","title_line_break":"伊朗阵容揭秘：\n锋线强劲后防存大漏洞","date":"2016-09-05 10:39:06","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdaca9490cbde7d000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdac4a07aecc52301dc0a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdac4a07aecc52301dc0a_320.jpg","thumbnail_picsize":"480,303","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdaca9490cbde7d000033&m=1473043190","list_dtime":"2016-09-05 10:39:06"},{"pk":"57ccda609490cbe47d00001c","title":"克洛普：梅西在西甲散步也进5球","title_line_break":"克洛普：\n梅西在西甲散步也进5球","date":"2016-09-05 10:37:20","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccda609490cbe47d00001c","thumbnail_pic":"http://zkres.myzaker.com/201609/57cad54e1bc8e0272b000024_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccda64f5a2248c62000003_320.jpg","thumbnail_picsize":"450,313","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccda609490cbe47d00001c&m=1473043192","list_dtime":"2016-09-05 10:37:20"},{"pk":"57ccda039490cb4b7e00002a","title":"不近人情？曼联去除名宿家人vip位置","date":"2016-09-05 10:35:47","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccda039490cb4b7e00002a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd9f2a07aecc52301dbe2_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd9f2a07aecc52301dbe2_320.jpg","thumbnail_picsize":"480,303","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccda039490cb4b7e00002a&m=1473042941","list_dtime":"2016-09-05 10:35:47"},{"pk":"57ccd93c9490cb1a7e000025","title":"首发不保！枪手皇储再遭弱队嫌弃","date":"2016-09-05 10:32:28","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd93c9490cb1a7e000025","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd92fa07aecc52301db38_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd92fa07aecc52301db38_320.jpg","thumbnail_picsize":"480,352","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccd93c9490cb1a7e000025&m=1473042786","list_dtime":"2016-09-05 10:32:28"},{"pk":"57ccd2609490cbe17d000022","title":"高洪波将变阵出击伊朗：张琳芃踢中卫","title_line_break":"高洪波将变阵出击伊朗：\n张琳芃踢中卫","date":"2016-09-05 10:30:27","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd2609490cbe17d000022","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd275f5a2246262000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd275f5a2246262000001_320.jpg","thumbnail_picsize":"1024,681","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccd2609490cbe17d000022&m=1473041046","list_dtime":"2016-09-05 10:30:27"},{"pk":"57ccd5689490cbd77d000019","title":"富力征战港超，\u201c小目标\u201d争进前六","date":"2016-09-05 10:30:27","auther_name":"南方都市报","weburl":"http://iphone.myzaker.com/l.php?l=57ccd5689490cbd77d000019","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd55ea07aecc52301d80a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd55ea07aecc52301d80a_320.jpg","thumbnail_picsize":"540,407","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccd5689490cbd77d000019&m=1473041787","list_dtime":"2016-09-05 10:30:27"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cd0cbd9490cb317e000042,57cd0d579490cb0b7e000049,57cd0b389490cb077e000033,57cd0acc9490cbda7d00002a,57cd0aaa9490cbe37d000039,57cd0a889490cb087e00003c","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57cd08a79490cb1e7e000049,57cd0a349490cb377e000075,57cd08829490cb0e7e00004f,57cd084e9490cb3f7e00004d,57cd08479490cbd87d000038,57cd078d9490cb207e000038","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cd05cd9490cb3b7e000029,57cd06ed9490cbdc7d00003f,57ccebfe9490cbd77d000024,57cceb8d9490cb0f7e000044,57cce77a9490cb107e000022,57cce4c09490cbf27d00002a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ccdd979490cbe67d000022,57cce4c09490cbf27d000028,57ccdd8f9490cb337e000048,57ccdd0c9490cb317e000033,57ccdd0c9490cb317e000035,57ccdd0c9490cb317e000034","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57ccdc829490cb157e000026,57ccdd0c9490cb317e000036,57ccdc229490cb437e000024,57ccdbbf9490cbf77d000025,57ccdbbf9490cbf77d000027,57ccdb109490cb117e000039","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57ccda609490cbe47d00001c,57ccdaca9490cbde7d000033,57ccda039490cb4b7e00002a,57ccd93c9490cb1a7e000025,57ccd2609490cbe17d000022,57ccd5689490cbd77d000019","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}}],"article_block_colors":["#d85847","#d85847"],"only_text_page_bgcolors":["#d85847","#d85847"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12083.png?t=1441702363","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12083.png?t=1441702363","hidden_time":"24","need_userinfo":"NO","block_title":"足球","block_color":"#d85847","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_7545c8eb04bd3c7e57ec8d5865cd1f3e","selected_index":"1","list":[{"pk":"zk_app_column_8","title":"头条","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12083","title":"足球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12083_zk_app_column_block_8","title":"足球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12083&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12084","title":"篮球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12084_zk_app_column_block_8","title":"篮球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12084&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_11610","title":"综合","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11610_zk_app_column_block_8","title":"综合体育","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11610&catalog_appid=8","data_type":"news"}}]}}
     */

    private String stat;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=12083&since_date=1473042627&nt=1&_appid=androidphone&catalog_appid=8","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=12083&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12083&ids=51a7106381853df24c000138&k=201609051410"}
     * catalog :
     * articles : [{"pk":"57cd0d579490cb0b7e000049","title":"让中国裁判走向世界，办法只有这个了","date":"2016-09-05 14:14:47","auther_name":"懂个球","weburl":"http://iphone.myzaker.com/l.php?l=57cd0d579490cb0b7e000049","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccf62e7f52e9c1410000c0_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccf62e7f52e9c1410000c0_320.jpg","thumbnail_picsize":"470,302","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0d579490cb0b7e000049&m=1473056076","list_dtime":"2016-09-05 14:14:47"},{"pk":"57cd0cbd9490cb317e000042","title":"细思极恐！前队员缘何总批瓜迪奥拉","date":"2016-09-05 14:12:13","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0cbd9490cb317e000042","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NTkyMV84NTA0NV9XNjQwSDM2MFM0NjMxOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NTkyMV84NTA0NV9XNjQwSDM2MFM0NjMxOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0cbd9490cb317e000042&m=1473055923","list_dtime":"2016-09-05 14:12:13"},{"pk":"57cd0b389490cb077e000033","title":"工作日不放弃 球迷被扣工资也看国足","title_line_break":"工作日不放弃\n球迷被扣工资也看国足","date":"2016-09-05 14:05:44","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0b389490cb077e000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd0b1ba07aecc52301fd99_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd0b1ba07aecc52301fd99_320.jpg","thumbnail_picsize":"580,400","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0b389490cb077e000033&m=1473055648","list_dtime":"2016-09-05 14:05:44"},{"pk":"57cd0acc9490cbda7d00002a","title":"皇马也挖死敌？65年首拥3名加泰球员","date":"2016-09-05 14:03:56","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0acc9490cbda7d00002a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc8db1bc8e03d51000023_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc8db1bc8e03d51000023_320.jpg","thumbnail_picsize":"640,405","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0acc9490cbda7d00002a&m=1473055419","list_dtime":"2016-09-05 14:03:56"},{"pk":"57cd0aaa9490cbe37d000039","title":"超贝克汉姆！英国门将半场任意球破门","date":"2016-09-05 14:03:22","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0aaa9490cbe37d000039","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc8dd1bc8e03d51000025_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc8dd1bc8e03d51000025_320.jpg","thumbnail_picsize":"634,357","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0aaa9490cbe37d000039&m=1473055380","list_dtime":"2016-09-05 14:03:22"},{"pk":"57cd0a889490cb087e00003c","title":"日本裁判界失话语权 中伊战也不公？","title_line_break":"日本裁判界失话语权\n中伊战也不公？","date":"2016-09-05 14:02:48","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0a889490cb087e00003c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd16a1bc8e06354000065_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd16a1bc8e06354000065_320.jpg","thumbnail_picsize":"355,421","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0a889490cb087e00003c&m=1473055358","list_dtime":"2016-09-05 14:02:48"},{"pk":"57cd0a349490cb377e000075","title":"马卢达：看穆帅执教曼联感觉很怪","title_line_break":"马卢达：\n看穆帅执教曼联感觉很怪","date":"2016-09-05 14:01:24","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0a349490cb377e000075","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd0a20a07aecc52301fd49_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd0a20a07aecc52301fd49_320.jpg","thumbnail_picsize":"386,281","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0a349490cb377e000075&m=1473055275","list_dtime":"2016-09-05 14:01:24"},{"pk":"57cd08a79490cb1e7e000049","title":"兄弟情！小白称伯纳乌大胜因小罗","date":"2016-09-05 13:54:47","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd08a79490cb1e7e000049","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd089fa07aecc52301fd35_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd089fa07aecc52301fd35_320.jpg","thumbnail_picsize":"550,391","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd08a79490cb1e7e000049&m=1473055084","list_dtime":"2016-09-05 13:54:47"},{"pk":"57cd08829490cb0e7e00004f","title":"国足需重整锋线 郜林强对抗性该领衔","title_line_break":"国足需重整锋线\n郜林强对抗性该领衔","date":"2016-09-05 13:54:10","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57cd08829490cb0e7e00004f","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccea081bc8e02c67000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccea081bc8e02c67000007_320.jpg","thumbnail_picsize":"600,400","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd08829490cb0e7e00004f&m=1473054833","list_dtime":"2016-09-05 13:54:10"},{"pk":"57cd084e9490cb3f7e00004d","title":"波斯铁骑今犹在 不见当年辱华人","title_line_break":"波斯铁骑今犹在\n不见当年辱华人","date":"2016-09-05 13:53:18","auther_name":"PPTV第1体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd084e9490cb3f7e00004d","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccf66b7f52e9c141000115_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccf66b7f52e9c141000115_320.jpg","thumbnail_picsize":"657,392","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd084e9490cb3f7e00004d&m=1473054758","list_dtime":"2016-09-05 13:53:18"},{"pk":"57cd08479490cbd87d000038","title":"前裁判爆料 阿Kun停赛背后有黑手？","title_line_break":"前裁判爆料\n阿Kun停赛背后有黑手？","date":"2016-09-05 13:53:11","auther_name":"PPTV第1体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd08479490cbd87d000038","thumbnail_pic":"http://zkres.myzaker.com/201608/57c50fad7f52e90e45000591_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c50fad7f52e90e45000591_320.jpg","thumbnail_picsize":"320,179","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd08479490cbd87d000038&m=1473054741","list_dtime":"2016-09-05 13:53:11"},{"pk":"57cd078d9490cb207e000038","title":"省钱？曝曼联禁止王牌球员交换球衣","date":"2016-09-05 13:50:05","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57cd078d9490cb207e000038","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccec0c1bc8e0b065000042_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccec0c1bc8e0b065000042_320.jpg","thumbnail_picsize":"450,307","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd078d9490cb207e000038&m=1473054591","list_dtime":"2016-09-05 13:50:05"},{"pk":"57cd06ed9490cbdc7d00003f","title":"迪马济奥：尤文或和利希施泰纳续约","title_line_break":"迪马济奥：\n尤文或和利希施泰纳续约","date":"2016-09-05 13:47:25","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57cd06ed9490cbdc7d00003f","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd06ed9490cbdc7d00003f&m=1473054432","list_dtime":"2016-09-05 13:47:25"},{"pk":"57cd05cd9490cb3b7e000029","title":"曝曼联欲引格子 穆帅钦定其接班鲁尼","title_line_break":"曝曼联欲引格子\n穆帅钦定其接班鲁尼","date":"2016-09-05 13:42:37","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd05cd9490cb3b7e000029","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccee771bc8e01067000015_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccee771bc8e01067000015_320.jpg","thumbnail_picsize":"960,607","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd05cd9490cb3b7e000029&m=1473055428","list_dtime":"2016-09-05 13:42:37"},{"pk":"57ccebfe9490cbd77d000024","title":"做备胎！曝切尔西签回昔日弃将内幕","date":"2016-09-05 11:52:30","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccebfe9490cbd77d000024","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccebc5a07aecc52301ef41_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccebc5a07aecc52301ef41_320.jpg","thumbnail_picsize":"480,314","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccebfe9490cbd77d000024&m=1473047504","list_dtime":"2016-09-05 11:52:30"},{"pk":"57cceb8d9490cb0f7e000044","title":"米兰中国老板承诺 冬季将砸1亿买人","title_line_break":"米兰中国老板承诺\n冬季将砸1亿买人","date":"2016-09-05 11:50:37","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57cceb8d9490cb0f7e000044","thumbnail_pic":"http://zkres.myzaker.com/201609/57cceb61a07aecc52301ef1b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cceb61a07aecc52301ef1b_320.jpg","thumbnail_picsize":"480,270","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cceb8d9490cb0f7e000044&m=1473047405","list_dtime":"2016-09-05 11:50:37"},{"pk":"57cce77a9490cb107e000022","title":"文图拉难改意大利防线 扎哈维有机会","title_line_break":"文图拉难改意大利防线\n扎哈维有机会","date":"2016-09-05 11:33:14","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57cce77a9490cb107e000022","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce18a1bc8e0385e000032_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce18a1bc8e0385e000032_320.jpg","thumbnail_picsize":"600,400","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cce77a9490cb107e000022&m=1473046383","list_dtime":"2016-09-05 11:33:14"},{"pk":"57cce4c09490cbf27d00002a","title":"伊恩-赖特：拉什福德会成为穆帅爱将","title_line_break":"伊恩-赖特：\n拉什福德会成为穆帅爱将","date":"2016-09-05 11:21:36","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57cce4c09490cbf27d00002a","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce0491bc8e05761000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce0491bc8e05761000000_320.jpg","thumbnail_picsize":"450,287","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cce4c09490cbf27d00002a&m=1473045672","list_dtime":"2016-09-05 11:21:36"},{"pk":"57cce4c09490cbf27d000028","title":"梅西伤势加重 称退国家队因当时崩溃","title_line_break":"梅西伤势加重\n称退国家队因当时崩溃","date":"2016-09-05 11:21:36","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce4c09490cbf27d000028","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cce4c09490cbf27d000028&m=1473045656","list_dtime":"2016-09-05 11:21:36"},{"pk":"57ccdd979490cbe67d000022","title":"旗开得胜穆勒破荒 德国队卫冕路开启","title_line_break":"旗开得胜穆勒破荒\n德国队卫冕路开启","date":"2016-09-05 10:51:03","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd979490cbe67d000022","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd0791bc8e0c055000030_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd0791bc8e0c055000030_320.jpg","thumbnail_picsize":"600,400","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdd979490cbe67d000022&m=1473043839","list_dtime":"2016-09-05 10:51:03"},{"pk":"57ccdd8f9490cb337e000048","title":"国足无伤病变四后卫 用张琳芃任航？","title_line_break":"国足无伤病变四后卫\n用张琳芃任航？","date":"2016-09-05 10:50:55","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd8f9490cb337e000048","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd8fc1bc8e0e85b00002d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd8fc1bc8e0e85b00002d_320.jpg","thumbnail_picsize":"450,291","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdd8f9490cb337e000048&m=1473043839","list_dtime":"2016-09-05 10:50:55"},{"pk":"57ccdd0c9490cb317e000033","title":"莱姆克：德甲上赛季经纪人佣金超一亿","title_line_break":"莱姆克：\n德甲上赛季经纪人佣金超一亿","date":"2016-09-05 10:48:44","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd0c9490cb317e000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd7c81bc8e0c65b000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd7c81bc8e0c65b000002_320.jpg","thumbnail_picsize":"450,253","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdd0c9490cb317e000033&m=1473043642","list_dtime":"2016-09-05 10:48:44"},{"pk":"57ccdd0c9490cb317e000035","title":"科斯塔库塔：意大利队未来一片光明","title_line_break":"科斯塔库塔：\n意大利队未来一片光明","date":"2016-09-05 10:48:44","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd0c9490cb317e000035","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdd0c9490cb317e000035&m=1473043654","list_dtime":"2016-09-05 10:48:44"},{"pk":"57ccdd0c9490cb317e000034","title":"巴拉克支持诺伊尔：具备队长一切素质","title_line_break":"巴拉克支持诺伊尔：\n具备队长一切素质","date":"2016-09-05 10:48:44","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd0c9490cb317e000034","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd7ca1bc8e0c65b000004_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd7ca1bc8e0c65b000004_320.jpg","thumbnail_picsize":"450,253","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdd0c9490cb317e000034&m=1473043620","list_dtime":"2016-09-05 10:48:44"},{"pk":"57ccdd0c9490cb317e000036","title":"斩获国家队首球！基米希：踢右路很棒","title_line_break":"斩获国家队首球！基米希：\n踢右路很棒","date":"2016-09-05 10:48:44","auther_name":"虎扑足球","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd0c9490cb317e000036","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd7cb1bc8e0c65b000008_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd7cb1bc8e0c65b000008_320.jpg","thumbnail_picsize":"450,292","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdd0c9490cb317e000036&m=1473043697","list_dtime":"2016-09-05 10:48:44"},{"pk":"57ccdc829490cb157e000026","title":"中伊战主裁摸底：曾送武磊生涯首红","title_line_break":"中伊战主裁摸底：\n曾送武磊生涯首红","date":"2016-09-05 10:46:26","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdc829490cb157e000026","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdcaaa07aecc52301dd41_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdcaaa07aecc52301dd41_320.jpg","thumbnail_picsize":"480,296","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdc829490cb157e000026&m=1473043654","list_dtime":"2016-09-05 10:46:26"},{"pk":"57ccdc229490cb437e000024","title":"小贝为鲁尼送祝福：请留在国家队","title_line_break":"小贝为鲁尼送祝福：\n请留在国家队","date":"2016-09-05 10:44:50","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdc229490cb437e000024","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdc2ca07aecc52301dcfd_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdc2ca07aecc52301dcfd_320.jpg","thumbnail_picsize":"480,306","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdc229490cb437e000024&m=1473043513","list_dtime":"2016-09-05 10:44:50"},{"pk":"57ccdbbf9490cbf77d000025","title":"留核心！曝皇马将与克罗斯续约3年","date":"2016-09-05 10:43:11","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdbbf9490cbf77d000025","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdbb4a07aecc52301dcf7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdbb4a07aecc52301dcf7_320.jpg","thumbnail_picsize":"480,326","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdbbf9490cbf77d000025&m=1473043509","list_dtime":"2016-09-05 10:43:11"},{"pk":"57ccdbbf9490cbf77d000027","title":"分裂！贝尔高年薪引队内两大佬不满","date":"2016-09-05 10:43:11","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdbbf9490cbf77d000027","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccb66a07aecc52301d2c9_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdb87a07aecc52301dce8_320.jpg","thumbnail_picsize":"550,313","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdbbf9490cbf77d000027&m=1473043402","list_dtime":"2016-09-05 10:43:11"},{"pk":"57ccdb109490cb117e000039","title":"法国足协主席：国家队愿召回本泽马","title_line_break":"法国足协主席：\n国家队愿召回本泽马","date":"2016-09-05 10:40:16","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdb109490cb117e000039","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdb05a07aecc52301dc83_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdb05a07aecc52301dc83_320.jpg","thumbnail_picsize":"480,304","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdb109490cb117e000039&m=1473043234","list_dtime":"2016-09-05 10:40:16"},{"pk":"57ccdaca9490cbde7d000033","title":"伊朗阵容揭秘：锋线强劲后防存大漏洞","title_line_break":"伊朗阵容揭秘：\n锋线强劲后防存大漏洞","date":"2016-09-05 10:39:06","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdaca9490cbde7d000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdac4a07aecc52301dc0a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdac4a07aecc52301dc0a_320.jpg","thumbnail_picsize":"480,303","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccdaca9490cbde7d000033&m=1473043190","list_dtime":"2016-09-05 10:39:06"},{"pk":"57ccda609490cbe47d00001c","title":"克洛普：梅西在西甲散步也进5球","title_line_break":"克洛普：\n梅西在西甲散步也进5球","date":"2016-09-05 10:37:20","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccda609490cbe47d00001c","thumbnail_pic":"http://zkres.myzaker.com/201609/57cad54e1bc8e0272b000024_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccda64f5a2248c62000003_320.jpg","thumbnail_picsize":"450,313","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccda609490cbe47d00001c&m=1473043192","list_dtime":"2016-09-05 10:37:20"},{"pk":"57ccda039490cb4b7e00002a","title":"不近人情？曼联去除名宿家人vip位置","date":"2016-09-05 10:35:47","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccda039490cb4b7e00002a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd9f2a07aecc52301dbe2_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd9f2a07aecc52301dbe2_320.jpg","thumbnail_picsize":"480,303","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccda039490cb4b7e00002a&m=1473042941","list_dtime":"2016-09-05 10:35:47"},{"pk":"57ccd93c9490cb1a7e000025","title":"首发不保！枪手皇储再遭弱队嫌弃","date":"2016-09-05 10:32:28","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd93c9490cb1a7e000025","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd92fa07aecc52301db38_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd92fa07aecc52301db38_320.jpg","thumbnail_picsize":"480,352","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccd93c9490cb1a7e000025&m=1473042786","list_dtime":"2016-09-05 10:32:28"},{"pk":"57ccd2609490cbe17d000022","title":"高洪波将变阵出击伊朗：张琳芃踢中卫","title_line_break":"高洪波将变阵出击伊朗：\n张琳芃踢中卫","date":"2016-09-05 10:30:27","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd2609490cbe17d000022","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd275f5a2246262000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd275f5a2246262000001_320.jpg","thumbnail_picsize":"1024,681","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccd2609490cbe17d000022&m=1473041046","list_dtime":"2016-09-05 10:30:27"},{"pk":"57ccd5689490cbd77d000019","title":"富力征战港超，\u201c小目标\u201d争进前六","date":"2016-09-05 10:30:27","auther_name":"南方都市报","weburl":"http://iphone.myzaker.com/l.php?l=57ccd5689490cbd77d000019","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd55ea07aecc52301d80a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd55ea07aecc52301d80a_320.jpg","thumbnail_picsize":"540,407","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57ccd5689490cbd77d000019&m=1473041787","list_dtime":"2016-09-05 10:30:27"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cd0cbd9490cb317e000042,57cd0d579490cb0b7e000049,57cd0b389490cb077e000033,57cd0acc9490cbda7d00002a,57cd0aaa9490cbe37d000039,57cd0a889490cb087e00003c","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57cd08a79490cb1e7e000049,57cd0a349490cb377e000075,57cd08829490cb0e7e00004f,57cd084e9490cb3f7e00004d,57cd08479490cbd87d000038,57cd078d9490cb207e000038","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cd05cd9490cb3b7e000029,57cd06ed9490cbdc7d00003f,57ccebfe9490cbd77d000024,57cceb8d9490cb0f7e000044,57cce77a9490cb107e000022,57cce4c09490cbf27d00002a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ccdd979490cbe67d000022,57cce4c09490cbf27d000028,57ccdd8f9490cb337e000048,57ccdd0c9490cb317e000033,57ccdd0c9490cb317e000035,57ccdd0c9490cb317e000034","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57ccdc829490cb157e000026,57ccdd0c9490cb317e000036,57ccdc229490cb437e000024,57ccdbbf9490cbf77d000025,57ccdbbf9490cbf77d000027,57ccdb109490cb117e000039","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57ccda609490cbe47d00001c,57ccdaca9490cbde7d000033,57ccda039490cb4b7e00002a,57ccd93c9490cb1a7e000025,57ccd2609490cbe17d000022,57ccd5689490cbd77d000019","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}}],"article_block_colors":["#d85847","#d85847"],"only_text_page_bgcolors":["#d85847","#d85847"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12083.png?t=1441702363","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12083.png?t=1441702363","hidden_time":"24","need_userinfo":"NO","block_title":"足球","block_color":"#d85847","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_7545c8eb04bd3c7e57ec8d5865cd1f3e","selected_index":"1","list":[{"pk":"zk_app_column_8","title":"头条","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12083","title":"足球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12083_zk_app_column_block_8","title":"足球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12083&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12084","title":"篮球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12084_zk_app_column_block_8","title":"篮球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12084&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_11610","title":"综合","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11610_zk_app_column_block_8","title":"综合体育","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11610&catalog_appid=8","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=12083&since_date=1473042627&nt=1&_appid=androidphone&catalog_appid=8
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=12083&need_app_integration=
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12083&ids=51a7106381853df24c000138&k=201609051410
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/12083.png?t=1441702363
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/12083.png?t=1441702363
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 足球
         * block_color : #d85847
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_7545c8eb04bd3c7e57ec8d5865cd1f3e
         * selected_index : 1
         * list : [{"pk":"zk_app_column_8","title":"头条","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12083","title":"足球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12083_zk_app_column_block_8","title":"足球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12083&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12084","title":"篮球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12084_zk_app_column_block_8","title":"篮球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12084&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_11610","title":"综合","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11610_zk_app_column_block_8","title":"综合体育","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11610&catalog_appid=8","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57cd0d579490cb0b7e000049
         * title : 让中国裁判走向世界，办法只有这个了
         * date : 2016-09-05 14:14:47
         * auther_name : 懂个球
         * weburl : http://iphone.myzaker.com/l.php?l=57cd0d579490cb0b7e000049
         * thumbnail_pic : http://zkres.myzaker.com/201609/57ccf62e7f52e9c1410000c0_640.jpg
         * thumbnail_mpic : http://zkres.myzaker.com/201609/57ccf62e7f52e9c1410000c0_320.jpg
         * thumbnail_picsize : 470,302
         * media_count : 12
         * is_full : NO
         * content :
         * special_info : {"show_jingcai":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12083&pk=57cd0d579490cb0b7e000049&m=1473056076
         * list_dtime : 2016-09-05 14:14:47
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 1
             * articles : 57cd0cbd9490cb317e000042,57cd0d579490cb0b7e000049,57cd0b389490cb077e000033,57cd0acc9490cbda7d00002a,57cd0aaa9490cbe37d000039,57cd0a889490cb087e00003c
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * open_type :
                 * bgimage_icon_style : 0
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;
                    private String bgimage_icon_style;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }

                    public String getBgimage_icon_style() {
                        return bgimage_icon_style;
                    }

                    public void setBgimage_icon_style(String bgimage_icon_style) {
                        this.bgimage_icon_style = bgimage_icon_style;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_8
             * title : 头条
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 8
                 * title : 体育新闻
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8
                 * data_type : news
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String is_full;
            private String content;
            /**
             * show_jingcai : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String show_jingcai;

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }
            }
        }
    }
}
