package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class Bean_imports {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=4&since_date=1472891309&nt=1&next_aticle_id=57ccad4a9490cb097e00001f&_appid=androidphone&opage=2&otimestamp=160","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=4&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=4&ids=5642f2aa9490cbb13200000e,54dde63f9490cbbf07000101&k=201609051310"},"catalog":"","articles":[{"pk":"57ccb3b09490cbf57d00000a","title":"G20峰会为何对中国如此重要？","date":"2016-09-05 07:52:16","auther_name":"商界","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57ccb3b09490cbf57d00000a","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbfc1a1bc8e0cc52000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbfc1a1bc8e0cc52000000_320.jpg","thumbnail_picsize":"580,328","media_count":"25","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c8f9fa9490cbd91700004b","block_title":"G20将如何影响你的钱袋子？","title":"G20将如何影响你的钱袋子？","block_in_title":"G20峰会为何对中国如此重要？","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=4&topic_id=57c8f9fa9490cbd91700004b&updated=1473041444"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccb3b09490cbf57d00000a&m=1473052202","list_dtime":"2016-09-05 07:52:16"},{"pk":"57ccdada1bc8e01c0c000032","title":"富豪都已逃离楼市，未来的钱会去哪？","date":"2016-09-05 10:39:25","auther_name":"种钱","page":"5","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=57ccdada1bc8e01c0c000032","thumbnail_pic":"http://zkres.myzaker.com/data/attachment/editor/2016/09/05/1473043367.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdbfaa07aecc52301dcf8_320.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","type":"other","special_info":{"open_type":"block","block_info":{"pk":"6","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=6","data_type":"rss"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=4&app_ids=4&pk=57ccdada1bc8e01c0c000032&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57ccdada1bc8e01c0c000032","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccdada1bc8e01c0c000032&m=1473052202","list_dtime":"2016-09-05 10:39:25"},{"pk":"57ccd89e9490cbff7d000026","title":"摸底房企资金流：1.5万亿资金等待出笼","title_line_break":"摸底房企资金流：\n1.5万亿资金等待出笼","date":"2016-09-05 10:29:10","auther_name":"21世纪经济报道","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ccd89e9490cbff7d000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZGFkZGEwN2FlY2M1MjMwMWRjMmZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZGFkZGEwN2FlY2M1MjMwMWRjMmZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd89e9490cbff7d000026&m=1473052202","list_dtime":"2016-09-05 10:29:10"},{"pk":"57cce59d9490cb127e000019","title":"刚需族贷款买房，月供多少最合适？","date":"2016-09-05 11:25:17","auther_name":"21世纪经济报道","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57cce59d9490cb127e000019","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Njc4NF80MTkyMl9XNjQwSDM2MFM4MjQ3Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Njc4NF80MTkyMl9XNjQwSDM2MFM4MjQ3Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57cce59d9490cb127e000019&url=http%3A%2F%2Fm.21jingji.com%2Farticle%2F20160905%2Fherald%2Fd478b70d2e9943142cec46f11c878dbf_zaker.html","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cce59d9490cb127e000019&m=1473052202","list_dtime":"2016-09-05 11:25:17"},{"pk":"57c93b139490cb3318000088","title":"ZAKER股市直播：周一市场动态","title_line_break":"ZAKER股市直播：\n周一市场动态","date":"2016-09-05 08:55:27","auther_name":"ZAKER","page":"2","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=57c93b139490cb3318000088","media_count":"0","is_full":"NO","content":"","type":"web2","special_info":{"open_type":"web","need_user_info":"N","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c93b139490cb3318000088&title=ZAKER%E8%82%A1%E5%B8%82%E7%9B%B4%E6%92%AD%EF%BC%9A%E5%91%A8%E4%B8%80%E5%B8%82%E5%9C%BA%E5%8A%A8%E6%80%81&open_type=web&_appid=androidphone&need_userinfo=N&url=http%3A%2F%2Flive.3g.cnfol.com%2Findex.php%3Fr%3DLiveStock%2Fzaker%26cls%3D0_new%26ch%3Dlive","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=4&app_ids=4&pk=57c93b139490cb3318000088&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c93b139490cb3318000088","icon_url":"http://zkres.myzaker.com/data/image/mark2/live_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57c93b139490cb3318000088&m=1473052202","list_dtime":"2016-09-05 08:55:27"},{"pk":"57cb50169490cbd00e000000","title":"日本实体店干掉电商，中国电商干掉实体店","date":"2016-09-05 00:17:29","auther_name":"看商界","page":"6","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=57cb50169490cbd00e000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57cab49a1bc8e0e917000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cab49a1bc8e0e917000000_320.jpg","thumbnail_picsize":"600,400","media_count":"23","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cb50169490cbd00e000000&m=1473052202","list_dtime":"2016-09-05 00:17:29"},{"pk":"57cce7e39490cbe77d000027","title":"沪指涨0.2% 权重股分化","title_line_break":"沪指涨0.2%\n权重股分化","date":"2016-09-05 11:34:12","auther_name":"腾讯证券","page":"1","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=57cce7e39490cbe77d000027","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce7e6a07aecc52301ede4_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce7e6a07aecc52301ede4_320.jpg","thumbnail_picsize":"505,330","media_count":"1","is_full":"NO","content":"","special_type":"tag","special_info":{"icon_url":"http://zkres.myzaker.com/data/image/mark2/wp_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cce7e39490cbe77d000027&m=1473052202","list_dtime":"2016-09-05 11:34:12"},{"pk":"57cc4aa59490cbe27d000000","title":"马云离A股有多远？","date":"2016-09-05 00:23:18","auther_name":"华夏时报","page":"4","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57cc4aa59490cbe27d000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjNGJkNmEwN2FlY2M1MjMwMWFlOWJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjNGJkNmEwN2FlY2M1MjMwMWFlOWJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cc4aa59490cbe27d000000&m=1473052202","list_dtime":"2016-09-05 00:23:18"},{"pk":"57cce4831bc8e01a0c00005f","title":"深圳有望成为全国首个消灭现金的城市？","date":"2016-09-05 11:23:59","auther_name":"深圳晚报","weburl":"http://iphone.myzaker.com/l.php?l=57cce4831bc8e01a0c00005f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce357a07aecc52301e8d6_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce357a07aecc52301e8d6_320.jpg","thumbnail_picsize":"287,229","media_count":"23","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cce4831bc8e01a0c00005f&m=1473052012","list_dtime":"2016-09-05 11:23:59"},{"pk":"57ccba329490cbee5c000000","title":"一张图映射了中国企业的现状","date":"2016-09-05 09:29:49","auther_name":"投资界","weburl":"http://iphone.myzaker.com/l.php?l=57ccba329490cbee5c000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb8471bc8e0aa47000032_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb8471bc8e0aa47000032_320.jpg","thumbnail_picsize":"574,538","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccba329490cbee5c000000&m=1473052012","list_dtime":"2016-09-05 09:29:49"},{"pk":"57ccd4d89490cbda7d000014","title":"深度：如何做到月薪10万？","title_line_break":"深度：\n如何做到月薪10万？","date":"2016-09-05 10:15:36","auther_name":"21世纪经济报道","weburl":"http://iphone.myzaker.com/l.php?l=57ccd4d89490cbda7d000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd1061bc8e07a5500000f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd1061bc8e07a5500000f_320.jpg","thumbnail_picsize":"640,349","media_count":"6","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccd4d89490cbda7d000014&url=http%3A%2F%2Fm.21jingji.com%2Farticle%2F20160905%2Fherald%2Fc60af4f19b4a689c6e54a84d8b94d41c_zaker.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd4d89490cbda7d000014&m=1473052012","list_dtime":"2016-09-05 10:15:36"},{"pk":"57ccb41e9490cbf67d000037","title":"银行信贷员眼里的买房人现状","date":"2016-09-05 07:54:06","auther_name":"融360","weburl":"http://iphone.myzaker.com/l.php?l=57ccb41e9490cbf67d000037","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca00601bc8e0cb28000015_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca00601bc8e0cb28000015_320.jpg","thumbnail_picsize":"600,400","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccb41e9490cbf67d000037&m=1473052012","list_dtime":"2016-09-05 07:54:06"},{"pk":"57ccc5d81bc8e01a0c000009","title":"在中国，哪里的富豪最多最有钱？","date":"2016-09-05 09:26:29","auther_name":"策略家","weburl":"http://iphone.myzaker.com/l.php?l=57ccc5d81bc8e01a0c000009","thumbnail_pic":"http://zkres.myzaker.com/img_upload/cms/ck/img/12214/2016/09/05/1473036798.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc20da07aecc52301cd36_320.jpg","thumbnail_picsize":"304,220","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccc5d81bc8e01a0c000009&m=1473052012","list_dtime":"2016-09-05 09:26:29"},{"pk":"57ccf65a9490cb4c7e000030","title":"马云给全球工商大佬展示哪五张照片","date":"2016-09-05 12:36:42","auther_name":"新华视界","weburl":"http://iphone.myzaker.com/l.php?l=57ccf65a9490cb4c7e000030","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc3111f5a2247e47000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc3111f5a2247e47000001_320.jpg","thumbnail_picsize":"640,426","media_count":"16","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccf65a9490cb4c7e000030&m=1473052011","list_dtime":"2016-09-05 12:36:42"},{"pk":"57ccdafc1bc8e0300c000032","title":"广州市民66万在郑州被盗刷 银行被判全赔","title_line_break":"广州市民66万在郑州被盗刷\n银行被判全赔","date":"2016-09-05 11:16:44","auther_name":"信息时报","weburl":"http://iphone.myzaker.com/l.php?l=57ccdafc1bc8e0300c000032","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd8d0a07aecc52301db06_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd8d0a07aecc52301db06_320.jpg","thumbnail_picsize":"424,238","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccdafc1bc8e0300c000032&m=1473052012","list_dtime":"2016-09-05 11:16:44"},{"pk":"57ccd4e89490cb227e000023","title":"万般无奈的不婚族","date":"2016-09-05 10:14:00","auther_name":"21世纪经济报道","weburl":"http://iphone.myzaker.com/l.php?l=57ccd4e89490cb227e000023","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccd4e89490cb227e000023&url=http%3A%2F%2Fm.21jingji.com%2Farticle%2F20160905%2Fherald%2F5fea83c73265ba05813a9241d8cccf68_zaker.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd4e89490cb227e000023&m=1473052012","list_dtime":"2016-09-05 10:14:00"},{"pk":"57ccce611bc8e0160c00002f","title":"养老金要涨了!对表自查你能涨多少","date":"2016-09-05 10:04:58","auther_name":"中国新闻网","weburl":"http://iphone.myzaker.com/l.php?l=57ccce611bc8e0160c00002f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccd05a07aecc52301d34e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccd05a07aecc52301d34e_320.jpg","thumbnail_picsize":"500,294","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccce611bc8e0160c00002f&m=1473052012","list_dtime":"2016-09-05 10:04:58"},{"pk":"57cce5909490cb4a7e000040","title":"体制问题不解决，东北振兴是纸上谈兵？","date":"2016-09-05 11:25:04","auther_name":"第一财经日报","weburl":"http://iphone.myzaker.com/l.php?l=57cce5909490cb4a7e000040","media_count":"1","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57cce5909490cb4a7e000040&url=http%3A%2F%2Fex-rss.yicai.com%2Fex%2Fzaker%2Fnews%2F5087033.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cce5909490cb4a7e000040&m=1473052011","list_dtime":"2016-09-05 11:25:04"},{"pk":"57ccd73c1bc8e0210c00001b","title":"马云买下KFC？蚂蚁金服投资额仅为5000万","date":"2016-09-05 10:28:06","auther_name":" 北京晨报 ","weburl":"http://iphone.myzaker.com/l.php?l=57ccd73c1bc8e0210c00001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc203a07aecc52301cd34_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc203a07aecc52301cd34_320.jpg","thumbnail_picsize":"624,439","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd73c1bc8e0210c00001b&m=1473052012","list_dtime":"2016-09-05 10:28:06"},{"pk":"57cced649490cb424b000007","title":"照抄阿里模式 万达的金融之路意在抢蛋糕？","title_line_break":"照抄阿里模式\n万达的金融之路意在抢蛋糕？","date":"2016-09-05 11:58:28","auther_name":"环球老虎财经","weburl":"http://iphone.myzaker.com/l.php?l=57cced649490cb424b000007","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cced649490cb424b000007&m=1473052011","list_dtime":"2016-09-05 11:58:28"},{"pk":"57ccde879490cbd51f000000","title":"494亿日元！安倍再次巨资援助埃及","date":"2016-09-05 11:12:40","auther_name":"第一财经日报","weburl":"http://iphone.myzaker.com/l.php?l=57ccde879490cbd51f000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccddbd7f52e988640001b5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccddbd7f52e988640001b5_320.jpg","thumbnail_picsize":"504,388","media_count":"1","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccde879490cbd51f000000&url=http%3A%2F%2Fex-rss.yicai.com%2Fex%2Fzaker%2Fnews%2F5087180.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccde879490cbd51f000000&m=1473052012","list_dtime":"2016-09-05 11:12:40"},{"pk":"57ccd48b9490cbf17d00001b","title":"\u201c房抵贷\u201d加杠杆火热 最高额度无上限","title_line_break":"\u201c房抵贷\u201d加杠杆火热\n最高额度无上限","date":"2016-09-05 10:22:53","auther_name":"财新网","weburl":"http://iphone.myzaker.com/l.php?l=57ccd48b9490cbf17d00001b","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccd48b9490cbf17d00001b&url=http%3A%2F%2Fm.finance.caixin.com%2Fzknews%2F2016-09-05%2F100985317.html%3Futm_source%3DZaker%26utm_medium%3DZakerAPP%26utm_campaign%3DHezuo","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd48b9490cbf17d00001b&m=1473052012","list_dtime":"2016-09-05 10:22:53"},{"pk":"57ccd65e9490cb6d7100001e","title":"7月铁路货运降幅扩大：货运量2.6亿吨 同比降6.7%","title_line_break":"7月铁路货运降幅扩大：\n货运量2.6亿吨 同比降6.7%","date":"2016-09-05 11:57:14","auther_name":"新浪财经","weburl":"http://iphone.myzaker.com/l.php?l=57ccd65e9490cb6d7100001e","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd65e9490cb6d7100001e&m=1473052011","list_dtime":"2016-09-05 11:57:14"},{"pk":"57ccb03e9490cb147e00002f","title":"9月5日操盘必读","date":"2016-09-05 07:37:04","auther_name":"财联社","weburl":"http://iphone.myzaker.com/l.php?l=57ccb03e9490cb147e00002f","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccb03e9490cb147e00002f&m=1473052012","list_dtime":"2016-09-05 07:37:04"},{"pk":"57ccd5249490cb1b7e000024","title":"百年杂货之王：创造零售业若干第一","title_line_break":"百年杂货之王：\n创造零售业若干第一","date":"2016-09-05 10:19:56","auther_name":"商界","weburl":"http://iphone.myzaker.com/l.php?l=57ccd5249490cb1b7e000024","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccccca1bc8e02f54000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccccca1bc8e02f54000000_320.jpg","thumbnail_picsize":"550,309","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd5249490cb1b7e000024&m=1473052012","list_dtime":"2016-09-05 10:19:56"},{"pk":"57cce7859490cb247e00003a","title":"央行今日净回笼300亿元 本周有3900亿逆回购到期","title_line_break":"央行今日净回笼300亿元\n本周有3900亿逆回购到期","date":"2016-09-05 11:33:25","auther_name":"东方财富网","weburl":"http://iphone.myzaker.com/l.php?l=57cce7859490cb247e00003a","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cce7859490cb247e00003a&m=1473052011","list_dtime":"2016-09-05 11:33:25"},{"pk":"57ccb1e39490cb0c7e00002e","title":"拿地不一定死，不拿地肯定死","date":"2016-09-05 07:44:35","auther_name":"楼市参考","weburl":"http://iphone.myzaker.com/l.php?l=57ccb1e39490cb0c7e00002e","thumbnail_pic":"http://zkres.myzaker.com/201608/57a5695d7f52e93b2200042f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57a5695d7f52e93b2200042f_320.jpg","thumbnail_picsize":"724,482","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccb1e39490cb0c7e00002e&m=1473052012","list_dtime":"2016-09-05 07:44:35"},{"pk":"57ca664f9490cbf43e000049","title":"吴晓波：对商业的反叛本身就是一门生意","title_line_break":"吴晓波：\n对商业的反叛本身就是一门生意","date":"2016-09-05 10:15:01","auther_name":"商界","weburl":"http://iphone.myzaker.com/l.php?l=57ca664f9490cbf43e000049","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca5ed11bc8e0c361000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca5ed11bc8e0c361000000_320.jpg","thumbnail_picsize":"500,274","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ca664f9490cbf43e000049&m=1473052012","list_dtime":"2016-09-05 10:15:01"},{"pk":"57ccacfb9490cb0c7e000028","title":"一张图看懂离婚潮背后的经济真相！","date":"2016-09-05 07:03:39","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57ccacfb9490cb0c7e000028","media_count":"2","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccacfb9490cb0c7e000028&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_1_1377_241055.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccacfb9490cb0c7e000028&m=1473052012","list_dtime":"2016-09-05 07:03:39"},{"pk":"57ccd4949490cb097e000027","title":"在岸人民币汇率开盘震荡升值","date":"2016-09-05 10:12:36","auther_name":"财新网","weburl":"http://iphone.myzaker.com/l.php?l=57ccd4949490cb097e000027","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccd4949490cb097e000027&url=http%3A%2F%2Fm.economy.caixin.com%2Fzknews%2F2016-09-05%2F100985345.html%3Futm_source%3DZaker%26utm_medium%3DZakerAPP%26utm_campaign%3DHezuo","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd4949490cb097e000027&m=1473052012","list_dtime":"2016-09-05 10:12:36"},{"pk":"57ccb4929490cb7e7200000c","title":"多地发布养老金调整方案 平均上涨6.5%","title_line_break":"多地发布养老金调整方案\n平均上涨6.5%","date":"2016-09-05 07:56:02","auther_name":"观察者网-财经","weburl":"http://iphone.myzaker.com/l.php?l=57ccb4929490cb7e7200000c","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbca5a1bc8e09e3100000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbca5a1bc8e09e3100000d_320.jpg","thumbnail_picsize":"500,333","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccb4929490cb7e7200000c&m=1473052012","list_dtime":"2016-09-05 07:56:02"},{"pk":"57ccae739490cbda7d00000f","title":"四大利好合力出击 A股\u201c金九银十\u201d值得期待","title_line_break":"四大利好合力出击\nA股\u201c金九银十\u201d值得期待","date":"2016-09-05 07:29:55","auther_name":"上海证券报","weburl":"http://iphone.myzaker.com/l.php?l=57ccae739490cbda7d00000f","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccae739490cbda7d00000f&m=1473052012","list_dtime":"2016-09-05 07:29:55"},{"pk":"57ccad4a9490cb097e00001d","title":"两面针陷多元发展死循环","date":"2016-09-05 07:24:58","auther_name":"北京商报","weburl":"http://iphone.myzaker.com/l.php?l=57ccad4a9490cb097e00001d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MzIyMl84MDAxMF9XNjQwSDM2MFM3Njk4Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MzIyMl84MDAxMF9XNjQwSDM2MFM3Njk4Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccad4a9490cb097e00001d&m=1473052012","list_dtime":"2016-09-05 07:24:58"},{"pk":"57ccd4d89490cbda7d000015","title":"\u201c房银商服\u201d成举牌\u201c高发地\u201d ","title_line_break":"\u201c房银商服\u201d成举牌\u201c高发地\u201d\n","date":"2016-09-05 10:18:43","auther_name":"21世纪经济报道","weburl":"http://iphone.myzaker.com/l.php?l=57ccd4d89490cbda7d000015","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccd4d89490cbda7d000015&url=http%3A%2F%2Fm.21jingji.com%2Farticle%2F20160905%2F4bbe81de2d661dcf1948a94a5859df81_zaker.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd4d89490cbda7d000015&m=1473052012","list_dtime":"2016-09-05 10:18:43"},{"pk":"57ccad4a9490cb097e00001e","title":"雀巢押宝医疗健康","date":"2016-09-05 07:34:34","auther_name":"北京商报","weburl":"http://iphone.myzaker.com/l.php?l=57ccad4a9490cb097e00001e","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccad4a9490cb097e00001e&m=1473052012","list_dtime":"2016-09-05 07:34:34"},{"pk":"57ccae739490cbda7d000010","title":"爱康科技拟9.6亿元收购爱康光电","date":"2016-09-05 07:34:51","auther_name":"上海证券报","weburl":"http://iphone.myzaker.com/l.php?l=57ccae739490cbda7d000010","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccae739490cbda7d000010&m=1473052012","list_dtime":"2016-09-05 07:34:51"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccd89e9490cbff7d000026,57cce4831bc8e01a0c00005f,57ccba329490cbee5c000000,57ccd4d89490cbda7d000014,57cce7e39490cbe77d000027,57ccb3b09490cbf57d00000a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccc5d81bc8e01a0c000009,57ccb41e9490cbf67d000037,57ccf65a9490cb4c7e000030,57ccdafc1bc8e0300c000032,57c93b139490cb3318000088,57ccd4e89490cb227e000023","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cce59d9490cb127e000019,57ccce611bc8e0160c00002f,57cce5909490cb4a7e000040,57ccd73c1bc8e0210c00001b,57cced649490cb424b000007,57ccde879490cbd51f000000","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cc4aa59490cbe27d000000,57ccd48b9490cbf17d00001b,57ccd65e9490cb6d7100001e,57ccb03e9490cb147e00002f,57ccd5249490cb1b7e000024,57cce7859490cb247e00003a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca664f9490cbf43e000049,57ccb1e39490cb0c7e00002e,57ccacfb9490cb0c7e000028,57ccd4949490cb097e000027,57ccdada1bc8e01c0c000032,57ccb4929490cb7e7200000c","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccad4a9490cb097e00001d,57ccae739490cbda7d00000f,57ccd4d89490cbda7d000015,57ccad4a9490cb097e00001e,57cb50169490cbd00e000000,57ccae739490cbda7d000010","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#f05a5a","#f05a5a"],"only_text_page_bgcolors":["#f05a5a","#f05a5a"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/4.png?t=1458286563","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/4.png?t=1458286563","hidden_time":"24","need_userinfo":"NO","block_title":"财经新闻","template_group":"classic","block_color":"#f05a5a","desktop_color_number":"0","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_3bed28aee080bf7e7e9e6e15317b5aa4","selected_index":"0","list":[{"pk":"zk_app_column_4","title":"要闻","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"4","title":"财经新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=4&catalog_appid=4","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_11691","title":"股票","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11691_zk_app_column_block_4","title":"股票频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11691&catalog_appid=4","data_type":"news"}},{"pk":"zk_app_column_11678","title":"行情","type":"web","web":{"url":"http://wl.myzaker.com/service/em.php?app_id=4&position=column_tab_ad&callback=http%3A%2F%2Fpassport.eastmoney.com%2Fmobileapp%2Fzaker_login.aspx","need_user_info":"Y","type":""}}]}}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=4&since_date=1472891309&nt=1&next_aticle_id=57ccad4a9490cb097e00001f&_appid=androidphone&opage=2&otimestamp=160","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=4&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=4&ids=5642f2aa9490cbb13200000e,54dde63f9490cbbf07000101&k=201609051310"}
     * catalog :
     * articles : [{"pk":"57ccb3b09490cbf57d00000a","title":"G20峰会为何对中国如此重要？","date":"2016-09-05 07:52:16","auther_name":"商界","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57ccb3b09490cbf57d00000a","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbfc1a1bc8e0cc52000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbfc1a1bc8e0cc52000000_320.jpg","thumbnail_picsize":"580,328","media_count":"25","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c8f9fa9490cbd91700004b","block_title":"G20将如何影响你的钱袋子？","title":"G20将如何影响你的钱袋子？","block_in_title":"G20峰会为何对中国如此重要？","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=4&topic_id=57c8f9fa9490cbd91700004b&updated=1473041444"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccb3b09490cbf57d00000a&m=1473052202","list_dtime":"2016-09-05 07:52:16"},{"pk":"57ccdada1bc8e01c0c000032","title":"富豪都已逃离楼市，未来的钱会去哪？","date":"2016-09-05 10:39:25","auther_name":"种钱","page":"5","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=57ccdada1bc8e01c0c000032","thumbnail_pic":"http://zkres.myzaker.com/data/attachment/editor/2016/09/05/1473043367.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdbfaa07aecc52301dcf8_320.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","type":"other","special_info":{"open_type":"block","block_info":{"pk":"6","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=6","data_type":"rss"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=4&app_ids=4&pk=57ccdada1bc8e01c0c000032&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57ccdada1bc8e01c0c000032","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccdada1bc8e01c0c000032&m=1473052202","list_dtime":"2016-09-05 10:39:25"},{"pk":"57ccd89e9490cbff7d000026","title":"摸底房企资金流：1.5万亿资金等待出笼","title_line_break":"摸底房企资金流：\n1.5万亿资金等待出笼","date":"2016-09-05 10:29:10","auther_name":"21世纪经济报道","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ccd89e9490cbff7d000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZGFkZGEwN2FlY2M1MjMwMWRjMmZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZGFkZGEwN2FlY2M1MjMwMWRjMmZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd89e9490cbff7d000026&m=1473052202","list_dtime":"2016-09-05 10:29:10"},{"pk":"57cce59d9490cb127e000019","title":"刚需族贷款买房，月供多少最合适？","date":"2016-09-05 11:25:17","auther_name":"21世纪经济报道","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57cce59d9490cb127e000019","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Njc4NF80MTkyMl9XNjQwSDM2MFM4MjQ3Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Njc4NF80MTkyMl9XNjQwSDM2MFM4MjQ3Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57cce59d9490cb127e000019&url=http%3A%2F%2Fm.21jingji.com%2Farticle%2F20160905%2Fherald%2Fd478b70d2e9943142cec46f11c878dbf_zaker.html","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cce59d9490cb127e000019&m=1473052202","list_dtime":"2016-09-05 11:25:17"},{"pk":"57c93b139490cb3318000088","title":"ZAKER股市直播：周一市场动态","title_line_break":"ZAKER股市直播：\n周一市场动态","date":"2016-09-05 08:55:27","auther_name":"ZAKER","page":"2","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=57c93b139490cb3318000088","media_count":"0","is_full":"NO","content":"","type":"web2","special_info":{"open_type":"web","need_user_info":"N","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c93b139490cb3318000088&title=ZAKER%E8%82%A1%E5%B8%82%E7%9B%B4%E6%92%AD%EF%BC%9A%E5%91%A8%E4%B8%80%E5%B8%82%E5%9C%BA%E5%8A%A8%E6%80%81&open_type=web&_appid=androidphone&need_userinfo=N&url=http%3A%2F%2Flive.3g.cnfol.com%2Findex.php%3Fr%3DLiveStock%2Fzaker%26cls%3D0_new%26ch%3Dlive","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=4&app_ids=4&pk=57c93b139490cb3318000088&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c93b139490cb3318000088","icon_url":"http://zkres.myzaker.com/data/image/mark2/live_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57c93b139490cb3318000088&m=1473052202","list_dtime":"2016-09-05 08:55:27"},{"pk":"57cb50169490cbd00e000000","title":"日本实体店干掉电商，中国电商干掉实体店","date":"2016-09-05 00:17:29","auther_name":"看商界","page":"6","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=57cb50169490cbd00e000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57cab49a1bc8e0e917000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cab49a1bc8e0e917000000_320.jpg","thumbnail_picsize":"600,400","media_count":"23","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cb50169490cbd00e000000&m=1473052202","list_dtime":"2016-09-05 00:17:29"},{"pk":"57cce7e39490cbe77d000027","title":"沪指涨0.2% 权重股分化","title_line_break":"沪指涨0.2%\n权重股分化","date":"2016-09-05 11:34:12","auther_name":"腾讯证券","page":"1","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=57cce7e39490cbe77d000027","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce7e6a07aecc52301ede4_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce7e6a07aecc52301ede4_320.jpg","thumbnail_picsize":"505,330","media_count":"1","is_full":"NO","content":"","special_type":"tag","special_info":{"icon_url":"http://zkres.myzaker.com/data/image/mark2/wp_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cce7e39490cbe77d000027&m=1473052202","list_dtime":"2016-09-05 11:34:12"},{"pk":"57cc4aa59490cbe27d000000","title":"马云离A股有多远？","date":"2016-09-05 00:23:18","auther_name":"华夏时报","page":"4","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57cc4aa59490cbe27d000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjNGJkNmEwN2FlY2M1MjMwMWFlOWJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjNGJkNmEwN2FlY2M1MjMwMWFlOWJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cc4aa59490cbe27d000000&m=1473052202","list_dtime":"2016-09-05 00:23:18"},{"pk":"57cce4831bc8e01a0c00005f","title":"深圳有望成为全国首个消灭现金的城市？","date":"2016-09-05 11:23:59","auther_name":"深圳晚报","weburl":"http://iphone.myzaker.com/l.php?l=57cce4831bc8e01a0c00005f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce357a07aecc52301e8d6_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce357a07aecc52301e8d6_320.jpg","thumbnail_picsize":"287,229","media_count":"23","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cce4831bc8e01a0c00005f&m=1473052012","list_dtime":"2016-09-05 11:23:59"},{"pk":"57ccba329490cbee5c000000","title":"一张图映射了中国企业的现状","date":"2016-09-05 09:29:49","auther_name":"投资界","weburl":"http://iphone.myzaker.com/l.php?l=57ccba329490cbee5c000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb8471bc8e0aa47000032_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb8471bc8e0aa47000032_320.jpg","thumbnail_picsize":"574,538","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccba329490cbee5c000000&m=1473052012","list_dtime":"2016-09-05 09:29:49"},{"pk":"57ccd4d89490cbda7d000014","title":"深度：如何做到月薪10万？","title_line_break":"深度：\n如何做到月薪10万？","date":"2016-09-05 10:15:36","auther_name":"21世纪经济报道","weburl":"http://iphone.myzaker.com/l.php?l=57ccd4d89490cbda7d000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd1061bc8e07a5500000f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd1061bc8e07a5500000f_320.jpg","thumbnail_picsize":"640,349","media_count":"6","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccd4d89490cbda7d000014&url=http%3A%2F%2Fm.21jingji.com%2Farticle%2F20160905%2Fherald%2Fc60af4f19b4a689c6e54a84d8b94d41c_zaker.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd4d89490cbda7d000014&m=1473052012","list_dtime":"2016-09-05 10:15:36"},{"pk":"57ccb41e9490cbf67d000037","title":"银行信贷员眼里的买房人现状","date":"2016-09-05 07:54:06","auther_name":"融360","weburl":"http://iphone.myzaker.com/l.php?l=57ccb41e9490cbf67d000037","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca00601bc8e0cb28000015_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca00601bc8e0cb28000015_320.jpg","thumbnail_picsize":"600,400","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccb41e9490cbf67d000037&m=1473052012","list_dtime":"2016-09-05 07:54:06"},{"pk":"57ccc5d81bc8e01a0c000009","title":"在中国，哪里的富豪最多最有钱？","date":"2016-09-05 09:26:29","auther_name":"策略家","weburl":"http://iphone.myzaker.com/l.php?l=57ccc5d81bc8e01a0c000009","thumbnail_pic":"http://zkres.myzaker.com/img_upload/cms/ck/img/12214/2016/09/05/1473036798.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc20da07aecc52301cd36_320.jpg","thumbnail_picsize":"304,220","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccc5d81bc8e01a0c000009&m=1473052012","list_dtime":"2016-09-05 09:26:29"},{"pk":"57ccf65a9490cb4c7e000030","title":"马云给全球工商大佬展示哪五张照片","date":"2016-09-05 12:36:42","auther_name":"新华视界","weburl":"http://iphone.myzaker.com/l.php?l=57ccf65a9490cb4c7e000030","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc3111f5a2247e47000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc3111f5a2247e47000001_320.jpg","thumbnail_picsize":"640,426","media_count":"16","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccf65a9490cb4c7e000030&m=1473052011","list_dtime":"2016-09-05 12:36:42"},{"pk":"57ccdafc1bc8e0300c000032","title":"广州市民66万在郑州被盗刷 银行被判全赔","title_line_break":"广州市民66万在郑州被盗刷\n银行被判全赔","date":"2016-09-05 11:16:44","auther_name":"信息时报","weburl":"http://iphone.myzaker.com/l.php?l=57ccdafc1bc8e0300c000032","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd8d0a07aecc52301db06_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd8d0a07aecc52301db06_320.jpg","thumbnail_picsize":"424,238","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccdafc1bc8e0300c000032&m=1473052012","list_dtime":"2016-09-05 11:16:44"},{"pk":"57ccd4e89490cb227e000023","title":"万般无奈的不婚族","date":"2016-09-05 10:14:00","auther_name":"21世纪经济报道","weburl":"http://iphone.myzaker.com/l.php?l=57ccd4e89490cb227e000023","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccd4e89490cb227e000023&url=http%3A%2F%2Fm.21jingji.com%2Farticle%2F20160905%2Fherald%2F5fea83c73265ba05813a9241d8cccf68_zaker.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd4e89490cb227e000023&m=1473052012","list_dtime":"2016-09-05 10:14:00"},{"pk":"57ccce611bc8e0160c00002f","title":"养老金要涨了!对表自查你能涨多少","date":"2016-09-05 10:04:58","auther_name":"中国新闻网","weburl":"http://iphone.myzaker.com/l.php?l=57ccce611bc8e0160c00002f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccd05a07aecc52301d34e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccd05a07aecc52301d34e_320.jpg","thumbnail_picsize":"500,294","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccce611bc8e0160c00002f&m=1473052012","list_dtime":"2016-09-05 10:04:58"},{"pk":"57cce5909490cb4a7e000040","title":"体制问题不解决，东北振兴是纸上谈兵？","date":"2016-09-05 11:25:04","auther_name":"第一财经日报","weburl":"http://iphone.myzaker.com/l.php?l=57cce5909490cb4a7e000040","media_count":"1","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57cce5909490cb4a7e000040&url=http%3A%2F%2Fex-rss.yicai.com%2Fex%2Fzaker%2Fnews%2F5087033.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cce5909490cb4a7e000040&m=1473052011","list_dtime":"2016-09-05 11:25:04"},{"pk":"57ccd73c1bc8e0210c00001b","title":"马云买下KFC？蚂蚁金服投资额仅为5000万","date":"2016-09-05 10:28:06","auther_name":" 北京晨报 ","weburl":"http://iphone.myzaker.com/l.php?l=57ccd73c1bc8e0210c00001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc203a07aecc52301cd34_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc203a07aecc52301cd34_320.jpg","thumbnail_picsize":"624,439","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd73c1bc8e0210c00001b&m=1473052012","list_dtime":"2016-09-05 10:28:06"},{"pk":"57cced649490cb424b000007","title":"照抄阿里模式 万达的金融之路意在抢蛋糕？","title_line_break":"照抄阿里模式\n万达的金融之路意在抢蛋糕？","date":"2016-09-05 11:58:28","auther_name":"环球老虎财经","weburl":"http://iphone.myzaker.com/l.php?l=57cced649490cb424b000007","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cced649490cb424b000007&m=1473052011","list_dtime":"2016-09-05 11:58:28"},{"pk":"57ccde879490cbd51f000000","title":"494亿日元！安倍再次巨资援助埃及","date":"2016-09-05 11:12:40","auther_name":"第一财经日报","weburl":"http://iphone.myzaker.com/l.php?l=57ccde879490cbd51f000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccddbd7f52e988640001b5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccddbd7f52e988640001b5_320.jpg","thumbnail_picsize":"504,388","media_count":"1","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccde879490cbd51f000000&url=http%3A%2F%2Fex-rss.yicai.com%2Fex%2Fzaker%2Fnews%2F5087180.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccde879490cbd51f000000&m=1473052012","list_dtime":"2016-09-05 11:12:40"},{"pk":"57ccd48b9490cbf17d00001b","title":"\u201c房抵贷\u201d加杠杆火热 最高额度无上限","title_line_break":"\u201c房抵贷\u201d加杠杆火热\n最高额度无上限","date":"2016-09-05 10:22:53","auther_name":"财新网","weburl":"http://iphone.myzaker.com/l.php?l=57ccd48b9490cbf17d00001b","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccd48b9490cbf17d00001b&url=http%3A%2F%2Fm.finance.caixin.com%2Fzknews%2F2016-09-05%2F100985317.html%3Futm_source%3DZaker%26utm_medium%3DZakerAPP%26utm_campaign%3DHezuo","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd48b9490cbf17d00001b&m=1473052012","list_dtime":"2016-09-05 10:22:53"},{"pk":"57ccd65e9490cb6d7100001e","title":"7月铁路货运降幅扩大：货运量2.6亿吨 同比降6.7%","title_line_break":"7月铁路货运降幅扩大：\n货运量2.6亿吨 同比降6.7%","date":"2016-09-05 11:57:14","auther_name":"新浪财经","weburl":"http://iphone.myzaker.com/l.php?l=57ccd65e9490cb6d7100001e","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd65e9490cb6d7100001e&m=1473052011","list_dtime":"2016-09-05 11:57:14"},{"pk":"57ccb03e9490cb147e00002f","title":"9月5日操盘必读","date":"2016-09-05 07:37:04","auther_name":"财联社","weburl":"http://iphone.myzaker.com/l.php?l=57ccb03e9490cb147e00002f","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccb03e9490cb147e00002f&m=1473052012","list_dtime":"2016-09-05 07:37:04"},{"pk":"57ccd5249490cb1b7e000024","title":"百年杂货之王：创造零售业若干第一","title_line_break":"百年杂货之王：\n创造零售业若干第一","date":"2016-09-05 10:19:56","auther_name":"商界","weburl":"http://iphone.myzaker.com/l.php?l=57ccd5249490cb1b7e000024","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccccca1bc8e02f54000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccccca1bc8e02f54000000_320.jpg","thumbnail_picsize":"550,309","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd5249490cb1b7e000024&m=1473052012","list_dtime":"2016-09-05 10:19:56"},{"pk":"57cce7859490cb247e00003a","title":"央行今日净回笼300亿元 本周有3900亿逆回购到期","title_line_break":"央行今日净回笼300亿元\n本周有3900亿逆回购到期","date":"2016-09-05 11:33:25","auther_name":"东方财富网","weburl":"http://iphone.myzaker.com/l.php?l=57cce7859490cb247e00003a","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57cce7859490cb247e00003a&m=1473052011","list_dtime":"2016-09-05 11:33:25"},{"pk":"57ccb1e39490cb0c7e00002e","title":"拿地不一定死，不拿地肯定死","date":"2016-09-05 07:44:35","auther_name":"楼市参考","weburl":"http://iphone.myzaker.com/l.php?l=57ccb1e39490cb0c7e00002e","thumbnail_pic":"http://zkres.myzaker.com/201608/57a5695d7f52e93b2200042f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57a5695d7f52e93b2200042f_320.jpg","thumbnail_picsize":"724,482","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccb1e39490cb0c7e00002e&m=1473052012","list_dtime":"2016-09-05 07:44:35"},{"pk":"57ca664f9490cbf43e000049","title":"吴晓波：对商业的反叛本身就是一门生意","title_line_break":"吴晓波：\n对商业的反叛本身就是一门生意","date":"2016-09-05 10:15:01","auther_name":"商界","weburl":"http://iphone.myzaker.com/l.php?l=57ca664f9490cbf43e000049","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca5ed11bc8e0c361000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca5ed11bc8e0c361000000_320.jpg","thumbnail_picsize":"500,274","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ca664f9490cbf43e000049&m=1473052012","list_dtime":"2016-09-05 10:15:01"},{"pk":"57ccacfb9490cb0c7e000028","title":"一张图看懂离婚潮背后的经济真相！","date":"2016-09-05 07:03:39","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57ccacfb9490cb0c7e000028","media_count":"2","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccacfb9490cb0c7e000028&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_1_1377_241055.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccacfb9490cb0c7e000028&m=1473052012","list_dtime":"2016-09-05 07:03:39"},{"pk":"57ccd4949490cb097e000027","title":"在岸人民币汇率开盘震荡升值","date":"2016-09-05 10:12:36","auther_name":"财新网","weburl":"http://iphone.myzaker.com/l.php?l=57ccd4949490cb097e000027","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccd4949490cb097e000027&url=http%3A%2F%2Fm.economy.caixin.com%2Fzknews%2F2016-09-05%2F100985345.html%3Futm_source%3DZaker%26utm_medium%3DZakerAPP%26utm_campaign%3DHezuo","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd4949490cb097e000027&m=1473052012","list_dtime":"2016-09-05 10:12:36"},{"pk":"57ccb4929490cb7e7200000c","title":"多地发布养老金调整方案 平均上涨6.5%","title_line_break":"多地发布养老金调整方案\n平均上涨6.5%","date":"2016-09-05 07:56:02","auther_name":"观察者网-财经","weburl":"http://iphone.myzaker.com/l.php?l=57ccb4929490cb7e7200000c","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbca5a1bc8e09e3100000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbca5a1bc8e09e3100000d_320.jpg","thumbnail_picsize":"500,333","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccb4929490cb7e7200000c&m=1473052012","list_dtime":"2016-09-05 07:56:02"},{"pk":"57ccae739490cbda7d00000f","title":"四大利好合力出击 A股\u201c金九银十\u201d值得期待","title_line_break":"四大利好合力出击\nA股\u201c金九银十\u201d值得期待","date":"2016-09-05 07:29:55","auther_name":"上海证券报","weburl":"http://iphone.myzaker.com/l.php?l=57ccae739490cbda7d00000f","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccae739490cbda7d00000f&m=1473052012","list_dtime":"2016-09-05 07:29:55"},{"pk":"57ccad4a9490cb097e00001d","title":"两面针陷多元发展死循环","date":"2016-09-05 07:24:58","auther_name":"北京商报","weburl":"http://iphone.myzaker.com/l.php?l=57ccad4a9490cb097e00001d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MzIyMl84MDAxMF9XNjQwSDM2MFM3Njk4Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MzIyMl84MDAxMF9XNjQwSDM2MFM3Njk4Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccad4a9490cb097e00001d&m=1473052012","list_dtime":"2016-09-05 07:24:58"},{"pk":"57ccd4d89490cbda7d000015","title":"\u201c房银商服\u201d成举牌\u201c高发地\u201d ","title_line_break":"\u201c房银商服\u201d成举牌\u201c高发地\u201d\n","date":"2016-09-05 10:18:43","auther_name":"21世纪经济报道","weburl":"http://iphone.myzaker.com/l.php?l=57ccd4d89490cbda7d000015","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=4&pk=57ccd4d89490cbda7d000015&url=http%3A%2F%2Fm.21jingji.com%2Farticle%2F20160905%2F4bbe81de2d661dcf1948a94a5859df81_zaker.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccd4d89490cbda7d000015&m=1473052012","list_dtime":"2016-09-05 10:18:43"},{"pk":"57ccad4a9490cb097e00001e","title":"雀巢押宝医疗健康","date":"2016-09-05 07:34:34","auther_name":"北京商报","weburl":"http://iphone.myzaker.com/l.php?l=57ccad4a9490cb097e00001e","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccad4a9490cb097e00001e&m=1473052012","list_dtime":"2016-09-05 07:34:34"},{"pk":"57ccae739490cbda7d000010","title":"爱康科技拟9.6亿元收购爱康光电","date":"2016-09-05 07:34:51","auther_name":"上海证券报","weburl":"http://iphone.myzaker.com/l.php?l=57ccae739490cbda7d000010","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccae739490cbda7d000010&m=1473052012","list_dtime":"2016-09-05 07:34:51"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccd89e9490cbff7d000026,57cce4831bc8e01a0c00005f,57ccba329490cbee5c000000,57ccd4d89490cbda7d000014,57cce7e39490cbe77d000027,57ccb3b09490cbf57d00000a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccc5d81bc8e01a0c000009,57ccb41e9490cbf67d000037,57ccf65a9490cb4c7e000030,57ccdafc1bc8e0300c000032,57c93b139490cb3318000088,57ccd4e89490cb227e000023","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cce59d9490cb127e000019,57ccce611bc8e0160c00002f,57cce5909490cb4a7e000040,57ccd73c1bc8e0210c00001b,57cced649490cb424b000007,57ccde879490cbd51f000000","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cc4aa59490cbe27d000000,57ccd48b9490cbf17d00001b,57ccd65e9490cb6d7100001e,57ccb03e9490cb147e00002f,57ccd5249490cb1b7e000024,57cce7859490cb247e00003a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca664f9490cbf43e000049,57ccb1e39490cb0c7e00002e,57ccacfb9490cb0c7e000028,57ccd4949490cb097e000027,57ccdada1bc8e01c0c000032,57ccb4929490cb7e7200000c","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccad4a9490cb097e00001d,57ccae739490cbda7d00000f,57ccd4d89490cbda7d000015,57ccad4a9490cb097e00001e,57cb50169490cbd00e000000,57ccae739490cbda7d000010","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#f05a5a","#f05a5a"],"only_text_page_bgcolors":["#f05a5a","#f05a5a"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/4.png?t=1458286563","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/4.png?t=1458286563","hidden_time":"24","need_userinfo":"NO","block_title":"财经新闻","template_group":"classic","block_color":"#f05a5a","desktop_color_number":"0","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_3bed28aee080bf7e7e9e6e15317b5aa4","selected_index":"0","list":[{"pk":"zk_app_column_4","title":"要闻","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"4","title":"财经新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=4&catalog_appid=4","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_11691","title":"股票","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11691_zk_app_column_block_4","title":"股票频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11691&catalog_appid=4","data_type":"news"}},{"pk":"zk_app_column_11678","title":"行情","type":"web","web":{"url":"http://wl.myzaker.com/service/em.php?app_id=4&position=column_tab_ad&callback=http%3A%2F%2Fpassport.eastmoney.com%2Fmobileapp%2Fzaker_login.aspx","need_user_info":"Y","type":""}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=4&since_date=1472891309&nt=1&next_aticle_id=57ccad4a9490cb097e00001f&_appid=androidphone&opage=2&otimestamp=160
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=4&need_app_integration=0
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=4&ids=5642f2aa9490cbb13200000e,54dde63f9490cbbf07000101&k=201609051310
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/4.png?t=1458286563
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/4.png?t=1458286563
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 财经新闻
         * template_group : classic
         * block_color : #f05a5a
         * desktop_color_number : 0
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_3bed28aee080bf7e7e9e6e15317b5aa4
         * selected_index : 0
         * list : [{"pk":"zk_app_column_4","title":"要闻","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"4","title":"财经新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=4&catalog_appid=4","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_11691","title":"股票","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11691_zk_app_column_block_4","title":"股票频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11691&catalog_appid=4","data_type":"news"}},{"pk":"zk_app_column_11678","title":"行情","type":"web","web":{"url":"http://wl.myzaker.com/service/em.php?app_id=4&position=column_tab_ad&callback=http%3A%2F%2Fpassport.eastmoney.com%2Fmobileapp%2Fzaker_login.aspx","need_user_info":"Y","type":""}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57ccb3b09490cbf57d00000a
         * title : G20峰会为何对中国如此重要？
         * date : 2016-09-05 07:52:16
         * auther_name : 商界
         * page : 1
         * index : 6
         * weburl : http://iphone.myzaker.com/l.php?l=57ccb3b09490cbf57d00000a
         * thumbnail_pic : http://zkres.myzaker.com/201609/57cbfc1a1bc8e0cc52000000_640.jpg
         * thumbnail_mpic : http://zkres.myzaker.com/201609/57cbfc1a1bc8e0cc52000000_320.jpg
         * thumbnail_picsize : 580,328
         * media_count : 25
         * is_full : NO
         * content :
         * special_type : topic
         * special_info : {"icon_type":"1","block_info":{"pk":"57c8f9fa9490cbd91700004b","block_title":"G20将如何影响你的钱袋子？","title":"G20将如何影响你的钱袋子？","block_in_title":"G20峰会为何对中国如此重要？","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=4&topic_id=57c8f9fa9490cbd91700004b&updated=1473041444"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=4&pk=57ccb3b09490cbf57d00000a&m=1473052202
         * list_dtime : 2016-09-05 07:52:16
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 2
             * articles : 57ccd89e9490cbff7d000026,57cce4831bc8e01a0c00005f,57ccba329490cbee5c000000,57ccd4d89490cbda7d000014,57cce7e39490cbe77d000027,57ccb3b09490cbf57d00000a
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/4.png?t=1458286563
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * open_type :
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String template_group;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getTemplate_group() {
                return template_group;
            }

            public void setTemplate_group(String template_group) {
                this.template_group = template_group;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_4
             * title : 要闻
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"4","title":"财经新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=4&catalog_appid=4","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 4
                 * title : 财经新闻
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=4&catalog_appid=4
                 * data_type : news
                 * skey : eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;
                    private String skey;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }

                    public String getSkey() {
                        return skey;
                    }

                    public void setSkey(String skey) {
                        this.skey = skey;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String is_full;
            private String content;
            private String special_type;
            /**
             * icon_type : 1
             * block_info : {"pk":"57c8f9fa9490cbd91700004b","block_title":"G20将如何影响你的钱袋子？","title":"G20将如何影响你的钱袋子？","block_in_title":"G20峰会为何对中国如此重要？","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=4&topic_id=57c8f9fa9490cbd91700004b&updated=1473041444"}
             * icon_url : http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getSpecial_type() {
                return special_type;
            }

            public void setSpecial_type(String special_type) {
                this.special_type = special_type;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String icon_type;
                /**
                 * pk : 57c8f9fa9490cbd91700004b
                 * block_title : G20将如何影响你的钱袋子？
                 * title : G20将如何影响你的钱袋子？
                 * block_in_title : G20峰会为何对中国如此重要？
                 * type : user
                 * need_userinfo : NO
                 * skey :
                 * api_url : http://iphone.myzaker.com/zaker/topic.php?app_id=4&topic_id=57c8f9fa9490cbd91700004b&updated=1473041444
                 */

                private BlockInfoBean block_info;
                private String icon_url;
                private String show_jingcai;
                private String list_nodsp;

                public String getIcon_type() {
                    return icon_type;
                }

                public void setIcon_type(String icon_type) {
                    this.icon_type = icon_type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public String getIcon_url() {
                    return icon_url;
                }

                public void setIcon_url(String icon_url) {
                    this.icon_url = icon_url;
                }

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }

                public static class BlockInfoBean {
                    private String pk;
                    private String block_title;
                    private String title;
                    private String block_in_title;
                    private String type;
                    private String need_userinfo;
                    private String skey;
                    private String api_url;

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getBlock_title() {
                        return block_title;
                    }

                    public void setBlock_title(String block_title) {
                        this.block_title = block_title;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getBlock_in_title() {
                        return block_in_title;
                    }

                    public void setBlock_in_title(String block_in_title) {
                        this.block_in_title = block_in_title;
                    }

                    public String getType() {
                        return type;
                    }

                    public void setType(String type) {
                        this.type = type;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getSkey() {
                        return skey;
                    }

                    public void setSkey(String skey) {
                        this.skey = skey;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }
                }
            }
        }
    }
}
