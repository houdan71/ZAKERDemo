package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/2.
 */
public class Bean_movie {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=10530&since_date=1472439872&nt=1&next_aticle_id=57c510421bc8e0a01b000007&_appid=androidphone&opage=2&otimestamp=159","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=10530&need_app_integration=1","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=10530&ids=5642f2aa9490cbb13200000e,51a7104681853dec4d00012f&k=201609021310"},"catalog":"","articles":[{"pk":"57c626399490cb4145000009","title":"收好这份片单，保证九月没烂片能骗到你","date":"2016-09-02 11:44:26","auther_name":"毒舌电影","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c626399490cb4145000009","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"90","app_ids":"10530","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c550b39490cb3f13000071","block_title":"每月片单","title":"每月片单","block_in_title":"收好这份片单，保证九月没烂片能骗到你","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=10530&topic_id=57c550b39490cb3f13000071&updated=1472786296"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png","show_jingcai":"Y","list_nodsp":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c626399490cb4145000009&m=1472792777","list_dtime":"2016-09-02 11:44:26","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c50bd39490cb3c72000017","title":"原来有这样一群导演，把观众当瞎子","date":"2016-09-02 10:41:46","auther_name":"十点电影","page":"1","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57c50bd39490cb3c72000017","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGExMDdmNTJlOTBlNDUwMDAwYjhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGExMDdmNTJlOTBlNDUwMDAwYjhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"300,225","media_count":"14","app_ids":"10530","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57c50bd39490cb3c72000017&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c50bd39490cb3c72000017%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","list_nodsp":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c50bd39490cb3c72000017&m=1472792778","list_dtime":"2016-09-02 10:41:46","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGExMDdmNTJlOTBlNDUwMDAwYjhfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGExMDdmNTJlOTBlNDUwMDAwYjhfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGExMDdmNTJlOTBlNDUwMDAwYjhfNjQwLmpwZw==_1242.jpg","w":"300","h":"225"}]},{"pk":"57c737449490cb0b70000001","title":"冲着斯嘉丽这个尤物，发现一部偷情神作","date":"2016-09-02 12:46:35","auther_name":"独立鱼电影","weburl":"http://iphone.myzaker.com/l.php?l=57c737449490cb0b70000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDI2MjdmNTJlOTViMDIwMDAzYjBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDI2MjdmNTJlOTViMDIwMDAzYjBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,382","media_count":"24","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c737449490cb0b70000001&m=1472792503","list_dtime":"2016-09-02 12:46:35","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDI2MjdmNTJlOTViMDIwMDAzYjBfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDI2MjdmNTJlOTViMDIwMDAzYjBfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDI2MjdmNTJlOTViMDIwMDAzYjBfNjQwLmpwZw==_1242.jpg","w":"600","h":"382"}]},{"pk":"57c84ca89490cba34c00009a","title":"9月新片推荐","date":"2016-09-02 11:44:44","auther_name":"独立鱼电影","weburl":"http://iphone.myzaker.com/l.php?l=57c84ca89490cba34c00009a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0MzUzMl80MzI0MF9XNDIzSDM4NVM1OTY0NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0MzUzMl80MzI0MF9XNDIzSDM4NVM1OTY0NS5qcGc=_1242.jpg","thumbnail_picsize":"423,385","media_count":"0","app_ids":"10530","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c84ca89490cba34c00009a&title=9%E6%9C%88%E6%96%B0%E7%89%87%E6%8E%A8%E8%8D%90&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_car.php%3Fpk%3D57c847b49490cb812c000076%26target%3Dweb3%26article_pk%3D57c84ca89490cba34c00009a","show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c84ca89490cba34c00009a&m=1472792503","list_dtime":"2016-09-02 11:44:44","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0MzUzMl80MzI0MF9XNDIzSDM4NVM1OTY0NS5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0MzUzMl80MzI0MF9XNDIzSDM4NVM1OTY0NS5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0MzUzMl80MzI0MF9XNDIzSDM4NVM1OTY0NS5qcGc=_1242.jpg","w":"423","h":"385"}]},{"pk":"57c70f6c9490cbbc07000001","title":"9月只有这11部电影值得你花钱！","date":"2016-09-02 12:47:28","auther_name":"抠电影","weburl":"http://iphone.myzaker.com/l.php?l=57c70f6c9490cbbc07000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcwMDQyNl82NDY3OV9XNjQwSDM2MFM1NjM2MS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcwMDQyNl82NDY3OV9XNjQwSDM2MFM1NjM2MS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"36","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c70f6c9490cbbc07000001&m=1472701431","list_dtime":"2016-09-02 12:47:28","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcwMDQyNl82NDY3OV9XNjQwSDM2MFM1NjM2MS5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcwMDQyNl82NDY3OV9XNjQwSDM2MFM1NjM2MS5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcwMDQyNl82NDY3OV9XNjQwSDM2MFM1NjM2MS5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c626399490cb414500000b","title":"我们再也回不去，那个美女如云的年代","date":"2016-09-02 10:00:30","auther_name":"毒舌电影","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c626399490cb414500000b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTQ0Nl8zNTA0M19XNjQwSDM2MFMzMzU2MS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTQ0Nl8zNTA0M19XNjQwSDM2MFMzMzU2MS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"55","app_ids":"10530","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c501e19490cb8713000031","block_title":"20160902影迷小宝鉴","title":"20160902影迷小宝鉴","block_in_title":"我们再也回不去，那个美女如云的年代","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=10530&topic_id=57c501e19490cb8713000031&updated=1472783475"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57c626399490cb414500000b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c626399490cb414500000b%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","list_nodsp":"Y","item_type":"1"},"type":"web3","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c626399490cb414500000b&m=1472792778","list_dtime":"2016-09-02 10:00:30","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTQ0Nl8zNTA0M19XNjQwSDM2MFMzMzU2MS5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTQ0Nl8zNTA0M19XNjQwSDM2MFMzMzU2MS5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTQ0Nl8zNTA0M19XNjQwSDM2MFMzMzU2MS5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c8e67e1bc8e0a9780000d1","title":"首位华人！成龙获奥斯卡终身成就荣誉奖","date":"2016-09-02 11:22:29","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c8e67e1bc8e0a9780000d1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8e67d1bc8e0a9780000cb_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8e67d1bc8e0a9780000cb_320.jpg","thumbnail_picsize":"600,450","media_count":"6","thumbnail_medias":[{"type":"image","id":"57c8e67d1bc8e0a9780000cb","url":"http://zkres.myzaker.com/201609/57c8e67d1bc8e0a9780000cb_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c8e67d1bc8e0a9780000cb_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c8e67d1bc8e0a9780000cb_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0902/20160902101533445963.jpg","w":"600","h":"450"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c8e67e1bc8e0a9780000d1&m=1472792503","list_dtime":"2016-09-02 11:22:29"},{"pk":"57c8dde61bc8e0d176000001","title":"《机器之血》成龙不满彭于晏用罗志祥？","date":"2016-09-02 10:58:19","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c8dde61bc8e0d176000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWE5Y2EwN2FlYzEzNTIwMDJiN2VfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWE5Y2EwN2FlYzEzNTIwMDJiN2VfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,434","media_count":"5","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c8dde61bc8e0d176000001&m=1472792503","list_dtime":"2016-09-02 10:58:19","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWE5Y2EwN2FlYzEzNTIwMDJiN2VfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWE5Y2EwN2FlYzEzNTIwMDJiN2VfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWE5Y2EwN2FlYzEzNTIwMDJiN2VfNjQwLmpwZw==_1242.jpg","w":"640","h":"434"}]},{"pk":"57c8ef111bc8e0897e000002","title":"《降临》记者会艾米真空上阵献吻杰瑞米","date":"2016-09-02 11:27:46","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c8ef111bc8e0897e000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8f1bba07aec1352003231_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8f1bba07aec1352003231_320.jpg","thumbnail_picsize":"683,1024","media_count":"1","thumbnail_medias":[{"type":"image","id":"57c8f1bba07aec1352003231","url":"http://zkres.myzaker.com/201609/57c8f1bba07aec1352003231_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c8f1bba07aec1352003231_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c8f1bba07aec1352003231_120.jpg","raw_url":"http://image14.m1905.cn/uploadfile/2016/0902/20160902104802295747_watermark.jpg","w":"683","h":"1024"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c8ef111bc8e0897e000002&m=1472792503","list_dtime":"2016-09-02 11:27:46"},{"pk":"57c8cc821bc8e0f66a000020","title":"《勇敢者的游戏》定妆照 巨石强森登场","title_line_break":"《勇敢者的游戏》定妆照\n巨石强森登场","date":"2016-09-02 11:29:58","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c8cc821bc8e0f66a000020","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8cc811bc8e0f66a00001f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8cc811bc8e0f66a00001f_320.jpg","thumbnail_picsize":"817,601","media_count":"1","thumbnail_medias":[{"type":"image","id":"57c8cc811bc8e0f66a00001f","url":"http://zkres.myzaker.com/201609/57c8cc811bc8e0f66a00001f_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c8cc811bc8e0f66a00001f_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c8cc811bc8e0f66a00001f_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0902/20160902082544934092.jpg","w":"817","h":"601"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c8cc821bc8e0f66a000020&m=1472792503","list_dtime":"2016-09-02 11:29:58"},{"pk":"57c635749490cba012000000","title":"不管是爱情还是悬疑，总之一定要看！","date":"2016-09-02 11:15:02","auther_name":"剧角映画","weburl":"http://iphone.myzaker.com/l.php?l=57c635749490cba012000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2MzA5NzdmNTJlOTljMDgwMDAwMDhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2MzA5NzdmNTJlOTljMDgwMDAwMDhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"6","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c635749490cba012000000&m=1472792503","list_dtime":"2016-09-02 11:15:02","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2MzA5NzdmNTJlOTljMDgwMDAwMDhfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2MzA5NzdmNTJlOTljMDgwMDAwMDhfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2MzA5NzdmNTJlOTljMDgwMDAwMDhfNjQwLmpwZw==_1242.jpg","w":"640","h":"427"}]},{"pk":"57c3b9289490cba33100001f","title":"如果你敢关灯看这片，我就服你！","date":"2016-09-01 14:53:02","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57c3b9289490cba33100001f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjhlZTdmNTJlOTE4MDkwMDAyNTJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjhlZTdmNTJlOTE4MDkwMDAyNTJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,400","media_count":"82","app_ids":"10530","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57c3b9289490cba33100001f&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c3b9289490cba33100001f%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c3b9289490cba33100001f&m=1472792504","list_dtime":"2016-09-01 14:53:02","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjhlZTdmNTJlOTE4MDkwMDAyNTJfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjhlZTdmNTJlOTE4MDkwMDAyNTJfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjhlZTdmNTJlOTE4MDkwMDAyNTJfNjQwLmpwZw==_1242.jpg","w":"600","h":"400"}]},{"pk":"57c2cd969490cb4135000006","title":"嫁给鬼才导演的她，杀了哈利波特的教父","date":"2016-09-01 14:49:48","auther_name":"电影头条","weburl":"http://iphone.myzaker.com/l.php?l=57c2cd969490cb4135000006","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyY2NjMDdmNTJlOTZlMDUwMDA4MThfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyY2NjMDdmNTJlOTZlMDUwMDA4MThfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,359","media_count":"25","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c2cd969490cb4135000006&m=1472792504","list_dtime":"2016-09-01 14:49:48","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyY2NjMDdmNTJlOTZlMDUwMDA4MThfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyY2NjMDdmNTJlOTZlMDUwMDA4MThfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyY2NjMDdmNTJlOTZlMDUwMDA4MThfNjQwLmpwZw==_1242.jpg","w":"640","h":"359"}]},{"pk":"57c7b2559490cb197f000003","title":"黄磊一段话，\u201d炸醒了\u201c中国半数父母","date":"2016-09-01 14:20:47","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57c7b2559490cb197f000003","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YWVhYTdmNTJlOWM0NmEwMDAxMWNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YWVhYTdmNTJlOWM0NmEwMDAxMWNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,337","media_count":"17","app_ids":"10530","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57c7b2559490cb197f000003&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c7b2559490cb197f000003%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7b2559490cb197f000003&m=1472792504","list_dtime":"2016-09-01 14:20:47","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YWVhYTdmNTJlOWM0NmEwMDAxMWNfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YWVhYTdmNTJlOWM0NmEwMDAxMWNfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YWVhYTdmNTJlOWM0NmEwMDAxMWNfNjQwLmpwZw==_1242.jpg","w":"600","h":"337"}]},{"pk":"57c7dd769490cbe22c00006f","title":"这些超耐看的电影海报你们有留意到吗？","date":"2016-09-01 15:49:33","auther_name":"ZAKER话题","weburl":"http://iphone.myzaker.com/l.php?l=57c7dd769490cbe22c00006f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNjc1OV8zMzY5OV9XNjQwSDM2MFMyNTEwOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNjc1OV8zMzY5OV9XNjQwSDM2MFMyNTEwOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","app_ids":"10530","is_full":"NO","content":"","type":"other","special_info":{"open_type":"post","post":{"pk":"57b6dd8a1716cfb27f000007","discussion_id":"168","auther":{"name":"vixy","uid":"11449465","user_flag":[{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user.png"}],"icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5725/11449465_1461608182.jpg.210.jpg"},"title":"","date":"2016-08-19 18:20:58","comment_count":"88","hot_num":"336","post_tag":[{"name":"精华","icon":"http://zkres.myzaker.com/data/image/mark2/selection3_2x.png"}],"content":"#好片互推# 不知道有没有人跟我一样有留意电影海报的习惯？想知道有哪些令你们印象深刻的海报，顺便拯救影荒~\r\n\r\n楼下先分享一些我觉得特别棒的海报和电影「不定期看心情更」。","medias":[{"type":"image","id":"57b6dd881716cf7c7f000010","w":"518","h":"800","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cf7c7f000010.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cf7c7f000010.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cf7c7f000010.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cf7c7f000010.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cf7c7f000010.jpg"},{"type":"image","id":"57b6dd881716cff27e000020","w":"545","h":"800","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cff27e000020.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cff27e000020.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cff27e000020.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cff27e000020.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cff27e000020.jpg"},{"type":"image","id":"57b6dd8a1716cfc47f00000d","w":"545","h":"800","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cfc47f00000d.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cfc47f00000d.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cfc47f00000d.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cfc47f00000d.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cfc47f00000d.jpg"},{"type":"image","id":"57b6dd8a1716cf4302000000","w":"545","h":"800","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cf4302000000.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cf4302000000.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cf4302000000.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cf4302000000.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cf4302000000.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57b6dd8a1716cfb27f000007","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57b6dd8a1716cfb27f000007&_appid=&_version=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57b6dd8a1716cfb27f000007","discussion":{"pk":"168","title":"电影圈","stitle":"电影同好联盟","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2015/07/15/55a5c62c9490cbac17000044.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2015/07/15/55a5c62c9490cbac17000044.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=168","block_color":"","subscribe_count":"606908","post_count":"11941"},"need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=10530&app_ids=10530&pk=57c7dd769490cbe22c00006f&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c7dd769490cbe22c00006f","show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7dd769490cbe22c00006f&m=1472792503","list_dtime":"2016-09-01 15:49:33","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNjc1OV8zMzY5OV9XNjQwSDM2MFMyNTEwOC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNjc1OV8zMzY5OV9XNjQwSDM2MFMyNTEwOC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNjc1OV8zMzY5OV9XNjQwSDM2MFMyNTEwOC5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c7a3139490cb2e39000002","title":"《权力的游戏》第七季宣布新主演","date":"2016-09-01 14:19:38","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57c7a3139490cb2e39000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a2d11bc8e0853500001d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a2d11bc8e0853500001d_320.jpg","thumbnail_picsize":"620,348","media_count":"2","thumbnail_medias":[{"type":"image","id":"57c7a2d11bc8e0853500001d","url":"http://zkres.myzaker.com/201609/57c7a2d11bc8e0853500001d_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c7a2d11bc8e0853500001d_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c7a2d11bc8e0853500001d_120.jpg","raw_url":"http://img31.mtime.cn/CMS/News/2016/09/01/100352.66290716_620X620.jpg","w":"620","h":"348"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7a3139490cb2e39000002&m=1472792504","list_dtime":"2016-09-01 14:19:38"},{"pk":"57c5f0579490cbd53c00000b","title":"就冲着这两个女人，这片就能打100分","date":"2016-09-01 11:45:04","auther_name":"电影那点事儿","weburl":"http://iphone.myzaker.com/l.php?l=57c5f0579490cbd53c00000b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NTY4N18xNzkzNV9XNjQwSDM2MFM2NTA1Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NTY4N18xNzkzNV9XNjQwSDM2MFM2NTA1Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"37","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c5f0579490cbd53c00000b&m=1472785257","list_dtime":"2016-09-01 11:45:04","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NTY4N18xNzkzNV9XNjQwSDM2MFM2NTA1Mi5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NTY4N18xNzkzNV9XNjQwSDM2MFM2NTA1Mi5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NTY4N18xNzkzNV9XNjQwSDM2MFM2NTA1Mi5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c7c18c9490cb3249000000","title":"这与《教父》并列的黑帮片，甚至更高一筹","date":"2016-09-01 14:53:03","auther_name":"剧角映画","weburl":"http://iphone.myzaker.com/l.php?l=57c7c18c9490cb3249000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YjlkZjdmNTJlOTNmMzUwMDAzNGNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YjlkZjdmNTJlOTNmMzUwMDAzNGNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,406","media_count":"34","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7c18c9490cb3249000000&m=1472792504","list_dtime":"2016-09-01 14:53:03","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YjlkZjdmNTJlOTNmMzUwMDAzNGNfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YjlkZjdmNTJlOTNmMzUwMDAzNGNfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YjlkZjdmNTJlOTNmMzUwMDAzNGNfNjQwLmpwZw==_1242.jpg","w":"600","h":"406"}]},{"pk":"57c5e1199490cb167000000a","title":"一人扮演多个角色，这就是演技派","date":"2016-09-01 14:58:51","auther_name":"热门电影","weburl":"http://iphone.myzaker.com/l.php?l=57c5e1199490cb167000000a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ZGQ2NTdmNTJlOTI3NWUwMDA0MmFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ZGQ2NTdmNTJlOTI3NWUwMDA0MmFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"338,220","media_count":"33","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c5e1199490cb167000000a&m=1472792503","list_dtime":"2016-09-01 14:58:51","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ZGQ2NTdmNTJlOTI3NWUwMDA0MmFfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ZGQ2NTdmNTJlOTI3NWUwMDA0MmFfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ZGQ2NTdmNTJlOTI3NWUwMDA0MmFfNjQwLmpwZw==_1242.jpg","w":"338","h":"220"}]},{"pk":"57c7beaf9490cbc12c00003a","title":"冯小刚新作《我不是潘金莲》有戏版海报","date":"2016-09-01 13:36:17","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c7beaf9490cbc12c00003a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YmViNGEwN2FlY2Y3N2UwNDY5ZDhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YmViNGEwN2FlY2Y3N2UwNDY5ZDhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,916","media_count":"3","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7beaf9490cbc12c00003a&m=1472792504","list_dtime":"2016-09-01 13:36:17","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YmViNGEwN2FlY2Y3N2UwNDY5ZDhfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YmViNGEwN2FlY2Y3N2UwNDY5ZDhfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YmViNGEwN2FlY2Y3N2UwNDY5ZDhfNjQwLmpwZw==_1242.jpg","w":"640","h":"916"}]},{"pk":"57c7d0c99490cb6519000000","title":"好莱坞大片接连扑街 都是烂番茄的锅？","title_line_break":"好莱坞大片接连扑街\n都是烂番茄的锅？","date":"2016-09-01 15:11:33","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c7d0c99490cb6519000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3Y2Y4NzFiYzhlMDk4NTUwMDAwMDBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3Y2Y4NzFiYzhlMDk4NTUwMDAwMDBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"295,241","media_count":"11","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7d0c99490cb6519000000&m=1472792503","list_dtime":"2016-09-01 15:11:33","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3Y2Y4NzFiYzhlMDk4NTUwMDAwMDBfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3Y2Y4NzFiYzhlMDk4NTUwMDAwMDBfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3Y2Y4NzFiYzhlMDk4NTUwMDAwMDBfNjQwLmpwZw==_1242.jpg","w":"295","h":"241"}]},{"pk":"57c7a3139490cb2e39000000","title":"《老炮儿》之后影帝冯小刚还要演戏","date":"2016-09-01 14:17:47","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57c7a3139490cb2e39000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a2cd1bc8e08535000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a2cd1bc8e08535000011_320.jpg","thumbnail_picsize":"620,423","media_count":"1","thumbnail_medias":[{"type":"image","id":"57c7a2cd1bc8e08535000011","url":"http://zkres.myzaker.com/201609/57c7a2cd1bc8e08535000011_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c7a2cd1bc8e08535000011_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c7a2cd1bc8e08535000011_120.jpg","raw_url":"http://img31.mtime.cn/CMS/News/2016/09/01/110656.37245857_620X620.jpg","w":"620","h":"423"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7a3139490cb2e39000000&m=1472792504","list_dtime":"2016-09-01 14:17:47"},{"pk":"57c7e2439490cb1b6c000000","title":"《寄生兽》邀你加入人兽大战","date":"2016-09-01 16:09:22","auther_name":"ZAKER玩乐","weburl":"http://iphone.myzaker.com/l.php?l=57c7e2439490cb1b6c000000","media_count":"0","app_ids":"10530","is_full":"NO","content":"","type":"web2","special_info":{"open_type":"web","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c7e2439490cb1b6c000000&title=%E3%80%8A%E5%AF%84%E7%94%9F%E5%85%BD%E3%80%8B%E9%82%80%E4%BD%A0%E5%8A%A0%E5%85%A5%E4%BA%BA%E5%85%BD%E5%A4%A7%E6%88%98&open_type=web&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fhuodong.myzaker.com%2Fmain%2Finteractive%2Fpraygame%2Flucky.php%3Fid%3D57c7927c9490cbd32c00002f","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=10530&app_ids=10530&pk=57c7e2439490cb1b6c000000&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c7e2439490cb1b6c000000","icon_url":"http://zkres.myzaker.com/data/image/mark2/activity_2x.png?v=2015061216","show_jingcai":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7e2439490cb1b6c000000&m=1472792503","list_dtime":"2016-09-01 16:09:22"},{"pk":"57c65b691bc8e0346e00000b","title":"你以为有猛男、大胸，续集就有人看吗？","date":"2016-09-01 10:22:55","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57c65b691bc8e0346e00000b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjA5OV8yMjU4N19XNjQwSDM2MFM0MTcyNi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjA5OV8yMjU4N19XNjQwSDM2MFM0MTcyNi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"29","app_ids":"10530","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57c65b691bc8e0346e00000b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c65b691bc8e0346e00000b%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c65b691bc8e0346e00000b&m=1472696579","list_dtime":"2016-09-01 10:22:55","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjA5OV8yMjU4N19XNjQwSDM2MFM0MTcyNi5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjA5OV8yMjU4N19XNjQwSDM2MFM0MTcyNi5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjA5OV8yMjU4N19XNjQwSDM2MFM0MTcyNi5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c7a9f91bc8e0ee39000019","title":"上校迈尔斯将继续出现在《阿凡达》续作当中","date":"2016-09-01 14:21:40","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c7a9f91bc8e0ee39000019","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YTlmOTFiYzhlMGVlMzkwMDAwMThfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YTlmOTFiYzhlMGVlMzkwMDAwMThfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,316","media_count":"1","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7a9f91bc8e0ee39000019&m=1472792504","list_dtime":"2016-09-01 14:21:40","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YTlmOTFiYzhlMGVlMzkwMDAwMThfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YTlmOTFiYzhlMGVlMzkwMDAwMThfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YTlmOTFiYzhlMGVlMzkwMDAwMThfNjQwLmpwZw==_1242.jpg","w":"600","h":"316"}]},{"pk":"57c594ee9490cbb64b000012","title":"这部三无鬼片竟然干掉了《X特遣队》","date":"2016-09-01 10:22:09","auther_name":"抠电影","weburl":"http://iphone.myzaker.com/l.php?l=57c594ee9490cbb64b000012","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjQ3NF84MzA0OF9XNjQwSDM2MFM2MDA1NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjQ3NF84MzA0OF9XNjQwSDM2MFM2MDA1NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"21","app_ids":"10530","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57c594ee9490cbb64b000012&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c594ee9490cbb64b000012%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c594ee9490cbb64b000012&m=1472696533","list_dtime":"2016-09-01 10:22:09","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjQ3NF84MzA0OF9XNjQwSDM2MFM2MDA1NS5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjQ3NF84MzA0OF9XNjQwSDM2MFM2MDA1NS5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjQ3NF84MzA0OF9XNjQwSDM2MFM2MDA1NS5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c546361bc8e03a3a000002","title":"《变形金刚5》回中世纪 亚瑟王望亮相","title_line_break":"《变形金刚5》回中世纪\n亚瑟王望亮相","date":"2016-09-01 10:31:58","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c546361bc8e03a3a000002","thumbnail_pic":"http://zkres.myzaker.com/201608/57c542041bc8e0e637000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c542041bc8e0e637000002_320.jpg","thumbnail_picsize":"600,450","media_count":"2","thumbnail_medias":[{"type":"image","id":"57c542041bc8e0e637000002","url":"http://zkres.myzaker.com/201608/57c542041bc8e0e637000002_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c542041bc8e0e637000002_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c542041bc8e0e637000002_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0830/20160830040158135367.jpg","w":"600","h":"450"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c546361bc8e03a3a000002&m=1472696468","list_dtime":"2016-09-01 10:31:58"},{"pk":"57c7b95f9490cb7f1f00001a","title":"金城武搭档周冬雨拍《男人手册》","date":"2016-09-01 14:19:03","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57c7b95f9490cb7f1f00001a","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7aea31bc8e0f23d000006_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7aea31bc8e0f23d000006_320.jpg","thumbnail_picsize":"620,348","media_count":"3","thumbnail_medias":[{"type":"image","id":"57c7aea31bc8e0f23d000006","url":"http://zkres.myzaker.com/201609/57c7aea31bc8e0f23d000006_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c7aea31bc8e0f23d000006_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c7aea31bc8e0f23d000006_120.jpg","raw_url":"http://img31.mtime.cn/CMS/News/2016/09/01/110859.82555831_620X620.jpg","w":"620","h":"348"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7b95f9490cb7f1f00001a&m=1472792504","list_dtime":"2016-09-01 14:19:03"},{"pk":"57c50bd39490cb3c72000016","title":"这特工片，囊括了英国影坛的半壁江山？","date":"2016-09-01 10:42:50","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57c50bd39490cb3c72000016","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGEwZjdmNTJlOWI3MDYwMDAwZWFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGEwZjdmNTJlOWI3MDYwMDAwZWFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"597,401","media_count":"36","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c50bd39490cb3c72000016&m=1472698209","list_dtime":"2016-09-01 10:42:50","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGEwZjdmNTJlOWI3MDYwMDAwZWFfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGEwZjdmNTJlOWI3MDYwMDAwZWFfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGEwZjdmNTJlOWI3MDYwMDAwZWFfNjQwLmpwZw==_1242.jpg","w":"597","h":"401"}]},{"pk":"57c78bab9490cbfb3f00001a","title":"本周《星际迷航》入侵，《寄生兽》也来了","date":"2016-09-01 14:16:02","auther_name":"热门电影","weburl":"http://iphone.myzaker.com/l.php?l=57c78bab9490cbfb3f00001a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0NWNkMzdmNTJlOWU2MjkwMDA5YWNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0NWNkMzdmNTJlOWU2MjkwMDA5YWNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,361","media_count":"8","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c78bab9490cbfb3f00001a&m=1472792504","list_dtime":"2016-09-01 14:16:02","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0NWNkMzdmNTJlOWU2MjkwMDA5YWNfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0NWNkMzdmNTJlOWU2MjkwMDA5YWNfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0NWNkMzdmNTJlOWU2MjkwMDA5YWNfNjQwLmpwZw==_1242.jpg","w":"640","h":"361"}]},{"pk":"57c7a17a1bc8e05d33000046","title":"《宇爱同游》郭碧婷与胜利组高颜值CP","date":"2016-09-01 14:18:38","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c7a17a1bc8e05d33000046","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a1791bc8e05d33000044_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a1791bc8e05d33000044_320.jpg","thumbnail_picsize":"600,450","media_count":"2","thumbnail_medias":[{"type":"image","id":"57c7a1791bc8e05d33000044","url":"http://zkres.myzaker.com/201609/57c7a1791bc8e05d33000044_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c7a1791bc8e05d33000044_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c7a1791bc8e05d33000044_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0901/20160901105202266162.jpg","w":"600","h":"450"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7a17a1bc8e05d33000046&m=1472792504","list_dtime":"2016-09-01 14:18:38"},{"pk":"57c707379490cb9659000000","title":"这10部喜剧片笑点奇特，不落俗套","date":"2016-09-01 10:48:16","auther_name":"电影那点事儿","weburl":"http://iphone.myzaker.com/l.php?l=57c707379490cb9659000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5ODIzOF85MDM2OF9XNjQwSDM2MFM0ODg0NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5ODIzOF85MDM2OF9XNjQwSDM2MFM0ODg0NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"10","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c707379490cb9659000000&m=1472698222","list_dtime":"2016-09-01 10:48:16","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5ODIzOF85MDM2OF9XNjQwSDM2MFM0ODg0NS5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5ODIzOF85MDM2OF9XNjQwSDM2MFM0ODg0NS5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5ODIzOF85MDM2OF9XNjQwSDM2MFM0ODg0NS5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c7a9fa1bc8e0ee3900001b","title":"\"冬兵\"新片将出演冠军赛车手","date":"2016-09-01 14:17:23","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c7a9fa1bc8e0ee3900001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a9fa1bc8e0ee3900001a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a9fa1bc8e0ee3900001a_320.jpg","thumbnail_picsize":"1000,667","media_count":"1","thumbnail_medias":[{"type":"image","id":"57c7a9fa1bc8e0ee3900001a","url":"http://zkres.myzaker.com/201609/57c7a9fa1bc8e0ee3900001a_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c7a9fa1bc8e0ee3900001a_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c7a9fa1bc8e0ee3900001a_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0901/20160901114017158320.jpg","w":"1000","h":"667"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7a9fa1bc8e0ee3900001b&m=1472792504","list_dtime":"2016-09-01 14:17:23"},{"pk":"57c4f5711bc8e00c08000011","title":"《闪电侠》曝新反派 寒冷队长有望亮相","title_line_break":"《闪电侠》曝新反派\n寒冷队长有望亮相","date":"2016-09-01 10:40:44","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c4f5711bc8e00c08000011","thumbnail_pic":"http://zkres.myzaker.com/201608/57c4f5701bc8e00c0800000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c4f5701bc8e00c0800000d_320.jpg","thumbnail_picsize":"600,450","media_count":"4","thumbnail_medias":[{"type":"image","id":"57c4f5701bc8e00c0800000d","url":"http://zkres.myzaker.com/201608/57c4f5701bc8e00c0800000d_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c4f5701bc8e00c0800000d_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c4f5701bc8e00c0800000d_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0830/20160830103549598000.jpg","w":"600","h":"450"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c4f5711bc8e00c08000011&m=1472697648","list_dtime":"2016-09-01 10:40:44"},{"pk":"57c6aa691bc8e0d12200004c","title":"真人版《钢之炼金术师》杀青","date":"2016-09-01 10:27:43","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c6aa691bc8e0d12200004c","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6aa681bc8e0d12200004b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6aa681bc8e0d12200004b_320.jpg","thumbnail_picsize":"600,400","media_count":"1","thumbnail_medias":[{"type":"image","id":"57c6aa681bc8e0d12200004b","url":"http://zkres.myzaker.com/201608/57c6aa681bc8e0d12200004b_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c6aa681bc8e0d12200004b_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c6aa681bc8e0d12200004b_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0831/20160831053054336355.jpg","w":"600","h":"400"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c6aa691bc8e0d12200004c&m=1472696867","list_dtime":"2016-09-01 10:27:43"},{"pk":"57c7871b1bc8e0df25000015","title":"《鲨滩》采访特辑\u201cS女王\u201d以身试险","date":"2016-09-01 10:18:39","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c7871b1bc8e0df25000015","media_count":"0","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7871b1bc8e0df25000015&m=1472696267","list_dtime":"2016-09-01 10:18:39"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c626399490cb4145000009,57c50bd39490cb3c72000017,57c737449490cb0b70000001,57c84ca89490cba34c00009a,57c70f6c9490cbbc07000001,57c626399490cb414500000b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c8e67e1bc8e0a9780000d1,57c8dde61bc8e0d176000001,57c8ef111bc8e0897e000002,57c8cc821bc8e0f66a000020,57c635749490cba012000000,57c3b9289490cba33100001f","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c2cd969490cb4135000006,57c7b2559490cb197f000003,57c7dd769490cbe22c00006f,57c7a3139490cb2e39000002,57c5f0579490cbd53c00000b,57c7c18c9490cb3249000000","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c5e1199490cb167000000a,57c7beaf9490cbc12c00003a,57c7d0c99490cb6519000000,57c7a3139490cb2e39000000,57c7e2439490cb1b6c000000,57c65b691bc8e0346e00000b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c7a9f91bc8e0ee39000019,57c594ee9490cbb64b000012,57c546361bc8e03a3a000002,57c7b95f9490cb7f1f00001a,57c50bd39490cb3c72000016,57c78bab9490cbfb3f00001a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c7a17a1bc8e05d33000046,57c707379490cb9659000000,57c7a9fa1bc8e0ee3900001b,57c4f5711bc8e00c08000011,57c6aa691bc8e0d12200004c,57c7871b1bc8e0df25000015","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}}],"article_block_colors":["#f77762","#f77762"],"only_text_page_bgcolors":["#f77762","#f77762"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/10530.png?t=1458284157","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/10530.png?t=1458284157","hidden_time":"24","need_userinfo":"NO","block_title":"电影资讯","block_color":"#f77762","desktop_color_number":"20","use_original_icon":"N"},"top_tab_info_url":"http://iphone.myzaker.com/zaker/top_tab_info.php?app_id=10530&full_arg=_appid,_v,_version,_lbs_city","show_type":"top_tab"}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=10530&since_date=1472439872&nt=1&next_aticle_id=57c510421bc8e0a01b000007&_appid=androidphone&opage=2&otimestamp=159","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=10530&need_app_integration=1","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=10530&ids=5642f2aa9490cbb13200000e,51a7104681853dec4d00012f&k=201609021310"}
     * catalog :
     * articles : [{"pk":"57c626399490cb4145000009","title":"收好这份片单，保证九月没烂片能骗到你","date":"2016-09-02 11:44:26","auther_name":"毒舌电影","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c626399490cb4145000009","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"90","app_ids":"10530","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c550b39490cb3f13000071","block_title":"每月片单","title":"每月片单","block_in_title":"收好这份片单，保证九月没烂片能骗到你","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=10530&topic_id=57c550b39490cb3f13000071&updated=1472786296"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png","show_jingcai":"Y","list_nodsp":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c626399490cb4145000009&m=1472792777","list_dtime":"2016-09-02 11:44:26","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c50bd39490cb3c72000017","title":"原来有这样一群导演，把观众当瞎子","date":"2016-09-02 10:41:46","auther_name":"十点电影","page":"1","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57c50bd39490cb3c72000017","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGExMDdmNTJlOTBlNDUwMDAwYjhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGExMDdmNTJlOTBlNDUwMDAwYjhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"300,225","media_count":"14","app_ids":"10530","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57c50bd39490cb3c72000017&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c50bd39490cb3c72000017%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","list_nodsp":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c50bd39490cb3c72000017&m=1472792778","list_dtime":"2016-09-02 10:41:46","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGExMDdmNTJlOTBlNDUwMDAwYjhfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGExMDdmNTJlOTBlNDUwMDAwYjhfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGExMDdmNTJlOTBlNDUwMDAwYjhfNjQwLmpwZw==_1242.jpg","w":"300","h":"225"}]},{"pk":"57c737449490cb0b70000001","title":"冲着斯嘉丽这个尤物，发现一部偷情神作","date":"2016-09-02 12:46:35","auther_name":"独立鱼电影","weburl":"http://iphone.myzaker.com/l.php?l=57c737449490cb0b70000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDI2MjdmNTJlOTViMDIwMDAzYjBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDI2MjdmNTJlOTViMDIwMDAzYjBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,382","media_count":"24","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c737449490cb0b70000001&m=1472792503","list_dtime":"2016-09-02 12:46:35","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDI2MjdmNTJlOTViMDIwMDAzYjBfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDI2MjdmNTJlOTViMDIwMDAzYjBfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDI2MjdmNTJlOTViMDIwMDAzYjBfNjQwLmpwZw==_1242.jpg","w":"600","h":"382"}]},{"pk":"57c84ca89490cba34c00009a","title":"9月新片推荐","date":"2016-09-02 11:44:44","auther_name":"独立鱼电影","weburl":"http://iphone.myzaker.com/l.php?l=57c84ca89490cba34c00009a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0MzUzMl80MzI0MF9XNDIzSDM4NVM1OTY0NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0MzUzMl80MzI0MF9XNDIzSDM4NVM1OTY0NS5qcGc=_1242.jpg","thumbnail_picsize":"423,385","media_count":"0","app_ids":"10530","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c84ca89490cba34c00009a&title=9%E6%9C%88%E6%96%B0%E7%89%87%E6%8E%A8%E8%8D%90&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_car.php%3Fpk%3D57c847b49490cb812c000076%26target%3Dweb3%26article_pk%3D57c84ca89490cba34c00009a","show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c84ca89490cba34c00009a&m=1472792503","list_dtime":"2016-09-02 11:44:44","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0MzUzMl80MzI0MF9XNDIzSDM4NVM1OTY0NS5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0MzUzMl80MzI0MF9XNDIzSDM4NVM1OTY0NS5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0MzUzMl80MzI0MF9XNDIzSDM4NVM1OTY0NS5qcGc=_1242.jpg","w":"423","h":"385"}]},{"pk":"57c70f6c9490cbbc07000001","title":"9月只有这11部电影值得你花钱！","date":"2016-09-02 12:47:28","auther_name":"抠电影","weburl":"http://iphone.myzaker.com/l.php?l=57c70f6c9490cbbc07000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcwMDQyNl82NDY3OV9XNjQwSDM2MFM1NjM2MS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcwMDQyNl82NDY3OV9XNjQwSDM2MFM1NjM2MS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"36","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c70f6c9490cbbc07000001&m=1472701431","list_dtime":"2016-09-02 12:47:28","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcwMDQyNl82NDY3OV9XNjQwSDM2MFM1NjM2MS5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcwMDQyNl82NDY3OV9XNjQwSDM2MFM1NjM2MS5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcwMDQyNl82NDY3OV9XNjQwSDM2MFM1NjM2MS5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c626399490cb414500000b","title":"我们再也回不去，那个美女如云的年代","date":"2016-09-02 10:00:30","auther_name":"毒舌电影","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c626399490cb414500000b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTQ0Nl8zNTA0M19XNjQwSDM2MFMzMzU2MS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTQ0Nl8zNTA0M19XNjQwSDM2MFMzMzU2MS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"55","app_ids":"10530","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c501e19490cb8713000031","block_title":"20160902影迷小宝鉴","title":"20160902影迷小宝鉴","block_in_title":"我们再也回不去，那个美女如云的年代","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=10530&topic_id=57c501e19490cb8713000031&updated=1472783475"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57c626399490cb414500000b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c626399490cb414500000b%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","list_nodsp":"Y","item_type":"1"},"type":"web3","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c626399490cb414500000b&m=1472792778","list_dtime":"2016-09-02 10:00:30","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTQ0Nl8zNTA0M19XNjQwSDM2MFMzMzU2MS5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTQ0Nl8zNTA0M19XNjQwSDM2MFMzMzU2MS5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTQ0Nl8zNTA0M19XNjQwSDM2MFMzMzU2MS5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c8e67e1bc8e0a9780000d1","title":"首位华人！成龙获奥斯卡终身成就荣誉奖","date":"2016-09-02 11:22:29","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c8e67e1bc8e0a9780000d1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8e67d1bc8e0a9780000cb_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8e67d1bc8e0a9780000cb_320.jpg","thumbnail_picsize":"600,450","media_count":"6","thumbnail_medias":[{"type":"image","id":"57c8e67d1bc8e0a9780000cb","url":"http://zkres.myzaker.com/201609/57c8e67d1bc8e0a9780000cb_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c8e67d1bc8e0a9780000cb_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c8e67d1bc8e0a9780000cb_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0902/20160902101533445963.jpg","w":"600","h":"450"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c8e67e1bc8e0a9780000d1&m=1472792503","list_dtime":"2016-09-02 11:22:29"},{"pk":"57c8dde61bc8e0d176000001","title":"《机器之血》成龙不满彭于晏用罗志祥？","date":"2016-09-02 10:58:19","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c8dde61bc8e0d176000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWE5Y2EwN2FlYzEzNTIwMDJiN2VfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWE5Y2EwN2FlYzEzNTIwMDJiN2VfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,434","media_count":"5","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c8dde61bc8e0d176000001&m=1472792503","list_dtime":"2016-09-02 10:58:19","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWE5Y2EwN2FlYzEzNTIwMDJiN2VfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWE5Y2EwN2FlYzEzNTIwMDJiN2VfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZWE5Y2EwN2FlYzEzNTIwMDJiN2VfNjQwLmpwZw==_1242.jpg","w":"640","h":"434"}]},{"pk":"57c8ef111bc8e0897e000002","title":"《降临》记者会艾米真空上阵献吻杰瑞米","date":"2016-09-02 11:27:46","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c8ef111bc8e0897e000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8f1bba07aec1352003231_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8f1bba07aec1352003231_320.jpg","thumbnail_picsize":"683,1024","media_count":"1","thumbnail_medias":[{"type":"image","id":"57c8f1bba07aec1352003231","url":"http://zkres.myzaker.com/201609/57c8f1bba07aec1352003231_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c8f1bba07aec1352003231_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c8f1bba07aec1352003231_120.jpg","raw_url":"http://image14.m1905.cn/uploadfile/2016/0902/20160902104802295747_watermark.jpg","w":"683","h":"1024"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c8ef111bc8e0897e000002&m=1472792503","list_dtime":"2016-09-02 11:27:46"},{"pk":"57c8cc821bc8e0f66a000020","title":"《勇敢者的游戏》定妆照 巨石强森登场","title_line_break":"《勇敢者的游戏》定妆照\n巨石强森登场","date":"2016-09-02 11:29:58","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c8cc821bc8e0f66a000020","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8cc811bc8e0f66a00001f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8cc811bc8e0f66a00001f_320.jpg","thumbnail_picsize":"817,601","media_count":"1","thumbnail_medias":[{"type":"image","id":"57c8cc811bc8e0f66a00001f","url":"http://zkres.myzaker.com/201609/57c8cc811bc8e0f66a00001f_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c8cc811bc8e0f66a00001f_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c8cc811bc8e0f66a00001f_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0902/20160902082544934092.jpg","w":"817","h":"601"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c8cc821bc8e0f66a000020&m=1472792503","list_dtime":"2016-09-02 11:29:58"},{"pk":"57c635749490cba012000000","title":"不管是爱情还是悬疑，总之一定要看！","date":"2016-09-02 11:15:02","auther_name":"剧角映画","weburl":"http://iphone.myzaker.com/l.php?l=57c635749490cba012000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2MzA5NzdmNTJlOTljMDgwMDAwMDhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2MzA5NzdmNTJlOTljMDgwMDAwMDhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"6","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c635749490cba012000000&m=1472792503","list_dtime":"2016-09-02 11:15:02","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2MzA5NzdmNTJlOTljMDgwMDAwMDhfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2MzA5NzdmNTJlOTljMDgwMDAwMDhfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2MzA5NzdmNTJlOTljMDgwMDAwMDhfNjQwLmpwZw==_1242.jpg","w":"640","h":"427"}]},{"pk":"57c3b9289490cba33100001f","title":"如果你敢关灯看这片，我就服你！","date":"2016-09-01 14:53:02","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57c3b9289490cba33100001f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjhlZTdmNTJlOTE4MDkwMDAyNTJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjhlZTdmNTJlOTE4MDkwMDAyNTJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,400","media_count":"82","app_ids":"10530","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57c3b9289490cba33100001f&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c3b9289490cba33100001f%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c3b9289490cba33100001f&m=1472792504","list_dtime":"2016-09-01 14:53:02","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjhlZTdmNTJlOTE4MDkwMDAyNTJfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjhlZTdmNTJlOTE4MDkwMDAyNTJfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MzYjhlZTdmNTJlOTE4MDkwMDAyNTJfNjQwLmpwZw==_1242.jpg","w":"600","h":"400"}]},{"pk":"57c2cd969490cb4135000006","title":"嫁给鬼才导演的她，杀了哈利波特的教父","date":"2016-09-01 14:49:48","auther_name":"电影头条","weburl":"http://iphone.myzaker.com/l.php?l=57c2cd969490cb4135000006","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyY2NjMDdmNTJlOTZlMDUwMDA4MThfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyY2NjMDdmNTJlOTZlMDUwMDA4MThfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,359","media_count":"25","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c2cd969490cb4135000006&m=1472792504","list_dtime":"2016-09-01 14:49:48","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyY2NjMDdmNTJlOTZlMDUwMDA4MThfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyY2NjMDdmNTJlOTZlMDUwMDA4MThfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyY2NjMDdmNTJlOTZlMDUwMDA4MThfNjQwLmpwZw==_1242.jpg","w":"640","h":"359"}]},{"pk":"57c7b2559490cb197f000003","title":"黄磊一段话，\u201d炸醒了\u201c中国半数父母","date":"2016-09-01 14:20:47","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57c7b2559490cb197f000003","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YWVhYTdmNTJlOWM0NmEwMDAxMWNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YWVhYTdmNTJlOWM0NmEwMDAxMWNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,337","media_count":"17","app_ids":"10530","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57c7b2559490cb197f000003&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c7b2559490cb197f000003%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7b2559490cb197f000003&m=1472792504","list_dtime":"2016-09-01 14:20:47","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YWVhYTdmNTJlOWM0NmEwMDAxMWNfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YWVhYTdmNTJlOWM0NmEwMDAxMWNfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YWVhYTdmNTJlOWM0NmEwMDAxMWNfNjQwLmpwZw==_1242.jpg","w":"600","h":"337"}]},{"pk":"57c7dd769490cbe22c00006f","title":"这些超耐看的电影海报你们有留意到吗？","date":"2016-09-01 15:49:33","auther_name":"ZAKER话题","weburl":"http://iphone.myzaker.com/l.php?l=57c7dd769490cbe22c00006f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNjc1OV8zMzY5OV9XNjQwSDM2MFMyNTEwOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNjc1OV8zMzY5OV9XNjQwSDM2MFMyNTEwOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","app_ids":"10530","is_full":"NO","content":"","type":"other","special_info":{"open_type":"post","post":{"pk":"57b6dd8a1716cfb27f000007","discussion_id":"168","auther":{"name":"vixy","uid":"11449465","user_flag":[{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user.png"}],"icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5725/11449465_1461608182.jpg.210.jpg"},"title":"","date":"2016-08-19 18:20:58","comment_count":"88","hot_num":"336","post_tag":[{"name":"精华","icon":"http://zkres.myzaker.com/data/image/mark2/selection3_2x.png"}],"content":"#好片互推# 不知道有没有人跟我一样有留意电影海报的习惯？想知道有哪些令你们印象深刻的海报，顺便拯救影荒~\r\n\r\n楼下先分享一些我觉得特别棒的海报和电影「不定期看心情更」。","medias":[{"type":"image","id":"57b6dd881716cf7c7f000010","w":"518","h":"800","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cf7c7f000010.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cf7c7f000010.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cf7c7f000010.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cf7c7f000010.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cf7c7f000010.jpg"},{"type":"image","id":"57b6dd881716cff27e000020","w":"545","h":"800","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cff27e000020.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cff27e000020.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cff27e000020.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cff27e000020.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd881716cff27e000020.jpg"},{"type":"image","id":"57b6dd8a1716cfc47f00000d","w":"545","h":"800","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cfc47f00000d.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cfc47f00000d.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cfc47f00000d.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cfc47f00000d.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cfc47f00000d.jpg"},{"type":"image","id":"57b6dd8a1716cf4302000000","w":"545","h":"800","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cf4302000000.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cf4302000000.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cf4302000000.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cf4302000000.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/19/57b6dd8a1716cf4302000000.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57b6dd8a1716cfb27f000007","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57b6dd8a1716cfb27f000007&_appid=&_version=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57b6dd8a1716cfb27f000007","discussion":{"pk":"168","title":"电影圈","stitle":"电影同好联盟","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2015/07/15/55a5c62c9490cbac17000044.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2015/07/15/55a5c62c9490cbac17000044.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=168","block_color":"","subscribe_count":"606908","post_count":"11941"},"need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=10530&app_ids=10530&pk=57c7dd769490cbe22c00006f&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c7dd769490cbe22c00006f","show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7dd769490cbe22c00006f&m=1472792503","list_dtime":"2016-09-01 15:49:33","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNjc1OV8zMzY5OV9XNjQwSDM2MFMyNTEwOC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNjc1OV8zMzY5OV9XNjQwSDM2MFMyNTEwOC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjcxNjc1OV8zMzY5OV9XNjQwSDM2MFMyNTEwOC5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c7a3139490cb2e39000002","title":"《权力的游戏》第七季宣布新主演","date":"2016-09-01 14:19:38","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57c7a3139490cb2e39000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a2d11bc8e0853500001d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a2d11bc8e0853500001d_320.jpg","thumbnail_picsize":"620,348","media_count":"2","thumbnail_medias":[{"type":"image","id":"57c7a2d11bc8e0853500001d","url":"http://zkres.myzaker.com/201609/57c7a2d11bc8e0853500001d_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c7a2d11bc8e0853500001d_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c7a2d11bc8e0853500001d_120.jpg","raw_url":"http://img31.mtime.cn/CMS/News/2016/09/01/100352.66290716_620X620.jpg","w":"620","h":"348"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7a3139490cb2e39000002&m=1472792504","list_dtime":"2016-09-01 14:19:38"},{"pk":"57c5f0579490cbd53c00000b","title":"就冲着这两个女人，这片就能打100分","date":"2016-09-01 11:45:04","auther_name":"电影那点事儿","weburl":"http://iphone.myzaker.com/l.php?l=57c5f0579490cbd53c00000b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NTY4N18xNzkzNV9XNjQwSDM2MFM2NTA1Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NTY4N18xNzkzNV9XNjQwSDM2MFM2NTA1Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"37","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c5f0579490cbd53c00000b&m=1472785257","list_dtime":"2016-09-01 11:45:04","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NTY4N18xNzkzNV9XNjQwSDM2MFM2NTA1Mi5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NTY4N18xNzkzNV9XNjQwSDM2MFM2NTA1Mi5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NTY4N18xNzkzNV9XNjQwSDM2MFM2NTA1Mi5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c7c18c9490cb3249000000","title":"这与《教父》并列的黑帮片，甚至更高一筹","date":"2016-09-01 14:53:03","auther_name":"剧角映画","weburl":"http://iphone.myzaker.com/l.php?l=57c7c18c9490cb3249000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YjlkZjdmNTJlOTNmMzUwMDAzNGNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YjlkZjdmNTJlOTNmMzUwMDAzNGNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,406","media_count":"34","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7c18c9490cb3249000000&m=1472792504","list_dtime":"2016-09-01 14:53:03","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YjlkZjdmNTJlOTNmMzUwMDAzNGNfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YjlkZjdmNTJlOTNmMzUwMDAzNGNfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YjlkZjdmNTJlOTNmMzUwMDAzNGNfNjQwLmpwZw==_1242.jpg","w":"600","h":"406"}]},{"pk":"57c5e1199490cb167000000a","title":"一人扮演多个角色，这就是演技派","date":"2016-09-01 14:58:51","auther_name":"热门电影","weburl":"http://iphone.myzaker.com/l.php?l=57c5e1199490cb167000000a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ZGQ2NTdmNTJlOTI3NWUwMDA0MmFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ZGQ2NTdmNTJlOTI3NWUwMDA0MmFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"338,220","media_count":"33","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c5e1199490cb167000000a&m=1472792503","list_dtime":"2016-09-01 14:58:51","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ZGQ2NTdmNTJlOTI3NWUwMDA0MmFfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ZGQ2NTdmNTJlOTI3NWUwMDA0MmFfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ZGQ2NTdmNTJlOTI3NWUwMDA0MmFfNjQwLmpwZw==_1242.jpg","w":"338","h":"220"}]},{"pk":"57c7beaf9490cbc12c00003a","title":"冯小刚新作《我不是潘金莲》有戏版海报","date":"2016-09-01 13:36:17","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c7beaf9490cbc12c00003a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YmViNGEwN2FlY2Y3N2UwNDY5ZDhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YmViNGEwN2FlY2Y3N2UwNDY5ZDhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,916","media_count":"3","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7beaf9490cbc12c00003a&m=1472792504","list_dtime":"2016-09-01 13:36:17","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YmViNGEwN2FlY2Y3N2UwNDY5ZDhfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YmViNGEwN2FlY2Y3N2UwNDY5ZDhfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YmViNGEwN2FlY2Y3N2UwNDY5ZDhfNjQwLmpwZw==_1242.jpg","w":"640","h":"916"}]},{"pk":"57c7d0c99490cb6519000000","title":"好莱坞大片接连扑街 都是烂番茄的锅？","title_line_break":"好莱坞大片接连扑街\n都是烂番茄的锅？","date":"2016-09-01 15:11:33","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c7d0c99490cb6519000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3Y2Y4NzFiYzhlMDk4NTUwMDAwMDBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3Y2Y4NzFiYzhlMDk4NTUwMDAwMDBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"295,241","media_count":"11","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7d0c99490cb6519000000&m=1472792503","list_dtime":"2016-09-01 15:11:33","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3Y2Y4NzFiYzhlMDk4NTUwMDAwMDBfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3Y2Y4NzFiYzhlMDk4NTUwMDAwMDBfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3Y2Y4NzFiYzhlMDk4NTUwMDAwMDBfNjQwLmpwZw==_1242.jpg","w":"295","h":"241"}]},{"pk":"57c7a3139490cb2e39000000","title":"《老炮儿》之后影帝冯小刚还要演戏","date":"2016-09-01 14:17:47","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57c7a3139490cb2e39000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a2cd1bc8e08535000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a2cd1bc8e08535000011_320.jpg","thumbnail_picsize":"620,423","media_count":"1","thumbnail_medias":[{"type":"image","id":"57c7a2cd1bc8e08535000011","url":"http://zkres.myzaker.com/201609/57c7a2cd1bc8e08535000011_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c7a2cd1bc8e08535000011_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c7a2cd1bc8e08535000011_120.jpg","raw_url":"http://img31.mtime.cn/CMS/News/2016/09/01/110656.37245857_620X620.jpg","w":"620","h":"423"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7a3139490cb2e39000000&m=1472792504","list_dtime":"2016-09-01 14:17:47"},{"pk":"57c7e2439490cb1b6c000000","title":"《寄生兽》邀你加入人兽大战","date":"2016-09-01 16:09:22","auther_name":"ZAKER玩乐","weburl":"http://iphone.myzaker.com/l.php?l=57c7e2439490cb1b6c000000","media_count":"0","app_ids":"10530","is_full":"NO","content":"","type":"web2","special_info":{"open_type":"web","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c7e2439490cb1b6c000000&title=%E3%80%8A%E5%AF%84%E7%94%9F%E5%85%BD%E3%80%8B%E9%82%80%E4%BD%A0%E5%8A%A0%E5%85%A5%E4%BA%BA%E5%85%BD%E5%A4%A7%E6%88%98&open_type=web&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fhuodong.myzaker.com%2Fmain%2Finteractive%2Fpraygame%2Flucky.php%3Fid%3D57c7927c9490cbd32c00002f","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=10530&app_ids=10530&pk=57c7e2439490cb1b6c000000&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c7e2439490cb1b6c000000","icon_url":"http://zkres.myzaker.com/data/image/mark2/activity_2x.png?v=2015061216","show_jingcai":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7e2439490cb1b6c000000&m=1472792503","list_dtime":"2016-09-01 16:09:22"},{"pk":"57c65b691bc8e0346e00000b","title":"你以为有猛男、大胸，续集就有人看吗？","date":"2016-09-01 10:22:55","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57c65b691bc8e0346e00000b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjA5OV8yMjU4N19XNjQwSDM2MFM0MTcyNi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjA5OV8yMjU4N19XNjQwSDM2MFM0MTcyNi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"29","app_ids":"10530","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57c65b691bc8e0346e00000b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c65b691bc8e0346e00000b%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c65b691bc8e0346e00000b&m=1472696579","list_dtime":"2016-09-01 10:22:55","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjA5OV8yMjU4N19XNjQwSDM2MFM0MTcyNi5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjA5OV8yMjU4N19XNjQwSDM2MFM0MTcyNi5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjA5OV8yMjU4N19XNjQwSDM2MFM0MTcyNi5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c7a9f91bc8e0ee39000019","title":"上校迈尔斯将继续出现在《阿凡达》续作当中","date":"2016-09-01 14:21:40","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c7a9f91bc8e0ee39000019","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YTlmOTFiYzhlMGVlMzkwMDAwMThfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YTlmOTFiYzhlMGVlMzkwMDAwMThfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,316","media_count":"1","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7a9f91bc8e0ee39000019&m=1472792504","list_dtime":"2016-09-01 14:21:40","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YTlmOTFiYzhlMGVlMzkwMDAwMThfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YTlmOTFiYzhlMGVlMzkwMDAwMThfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3YTlmOTFiYzhlMGVlMzkwMDAwMThfNjQwLmpwZw==_1242.jpg","w":"600","h":"316"}]},{"pk":"57c594ee9490cbb64b000012","title":"这部三无鬼片竟然干掉了《X特遣队》","date":"2016-09-01 10:22:09","auther_name":"抠电影","weburl":"http://iphone.myzaker.com/l.php?l=57c594ee9490cbb64b000012","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjQ3NF84MzA0OF9XNjQwSDM2MFM2MDA1NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjQ3NF84MzA0OF9XNjQwSDM2MFM2MDA1NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"21","app_ids":"10530","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57c594ee9490cbb64b000012&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c594ee9490cbb64b000012%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c594ee9490cbb64b000012&m=1472696533","list_dtime":"2016-09-01 10:22:09","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjQ3NF84MzA0OF9XNjQwSDM2MFM2MDA1NS5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjQ3NF84MzA0OF9XNjQwSDM2MFM2MDA1NS5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjQ3NF84MzA0OF9XNjQwSDM2MFM2MDA1NS5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c546361bc8e03a3a000002","title":"《变形金刚5》回中世纪 亚瑟王望亮相","title_line_break":"《变形金刚5》回中世纪\n亚瑟王望亮相","date":"2016-09-01 10:31:58","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c546361bc8e03a3a000002","thumbnail_pic":"http://zkres.myzaker.com/201608/57c542041bc8e0e637000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c542041bc8e0e637000002_320.jpg","thumbnail_picsize":"600,450","media_count":"2","thumbnail_medias":[{"type":"image","id":"57c542041bc8e0e637000002","url":"http://zkres.myzaker.com/201608/57c542041bc8e0e637000002_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c542041bc8e0e637000002_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c542041bc8e0e637000002_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0830/20160830040158135367.jpg","w":"600","h":"450"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c546361bc8e03a3a000002&m=1472696468","list_dtime":"2016-09-01 10:31:58"},{"pk":"57c7b95f9490cb7f1f00001a","title":"金城武搭档周冬雨拍《男人手册》","date":"2016-09-01 14:19:03","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57c7b95f9490cb7f1f00001a","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7aea31bc8e0f23d000006_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7aea31bc8e0f23d000006_320.jpg","thumbnail_picsize":"620,348","media_count":"3","thumbnail_medias":[{"type":"image","id":"57c7aea31bc8e0f23d000006","url":"http://zkres.myzaker.com/201609/57c7aea31bc8e0f23d000006_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c7aea31bc8e0f23d000006_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c7aea31bc8e0f23d000006_120.jpg","raw_url":"http://img31.mtime.cn/CMS/News/2016/09/01/110859.82555831_620X620.jpg","w":"620","h":"348"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7b95f9490cb7f1f00001a&m=1472792504","list_dtime":"2016-09-01 14:19:03"},{"pk":"57c50bd39490cb3c72000016","title":"这特工片，囊括了英国影坛的半壁江山？","date":"2016-09-01 10:42:50","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57c50bd39490cb3c72000016","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGEwZjdmNTJlOWI3MDYwMDAwZWFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGEwZjdmNTJlOWI3MDYwMDAwZWFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"597,401","media_count":"36","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c50bd39490cb3c72000016&m=1472698209","list_dtime":"2016-09-01 10:42:50","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGEwZjdmNTJlOWI3MDYwMDAwZWFfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGEwZjdmNTJlOWI3MDYwMDAwZWFfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGEwZjdmNTJlOWI3MDYwMDAwZWFfNjQwLmpwZw==_1242.jpg","w":"597","h":"401"}]},{"pk":"57c78bab9490cbfb3f00001a","title":"本周《星际迷航》入侵，《寄生兽》也来了","date":"2016-09-01 14:16:02","auther_name":"热门电影","weburl":"http://iphone.myzaker.com/l.php?l=57c78bab9490cbfb3f00001a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0NWNkMzdmNTJlOWU2MjkwMDA5YWNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0NWNkMzdmNTJlOWU2MjkwMDA5YWNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,361","media_count":"8","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c78bab9490cbfb3f00001a&m=1472792504","list_dtime":"2016-09-01 14:16:02","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0NWNkMzdmNTJlOWU2MjkwMDA5YWNfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0NWNkMzdmNTJlOWU2MjkwMDA5YWNfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0NWNkMzdmNTJlOWU2MjkwMDA5YWNfNjQwLmpwZw==_1242.jpg","w":"640","h":"361"}]},{"pk":"57c7a17a1bc8e05d33000046","title":"《宇爱同游》郭碧婷与胜利组高颜值CP","date":"2016-09-01 14:18:38","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c7a17a1bc8e05d33000046","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a1791bc8e05d33000044_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a1791bc8e05d33000044_320.jpg","thumbnail_picsize":"600,450","media_count":"2","thumbnail_medias":[{"type":"image","id":"57c7a1791bc8e05d33000044","url":"http://zkres.myzaker.com/201609/57c7a1791bc8e05d33000044_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c7a1791bc8e05d33000044_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c7a1791bc8e05d33000044_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0901/20160901105202266162.jpg","w":"600","h":"450"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7a17a1bc8e05d33000046&m=1472792504","list_dtime":"2016-09-01 14:18:38"},{"pk":"57c707379490cb9659000000","title":"这10部喜剧片笑点奇特，不落俗套","date":"2016-09-01 10:48:16","auther_name":"电影那点事儿","weburl":"http://iphone.myzaker.com/l.php?l=57c707379490cb9659000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5ODIzOF85MDM2OF9XNjQwSDM2MFM0ODg0NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5ODIzOF85MDM2OF9XNjQwSDM2MFM0ODg0NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"10","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c707379490cb9659000000&m=1472698222","list_dtime":"2016-09-01 10:48:16","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5ODIzOF85MDM2OF9XNjQwSDM2MFM0ODg0NS5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5ODIzOF85MDM2OF9XNjQwSDM2MFM0ODg0NS5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5ODIzOF85MDM2OF9XNjQwSDM2MFM0ODg0NS5qcGc=_1242.jpg","w":"640","h":"360"}]},{"pk":"57c7a9fa1bc8e0ee3900001b","title":"\"冬兵\"新片将出演冠军赛车手","date":"2016-09-01 14:17:23","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c7a9fa1bc8e0ee3900001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a9fa1bc8e0ee3900001a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a9fa1bc8e0ee3900001a_320.jpg","thumbnail_picsize":"1000,667","media_count":"1","thumbnail_medias":[{"type":"image","id":"57c7a9fa1bc8e0ee3900001a","url":"http://zkres.myzaker.com/201609/57c7a9fa1bc8e0ee3900001a_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c7a9fa1bc8e0ee3900001a_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c7a9fa1bc8e0ee3900001a_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0901/20160901114017158320.jpg","w":"1000","h":"667"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7a9fa1bc8e0ee3900001b&m=1472792504","list_dtime":"2016-09-01 14:17:23"},{"pk":"57c4f5711bc8e00c08000011","title":"《闪电侠》曝新反派 寒冷队长有望亮相","title_line_break":"《闪电侠》曝新反派\n寒冷队长有望亮相","date":"2016-09-01 10:40:44","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c4f5711bc8e00c08000011","thumbnail_pic":"http://zkres.myzaker.com/201608/57c4f5701bc8e00c0800000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c4f5701bc8e00c0800000d_320.jpg","thumbnail_picsize":"600,450","media_count":"4","thumbnail_medias":[{"type":"image","id":"57c4f5701bc8e00c0800000d","url":"http://zkres.myzaker.com/201608/57c4f5701bc8e00c0800000d_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c4f5701bc8e00c0800000d_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c4f5701bc8e00c0800000d_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0830/20160830103549598000.jpg","w":"600","h":"450"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c4f5711bc8e00c08000011&m=1472697648","list_dtime":"2016-09-01 10:40:44"},{"pk":"57c6aa691bc8e0d12200004c","title":"真人版《钢之炼金术师》杀青","date":"2016-09-01 10:27:43","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c6aa691bc8e0d12200004c","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6aa681bc8e0d12200004b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6aa681bc8e0d12200004b_320.jpg","thumbnail_picsize":"600,400","media_count":"1","thumbnail_medias":[{"type":"image","id":"57c6aa681bc8e0d12200004b","url":"http://zkres.myzaker.com/201608/57c6aa681bc8e0d12200004b_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c6aa681bc8e0d12200004b_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c6aa681bc8e0d12200004b_120.jpg","raw_url":"http://image11.m1905.cn/uploadfile/2016/0831/20160831053054336355.jpg","w":"600","h":"400"}],"app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c6aa691bc8e0d12200004c&m=1472696867","list_dtime":"2016-09-01 10:27:43"},{"pk":"57c7871b1bc8e0df25000015","title":"《鲨滩》采访特辑\u201cS女王\u201d以身试险","date":"2016-09-01 10:18:39","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c7871b1bc8e0df25000015","media_count":"0","app_ids":"10530","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c7871b1bc8e0df25000015&m=1472696267","list_dtime":"2016-09-01 10:18:39"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c626399490cb4145000009,57c50bd39490cb3c72000017,57c737449490cb0b70000001,57c84ca89490cba34c00009a,57c70f6c9490cbbc07000001,57c626399490cb414500000b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c8e67e1bc8e0a9780000d1,57c8dde61bc8e0d176000001,57c8ef111bc8e0897e000002,57c8cc821bc8e0f66a000020,57c635749490cba012000000,57c3b9289490cba33100001f","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c2cd969490cb4135000006,57c7b2559490cb197f000003,57c7dd769490cbe22c00006f,57c7a3139490cb2e39000002,57c5f0579490cbd53c00000b,57c7c18c9490cb3249000000","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c5e1199490cb167000000a,57c7beaf9490cbc12c00003a,57c7d0c99490cb6519000000,57c7a3139490cb2e39000000,57c7e2439490cb1b6c000000,57c65b691bc8e0346e00000b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c7a9f91bc8e0ee39000019,57c594ee9490cbb64b000012,57c546361bc8e03a3a000002,57c7b95f9490cb7f1f00001a,57c50bd39490cb3c72000016,57c78bab9490cbfb3f00001a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c7a17a1bc8e05d33000046,57c707379490cb9659000000,57c7a9fa1bc8e0ee3900001b,57c4f5711bc8e00c08000011,57c6aa691bc8e0d12200004c,57c7871b1bc8e0df25000015","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}}],"article_block_colors":["#f77762","#f77762"],"only_text_page_bgcolors":["#f77762","#f77762"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/10530.png?t=1458284157","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/10530.png?t=1458284157","hidden_time":"24","need_userinfo":"NO","block_title":"电影资讯","block_color":"#f77762","desktop_color_number":"20","use_original_icon":"N"}
     * top_tab_info_url : http://iphone.myzaker.com/zaker/top_tab_info.php?app_id=10530&full_arg=_appid,_v,_version,_lbs_city
     * show_type : top_tab
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=10530&since_date=1472439872&nt=1&next_aticle_id=57c510421bc8e0a01b000007&_appid=androidphone&opage=2&otimestamp=159
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=10530&need_app_integration=1
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=10530&ids=5642f2aa9490cbb13200000e,51a7104681853dec4d00012f&k=201609021310
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/10530.png?t=1458284157
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/10530.png?t=1458284157
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 电影资讯
         * block_color : #f77762
         * desktop_color_number : 20
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        private String top_tab_info_url;
        private String show_type;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57c626399490cb4145000009
         * title : 收好这份片单，保证九月没烂片能骗到你
         * date : 2016-09-02 11:44:26
         * auther_name : 毒舌电影
         * page : 1
         * index : 1
         * weburl : http://iphone.myzaker.com/l.php?l=57c626399490cb4145000009
         * thumbnail_pic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg
         * thumbnail_mpic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg
         * thumbnail_picsize : 640,360
         * media_count : 90
         * app_ids : 10530
         * is_full : NO
         * content :
         * special_type : topic
         * special_info : {"icon_type":"1","block_info":{"pk":"57c550b39490cb3f13000071","block_title":"每月片单","title":"每月片单","block_in_title":"收好这份片单，保证九月没烂片能骗到你","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=10530&topic_id=57c550b39490cb3f13000071&updated=1472786296"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png","show_jingcai":"Y","list_nodsp":"Y","item_type":"1_b"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c626399490cb4145000009&m=1472792777
         * list_dtime : 2016-09-02 11:44:26
         * thumbnail_medias : [{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg","w":"640","h":"360"}]
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public String getTop_tab_info_url() {
            return top_tab_info_url;
        }

        public void setTop_tab_info_url(String top_tab_info_url) {
            this.top_tab_info_url = top_tab_info_url;
        }

        public String getShow_type() {
            return show_type;
        }

        public void setShow_type(String show_type) {
            this.show_type = show_type;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 4
             * articles : 57c626399490cb4145000009,57c50bd39490cb3c72000017,57c737449490cb0b70000001,57c84ca89490cba34c00009a,57c70f6c9490cbbc07000001,57c626399490cb414500000b
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/10530.png?t=1458284157
                 * bgimage_frame : 0,0,320,44
                 * title_h : 44
                 * hide_title : YES
                 * open_type :
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String app_ids;
            private String is_full;
            private String content;
            private String special_type;
            /**
             * icon_type : 1
             * block_info : {"pk":"57c550b39490cb3f13000071","block_title":"每月片单","title":"每月片单","block_in_title":"收好这份片单，保证九月没烂片能骗到你","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=10530&topic_id=57c550b39490cb3f13000071&updated=1472786296"}
             * icon_url : http://zkres.myzaker.com/data/image/mark2/topic_2x.png
             * show_jingcai : Y
             * list_nodsp : Y
             * item_type : 1_b
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;
            /**
             * type : image
             * url : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg
             * m_url : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg
             * raw_url : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0NTA3N183Njg1NF9XNjQwSDM2MFM5Mjg0Mi5qcGc=_1242.jpg
             * w : 640
             * h : 360
             */

            private List<ThumbnailMediasBean> thumbnail_medias;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getApp_ids() {
                return app_ids;
            }

            public void setApp_ids(String app_ids) {
                this.app_ids = app_ids;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getSpecial_type() {
                return special_type;
            }

            public void setSpecial_type(String special_type) {
                this.special_type = special_type;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public List<ThumbnailMediasBean> getThumbnail_medias() {
                return thumbnail_medias;
            }

            public void setThumbnail_medias(List<ThumbnailMediasBean> thumbnail_medias) {
                this.thumbnail_medias = thumbnail_medias;
            }

            public static class SpecialInfoBean {
                private String icon_type;
                /**
                 * pk : 57c550b39490cb3f13000071
                 * block_title : 每月片单
                 * title : 每月片单
                 * block_in_title : 收好这份片单，保证九月没烂片能骗到你
                 * type : user
                 * need_userinfo : NO
                 * skey :
                 * api_url : http://iphone.myzaker.com/zaker/topic.php?app_id=10530&topic_id=57c550b39490cb3f13000071&updated=1472786296
                 */

                private BlockInfoBean block_info;
                private String icon_url;
                private String show_jingcai;
                private String list_nodsp;
                private String item_type;

                public String getIcon_type() {
                    return icon_type;
                }

                public void setIcon_type(String icon_type) {
                    this.icon_type = icon_type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public String getIcon_url() {
                    return icon_url;
                }

                public void setIcon_url(String icon_url) {
                    this.icon_url = icon_url;
                }

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }

                public String getItem_type() {
                    return item_type;
                }

                public void setItem_type(String item_type) {
                    this.item_type = item_type;
                }

                public static class BlockInfoBean {
                    private String pk;
                    private String block_title;
                    private String title;
                    private String block_in_title;
                    private String type;
                    private String need_userinfo;
                    private String skey;
                    private String api_url;

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getBlock_title() {
                        return block_title;
                    }

                    public void setBlock_title(String block_title) {
                        this.block_title = block_title;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getBlock_in_title() {
                        return block_in_title;
                    }

                    public void setBlock_in_title(String block_in_title) {
                        this.block_in_title = block_in_title;
                    }

                    public String getType() {
                        return type;
                    }

                    public void setType(String type) {
                        this.type = type;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getSkey() {
                        return skey;
                    }

                    public void setSkey(String skey) {
                        this.skey = skey;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }
                }
            }

            public static class ThumbnailMediasBean {
                private String type;
                private String url;
                private String m_url;
                private String raw_url;
                private String w;
                private String h;

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public String getUrl() {
                    return url;
                }

                public void setUrl(String url) {
                    this.url = url;
                }

                public String getM_url() {
                    return m_url;
                }

                public void setM_url(String m_url) {
                    this.m_url = m_url;
                }

                public String getRaw_url() {
                    return raw_url;
                }

                public void setRaw_url(String raw_url) {
                    this.raw_url = raw_url;
                }

                public String getW() {
                    return w;
                }

                public void setW(String w) {
                    this.w = w;
                }

                public String getH() {
                    return h;
                }

                public void setH(String h) {
                    this.h = h;
                }
            }
        }
    }
}
