package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/2.
 */
public class Bean_moviefan {


    /**
     * stat : 1
     * msg : ok
     * data : {"discussion_info":{"pk":"168","title":"电影圈","stitle":"电影同好联盟","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2015/07/15/55a5c62c9490cbac17000044.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2015/07/15/55a5c62c9490cbac17000044.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=168","block_color":"","subscribe_count":"607155","post_count":"11957"},"info":{"pre_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=168&timestamp=1472790955.6493&order=2&act=pre&order_type=last_comment","next_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=168&timestamp=1472791455.4059&order=0&act=next&order_type=last_comment"},"posts":[{"pk":"57c690499490cb0a4b000051","discussion_id":"168","auther":{"name":"文艺Z娘","uid":"10047301","user_flag":[{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user.png"}],"icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5024/10047301_1436323441.jpg.210.jpg"},"title":"","date":"2016-08-31 16:07:37","content":"盘点被剪辑过的电影，得《寄生兽》影票","comment_count":"99","hot_num":"11245","like_num":"76","post_tag":[{"name":"置顶","icon":"http://zkres.myzaker.com/data/image/mark2/stick3_2x.png"}],"list_tip":["3163 热度","99 回复"],"list_date":"2016-09-02 12:35:55","thumbnail_medias":[{"type":"image","id":"57c7e1909490cb7b2c00006e","w":"921","h":"494","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg"}],"medias":[{"type":"image","id":"57c7e1909490cb7b2c00006e","w":"921","h":"494","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c690499490cb0a4b000051","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c690499490cb0a4b000051&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c690499490cb0a4b000051","is_top":"1","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c8e09335a324b317000272","discussion_id":"168","auther":{"name":"智障儿童戴套套","uid":"11647772","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5824/11647772_1471622960.jpg.210.jpg"},"title":"","date":"2016-09-02 10:14:43","content":" 在这个基情满满，腐女当道的新时代，少不了同性恋题材的电影。盘点下曾经看过的同性恋电影： 最为经典的算《断背山》，剧情平淡，发展缓慢，实在不懂，这部电影的伟大之处，可能是我的理解跟不上。 《霸王别姬》，张国荣不是在演戏，而是在表现真实的自我。电影设定的时代很特殊，二人之间的感情也更为曲折。最让人揪心的，莫过于文革时期的批斗大会。 《暹罗之恋》，马里奥干净帅气，影片的结局感人。 《刺青》，我是不喜欢杨丞琳的，但是看完这部影片，竟对她生出好感。刺青，意味着什么？每个人选择刺青的理...","comment_count":"25","hot_num":"777","like_num":"11","post_tag":[{"name":"置顶","icon":"http://zkres.myzaker.com/data/image/mark2/stick3_2x.png"}],"list_tip":["34 热度","25 回复"],"list_date":"2016-09-02 12:03:05","thumbnail_medias":[{"type":"image","id":"57c8e08f1716cfae36000267","w":"381","h":"254","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg"},{"type":"image","id":"57c8e09035a324be1700025a","w":"600","h":"337","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg"},{"type":"image","id":"57c8e09035a324d517000257","w":"550","h":"367","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg"},{"type":"image","id":"57c8e09235a3240618000283","w":"1875","h":"1407","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg"},{"type":"image","id":"57c8e09235a3240618000284","w":"1231","h":"815","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg"},{"type":"image","id":"57c8e0931716cf9536000268","w":"1280","h":"960","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg"}],"medias":[{"type":"image","id":"57c8e08f1716cfae36000267","w":"381","h":"254","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg"},{"type":"image","id":"57c8e09035a324be1700025a","w":"600","h":"337","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg"},{"type":"image","id":"57c8e09035a324d517000257","w":"550","h":"367","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg"},{"type":"image","id":"57c8e09235a3240618000283","w":"1875","h":"1407","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg"},{"type":"image","id":"57c8e09235a3240618000284","w":"1231","h":"815","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg"},{"type":"image","id":"57c8e0931716cf9536000268","w":"1280","h":"960","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c8e09335a324b317000272","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c8e09335a324b317000272&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c8e09335a324b317000272","is_top":"1","special_info":{"item_type":"1","medias_count":"6"},"is_liked":"0"},{"pk":"57c553b81716cfa35d00006b","discussion_id":"168","auther":{"name":"Balalalala","uid":"2033520","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/1017/2033520_1465356369.jpg.210.jpg"},"title":"","date":"2016-08-30 17:36:56","content":"#关于《哭声》的困惑# 之前看这里的大神发过几篇哭声的影评，多是赞叹和肯定，但最近我的朋友看完之后表示混乱但无感，劝我不用特地去看。 我个人看惊悚片之前是有看影评和浅度剧透的习惯🌚因为胆比较小～然后翻到采访导演的纪录📝，结果看完更加一脸懵逼，导演的逻辑好难理解甚至有点混乱，是不是真的像某些影评说的：导演想的线太多但最后不能理清楚，看似很有奥义其实是一团乱麻？ 如果有人能再说说这部电影，我才能安心去看啊～～求分享 ps:圣痕这个概念以前没怎么看过啊，求解释！","comment_count":"53","hot_num":"7397","like_num":"59","post_tag":[],"list_tip":["152 热度","53 回复"],"list_date":"2016-09-02 14:20:26","thumbnail_medias":[{"type":"image","id":"57c553b61716cf715d000048","w":"892","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg"},{"type":"image","id":"57c553b71716cfa65d00004b","w":"1600","h":"1066","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg"},{"type":"image","id":"57c553b71716cf545d000051","w":"750","h":"1334","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg"},{"type":"image","id":"57c553b81716cf825d000061","w":"750","h":"1334","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg"},{"type":"image","id":"57c553b81716cf505d00005c","w":"750","h":"1334","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg"}],"medias":[{"type":"image","id":"57c553b61716cf715d000048","w":"892","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg"},{"type":"image","id":"57c553b71716cfa65d00004b","w":"1600","h":"1066","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg"},{"type":"image","id":"57c553b71716cf545d000051","w":"750","h":"1334","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg"},{"type":"image","id":"57c553b81716cf825d000061","w":"750","h":"1334","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg"},{"type":"image","id":"57c553b81716cf505d00005c","w":"750","h":"1334","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c553b81716cfa35d00006b","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c553b81716cfa35d00006b&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c553b81716cfa35d00006b","special_info":{"item_type":"1","medias_count":"5"},"is_liked":"0"},{"pk":"57c7f16635a324f90a00026e","discussion_id":"168","auther":{"name":"盛夏","uid":"10596231","icon":"http://q.qlogo.cn/qqapp/100318686/1BACDC807BBA99B33B17FDD19E897BD0/40"},"title":"","date":"2016-09-01 17:14:14","content":"今天看了穆赫兰道，看到一个小时才知道这是一场梦，有没有看过的觉得这个电影咋样，我反正是不喜欢。","comment_count":"10","hot_num":"841","like_num":"1","post_tag":[],"list_tip":["22 热度","10 回复"],"list_date":"2016-09-02 14:15:00","thumbnail_medias":[],"medias":[],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c7f16635a324f90a00026e","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c7f16635a324f90a00026e&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c7f16635a324f90a00026e","is_liked":"0"},{"pk":"57c8eea435a3244e190000d6","discussion_id":"168","auther":{"name":"章鱼常","uid":"807624","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/404/807624_1472352651.jpg.210.jpg"},"title":"","date":"2016-09-02 11:14:44","content":"刚刚看新闻阿根廷总统专机抵萧山机场，那场面，突然就想到了《伦敦陷落》😂","comment_count":"13","hot_num":"331","like_num":"3","post_tag":[],"list_tip":["16 热度","13 回复"],"list_date":"2016-09-02 14:10:22","thumbnail_medias":[{"type":"image","id":"57c8eea31716cf6a36000429","w":"634","h":"373","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg"}],"medias":[{"type":"image","id":"57c8eea31716cf6a36000429","w":"634","h":"373","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c8eea435a3244e190000d6","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c8eea435a3244e190000d6&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c8eea435a3244e190000d6","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c7f40435a324420b0002c7","discussion_id":"168","auther":{"name":"Balalalala","uid":"2033520","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/1017/2033520_1465356369.jpg.210.jpg"},"title":"","date":"2016-09-01 17:25:24","content":"突然发现之前社区推荐很久的《银翼杀手》我还没看！！！！我这个渣渣😂😂😂","comment_count":"37","hot_num":"1073","like_num":"6","post_tag":[],"list_tip":["46 热度","37 回复"],"list_date":"2016-09-02 14:08:25","thumbnail_medias":[{"type":"image","id":"57c7f3f51716cf0e15000073","w":"600","h":"274","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg"}],"medias":[{"type":"image","id":"57c7f3f51716cf0e15000073","w":"600","h":"274","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c7f40435a324420b0002c7","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c7f40435a324420b0002c7&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c7f40435a324420b0002c7","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c20b801716cf927f000007","discussion_id":"168","auther":{"name":"iTaylor","uid":"10548002","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5275/10548002_1462744357.jpg.210.jpg"},"title":"","date":"2016-08-28 05:52:00","content":"看完以后表示得看好几部喜剧片才能缓过来啊😷😷","comment_count":"30","hot_num":"4567","like_num":"6","post_tag":[],"list_tip":["197 热度","30 回复"],"list_date":"2016-09-02 14:02:25","thumbnail_medias":[{"type":"image","id":"57c20b801716cf6301000001","w":"353","h":"500","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg"}],"medias":[{"type":"image","id":"57c20b801716cf6301000001","w":"353","h":"500","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c20b801716cf927f000007","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c20b801716cf927f000007&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c20b801716cf927f000007","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c914cb35a324a41b000035","discussion_id":"168","auther":{"name":"一一一九","uid":"10439837","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5220/10439837_1426068272.jpg.210.jpg"},"title":"","date":"2016-09-02 13:57:31","content":"《小森林》中的环境给我的感觉明净清新，很多让现在的我们不足为道甚至嫌弃地农活都被演绎的\u201c脱俗\u201d，很多食物自给自足，吃的安全放心；村民之间的关系和睦融洽，有好吃的互相分享，有时间就席地而坐把手话家常...里面的世界没有纷争没有喧闹，每天都让人精神地过！","comment_count":"0","hot_num":"25","like_num":"0","post_tag":[],"list_tip":["0 热度","0 回复"],"list_date":"2016-09-02 13:57:31","thumbnail_medias":[{"type":"image","id":"57c914c71716cf273a0000df","w":"640","h":"2356","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg"},{"type":"image","id":"57c914c81716cf813a0000f6","w":"638","h":"2057","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg"},{"type":"image","id":"57c914ca35a324a11b000035","w":"640","h":"2079","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg"},{"type":"image","id":"57c914cb1716cf3e3a0000e3","w":"640","h":"2062","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg"}],"medias":[{"type":"image","id":"57c914c71716cf273a0000df","w":"640","h":"2356","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg"},{"type":"image","id":"57c914c81716cf813a0000f6","w":"638","h":"2057","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg"},{"type":"image","id":"57c914ca35a324a11b000035","w":"640","h":"2079","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg"},{"type":"image","id":"57c914cb1716cf3e3a0000e3","w":"640","h":"2062","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c914cb35a324a41b000035","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c914cb35a324a41b000035&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c914cb35a324a41b000035","special_info":{"item_type":"1","medias_count":"4"},"is_liked":"0"},{"pk":"57c908ec35a3248b1a00018a","discussion_id":"168","auther":{"name":"灭王者之风","uid":"11628472","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5815/11628472_1469624731.jpg.210.jpg"},"title":"","date":"2016-09-02 13:06:52","content":"『ZAKER观影报告：《冰川时代5》』 评分：9分 一句话短评：十四年松鼠还是未能吃到橡果 推荐观影人群：家庭、松鼠迷、冰川迷 值不值回票价：值 详细影评： 从冰川1到5，十四年了。这次可爱的松鼠为了追松果这次玩起了UFO。去了太空，并来一次星际大碰撞\u2026\u2026难道是因为星际迷航要出的原因么\u2026\u2026小松鼠还是这么折腾，执着，作。不过我喜欢这只松鼠，如果不是他的作，我想就没多少人去看了。桃子有了男友，看上去傻傻的，但对桃子非常好。其实女人嘛，找一个爱自己的男人的就行了。树懒也找到了自己的...","comment_count":"0","hot_num":"99","like_num":"1","post_tag":[],"list_tip":["2 热度","0 回复"],"list_date":"2016-09-02 13:06:52","thumbnail_medias":[{"type":"image","id":"57c908ea35a324bd1a00015f","w":"360","h":"151","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg"},{"type":"image","id":"57c908eb1716cf8b380002e6","w":"360","h":"169","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg"}],"medias":[{"type":"image","id":"57c908ea35a324bd1a00015f","w":"360","h":"151","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg"},{"type":"image","id":"57c908eb1716cf8b380002e6","w":"360","h":"169","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c908ec35a3248b1a00018a","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c908ec35a3248b1a00018a&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c908ec35a3248b1a00018a","special_info":{"item_type":"2","medias_count":"2"},"is_liked":"0"},{"pk":"57c9039f35a324c81a0000ae","discussion_id":"168","auther":{"name":"☁","uid":"11426437","icon":"http://wx.qlogo.cn/mmopen/ajNVdqHZLLCoq6DUic2DPbibtKyzMZVZYuvM3OicLKhFesy4Wic9ku9h61OFNJOKcMJichzWGgQXGb19Lj766cPZ2dA/0"},"title":"","date":"2016-09-02 12:44:15","additional_info":{"title":"9月新片推荐","article_pk":"57c84ca89490cba34c00009a","author":"独立鱼电影","pic":"http://zkres.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0MzUzMl80MzI0MF9XNDIzSDM4NVM1OTY0NS5qcGc=_320.jpg","open_info":{"open_detail_url":"http://iphone.myzaker.com/zaker/open_quote_url.php?type=article&pk=57c84ca89490cba34c00009a&app_id=10530"}},"content":"分享文章","comment_count":"0","hot_num":"120","like_num":"0","post_tag":[],"list_tip":["0 热度","0 回复"],"list_date":"2016-09-02 12:44:15","thumbnail_medias":[],"medias":[],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c9039f35a324c81a0000ae","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c9039f35a324c81a0000ae&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c9039f35a324c81a0000ae","is_liked":"0"}]}
     */

    private String stat;
    private String msg;
    /**
     * discussion_info : {"pk":"168","title":"电影圈","stitle":"电影同好联盟","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2015/07/15/55a5c62c9490cbac17000044.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2015/07/15/55a5c62c9490cbac17000044.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=168","block_color":"","subscribe_count":"607155","post_count":"11957"}
     * info : {"pre_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=168&timestamp=1472790955.6493&order=2&act=pre&order_type=last_comment","next_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=168&timestamp=1472791455.4059&order=0&act=next&order_type=last_comment"}
     * posts : [{"pk":"57c690499490cb0a4b000051","discussion_id":"168","auther":{"name":"文艺Z娘","uid":"10047301","user_flag":[{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user.png"}],"icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5024/10047301_1436323441.jpg.210.jpg"},"title":"","date":"2016-08-31 16:07:37","content":"盘点被剪辑过的电影，得《寄生兽》影票","comment_count":"99","hot_num":"11245","like_num":"76","post_tag":[{"name":"置顶","icon":"http://zkres.myzaker.com/data/image/mark2/stick3_2x.png"}],"list_tip":["3163 热度","99 回复"],"list_date":"2016-09-02 12:35:55","thumbnail_medias":[{"type":"image","id":"57c7e1909490cb7b2c00006e","w":"921","h":"494","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg"}],"medias":[{"type":"image","id":"57c7e1909490cb7b2c00006e","w":"921","h":"494","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c690499490cb0a4b000051","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c690499490cb0a4b000051&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c690499490cb0a4b000051","is_top":"1","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c8e09335a324b317000272","discussion_id":"168","auther":{"name":"智障儿童戴套套","uid":"11647772","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5824/11647772_1471622960.jpg.210.jpg"},"title":"","date":"2016-09-02 10:14:43","content":" 在这个基情满满，腐女当道的新时代，少不了同性恋题材的电影。盘点下曾经看过的同性恋电影： 最为经典的算《断背山》，剧情平淡，发展缓慢，实在不懂，这部电影的伟大之处，可能是我的理解跟不上。 《霸王别姬》，张国荣不是在演戏，而是在表现真实的自我。电影设定的时代很特殊，二人之间的感情也更为曲折。最让人揪心的，莫过于文革时期的批斗大会。 《暹罗之恋》，马里奥干净帅气，影片的结局感人。 《刺青》，我是不喜欢杨丞琳的，但是看完这部影片，竟对她生出好感。刺青，意味着什么？每个人选择刺青的理...","comment_count":"25","hot_num":"777","like_num":"11","post_tag":[{"name":"置顶","icon":"http://zkres.myzaker.com/data/image/mark2/stick3_2x.png"}],"list_tip":["34 热度","25 回复"],"list_date":"2016-09-02 12:03:05","thumbnail_medias":[{"type":"image","id":"57c8e08f1716cfae36000267","w":"381","h":"254","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg"},{"type":"image","id":"57c8e09035a324be1700025a","w":"600","h":"337","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg"},{"type":"image","id":"57c8e09035a324d517000257","w":"550","h":"367","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg"},{"type":"image","id":"57c8e09235a3240618000283","w":"1875","h":"1407","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg"},{"type":"image","id":"57c8e09235a3240618000284","w":"1231","h":"815","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg"},{"type":"image","id":"57c8e0931716cf9536000268","w":"1280","h":"960","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg"}],"medias":[{"type":"image","id":"57c8e08f1716cfae36000267","w":"381","h":"254","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e08f1716cfae36000267.jpg"},{"type":"image","id":"57c8e09035a324be1700025a","w":"600","h":"337","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324be1700025a.jpg"},{"type":"image","id":"57c8e09035a324d517000257","w":"550","h":"367","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09035a324d517000257.jpg"},{"type":"image","id":"57c8e09235a3240618000283","w":"1875","h":"1407","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000283.jpg"},{"type":"image","id":"57c8e09235a3240618000284","w":"1231","h":"815","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e09235a3240618000284.jpg"},{"type":"image","id":"57c8e0931716cf9536000268","w":"1280","h":"960","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8e0931716cf9536000268.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c8e09335a324b317000272","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c8e09335a324b317000272&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c8e09335a324b317000272","is_top":"1","special_info":{"item_type":"1","medias_count":"6"},"is_liked":"0"},{"pk":"57c553b81716cfa35d00006b","discussion_id":"168","auther":{"name":"Balalalala","uid":"2033520","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/1017/2033520_1465356369.jpg.210.jpg"},"title":"","date":"2016-08-30 17:36:56","content":"#关于《哭声》的困惑# 之前看这里的大神发过几篇哭声的影评，多是赞叹和肯定，但最近我的朋友看完之后表示混乱但无感，劝我不用特地去看。 我个人看惊悚片之前是有看影评和浅度剧透的习惯🌚因为胆比较小～然后翻到采访导演的纪录📝，结果看完更加一脸懵逼，导演的逻辑好难理解甚至有点混乱，是不是真的像某些影评说的：导演想的线太多但最后不能理清楚，看似很有奥义其实是一团乱麻？ 如果有人能再说说这部电影，我才能安心去看啊～～求分享 ps:圣痕这个概念以前没怎么看过啊，求解释！","comment_count":"53","hot_num":"7397","like_num":"59","post_tag":[],"list_tip":["152 热度","53 回复"],"list_date":"2016-09-02 14:20:26","thumbnail_medias":[{"type":"image","id":"57c553b61716cf715d000048","w":"892","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg"},{"type":"image","id":"57c553b71716cfa65d00004b","w":"1600","h":"1066","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg"},{"type":"image","id":"57c553b71716cf545d000051","w":"750","h":"1334","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg"},{"type":"image","id":"57c553b81716cf825d000061","w":"750","h":"1334","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg"},{"type":"image","id":"57c553b81716cf505d00005c","w":"750","h":"1334","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg"}],"medias":[{"type":"image","id":"57c553b61716cf715d000048","w":"892","h":"1280","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b61716cf715d000048.jpg"},{"type":"image","id":"57c553b71716cfa65d00004b","w":"1600","h":"1066","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cfa65d00004b.jpg"},{"type":"image","id":"57c553b71716cf545d000051","w":"750","h":"1334","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b71716cf545d000051.jpg"},{"type":"image","id":"57c553b81716cf825d000061","w":"750","h":"1334","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf825d000061.jpg"},{"type":"image","id":"57c553b81716cf505d00005c","w":"750","h":"1334","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c553b81716cf505d00005c.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c553b81716cfa35d00006b","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c553b81716cfa35d00006b&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c553b81716cfa35d00006b","special_info":{"item_type":"1","medias_count":"5"},"is_liked":"0"},{"pk":"57c7f16635a324f90a00026e","discussion_id":"168","auther":{"name":"盛夏","uid":"10596231","icon":"http://q.qlogo.cn/qqapp/100318686/1BACDC807BBA99B33B17FDD19E897BD0/40"},"title":"","date":"2016-09-01 17:14:14","content":"今天看了穆赫兰道，看到一个小时才知道这是一场梦，有没有看过的觉得这个电影咋样，我反正是不喜欢。","comment_count":"10","hot_num":"841","like_num":"1","post_tag":[],"list_tip":["22 热度","10 回复"],"list_date":"2016-09-02 14:15:00","thumbnail_medias":[],"medias":[],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c7f16635a324f90a00026e","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c7f16635a324f90a00026e&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c7f16635a324f90a00026e","is_liked":"0"},{"pk":"57c8eea435a3244e190000d6","discussion_id":"168","auther":{"name":"章鱼常","uid":"807624","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/404/807624_1472352651.jpg.210.jpg"},"title":"","date":"2016-09-02 11:14:44","content":"刚刚看新闻阿根廷总统专机抵萧山机场，那场面，突然就想到了《伦敦陷落》😂","comment_count":"13","hot_num":"331","like_num":"3","post_tag":[],"list_tip":["16 热度","13 回复"],"list_date":"2016-09-02 14:10:22","thumbnail_medias":[{"type":"image","id":"57c8eea31716cf6a36000429","w":"634","h":"373","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg"}],"medias":[{"type":"image","id":"57c8eea31716cf6a36000429","w":"634","h":"373","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c8eea31716cf6a36000429.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c8eea435a3244e190000d6","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c8eea435a3244e190000d6&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c8eea435a3244e190000d6","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c7f40435a324420b0002c7","discussion_id":"168","auther":{"name":"Balalalala","uid":"2033520","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/1017/2033520_1465356369.jpg.210.jpg"},"title":"","date":"2016-09-01 17:25:24","content":"突然发现之前社区推荐很久的《银翼杀手》我还没看！！！！我这个渣渣😂😂😂","comment_count":"37","hot_num":"1073","like_num":"6","post_tag":[],"list_tip":["46 热度","37 回复"],"list_date":"2016-09-02 14:08:25","thumbnail_medias":[{"type":"image","id":"57c7f3f51716cf0e15000073","w":"600","h":"274","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg"}],"medias":[{"type":"image","id":"57c7f3f51716cf0e15000073","w":"600","h":"274","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7f3f51716cf0e15000073.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c7f40435a324420b0002c7","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c7f40435a324420b0002c7&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c7f40435a324420b0002c7","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c20b801716cf927f000007","discussion_id":"168","auther":{"name":"iTaylor","uid":"10548002","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5275/10548002_1462744357.jpg.210.jpg"},"title":"","date":"2016-08-28 05:52:00","content":"看完以后表示得看好几部喜剧片才能缓过来啊😷😷","comment_count":"30","hot_num":"4567","like_num":"6","post_tag":[],"list_tip":["197 热度","30 回复"],"list_date":"2016-09-02 14:02:25","thumbnail_medias":[{"type":"image","id":"57c20b801716cf6301000001","w":"353","h":"500","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg"}],"medias":[{"type":"image","id":"57c20b801716cf6301000001","w":"353","h":"500","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/28/57c20b801716cf6301000001.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c20b801716cf927f000007","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c20b801716cf927f000007&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c20b801716cf927f000007","special_info":{"item_type":"1","medias_count":"1"},"is_liked":"0"},{"pk":"57c914cb35a324a41b000035","discussion_id":"168","auther":{"name":"一一一九","uid":"10439837","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5220/10439837_1426068272.jpg.210.jpg"},"title":"","date":"2016-09-02 13:57:31","content":"《小森林》中的环境给我的感觉明净清新，很多让现在的我们不足为道甚至嫌弃地农活都被演绎的\u201c脱俗\u201d，很多食物自给自足，吃的安全放心；村民之间的关系和睦融洽，有好吃的互相分享，有时间就席地而坐把手话家常...里面的世界没有纷争没有喧闹，每天都让人精神地过！","comment_count":"0","hot_num":"25","like_num":"0","post_tag":[],"list_tip":["0 热度","0 回复"],"list_date":"2016-09-02 13:57:31","thumbnail_medias":[{"type":"image","id":"57c914c71716cf273a0000df","w":"640","h":"2356","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg"},{"type":"image","id":"57c914c81716cf813a0000f6","w":"638","h":"2057","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg"},{"type":"image","id":"57c914ca35a324a11b000035","w":"640","h":"2079","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg"},{"type":"image","id":"57c914cb1716cf3e3a0000e3","w":"640","h":"2062","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg"}],"medias":[{"type":"image","id":"57c914c71716cf273a0000df","w":"640","h":"2356","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c71716cf273a0000df.jpg"},{"type":"image","id":"57c914c81716cf813a0000f6","w":"638","h":"2057","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914c81716cf813a0000f6.jpg"},{"type":"image","id":"57c914ca35a324a11b000035","w":"640","h":"2079","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914ca35a324a11b000035.jpg"},{"type":"image","id":"57c914cb1716cf3e3a0000e3","w":"640","h":"2062","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg.120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c914cb1716cf3e3a0000e3.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c914cb35a324a41b000035","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c914cb35a324a41b000035&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c914cb35a324a41b000035","special_info":{"item_type":"1","medias_count":"4"},"is_liked":"0"},{"pk":"57c908ec35a3248b1a00018a","discussion_id":"168","auther":{"name":"灭王者之风","uid":"11628472","icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5815/11628472_1469624731.jpg.210.jpg"},"title":"","date":"2016-09-02 13:06:52","content":"『ZAKER观影报告：《冰川时代5》』 评分：9分 一句话短评：十四年松鼠还是未能吃到橡果 推荐观影人群：家庭、松鼠迷、冰川迷 值不值回票价：值 详细影评： 从冰川1到5，十四年了。这次可爱的松鼠为了追松果这次玩起了UFO。去了太空，并来一次星际大碰撞\u2026\u2026难道是因为星际迷航要出的原因么\u2026\u2026小松鼠还是这么折腾，执着，作。不过我喜欢这只松鼠，如果不是他的作，我想就没多少人去看了。桃子有了男友，看上去傻傻的，但对桃子非常好。其实女人嘛，找一个爱自己的男人的就行了。树懒也找到了自己的...","comment_count":"0","hot_num":"99","like_num":"1","post_tag":[],"list_tip":["2 热度","0 回复"],"list_date":"2016-09-02 13:06:52","thumbnail_medias":[{"type":"image","id":"57c908ea35a324bd1a00015f","w":"360","h":"151","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg"},{"type":"image","id":"57c908eb1716cf8b380002e6","w":"360","h":"169","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg"}],"medias":[{"type":"image","id":"57c908ea35a324bd1a00015f","w":"360","h":"151","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908ea35a324bd1a00015f.jpg"},{"type":"image","id":"57c908eb1716cf8b380002e6","w":"360","h":"169","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/02/57c908eb1716cf8b380002e6.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c908ec35a3248b1a00018a","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c908ec35a3248b1a00018a&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c908ec35a3248b1a00018a","special_info":{"item_type":"2","medias_count":"2"},"is_liked":"0"},{"pk":"57c9039f35a324c81a0000ae","discussion_id":"168","auther":{"name":"☁","uid":"11426437","icon":"http://wx.qlogo.cn/mmopen/ajNVdqHZLLCoq6DUic2DPbibtKyzMZVZYuvM3OicLKhFesy4Wic9ku9h61OFNJOKcMJichzWGgQXGb19Lj766cPZ2dA/0"},"title":"","date":"2016-09-02 12:44:15","additional_info":{"title":"9月新片推荐","article_pk":"57c84ca89490cba34c00009a","author":"独立鱼电影","pic":"http://zkres.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3Mjc0MzUzMl80MzI0MF9XNDIzSDM4NVM1OTY0NS5qcGc=_320.jpg","open_info":{"open_detail_url":"http://iphone.myzaker.com/zaker/open_quote_url.php?type=article&pk=57c84ca89490cba34c00009a&app_id=10530"}},"content":"分享文章","comment_count":"0","hot_num":"120","like_num":"0","post_tag":[],"list_tip":["0 热度","0 回复"],"list_date":"2016-09-02 12:44:15","thumbnail_medias":[],"medias":[],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c9039f35a324c81a0000ae","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c9039f35a324c81a0000ae&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c9039f35a324c81a0000ae","is_liked":"0"}]
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * pk : 168
         * title : 电影圈
         * stitle : 电影同好联盟
         * pic : http://disres.myzaker.com/img_upload/discussion/disicon/2015/07/15/55a5c62c9490cbac17000044.png
         * large_pic : http://disres.myzaker.com/img_upload/discussion/disicon/2015/07/15/55a5c62c9490cbac17000044.png
         * api_url : http://dis.myzaker.com/api/get_post.php?discussion_id=168
         * block_color :
         * subscribe_count : 607155
         * post_count : 11957
         */

        private DiscussionInfoBean discussion_info;
        /**
         * pre_url : http://dis.myzaker.com/api/get_post.php?discussion_id=168&timestamp=1472790955.6493&order=2&act=pre&order_type=last_comment
         * next_url : http://dis.myzaker.com/api/get_post.php?discussion_id=168&timestamp=1472791455.4059&order=0&act=next&order_type=last_comment
         */

        private InfoBean info;
        /**
         * pk : 57c690499490cb0a4b000051
         * discussion_id : 168
         * auther : {"name":"文艺Z娘","uid":"10047301","user_flag":[{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user.png"}],"icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5024/10047301_1436323441.jpg.210.jpg"}
         * title :
         * date : 2016-08-31 16:07:37
         * content : 盘点被剪辑过的电影，得《寄生兽》影票
         * comment_count : 99
         * hot_num : 11245
         * like_num : 76
         * post_tag : [{"name":"置顶","icon":"http://zkres.myzaker.com/data/image/mark2/stick3_2x.png"}]
         * list_tip : ["3163 热度","99 回复"]
         * list_date : 2016-09-02 12:35:55
         * thumbnail_medias : [{"type":"image","id":"57c7e1909490cb7b2c00006e","w":"921","h":"494","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg"}]
         * medias : [{"type":"image","id":"57c7e1909490cb7b2c00006e","w":"921","h":"494","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg"}]
         * weburl : http://dis.myzaker.com/api/l.php?discussion_id=168&post_id=57c690499490cb0a4b000051
         * content_url : http://dis.myzaker.com/api/view_post.php?discussion_id=168&post_id=57c690499490cb0a4b000051&disds=1&_appid=AndroidPhone&_version=6.7&_udid=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920.08%3A00%3A27%3A4c%3A0a%3A58&_uid=&_utoken=&_bsize=1080_1920&_dev=515&_net=wifi&_os=4.4.4_GoogleNexus5-4.4.4-API19-1080x1920&_os_name=GoogleNexus5-4.4.4-API19-1080x1920&_lat=38.88973&_lng=121.551023&_v=6.7&_from_app=
         * comment_list_url : http://dis.myzaker.com/api/get_comment.php?discussion_id=168&post_id=57c690499490cb0a4b000051
         * is_top : 1
         * special_info : {"item_type":"1","medias_count":"1"}
         * is_liked : 0
         */

        private List<PostsBean> posts;

        public DiscussionInfoBean getDiscussion_info() {
            return discussion_info;
        }

        public void setDiscussion_info(DiscussionInfoBean discussion_info) {
            this.discussion_info = discussion_info;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public List<PostsBean> getPosts() {
            return posts;
        }

        public void setPosts(List<PostsBean> posts) {
            this.posts = posts;
        }

        public static class DiscussionInfoBean {
            private String pk;
            private String title;
            private String stitle;
            private String pic;
            private String large_pic;
            private String api_url;
            private String block_color;
            private String subscribe_count;
            private String post_count;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getApi_url() {
                return api_url;
            }

            public void setApi_url(String api_url) {
                this.api_url = api_url;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getSubscribe_count() {
                return subscribe_count;
            }

            public void setSubscribe_count(String subscribe_count) {
                this.subscribe_count = subscribe_count;
            }

            public String getPost_count() {
                return post_count;
            }

            public void setPost_count(String post_count) {
                this.post_count = post_count;
            }
        }

        public static class InfoBean {
            private String pre_url;
            private String next_url;

            public String getPre_url() {
                return pre_url;
            }

            public void setPre_url(String pre_url) {
                this.pre_url = pre_url;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }
        }

        public static class PostsBean {
            private String pk;
            private String discussion_id;
            /**
             * name : 文艺Z娘
             * uid : 10047301
             * user_flag : [{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user.png"}]
             * icon : http://ucres.myzaker.com/img_upload/user_avatar/2015/5024/10047301_1436323441.jpg.210.jpg
             */

            private AutherBean auther;
            private String title;
            private String date;
            private String content;
            private String comment_count;
            private String hot_num;
            private String like_num;
            private String list_date;
            private String weburl;
            private String content_url;
            private String comment_list_url;
            private String is_top;
            /**
             * item_type : 1
             * medias_count : 1
             */

            private SpecialInfoBean special_info;
            private String is_liked;
            /**
             * name : 置顶
             * icon : http://zkres.myzaker.com/data/image/mark2/stick3_2x.png
             */

            private List<PostTagBean> post_tag;
            private List<String> list_tip;
            /**
             * type : image
             * id : 57c7e1909490cb7b2c00006e
             * w : 921
             * h : 494
             * url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h800.jpg
             * m_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h400.jpg
             * s_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h200.jpg
             * min_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h120.jpg
             * raw_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg
             */

            private List<ThumbnailMediasBean> thumbnail_medias;
            /**
             * type : image
             * id : 57c7e1909490cb7b2c00006e
             * w : 921
             * h : 494
             * url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h800.jpg
             * m_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h400.jpg
             * s_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h200.jpg
             * min_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg.h120.jpg
             * raw_url : http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c7e1909490cb7b2c00006e.jpg
             */

            private List<MediasBean> medias;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getDiscussion_id() {
                return discussion_id;
            }

            public void setDiscussion_id(String discussion_id) {
                this.discussion_id = discussion_id;
            }

            public AutherBean getAuther() {
                return auther;
            }

            public void setAuther(AutherBean auther) {
                this.auther = auther;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getComment_count() {
                return comment_count;
            }

            public void setComment_count(String comment_count) {
                this.comment_count = comment_count;
            }

            public String getHot_num() {
                return hot_num;
            }

            public void setHot_num(String hot_num) {
                this.hot_num = hot_num;
            }

            public String getLike_num() {
                return like_num;
            }

            public void setLike_num(String like_num) {
                this.like_num = like_num;
            }

            public String getList_date() {
                return list_date;
            }

            public void setList_date(String list_date) {
                this.list_date = list_date;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getContent_url() {
                return content_url;
            }

            public void setContent_url(String content_url) {
                this.content_url = content_url;
            }

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getIs_top() {
                return is_top;
            }

            public void setIs_top(String is_top) {
                this.is_top = is_top;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getIs_liked() {
                return is_liked;
            }

            public void setIs_liked(String is_liked) {
                this.is_liked = is_liked;
            }

            public List<PostTagBean> getPost_tag() {
                return post_tag;
            }

            public void setPost_tag(List<PostTagBean> post_tag) {
                this.post_tag = post_tag;
            }

            public List<String> getList_tip() {
                return list_tip;
            }

            public void setList_tip(List<String> list_tip) {
                this.list_tip = list_tip;
            }

            public List<ThumbnailMediasBean> getThumbnail_medias() {
                return thumbnail_medias;
            }

            public void setThumbnail_medias(List<ThumbnailMediasBean> thumbnail_medias) {
                this.thumbnail_medias = thumbnail_medias;
            }

            public List<MediasBean> getMedias() {
                return medias;
            }

            public void setMedias(List<MediasBean> medias) {
                this.medias = medias;
            }

            public static class AutherBean {
                private String name;
                private String uid;
                private String icon;
                /**
                 * pic : http://zkres.myzaker.com/data/image/discussion/img/ic_official_user.png
                 */

                private List<UserFlagBean> user_flag;

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public String getUid() {
                    return uid;
                }

                public void setUid(String uid) {
                    this.uid = uid;
                }

                public String getIcon() {
                    return icon;
                }

                public void setIcon(String icon) {
                    this.icon = icon;
                }

                public List<UserFlagBean> getUser_flag() {
                    return user_flag;
                }

                public void setUser_flag(List<UserFlagBean> user_flag) {
                    this.user_flag = user_flag;
                }

                public static class UserFlagBean {
                    private String pic;

                    public String getPic() {
                        return pic;
                    }

                    public void setPic(String pic) {
                        this.pic = pic;
                    }
                }
            }

            public static class SpecialInfoBean {
                private String item_type;
                private String medias_count;

                public String getItem_type() {
                    return item_type;
                }

                public void setItem_type(String item_type) {
                    this.item_type = item_type;
                }

                public String getMedias_count() {
                    return medias_count;
                }

                public void setMedias_count(String medias_count) {
                    this.medias_count = medias_count;
                }
            }

            public static class PostTagBean {
                private String name;
                private String icon;

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public String getIcon() {
                    return icon;
                }

                public void setIcon(String icon) {
                    this.icon = icon;
                }
            }

            public static class ThumbnailMediasBean {
                private String type;
                private String id;
                private String w;
                private String h;
                private String url;
                private String m_url;
                private String s_url;
                private String min_url;
                private String raw_url;

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public String getId() {
                    return id;
                }

                public void setId(String id) {
                    this.id = id;
                }

                public String getW() {
                    return w;
                }

                public void setW(String w) {
                    this.w = w;
                }

                public String getH() {
                    return h;
                }

                public void setH(String h) {
                    this.h = h;
                }

                public String getUrl() {
                    return url;
                }

                public void setUrl(String url) {
                    this.url = url;
                }

                public String getM_url() {
                    return m_url;
                }

                public void setM_url(String m_url) {
                    this.m_url = m_url;
                }

                public String getS_url() {
                    return s_url;
                }

                public void setS_url(String s_url) {
                    this.s_url = s_url;
                }

                public String getMin_url() {
                    return min_url;
                }

                public void setMin_url(String min_url) {
                    this.min_url = min_url;
                }

                public String getRaw_url() {
                    return raw_url;
                }

                public void setRaw_url(String raw_url) {
                    this.raw_url = raw_url;
                }
            }

            public static class MediasBean {
                private String type;
                private String id;
                private String w;
                private String h;
                private String url;
                private String m_url;
                private String s_url;
                private String min_url;
                private String raw_url;

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public String getId() {
                    return id;
                }

                public void setId(String id) {
                    this.id = id;
                }

                public String getW() {
                    return w;
                }

                public void setW(String w) {
                    this.w = w;
                }

                public String getH() {
                    return h;
                }

                public void setH(String h) {
                    this.h = h;
                }

                public String getUrl() {
                    return url;
                }

                public void setUrl(String url) {
                    this.url = url;
                }

                public String getM_url() {
                    return m_url;
                }

                public void setM_url(String m_url) {
                    this.m_url = m_url;
                }

                public String getS_url() {
                    return s_url;
                }

                public void setS_url(String s_url) {
                    this.s_url = s_url;
                }

                public String getMin_url() {
                    return min_url;
                }

                public void setMin_url(String min_url) {
                    this.min_url = min_url;
                }

                public String getRaw_url() {
                    return raw_url;
                }

                public void setRaw_url(String raw_url) {
                    this.raw_url = raw_url;
                }
            }
        }
    }
}
