package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/3.
 */
public class Bean_news {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=660&since_date=1472797145&nt=1&next_aticle_id=57ca32ac9490cbca3e00001b&_appid=androidphone&opage=2&otimestamp=132","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=660&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=660&ids=5642f2aa9490cbb13200000e,5472a9b69490cb48180000f9,51a70fbe81853d904c00015e&k=201609031050"},"catalog":"","articles":[{"pk":"57ca2eed9490cbe53e000024","title":"杭州时间开启，习近平见了哪些新老朋友？","date":"2016-09-03 10:01:04","no_comment":"Y","auther_name":"新华网","page":"1","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57ca2eed9490cbe53e000024","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca2ef8a07aecc5230069f8_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca2ef8a07aecc5230069f8_320.jpg","thumbnail_picsize":"600,477","media_count":"10","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57beda289490cbe65500007b","block_title":"G20杭州峰会","title":"G20杭州峰会","block_in_title":"杭州时间开启，习近平见了哪些新老朋友？","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=660&topic_id=57beda289490cbe65500007b&updated=1472868146"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca2eed9490cbe53e000024&m=1472871304&no_comment=Y","list_dtime":"2016-09-03 10:01:04"},{"pk":"57ca31f19490cb1b3f00001c","title":"起跑线争夺战，排队的中国家长","date":"2016-09-03 10:14:02","auther_name":"网易综合","page":"2","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57ca31f19490cb1b3f00001c","media_count":"0","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c94ccd9490cb3d18000083","block_title":"ZAKER新闻周刊第六十四期","title":"ZAKER新闻周刊第六十四期","block_in_title":"起跑线争夺战，排队的中国家长","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=660&topic_id=57c94ccd9490cb3d18000083&updated=1472868870"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca31f19490cb1b3f00001c&m=1472871304","list_dtime":"2016-09-03 10:14:02"},{"pk":"57ca15ce9490cb133f000038","title":"太原复建明初古城初具规模 三城墙完工","title_line_break":"太原复建明初古城初具规模\n三城墙完工","date":"2016-09-03 08:15:53","auther_name":"中新网","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ca15ce9490cb133f000038","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9bc711bc8e0320b000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9bc711bc8e0320b000003_320.jpg","thumbnail_picsize":"600,418","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca15ce9490cb133f000038&m=1472871304","list_dtime":"2016-09-03 08:15:53"},{"pk":"57ca14599490cbff3e000013","title":"多地发养老金调整方案 部分涨幅超6.5%","title_line_break":"多地发养老金调整方案\n部分涨幅超6.5%","date":"2016-09-03 08:25:18","auther_name":"中新网","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57ca14599490cbff3e000013","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9fabb1bc8e04927000013_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9fabb1bc8e04927000013_320.jpg","thumbnail_picsize":"500,336","media_count":"3","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c888c1a07aec1258000000","block_title":"20160903早报","title":"20160903早报","block_in_title":"多个地方发布养老金调整方案 ","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=660&topic_id=57c888c1a07aec1258000000&updated=1472863459"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/daily_morning_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca14599490cbff3e000013&m=1472871304","list_dtime":"2016-09-03 08:25:18"},{"pk":"57ca1b0e9490cbf73e000020","title":"女子不雅视频被传上网自杀 涉事警察被拘","title_line_break":"女子不雅视频被传上网自杀\n涉事警察被拘","date":"2016-09-03 08:35:53","auther_name":"中新网","page":"2","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=57ca1b0e9490cbf73e000020","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca1b3277a32431350004aa_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1b3277a32431350004aa_320.jpg","thumbnail_picsize":"495,752","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca1b0e9490cbf73e000020&m=1472871435","list_dtime":"2016-09-03 08:35:53"},{"pk":"57ca329a9490cbdf3e000022","title":"中国掀\u201c厕所革命\u201d 公厕内可取钱看电视","title_line_break":"中国掀\u201c厕所革命\u201d\n公厕内可取钱看电视","date":"2016-09-03 10:20:27","auther_name":"中新网移动版","weburl":"http://iphone.myzaker.com/l.php?l=57ca329a9490cbdf3e000022","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=660&pk=57ca329a9490cbdf3e000022&url=http%3A%2F%2Fku.m.chinanews.com%2Fwapapp%2Fzaker%2Fgj%2F2016%2F09-03%2F7992914.shtml","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca329a9490cbdf3e000022&m=1472871304","list_dtime":"2016-09-03 10:20:27"},{"pk":"57ca32e19490cbc43e00003d","title":"北京五年内将建三环半 ","title_line_break":"北京五年内将建三环半\n","date":"2016-09-03 10:18:09","auther_name":"北京晨报","weburl":"http://iphone.myzaker.com/l.php?l=57ca32e19490cbc43e00003d","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca32e19490cbc43e00003d&m=1472871304","list_dtime":"2016-09-03 10:18:09"},{"pk":"57ca2ce79490cb213f00002c","title":"李小鹏任交通运输部部长","date":"2016-09-03 09:52:24","auther_name":"新华社","weburl":"http://iphone.myzaker.com/l.php?l=57ca2ce79490cb213f00002c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca3aefa07aecc523007245_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca3aefa07aecc523007245_320.jpg","thumbnail_picsize":"300,218","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca2ce79490cb213f00002c&m=1472871304","list_dtime":"2016-09-03 09:52:24"},{"pk":"57ca1c169490cbe33e000033","title":"长春一军校最牛开学典礼堪比阅兵 ","title_line_break":"长春一军校最牛开学典礼堪比阅兵\n","date":"2016-09-03 08:39:53","auther_name":"腾讯图片","weburl":"http://iphone.myzaker.com/l.php?l=57ca1c169490cbe33e000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca1c1ba07aecc52300616a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1c1ba07aecc52300616a_320.jpg","thumbnail_picsize":"980,653","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca1c169490cbe33e000033&m=1472871101","list_dtime":"2016-09-03 08:39:53"},{"pk":"57ca149f9490cb003f00002e","title":"马云终于报\u201c仇\u201d：真的把肯德基给买了","title_line_break":"马云终于报\u201c仇\u201d：\n真的把肯德基给买了","date":"2016-09-03 08:21:48","auther_name":"中青网","weburl":"http://iphone.myzaker.com/l.php?l=57ca149f9490cb003f00002e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca0ca91bc8e0da2b00004a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca0ca91bc8e0da2b00004a_320.jpg","thumbnail_picsize":"604,497","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca149f9490cb003f00002e&m=1472871101","list_dtime":"2016-09-03 08:21:48"},{"pk":"57ca1a3a9490cbd02c000000","title":"任内最后一次访华！奥巴马搭专机来杭州","date":"2016-09-03 08:36:52","auther_name":"中青网","weburl":"http://iphone.myzaker.com/l.php?l=57ca1a3a9490cbd02c000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca11d51bc8e02732000006_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca11d51bc8e02732000006_320.jpg","thumbnail_picsize":"747,598","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca1a3a9490cbd02c000000&m=1472871101","list_dtime":"2016-09-03 08:36:52"},{"pk":"57ca10d59490cbee3e000012","title":"乌兹别克斯坦总统卡里莫夫病逝 ","title_line_break":"乌兹别克斯坦总统卡里莫夫病逝\n","date":"2016-09-03 07:52:05","auther_name":"人民网","weburl":"http://iphone.myzaker.com/l.php?l=57ca10d59490cbee3e000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca10de9490cb193f000025_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca10de9490cb193f000025_320.jpg","thumbnail_picsize":"454,515","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca10d59490cbee3e000012&m=1472871101","list_dtime":"2016-09-03 07:52:05"},{"pk":"57ca145e9490cbe73e00002d","title":"菲总统希望年内访华 外交部回应","title_line_break":"菲总统希望年内访华\n外交部回应","date":"2016-09-03 08:23:33","auther_name":"央广网","weburl":"http://iphone.myzaker.com/l.php?l=57ca145e9490cbe73e00002d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9f7fc1bc8e0cd2500003b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9f7fc1bc8e0cd2500003b_320.jpg","thumbnail_picsize":"500,323","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca145e9490cbe73e00002d&m=1472871101","list_dtime":"2016-09-03 08:23:33"},{"pk":"57ca20109490cb213f000029","title":"停在杭州机场的各国领导人专机型号曝光","date":"2016-09-03 09:01:23","auther_name":"央视新闻","weburl":"http://iphone.myzaker.com/l.php?l=57ca20109490cb213f000029","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca1f3d1bc8e0483a00001f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1f3d1bc8e0483a00001f_320.jpg","thumbnail_picsize":"620,349","media_count":"23","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca20109490cb213f000029&m=1472871101","list_dtime":"2016-09-03 09:01:23"},{"pk":"57ca148c9490cbfc3e000014","title":"四川一高校美女云集 迎\u201c高颜值\u201d开学季","title_line_break":"四川一高校美女云集\n迎\u201c高颜值\u201d开学季","date":"2016-09-03 08:08:44","auther_name":"中新网","weburl":"http://iphone.myzaker.com/l.php?l=57ca148c9490cbfc3e000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca0ca81bc8e0da2b000040_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca0ca81bc8e0da2b000040_320.jpg","thumbnail_picsize":"930,620","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca148c9490cbfc3e000014&m=1472871101","list_dtime":"2016-09-03 08:08:44"},{"pk":"57ca14259490cbc43e000023","title":"郎平受访：不介意曾被叫\u201c叛将\u201d","title_line_break":"郎平受访：\n不介意曾被叫\u201c叛将\u201d","date":"2016-09-03 08:27:13","auther_name":"参考消息网","weburl":"http://iphone.myzaker.com/l.php?l=57ca14259490cbc43e000023","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9fab71bc8e0492700000c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9fab71bc8e0492700000c_320.jpg","thumbnail_picsize":"600,901","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca14259490cbc43e000023&m=1472871101","list_dtime":"2016-09-03 08:27:13"},{"pk":"57ca2a799490cbc53e000037","title":"加拿大\u201c最帅总理\u201d上海发布会上打太极","date":"2016-09-03 09:41:02","auther_name":"网易综合","weburl":"http://iphone.myzaker.com/l.php?l=57ca2a799490cbc53e000037","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca2a7c77a3247d350005c1_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca2a7c77a3247d350005c1_320.jpg","thumbnail_picsize":"1440,960","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca2a799490cbc53e000037&m=1472871101","list_dtime":"2016-09-03 09:41:02"},{"pk":"57ca1a699490cb263f00000f","title":"成龙回应得奥斯卡：希望不是最后一座小金人","title_line_break":"成龙回应得奥斯卡：\n希望不是最后一座小金人","date":"2016-09-03 08:35:51","auther_name":"新华炫闻","weburl":"http://iphone.myzaker.com/l.php?l=57ca1a699490cb263f00000f","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca13d61bc8e05b33000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca13d61bc8e05b33000000_320.jpg","thumbnail_picsize":"581,459","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca1a699490cb263f00000f&m=1472871101","list_dtime":"2016-09-03 08:35:51"},{"pk":"57c8e9ca1bc8e0763000002d","title":"女司机倒车倒进河 邻居保安跳水营救","title_line_break":"女司机倒车倒进河\n邻居保安跳水营救","date":"2016-09-03 08:20:30","auther_name":"现代快报全媒体","weburl":"http://iphone.myzaker.com/l.php?l=57c8e9ca1bc8e0763000002d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvY21zL2FydGljbGVfaW1nLzEwMTY5L3VwXzEwMTY5XzE0NzI3Nzc2NzQ5MDgyLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvY21zL2FydGljbGVfaW1nLzEwMTY5L3VwXzEwMTY5XzE0NzI3Nzc2NzQ5MDgyLmpwZw==_1242.jpg","thumbnail_picsize":"726,440","media_count":"1","is_full":"NO","content":"","type":"other","special_info":{"open_type":"article_video","video_label":"00:54","video_size":"272,272","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57c8e9ca1bc8e0763000002d&m=1472871101","list_dtime":"2016-09-03 08:20:30"},{"pk":"57ca150d9490cb253f00002d","title":"公务员夫妻被拍殴打母亲 纪委介入调查","title_line_break":"公务员夫妻被拍殴打母亲\n纪委介入调查","date":"2016-09-03 08:10:53","auther_name":"京华时报","weburl":"http://iphone.myzaker.com/l.php?l=57ca150d9490cb253f00002d","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca150d9490cb253f00002d&m=1472871101","list_dtime":"2016-09-03 08:10:53"},{"pk":"57ca27ab9490cb253f00002e","title":"铁路又要大调图 你常坐车次有啥变化？","title_line_break":"铁路又要大调图\n你常坐车次有啥变化？","date":"2016-09-03 09:37:53","auther_name":"新华炫闻","weburl":"http://iphone.myzaker.com/l.php?l=57ca27ab9490cb253f00002e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca21121bc8e00d3c00001a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca21121bc8e00d3c00001a_320.jpg","thumbnail_picsize":"493,303","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca27ab9490cb253f00002e&m=1472871101","list_dtime":"2016-09-03 09:37:53"},{"pk":"57ca14359490cb223f00001b","title":"傅园慧身价暴涨20倍 体育IP潜力大","title_line_break":"傅园慧身价暴涨20倍\n体育IP潜力大","date":"2016-09-03 08:26:16","auther_name":"央广网","weburl":"http://iphone.myzaker.com/l.php?l=57ca14359490cb223f00001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9fab81bc8e0492700000f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9fab81bc8e0492700000f_320.jpg","thumbnail_picsize":"834,525","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca14359490cb223f00001b&m=1472871101","list_dtime":"2016-09-03 08:26:16"},{"pk":"57ca15429490cb213f000028","title":"内衣贼频光顾大学 校方人员:难避免","title_line_break":"内衣贼频光顾大学 校方人员:\n难避免","date":"2016-09-03 08:18:14","auther_name":"北京晨报","weburl":"http://iphone.myzaker.com/l.php?l=57ca15429490cb213f000028","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca15429490cb213f000028&m=1472871101","list_dtime":"2016-09-03 08:18:14"},{"pk":"57ca393f9490cbee3e000021","title":"中国最大电动车企业合伙人因敲诈案翻脸","date":"2016-09-03 10:47:43","auther_name":"观察者网","weburl":"http://iphone.myzaker.com/l.php?l=57ca393f9490cbee3e000021","media_count":"1","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=660&pk=57ca393f9490cbee3e000021&url=http%3A%2F%2Fnewrss.guancha.cn%2Fzaker%2Fpost%2Feconomy%2F2016_09_03_373306.shtml","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca393f9490cbee3e000021&m=1472871100","list_dtime":"2016-09-03 10:47:43"},{"pk":"57ca392b9490cb473f000038","title":"终于找到\u201c被乒乓耽误的诗人\u201d的铁证！","date":"2016-09-03 10:44:59","auther_name":"观察者网","weburl":"http://iphone.myzaker.com/l.php?l=57ca392b9490cb473f000038","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca2e731bc8e0174500000c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca2e731bc8e0174500000c_320.jpg","thumbnail_picsize":"400,267","media_count":"12","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=660&pk=57ca392b9490cb473f000038&url=http%3A%2F%2Fnewrss.guancha.cn%2Fzaker%2Fpost%2Fsports%2F2016_09_03_373303.shtml","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca392b9490cb473f000038&m=1472871100","list_dtime":"2016-09-03 10:44:59"},{"pk":"57ca38f99490cb1b3f00001d","title":"这些一把手为何才上任又离任","date":"2016-09-03 10:44:09","auther_name":"凤凰新闻","weburl":"http://iphone.myzaker.com/l.php?l=57ca38f99490cb1b3f00001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca2cff1bc8e0b942000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca2cff1bc8e0b942000003_320.jpg","thumbnail_picsize":"464,300","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca38f99490cb1b3f00001d&m=1472871100","list_dtime":"2016-09-03 10:44:09"},{"pk":"57ca38bb9490cb0f3f000016","title":"考生通知书被作废 教育部介入调查","title_line_break":"考生通知书被作废\n教育部介入调查","date":"2016-09-03 10:43:07","auther_name":"央广网","weburl":"http://iphone.myzaker.com/l.php?l=57ca38bb9490cb0f3f000016","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=660&pk=57ca38bb9490cb0f3f000016&url=http%3A%2F%2Fku.m.chinanews.com%2Fwapapp%2Fzaker%2Fsh%2F2016%2F09-03%2F7992930.shtml","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca38bb9490cb0f3f000016&m=1472871100","list_dtime":"2016-09-03 10:43:07"},{"pk":"57ca367a1bc8e0727b000015","title":"河南现\u201c纸片楼\u201d 市民：给钱都不住","title_line_break":"河南现\u201c纸片楼\u201d 市民：\n给钱都不住","date":"2016-09-03 10:42:20","auther_name":"腾讯网","weburl":"http://iphone.myzaker.com/l.php?l=57ca367a1bc8e0727b000015","thumbnail_pic":"http://zkres.myzaker.com/img_upload/cms/ck/img/10140/2016/09/03/1472869868.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca35f3a07aecc523006fef_320.jpg","thumbnail_picsize":"500,333","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca367a1bc8e0727b000015&m=1472871100","list_dtime":"2016-09-03 10:42:20"},{"pk":"57ca17991bc8e0877b00000a","title":"终身成就奖为何授予成龙","date":"2016-09-03 08:21:45","auther_name":"深圳晚报","weburl":"http://iphone.myzaker.com/l.php?l=57ca17991bc8e0877b00000a","thumbnail_pic":"http://zkres.myzaker.com/img_upload/cms/ck/img/10055/2016/09/03/1472861809.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1693a07aecc523005f2b_320.jpg","thumbnail_picsize":"425,240","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca17991bc8e0877b00000a&m=1472871101","list_dtime":"2016-09-03 08:21:45"},{"pk":"57ca1a279490cb4c3f000011","title":"郑州女孩病房窗台上\u201c写字救母\u201d","date":"2016-09-03 08:35:33","auther_name":"新华网","weburl":"http://iphone.myzaker.com/l.php?l=57ca1a279490cb4c3f000011","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca11d51bc8e02732000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca11d51bc8e02732000000_320.jpg","thumbnail_picsize":"899,599","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca1a279490cb4c3f000011&m=1472871101","list_dtime":"2016-09-03 08:35:33"},{"pk":"57ca205a9490cb1c3f00001c","title":"新西兰公司售罐装空气 市场定位为中国","title_line_break":"新西兰公司售罐装空气\n市场定位为中国","date":"2016-09-03 09:02:33","auther_name":"环球网","weburl":"http://iphone.myzaker.com/l.php?l=57ca205a9490cb1c3f00001c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca1aec1bc8e0c234000113_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1aec1bc8e0c234000113_320.jpg","thumbnail_picsize":"620,349","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca205a9490cb1c3f00001c&m=1472871101","list_dtime":"2016-09-03 09:02:33"},{"pk":"57ca36201bc8e0807b000023","title":"31岁业余摄影师拍摄蜘蛛捕鱼过程","date":"2016-09-03 10:32:00","auther_name":"中青在线","weburl":"http://iphone.myzaker.com/l.php?l=57ca36201bc8e0807b000023","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca35eea07aecc523006fe7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca35eea07aecc523006fe7_320.jpg","thumbnail_picsize":"944,589","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca36201bc8e0807b000023&m=1472871100","list_dtime":"2016-09-03 10:32:00"},{"pk":"57ca22ec1bc8e0757b000011","title":"\u201c民警\u201d求同行行方便 一查男子是\u201c三逃\u201d    ","title_line_break":"\u201c民警\u201d求同行行方便\n一查男子是\u201c三逃\u201d    ","date":"2016-09-03 09:40:07","auther_name":"现代快报全媒体","weburl":"http://iphone.myzaker.com/l.php?l=57ca22ec1bc8e0757b000011","thumbnail_pic":"http://zkres.myzaker.com/img_upload/cms/ck/img/10169/2016/09/03/1472864960.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca22e3a07aecc52300633a_320.jpg","thumbnail_picsize":"600,450","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca22ec1bc8e0757b000011&m=1472871101","list_dtime":"2016-09-03 09:40:07"},{"pk":"57ca32389490cb093f00004b","title":"上海财大一教授被解聘 称举报院长遭报复","title_line_break":"上海财大一教授被解聘\n称举报院长遭报复","date":"2016-09-03 10:22:06","auther_name":"央广网","weburl":"http://iphone.myzaker.com/l.php?l=57ca32389490cb093f00004b","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca32389490cb093f00004b&m=1472871100","list_dtime":"2016-09-03 10:22:06"},{"pk":"57ca20219490cb4d3f000017","title":"网络电台女主播宣传禁毒私下贩毒","date":"2016-09-03 09:03:59","auther_name":"京华时报","weburl":"http://iphone.myzaker.com/l.php?l=57ca20219490cb4d3f000017","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca1ada1bc8e0c2340000b5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1ada1bc8e0c2340000b5_320.jpg","thumbnail_picsize":"450,321","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca20219490cb4d3f000017&m=1472871101","list_dtime":"2016-09-03 09:03:59"},{"pk":"57ca32679490cbe03e000036","title":"揭秘\u201c闻臭师\u201d：鼻子不能太灵","title_line_break":"揭秘\u201c闻臭师\u201d：\n鼻子不能太灵","date":"2016-09-03 10:21:34","auther_name":"齐鲁晚报","weburl":"http://iphone.myzaker.com/l.php?l=57ca32679490cbe03e000036","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca2c871bc8e05e4100001e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca2c871bc8e05e4100001e_320.jpg","thumbnail_picsize":"600,449","media_count":"1","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=660&pk=57ca32679490cbe03e000036&url=http%3A%2F%2Fku.m.chinanews.com%2Fwapapp%2Fzaker%2Fsh%2F2016%2F09-03%2F7992933.shtml","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca32679490cbe03e000036&m=1472871101","list_dtime":"2016-09-03 10:21:34"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57ca15ce9490cb133f000038,57ca2eed9490cbe53e000024,57ca329a9490cbdf3e000022,57ca32e19490cbc43e00003d,57ca2ce79490cb213f00002c,57ca14599490cbff3e000013","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57ca149f9490cb003f00002e,57ca1c169490cbe33e000033,57ca1a3a9490cbd02c000000,57ca10d59490cbee3e000012,57ca1b0e9490cbf73e000020,57ca31f19490cb1b3f00001c","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57ca20109490cb213f000029,57ca145e9490cbe73e00002d,57ca148c9490cbfc3e000014,57ca14259490cbc43e000023,57ca2a799490cbc53e000037,57ca1a699490cb263f00000f","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca27ab9490cb253f00002e,57ca150d9490cb253f00002d,57c8e9ca1bc8e0763000002d,57ca14359490cb223f00001b,57ca15429490cb213f000028,57ca393f9490cbee3e000021","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca38f99490cb1b3f00001d,57ca392b9490cb473f000038,57ca38bb9490cb0f3f000016,57ca367a1bc8e0727b000015,57ca17991bc8e0877b00000a,57ca1a279490cb4c3f000011","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ca36201bc8e0807b000023,57ca205a9490cb1c3f00001c,57ca22ec1bc8e0757b000011,57ca32389490cb093f00004b,57ca20219490cb4d3f000017,57ca32679490cbe03e000036","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#4cace7","#4cace7"],"only_text_page_bgcolors":["#4cace7","#4cace7"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/660.png?t=1458290767","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/660.png?t=1458290767","hidden_time":"24","need_userinfo":"NO","block_title":"头条新闻","block_color":"#4cace7","desktop_color_number":"16","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_8f47af21c26120de753ce7ff2a934b65","selected_index":"0","list":[{"pk":"zk_app_column_660","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"660","title":"新闻头条","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=660&catalog_appid=660","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_1","title":"国内","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1_zk_app_column_block_660","title":"国内新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1&catalog_appid=660","data_type":"news"}},{"pk":"zk_app_column_2","title":"国际","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"2_zk_app_column_block_660","title":"国际新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=2&catalog_appid=660","data_type":"news"}},{"pk":"zk_app_column_14","title":"社会","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"14_zk_app_column_block_660","title":"社会万象","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=14&catalog_appid=660","data_type":"news"}}]}}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=660&since_date=1472797145&nt=1&next_aticle_id=57ca32ac9490cbca3e00001b&_appid=androidphone&opage=2&otimestamp=132","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=660&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=660&ids=5642f2aa9490cbb13200000e,5472a9b69490cb48180000f9,51a70fbe81853d904c00015e&k=201609031050"}
     * catalog :
     * articles : [{"pk":"57ca2eed9490cbe53e000024","title":"杭州时间开启，习近平见了哪些新老朋友？","date":"2016-09-03 10:01:04","no_comment":"Y","auther_name":"新华网","page":"1","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57ca2eed9490cbe53e000024","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca2ef8a07aecc5230069f8_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca2ef8a07aecc5230069f8_320.jpg","thumbnail_picsize":"600,477","media_count":"10","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57beda289490cbe65500007b","block_title":"G20杭州峰会","title":"G20杭州峰会","block_in_title":"杭州时间开启，习近平见了哪些新老朋友？","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=660&topic_id=57beda289490cbe65500007b&updated=1472868146"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca2eed9490cbe53e000024&m=1472871304&no_comment=Y","list_dtime":"2016-09-03 10:01:04"},{"pk":"57ca31f19490cb1b3f00001c","title":"起跑线争夺战，排队的中国家长","date":"2016-09-03 10:14:02","auther_name":"网易综合","page":"2","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57ca31f19490cb1b3f00001c","media_count":"0","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c94ccd9490cb3d18000083","block_title":"ZAKER新闻周刊第六十四期","title":"ZAKER新闻周刊第六十四期","block_in_title":"起跑线争夺战，排队的中国家长","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=660&topic_id=57c94ccd9490cb3d18000083&updated=1472868870"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca31f19490cb1b3f00001c&m=1472871304","list_dtime":"2016-09-03 10:14:02"},{"pk":"57ca15ce9490cb133f000038","title":"太原复建明初古城初具规模 三城墙完工","title_line_break":"太原复建明初古城初具规模\n三城墙完工","date":"2016-09-03 08:15:53","auther_name":"中新网","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ca15ce9490cb133f000038","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9bc711bc8e0320b000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9bc711bc8e0320b000003_320.jpg","thumbnail_picsize":"600,418","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca15ce9490cb133f000038&m=1472871304","list_dtime":"2016-09-03 08:15:53"},{"pk":"57ca14599490cbff3e000013","title":"多地发养老金调整方案 部分涨幅超6.5%","title_line_break":"多地发养老金调整方案\n部分涨幅超6.5%","date":"2016-09-03 08:25:18","auther_name":"中新网","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57ca14599490cbff3e000013","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9fabb1bc8e04927000013_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9fabb1bc8e04927000013_320.jpg","thumbnail_picsize":"500,336","media_count":"3","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c888c1a07aec1258000000","block_title":"20160903早报","title":"20160903早报","block_in_title":"多个地方发布养老金调整方案 ","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=660&topic_id=57c888c1a07aec1258000000&updated=1472863459"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/daily_morning_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca14599490cbff3e000013&m=1472871304","list_dtime":"2016-09-03 08:25:18"},{"pk":"57ca1b0e9490cbf73e000020","title":"女子不雅视频被传上网自杀 涉事警察被拘","title_line_break":"女子不雅视频被传上网自杀\n涉事警察被拘","date":"2016-09-03 08:35:53","auther_name":"中新网","page":"2","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=57ca1b0e9490cbf73e000020","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca1b3277a32431350004aa_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1b3277a32431350004aa_320.jpg","thumbnail_picsize":"495,752","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca1b0e9490cbf73e000020&m=1472871435","list_dtime":"2016-09-03 08:35:53"},{"pk":"57ca329a9490cbdf3e000022","title":"中国掀\u201c厕所革命\u201d 公厕内可取钱看电视","title_line_break":"中国掀\u201c厕所革命\u201d\n公厕内可取钱看电视","date":"2016-09-03 10:20:27","auther_name":"中新网移动版","weburl":"http://iphone.myzaker.com/l.php?l=57ca329a9490cbdf3e000022","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=660&pk=57ca329a9490cbdf3e000022&url=http%3A%2F%2Fku.m.chinanews.com%2Fwapapp%2Fzaker%2Fgj%2F2016%2F09-03%2F7992914.shtml","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca329a9490cbdf3e000022&m=1472871304","list_dtime":"2016-09-03 10:20:27"},{"pk":"57ca32e19490cbc43e00003d","title":"北京五年内将建三环半 ","title_line_break":"北京五年内将建三环半\n","date":"2016-09-03 10:18:09","auther_name":"北京晨报","weburl":"http://iphone.myzaker.com/l.php?l=57ca32e19490cbc43e00003d","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca32e19490cbc43e00003d&m=1472871304","list_dtime":"2016-09-03 10:18:09"},{"pk":"57ca2ce79490cb213f00002c","title":"李小鹏任交通运输部部长","date":"2016-09-03 09:52:24","auther_name":"新华社","weburl":"http://iphone.myzaker.com/l.php?l=57ca2ce79490cb213f00002c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca3aefa07aecc523007245_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca3aefa07aecc523007245_320.jpg","thumbnail_picsize":"300,218","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca2ce79490cb213f00002c&m=1472871304","list_dtime":"2016-09-03 09:52:24"},{"pk":"57ca1c169490cbe33e000033","title":"长春一军校最牛开学典礼堪比阅兵 ","title_line_break":"长春一军校最牛开学典礼堪比阅兵\n","date":"2016-09-03 08:39:53","auther_name":"腾讯图片","weburl":"http://iphone.myzaker.com/l.php?l=57ca1c169490cbe33e000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca1c1ba07aecc52300616a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1c1ba07aecc52300616a_320.jpg","thumbnail_picsize":"980,653","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca1c169490cbe33e000033&m=1472871101","list_dtime":"2016-09-03 08:39:53"},{"pk":"57ca149f9490cb003f00002e","title":"马云终于报\u201c仇\u201d：真的把肯德基给买了","title_line_break":"马云终于报\u201c仇\u201d：\n真的把肯德基给买了","date":"2016-09-03 08:21:48","auther_name":"中青网","weburl":"http://iphone.myzaker.com/l.php?l=57ca149f9490cb003f00002e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca0ca91bc8e0da2b00004a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca0ca91bc8e0da2b00004a_320.jpg","thumbnail_picsize":"604,497","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca149f9490cb003f00002e&m=1472871101","list_dtime":"2016-09-03 08:21:48"},{"pk":"57ca1a3a9490cbd02c000000","title":"任内最后一次访华！奥巴马搭专机来杭州","date":"2016-09-03 08:36:52","auther_name":"中青网","weburl":"http://iphone.myzaker.com/l.php?l=57ca1a3a9490cbd02c000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca11d51bc8e02732000006_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca11d51bc8e02732000006_320.jpg","thumbnail_picsize":"747,598","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca1a3a9490cbd02c000000&m=1472871101","list_dtime":"2016-09-03 08:36:52"},{"pk":"57ca10d59490cbee3e000012","title":"乌兹别克斯坦总统卡里莫夫病逝 ","title_line_break":"乌兹别克斯坦总统卡里莫夫病逝\n","date":"2016-09-03 07:52:05","auther_name":"人民网","weburl":"http://iphone.myzaker.com/l.php?l=57ca10d59490cbee3e000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca10de9490cb193f000025_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca10de9490cb193f000025_320.jpg","thumbnail_picsize":"454,515","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca10d59490cbee3e000012&m=1472871101","list_dtime":"2016-09-03 07:52:05"},{"pk":"57ca145e9490cbe73e00002d","title":"菲总统希望年内访华 外交部回应","title_line_break":"菲总统希望年内访华\n外交部回应","date":"2016-09-03 08:23:33","auther_name":"央广网","weburl":"http://iphone.myzaker.com/l.php?l=57ca145e9490cbe73e00002d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9f7fc1bc8e0cd2500003b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9f7fc1bc8e0cd2500003b_320.jpg","thumbnail_picsize":"500,323","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca145e9490cbe73e00002d&m=1472871101","list_dtime":"2016-09-03 08:23:33"},{"pk":"57ca20109490cb213f000029","title":"停在杭州机场的各国领导人专机型号曝光","date":"2016-09-03 09:01:23","auther_name":"央视新闻","weburl":"http://iphone.myzaker.com/l.php?l=57ca20109490cb213f000029","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca1f3d1bc8e0483a00001f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1f3d1bc8e0483a00001f_320.jpg","thumbnail_picsize":"620,349","media_count":"23","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca20109490cb213f000029&m=1472871101","list_dtime":"2016-09-03 09:01:23"},{"pk":"57ca148c9490cbfc3e000014","title":"四川一高校美女云集 迎\u201c高颜值\u201d开学季","title_line_break":"四川一高校美女云集\n迎\u201c高颜值\u201d开学季","date":"2016-09-03 08:08:44","auther_name":"中新网","weburl":"http://iphone.myzaker.com/l.php?l=57ca148c9490cbfc3e000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca0ca81bc8e0da2b000040_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca0ca81bc8e0da2b000040_320.jpg","thumbnail_picsize":"930,620","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca148c9490cbfc3e000014&m=1472871101","list_dtime":"2016-09-03 08:08:44"},{"pk":"57ca14259490cbc43e000023","title":"郎平受访：不介意曾被叫\u201c叛将\u201d","title_line_break":"郎平受访：\n不介意曾被叫\u201c叛将\u201d","date":"2016-09-03 08:27:13","auther_name":"参考消息网","weburl":"http://iphone.myzaker.com/l.php?l=57ca14259490cbc43e000023","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9fab71bc8e0492700000c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9fab71bc8e0492700000c_320.jpg","thumbnail_picsize":"600,901","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca14259490cbc43e000023&m=1472871101","list_dtime":"2016-09-03 08:27:13"},{"pk":"57ca2a799490cbc53e000037","title":"加拿大\u201c最帅总理\u201d上海发布会上打太极","date":"2016-09-03 09:41:02","auther_name":"网易综合","weburl":"http://iphone.myzaker.com/l.php?l=57ca2a799490cbc53e000037","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca2a7c77a3247d350005c1_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca2a7c77a3247d350005c1_320.jpg","thumbnail_picsize":"1440,960","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca2a799490cbc53e000037&m=1472871101","list_dtime":"2016-09-03 09:41:02"},{"pk":"57ca1a699490cb263f00000f","title":"成龙回应得奥斯卡：希望不是最后一座小金人","title_line_break":"成龙回应得奥斯卡：\n希望不是最后一座小金人","date":"2016-09-03 08:35:51","auther_name":"新华炫闻","weburl":"http://iphone.myzaker.com/l.php?l=57ca1a699490cb263f00000f","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca13d61bc8e05b33000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca13d61bc8e05b33000000_320.jpg","thumbnail_picsize":"581,459","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca1a699490cb263f00000f&m=1472871101","list_dtime":"2016-09-03 08:35:51"},{"pk":"57c8e9ca1bc8e0763000002d","title":"女司机倒车倒进河 邻居保安跳水营救","title_line_break":"女司机倒车倒进河\n邻居保安跳水营救","date":"2016-09-03 08:20:30","auther_name":"现代快报全媒体","weburl":"http://iphone.myzaker.com/l.php?l=57c8e9ca1bc8e0763000002d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvY21zL2FydGljbGVfaW1nLzEwMTY5L3VwXzEwMTY5XzE0NzI3Nzc2NzQ5MDgyLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvY21zL2FydGljbGVfaW1nLzEwMTY5L3VwXzEwMTY5XzE0NzI3Nzc2NzQ5MDgyLmpwZw==_1242.jpg","thumbnail_picsize":"726,440","media_count":"1","is_full":"NO","content":"","type":"other","special_info":{"open_type":"article_video","video_label":"00:54","video_size":"272,272","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57c8e9ca1bc8e0763000002d&m=1472871101","list_dtime":"2016-09-03 08:20:30"},{"pk":"57ca150d9490cb253f00002d","title":"公务员夫妻被拍殴打母亲 纪委介入调查","title_line_break":"公务员夫妻被拍殴打母亲\n纪委介入调查","date":"2016-09-03 08:10:53","auther_name":"京华时报","weburl":"http://iphone.myzaker.com/l.php?l=57ca150d9490cb253f00002d","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca150d9490cb253f00002d&m=1472871101","list_dtime":"2016-09-03 08:10:53"},{"pk":"57ca27ab9490cb253f00002e","title":"铁路又要大调图 你常坐车次有啥变化？","title_line_break":"铁路又要大调图\n你常坐车次有啥变化？","date":"2016-09-03 09:37:53","auther_name":"新华炫闻","weburl":"http://iphone.myzaker.com/l.php?l=57ca27ab9490cb253f00002e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca21121bc8e00d3c00001a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca21121bc8e00d3c00001a_320.jpg","thumbnail_picsize":"493,303","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca27ab9490cb253f00002e&m=1472871101","list_dtime":"2016-09-03 09:37:53"},{"pk":"57ca14359490cb223f00001b","title":"傅园慧身价暴涨20倍 体育IP潜力大","title_line_break":"傅园慧身价暴涨20倍\n体育IP潜力大","date":"2016-09-03 08:26:16","auther_name":"央广网","weburl":"http://iphone.myzaker.com/l.php?l=57ca14359490cb223f00001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9fab81bc8e0492700000f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9fab81bc8e0492700000f_320.jpg","thumbnail_picsize":"834,525","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca14359490cb223f00001b&m=1472871101","list_dtime":"2016-09-03 08:26:16"},{"pk":"57ca15429490cb213f000028","title":"内衣贼频光顾大学 校方人员:难避免","title_line_break":"内衣贼频光顾大学 校方人员:\n难避免","date":"2016-09-03 08:18:14","auther_name":"北京晨报","weburl":"http://iphone.myzaker.com/l.php?l=57ca15429490cb213f000028","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca15429490cb213f000028&m=1472871101","list_dtime":"2016-09-03 08:18:14"},{"pk":"57ca393f9490cbee3e000021","title":"中国最大电动车企业合伙人因敲诈案翻脸","date":"2016-09-03 10:47:43","auther_name":"观察者网","weburl":"http://iphone.myzaker.com/l.php?l=57ca393f9490cbee3e000021","media_count":"1","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=660&pk=57ca393f9490cbee3e000021&url=http%3A%2F%2Fnewrss.guancha.cn%2Fzaker%2Fpost%2Feconomy%2F2016_09_03_373306.shtml","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca393f9490cbee3e000021&m=1472871100","list_dtime":"2016-09-03 10:47:43"},{"pk":"57ca392b9490cb473f000038","title":"终于找到\u201c被乒乓耽误的诗人\u201d的铁证！","date":"2016-09-03 10:44:59","auther_name":"观察者网","weburl":"http://iphone.myzaker.com/l.php?l=57ca392b9490cb473f000038","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca2e731bc8e0174500000c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca2e731bc8e0174500000c_320.jpg","thumbnail_picsize":"400,267","media_count":"12","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=660&pk=57ca392b9490cb473f000038&url=http%3A%2F%2Fnewrss.guancha.cn%2Fzaker%2Fpost%2Fsports%2F2016_09_03_373303.shtml","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca392b9490cb473f000038&m=1472871100","list_dtime":"2016-09-03 10:44:59"},{"pk":"57ca38f99490cb1b3f00001d","title":"这些一把手为何才上任又离任","date":"2016-09-03 10:44:09","auther_name":"凤凰新闻","weburl":"http://iphone.myzaker.com/l.php?l=57ca38f99490cb1b3f00001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca2cff1bc8e0b942000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca2cff1bc8e0b942000003_320.jpg","thumbnail_picsize":"464,300","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca38f99490cb1b3f00001d&m=1472871100","list_dtime":"2016-09-03 10:44:09"},{"pk":"57ca38bb9490cb0f3f000016","title":"考生通知书被作废 教育部介入调查","title_line_break":"考生通知书被作废\n教育部介入调查","date":"2016-09-03 10:43:07","auther_name":"央广网","weburl":"http://iphone.myzaker.com/l.php?l=57ca38bb9490cb0f3f000016","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=660&pk=57ca38bb9490cb0f3f000016&url=http%3A%2F%2Fku.m.chinanews.com%2Fwapapp%2Fzaker%2Fsh%2F2016%2F09-03%2F7992930.shtml","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca38bb9490cb0f3f000016&m=1472871100","list_dtime":"2016-09-03 10:43:07"},{"pk":"57ca367a1bc8e0727b000015","title":"河南现\u201c纸片楼\u201d 市民：给钱都不住","title_line_break":"河南现\u201c纸片楼\u201d 市民：\n给钱都不住","date":"2016-09-03 10:42:20","auther_name":"腾讯网","weburl":"http://iphone.myzaker.com/l.php?l=57ca367a1bc8e0727b000015","thumbnail_pic":"http://zkres.myzaker.com/img_upload/cms/ck/img/10140/2016/09/03/1472869868.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca35f3a07aecc523006fef_320.jpg","thumbnail_picsize":"500,333","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca367a1bc8e0727b000015&m=1472871100","list_dtime":"2016-09-03 10:42:20"},{"pk":"57ca17991bc8e0877b00000a","title":"终身成就奖为何授予成龙","date":"2016-09-03 08:21:45","auther_name":"深圳晚报","weburl":"http://iphone.myzaker.com/l.php?l=57ca17991bc8e0877b00000a","thumbnail_pic":"http://zkres.myzaker.com/img_upload/cms/ck/img/10055/2016/09/03/1472861809.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1693a07aecc523005f2b_320.jpg","thumbnail_picsize":"425,240","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca17991bc8e0877b00000a&m=1472871101","list_dtime":"2016-09-03 08:21:45"},{"pk":"57ca1a279490cb4c3f000011","title":"郑州女孩病房窗台上\u201c写字救母\u201d","date":"2016-09-03 08:35:33","auther_name":"新华网","weburl":"http://iphone.myzaker.com/l.php?l=57ca1a279490cb4c3f000011","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca11d51bc8e02732000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca11d51bc8e02732000000_320.jpg","thumbnail_picsize":"899,599","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca1a279490cb4c3f000011&m=1472871101","list_dtime":"2016-09-03 08:35:33"},{"pk":"57ca205a9490cb1c3f00001c","title":"新西兰公司售罐装空气 市场定位为中国","title_line_break":"新西兰公司售罐装空气\n市场定位为中国","date":"2016-09-03 09:02:33","auther_name":"环球网","weburl":"http://iphone.myzaker.com/l.php?l=57ca205a9490cb1c3f00001c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca1aec1bc8e0c234000113_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1aec1bc8e0c234000113_320.jpg","thumbnail_picsize":"620,349","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca205a9490cb1c3f00001c&m=1472871101","list_dtime":"2016-09-03 09:02:33"},{"pk":"57ca36201bc8e0807b000023","title":"31岁业余摄影师拍摄蜘蛛捕鱼过程","date":"2016-09-03 10:32:00","auther_name":"中青在线","weburl":"http://iphone.myzaker.com/l.php?l=57ca36201bc8e0807b000023","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca35eea07aecc523006fe7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca35eea07aecc523006fe7_320.jpg","thumbnail_picsize":"944,589","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca36201bc8e0807b000023&m=1472871100","list_dtime":"2016-09-03 10:32:00"},{"pk":"57ca22ec1bc8e0757b000011","title":"\u201c民警\u201d求同行行方便 一查男子是\u201c三逃\u201d    ","title_line_break":"\u201c民警\u201d求同行行方便\n一查男子是\u201c三逃\u201d    ","date":"2016-09-03 09:40:07","auther_name":"现代快报全媒体","weburl":"http://iphone.myzaker.com/l.php?l=57ca22ec1bc8e0757b000011","thumbnail_pic":"http://zkres.myzaker.com/img_upload/cms/ck/img/10169/2016/09/03/1472864960.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca22e3a07aecc52300633a_320.jpg","thumbnail_picsize":"600,450","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca22ec1bc8e0757b000011&m=1472871101","list_dtime":"2016-09-03 09:40:07"},{"pk":"57ca32389490cb093f00004b","title":"上海财大一教授被解聘 称举报院长遭报复","title_line_break":"上海财大一教授被解聘\n称举报院长遭报复","date":"2016-09-03 10:22:06","auther_name":"央广网","weburl":"http://iphone.myzaker.com/l.php?l=57ca32389490cb093f00004b","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca32389490cb093f00004b&m=1472871100","list_dtime":"2016-09-03 10:22:06"},{"pk":"57ca20219490cb4d3f000017","title":"网络电台女主播宣传禁毒私下贩毒","date":"2016-09-03 09:03:59","auther_name":"京华时报","weburl":"http://iphone.myzaker.com/l.php?l=57ca20219490cb4d3f000017","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca1ada1bc8e0c2340000b5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1ada1bc8e0c2340000b5_320.jpg","thumbnail_picsize":"450,321","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca20219490cb4d3f000017&m=1472871101","list_dtime":"2016-09-03 09:03:59"},{"pk":"57ca32679490cbe03e000036","title":"揭秘\u201c闻臭师\u201d：鼻子不能太灵","title_line_break":"揭秘\u201c闻臭师\u201d：\n鼻子不能太灵","date":"2016-09-03 10:21:34","auther_name":"齐鲁晚报","weburl":"http://iphone.myzaker.com/l.php?l=57ca32679490cbe03e000036","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca2c871bc8e05e4100001e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca2c871bc8e05e4100001e_320.jpg","thumbnail_picsize":"600,449","media_count":"1","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=660&pk=57ca32679490cbe03e000036&url=http%3A%2F%2Fku.m.chinanews.com%2Fwapapp%2Fzaker%2Fsh%2F2016%2F09-03%2F7992933.shtml","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca32679490cbe03e000036&m=1472871101","list_dtime":"2016-09-03 10:21:34"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57ca15ce9490cb133f000038,57ca2eed9490cbe53e000024,57ca329a9490cbdf3e000022,57ca32e19490cbc43e00003d,57ca2ce79490cb213f00002c,57ca14599490cbff3e000013","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57ca149f9490cb003f00002e,57ca1c169490cbe33e000033,57ca1a3a9490cbd02c000000,57ca10d59490cbee3e000012,57ca1b0e9490cbf73e000020,57ca31f19490cb1b3f00001c","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57ca20109490cb213f000029,57ca145e9490cbe73e00002d,57ca148c9490cbfc3e000014,57ca14259490cbc43e000023,57ca2a799490cbc53e000037,57ca1a699490cb263f00000f","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca27ab9490cb253f00002e,57ca150d9490cb253f00002d,57c8e9ca1bc8e0763000002d,57ca14359490cb223f00001b,57ca15429490cb213f000028,57ca393f9490cbee3e000021","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca38f99490cb1b3f00001d,57ca392b9490cb473f000038,57ca38bb9490cb0f3f000016,57ca367a1bc8e0727b000015,57ca17991bc8e0877b00000a,57ca1a279490cb4c3f000011","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ca36201bc8e0807b000023,57ca205a9490cb1c3f00001c,57ca22ec1bc8e0757b000011,57ca32389490cb093f00004b,57ca20219490cb4d3f000017,57ca32679490cbe03e000036","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#4cace7","#4cace7"],"only_text_page_bgcolors":["#4cace7","#4cace7"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/660.png?t=1458290767","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/660.png?t=1458290767","hidden_time":"24","need_userinfo":"NO","block_title":"头条新闻","block_color":"#4cace7","desktop_color_number":"16","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_8f47af21c26120de753ce7ff2a934b65","selected_index":"0","list":[{"pk":"zk_app_column_660","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"660","title":"新闻头条","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=660&catalog_appid=660","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_1","title":"国内","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1_zk_app_column_block_660","title":"国内新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1&catalog_appid=660","data_type":"news"}},{"pk":"zk_app_column_2","title":"国际","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"2_zk_app_column_block_660","title":"国际新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=2&catalog_appid=660","data_type":"news"}},{"pk":"zk_app_column_14","title":"社会","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"14_zk_app_column_block_660","title":"社会万象","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=14&catalog_appid=660","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=660&since_date=1472797145&nt=1&next_aticle_id=57ca32ac9490cbca3e00001b&_appid=androidphone&opage=2&otimestamp=132
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=660&need_app_integration=0
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=660&ids=5642f2aa9490cbb13200000e,5472a9b69490cb48180000f9,51a70fbe81853d904c00015e&k=201609031050
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/660.png?t=1458290767
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/660.png?t=1458290767
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 头条新闻
         * block_color : #4cace7
         * desktop_color_number : 16
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_8f47af21c26120de753ce7ff2a934b65
         * selected_index : 0
         * list : [{"pk":"zk_app_column_660","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"660","title":"新闻头条","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=660&catalog_appid=660","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_1","title":"国内","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1_zk_app_column_block_660","title":"国内新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1&catalog_appid=660","data_type":"news"}},{"pk":"zk_app_column_2","title":"国际","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"2_zk_app_column_block_660","title":"国际新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=2&catalog_appid=660","data_type":"news"}},{"pk":"zk_app_column_14","title":"社会","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"14_zk_app_column_block_660","title":"社会万象","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=14&catalog_appid=660","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57ca2eed9490cbe53e000024
         * title : 杭州时间开启，习近平见了哪些新老朋友？
         * date : 2016-09-03 10:01:04
         * no_comment : Y
         * auther_name : 新华网
         * page : 1
         * index : 2
         * weburl : http://iphone.myzaker.com/l.php?l=57ca2eed9490cbe53e000024
         * thumbnail_pic : http://zkres.myzaker.com/201609/57ca2ef8a07aecc5230069f8_640.jpg
         * thumbnail_mpic : http://zkres.myzaker.com/201609/57ca2ef8a07aecc5230069f8_320.jpg
         * thumbnail_picsize : 600,477
         * media_count : 10
         * is_full : NO
         * content :
         * special_type : topic
         * special_info : {"icon_type":"1","block_info":{"pk":"57beda289490cbe65500007b","block_title":"G20杭州峰会","title":"G20杭州峰会","block_in_title":"杭州时间开启，习近平见了哪些新老朋友？","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=660&topic_id=57beda289490cbe65500007b&updated=1472868146"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=660&pk=57ca2eed9490cbe53e000024&m=1472871304&no_comment=Y
         * list_dtime : 2016-09-03 10:01:04
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 1
             * articles : 57ca15ce9490cb133f000038,57ca2eed9490cbe53e000024,57ca329a9490cbdf3e000022,57ca32e19490cbc43e00003d,57ca2ce79490cb213f00002c,57ca14599490cbff3e000013
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/660.png?t=1458290767
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * open_type :
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_660
             * title : 综合
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"660","title":"新闻头条","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=660&catalog_appid=660","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 660
                 * title : 新闻头条
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=660&catalog_appid=660
                 * data_type : news
                 * skey : eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;
                    private String skey;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }

                    public String getSkey() {
                        return skey;
                    }

                    public void setSkey(String skey) {
                        this.skey = skey;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String no_comment;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String is_full;
            private String content;
            private String special_type;
            /**
             * icon_type : 1
             * block_info : {"pk":"57beda289490cbe65500007b","block_title":"G20杭州峰会","title":"G20杭州峰会","block_in_title":"杭州时间开启，习近平见了哪些新老朋友？","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=660&topic_id=57beda289490cbe65500007b&updated=1472868146"}
             * icon_url : http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getNo_comment() {
                return no_comment;
            }

            public void setNo_comment(String no_comment) {
                this.no_comment = no_comment;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getSpecial_type() {
                return special_type;
            }

            public void setSpecial_type(String special_type) {
                this.special_type = special_type;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String icon_type;
                /**
                 * pk : 57beda289490cbe65500007b
                 * block_title : G20杭州峰会
                 * title : G20杭州峰会
                 * block_in_title : 杭州时间开启，习近平见了哪些新老朋友？
                 * type : user
                 * need_userinfo : NO
                 * skey :
                 * api_url : http://iphone.myzaker.com/zaker/topic.php?app_id=660&topic_id=57beda289490cbe65500007b&updated=1472868146
                 */

                private BlockInfoBean block_info;
                private String icon_url;
                private String show_jingcai;
                private String list_nodsp;

                public String getIcon_type() {
                    return icon_type;
                }

                public void setIcon_type(String icon_type) {
                    this.icon_type = icon_type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public String getIcon_url() {
                    return icon_url;
                }

                public void setIcon_url(String icon_url) {
                    this.icon_url = icon_url;
                }

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }

                public static class BlockInfoBean {
                    private String pk;
                    private String block_title;
                    private String title;
                    private String block_in_title;
                    private String type;
                    private String need_userinfo;
                    private String skey;
                    private String api_url;

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getBlock_title() {
                        return block_title;
                    }

                    public void setBlock_title(String block_title) {
                        this.block_title = block_title;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getBlock_in_title() {
                        return block_in_title;
                    }

                    public void setBlock_in_title(String block_in_title) {
                        this.block_in_title = block_in_title;
                    }

                    public String getType() {
                        return type;
                    }

                    public void setType(String type) {
                        this.type = type;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getSkey() {
                        return skey;
                    }

                    public void setSkey(String skey) {
                        this.skey = skey;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }
                }
            }
        }
    }
}
