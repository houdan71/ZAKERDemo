package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class Bean_number {

    /**
     * stat : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=11542&since_date=1472959580&nt=1&_appid=androidphone&catalog_appid=13","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=11542&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=11542&ids=5642f2aa9490cbb13200000e,51a7103481853d8f4c000143&k=201609051540"},"catalog":"","articles":[{"pk":"57caee9e7f52e9db4100019a","title":"作业和手机缺一不可，开学季优惠机盘点","date":"2016-09-05 03:46:12","auther_name":"数字尾巴","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57caee9e7f52e9db4100019a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE2MV82MzE5M19XNjQwSDM2MFM0MDAzNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE2MV82MzE5M19XNjQwSDM2MFM0MDAzNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"47","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57caee9e7f52e9db4100019a&m=1473061067","list_dtime":"2016-09-05 03:46:12"},{"pk":"57ccd6b09490cb0f7e000030","title":"新款iPhone7还能成为安卓杀手吗？","date":"2016-09-05 10:21:00","auther_name":"智能硬件小站","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ccd6b09490cb0f7e000030","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDI2OV85OTQwNF9XNjQwSDM2MFMzNzkwNS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDI2OV85OTQwNF9XNjQwSDM2MFMzNzkwNS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccd6b09490cb0f7e000030&m=1473061066","list_dtime":"2016-09-05 10:21:00"},{"pk":"57ccc5b79490cbfb7d00001e","title":"iPhone 7亮光黑惊艳：工艺复杂或成新风向","title_line_break":"iPhone 7亮光黑惊艳：\n工艺复杂或成新风向","date":"2016-09-05 09:11:42","auther_name":"科客网","page":"2","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57ccc5b79490cbfb7d00001e","thumbnail_pic":"http://zkres.myzaker.com/201609/57c98f5b1bc8e0526e000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c98f5b1bc8e0526e000011_320.jpg","thumbnail_picsize":"550,412","media_count":"3","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57958aff9490cb873200002b","block_title":"2016苹果秋季发布会前瞻","title":"2016苹果秋季发布会前瞻","block_in_title":"iPhone 7亮光黑惊艳：工艺复杂或成新风向","type":"user","skey":"","need_userinfo":"NO","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=11542&topic_id=57958aff9490cb873200002b&updated=1473038298"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccc5b79490cbfb7d00001e&m=1473061066","list_dtime":"2016-09-05 09:11:42"},{"pk":"57ccd8399490cb3622000006","title":"三星Note 7全球召回，你怎么看？","title_line_break":"三星Note\n7全球召回，你怎么看？","date":"2016-09-05 10:28:09","auther_name":"数码脑残粉","page":"2","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57ccd8399490cb3622000006","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"156","title":"数码脑残粉","stitle":"数码科技达人聚集地","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=156","block_color":"","subscribe_count":"294425","post_count":"16689","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=11542&app_ids=11542&pk=57ccd8399490cb3622000006&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57ccd8399490cb3622000006","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccd8399490cb3622000006&m=1473061066","list_dtime":"2016-09-05 10:28:09"},{"pk":"57c785349490cbe92c000019","title":"原来Mac微信2.0里有这么多新功能","date":"2016-09-05 10:20:13","auther_name":"ZEALER","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c785349490cbe92c000019","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","video_inside":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c785349490cbe92c000019&title=%E5%8E%9F%E6%9D%A5Mac%E5%BE%AE%E4%BF%A12.0%E9%87%8C%E6%9C%89%E8%BF%99%E4%B9%88%E5%A4%9A%E6%96%B0%E5%8A%9F%E8%83%BD&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c785349490cbe92c000019%26app_id%3D11542%26target%3Dweb3","icon_url":"http://zkres.myzaker.com/data/image/mark2/video_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c785349490cbe92c000019&m=1473061066","list_dtime":"2016-09-05 10:20:13"},{"pk":"57c938409490cbd017000057","title":"带Surface出趟差 没砸是我脾气好","title_line_break":"带Surface出趟差\n没砸是我脾气好","date":"2016-09-05 10:28:48","auther_name":"腾讯数码","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c938409490cbd017000057","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyNzk5Ml82NDEwOF9XNjQwSDM2MFM1NDAzNS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyNzk5Ml82NDEwOF9XNjQwSDM2MFM1NDAzNS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"27","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c938409490cbd017000057&m=1473061066","list_dtime":"2016-09-05 10:28:48"},{"pk":"57cd20629490cb9722000033","title":"三星Note 7压阵! 8月新手机回顾","date":"2016-09-05 15:34:12","auther_name":"机锋网","weburl":"http://iphone.myzaker.com/l.php?l=57cd20629490cb9722000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd207aa07aecc523020b63_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd207aa07aecc523020b63_320.jpg","thumbnail_picsize":"550,412","media_count":"16","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cd20629490cb9722000033&m=1473061066","list_dtime":"2016-09-05 15:34:12"},{"pk":"57cd1e089490cb0a7e00003d","title":"这是全网首篇米家扫地机器人深度评测","date":"2016-09-05 15:24:35","auther_name":"科技犬","weburl":"http://iphone.myzaker.com/l.php?l=57cd1e089490cb0a7e00003d","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd1e17a07aecc523020a0c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd1e17a07aecc523020a0c_320.jpg","thumbnail_picsize":"730,487","media_count":"29","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cd1e089490cb0a7e00003d&m=1473061066","list_dtime":"2016-09-05 15:24:35"},{"pk":"57cd08ef9490cb227e000035","title":"看完更期待！苹果秋季发布会看点汇总","date":"2016-09-05 13:59:37","auther_name":"焯见","weburl":"http://iphone.myzaker.com/l.php?l=57cd08ef9490cb227e000035","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd08f177a3243b6400000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd08f177a3243b6400000d_320.jpg","thumbnail_picsize":"640,405","media_count":"16","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cd08ef9490cb227e000035&m=1473061066","list_dtime":"2016-09-05 13:59:37"},{"pk":"57ccea429490cbea7d000027","title":"在肾7到来之前先温习下历代iPhone吧","date":"2016-09-05 10:52:10","auther_name":"中关村","weburl":"http://iphone.myzaker.com/l.php?l=57ccea429490cbea7d000027","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca512f7f52e91b4800038f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca512f7f52e91b4800038f_320.jpg","thumbnail_picsize":"640,427","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccea429490cbea7d000027&m=1473061066","list_dtime":"2016-09-05 10:52:10"},{"pk":"57ccdcd89490cbf67d00004d","title":"你所不了解的使用智能手机十大隐患","date":"2016-09-05 10:45:32","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57ccdcd89490cbf67d00004d","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca51287f52e90a7f00023e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca51287f52e90a7f00023e_320.jpg","thumbnail_picsize":"640,454","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccdcd89490cbf67d00004d&m=1473061066","list_dtime":"2016-09-05 10:45:32"},{"pk":"57cbe0f37f52e95e3e000033","title":"7代酷睿有啥提升？戴尔燃7000评测","date":"2016-09-05 10:40:21","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57cbe0f37f52e95e3e000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbe0f17f52e95e3e00001b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbe0f17f52e95e3e00001b_320.jpg","thumbnail_picsize":"600,450","media_count":"24","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cbe0f37f52e95e3e000033&m=1473061066","list_dtime":"2016-09-05 10:40:21"},{"pk":"57cc951f1bc8e0cc3100009b","title":"行车记录仪像素潜规则 您真的知道吗","title_line_break":"行车记录仪像素潜规则\n您真的知道吗","date":"2016-09-05 10:24:44","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57cc951f1bc8e0cc3100009b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc91681bc8e0cc3100001f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc91681bc8e0cc3100001f_320.jpg","thumbnail_picsize":"500,303","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cc951f1bc8e0cc3100009b&m=1473061066","list_dtime":"2016-09-05 10:24:44"},{"pk":"57ccd5a89490cbe17d000023","title":"奇葩配置真无语 2000元主机咋选不上当","title_line_break":"奇葩配置真无语\n2000元主机咋选不上当","date":"2016-09-05 10:16:22","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57ccd5a89490cbe17d000023","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd5aea07aecc52301d841_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd5aea07aecc52301d841_320.jpg","thumbnail_picsize":"640,373","media_count":"20","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccd5a89490cbe17d000023&m=1473061066","list_dtime":"2016-09-05 10:16:22"},{"pk":"57cc01159490cbcf2600001b","title":"被你忽略的安全手机 360 Q5 Plus评测","date":"2016-09-05 10:03:11","auther_name":"智能帮","weburl":"http://iphone.myzaker.com/l.php?l=57cc01159490cbcf2600001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbf8e61bc8e0eb50000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbf8e61bc8e0eb50000000_320.jpg","thumbnail_picsize":"580,387","media_count":"38","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cc01159490cbcf2600001b&m=1473061066","list_dtime":"2016-09-05 10:03:11"},{"pk":"57ccbc299490cb297e000012","title":"什么？华为小米魅族今年竟出这么多新机","date":"2016-09-05 08:27:22","auther_name":"数字尾巴","weburl":"http://iphone.myzaker.com/l.php?l=57ccbc299490cb297e000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbc35a07aecc52301ca93_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbc35a07aecc52301ca93_320.jpg","thumbnail_picsize":"680,453","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccbc299490cb297e000012&m=1473061066","list_dtime":"2016-09-05 08:27:22"},{"pk":"57cc95121bc8e0cc3100008b","title":"英特尔告诉你设计师电脑应该是什么样","date":"2016-09-05 07:17:48","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57cc95121bc8e0cc3100008b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc950f1bc8e0cc31000086_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc950f1bc8e0cc31000086_320.jpg","thumbnail_picsize":"568,373","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cc95121bc8e0cc3100008b&m=1473061066","list_dtime":"2016-09-05 07:17:48"},{"pk":"57cca9fe9490cb4d7e000010","title":"通俗易懂教你如何挑选一副好耳机","date":"2016-09-05 07:10:01","auther_name":"太平洋电脑网","weburl":"http://iphone.myzaker.com/l.php?l=57cca9fe9490cb4d7e000010","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccaa09a07aecc52301c59d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccaa09a07aecc52301c59d_320.jpg","thumbnail_picsize":"640,427","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cca9fe9490cb4d7e000010&m=1473061066","list_dtime":"2016-09-05 07:10:01"},{"pk":"57c9ea621bc8e0011e000148","title":"新龙种亮相 微星GTX 1070暗黑龙爵评测","date":"2016-09-05 03:59:02","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57c9ea621bc8e0011e000148","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9ea5f1bc8e0011e00012f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9ea5f1bc8e0011e00012f_320.jpg","thumbnail_picsize":"640,480","media_count":"35","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c9ea621bc8e0011e000148&m=1473061066","list_dtime":"2016-09-05 03:59:02"},{"pk":"57c0ba181bc8e0aa22000004","title":"行车记录仪都长什么样？你真的知道吗","date":"2016-09-05 03:57:33","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57c0ba181bc8e0aa22000004","thumbnail_pic":"http://zkres.myzaker.com/201608/57bf63fc1bc8e01251000023_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bf63fc1bc8e01251000023_320.jpg","thumbnail_picsize":"640,480","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c0ba181bc8e0aa22000004&m=1473061067","list_dtime":"2016-09-05 03:57:33"},{"pk":"57c8a7c71bc8e01a59000042","title":"国产货到底如何 台电TBook 16 Pro评测","date":"2016-09-05 03:52:56","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57c8a7c71bc8e01a59000042","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8a3b31bc8e00a5700003c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8a3b31bc8e00a5700003c_320.jpg","thumbnail_picsize":"640,350","media_count":"25","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c8a7c71bc8e01a59000042&m=1473061067","list_dtime":"2016-09-05 03:52:56"},{"pk":"57c907311bc8e0e70e000037","title":"搭GTX1070 微星10热管笔电GT73 VR评测","date":"2016-09-05 02:54:34","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57c907311bc8e0e70e000037","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9072b1bc8e0e70e000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9072b1bc8e0e70e000011_320.jpg","thumbnail_picsize":"640,427","media_count":"61","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c907311bc8e0e70e000037&m=1473061067","list_dtime":"2016-09-05 02:54:34"},{"pk":"57cb979f9490cb2009000015","title":"索尼新老walkman三代同堂，独家对比","date":"2016-09-05 02:26:51","auther_name":"乙迷音乐论坛","weburl":"http://iphone.myzaker.com/l.php?l=57cb979f9490cb2009000015","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb8d361bc8e07d10000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb8d361bc8e07d10000000_320.jpg","thumbnail_picsize":"640,363","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cb979f9490cb2009000015&m=1473061067","list_dtime":"2016-09-05 02:26:51"},{"pk":"57cae80a7f52e9e7410001be","title":"配得上完美二字！机皇Note 7深度评测","title_line_break":"配得上完美二字！机皇Note\n7深度评测","date":"2016-09-05 02:24:51","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57cae80a7f52e9e7410001be","thumbnail_pic":"http://zkres.myzaker.com/201609/57cae8097f52e9e741000153_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cae8097f52e9e741000153_320.jpg","thumbnail_picsize":"800,449","media_count":"108","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cae80a7f52e9e7410001be&m=1473061067","list_dtime":"2016-09-05 02:24:51"},{"pk":"57c77fe29490cbea2c000028","title":"会上瘾的机械键盘，卖两千多还抢着买","date":"2016-09-04 13:34:22","auther_name":"极果","weburl":"http://iphone.myzaker.com/l.php?l=57c77fe29490cbea2c000028","thumbnail_pic":"http://zkres.myzaker.com/201608/57c0f63ca07aecf77e015626_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c0f63ca07aecf77e015626_320.jpg","thumbnail_picsize":"640,360","media_count":"72","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c77fe29490cbea2c000028&m=1473053403","list_dtime":"2016-09-04 13:34:22"},{"pk":"57c697f49490cbc20d00001a","title":"Mini-Audio Oriolus黑黄鹂二代圈铁耳机","title_line_break":"Mini-Audio\nOriolus黑黄鹂二代圈铁耳机","date":"2016-09-04 13:31:27","auther_name":"乐享派","weburl":"http://iphone.myzaker.com/l.php?l=57c697f49490cbc20d00001a","thumbnail_pic":"http://zkres.myzaker.com/201608/57c678e31bc8e08a04000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c678e31bc8e08a04000001_320.jpg","thumbnail_picsize":"980,654","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c697f49490cbc20d00001a&m=1473053403","list_dtime":"2016-09-04 13:31:27"},{"pk":"57c768f39490cbe12c000016","title":"先定个小目标：比如说换部高颜值新机","title_line_break":"先定个小目标：\n比如说换部高颜值新机","date":"2016-09-04 13:28:57","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57c768f39490cbe12c000016","thumbnail_pic":"http://zkres.myzaker.com/201605/57325a351bc8e0a30b000036_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201605/57325a351bc8e0a30b000036_320.jpg","thumbnail_picsize":"640,480","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c768f39490cbe12c000016&m=1473053129","list_dtime":"2016-09-04 13:28:57"},{"pk":"57c7f6519490cbc85d00001d","title":"ROLIC解题，如何做一款优秀的百元手环","date":"2016-09-04 13:27:33","auther_name":"乐享派","weburl":"http://iphone.myzaker.com/l.php?l=57c7f6519490cbc85d00001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7c3051bc8e03d4e000019_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7c3051bc8e03d4e000019_320.jpg","thumbnail_picsize":"980,550","media_count":"19","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c7f6519490cbc85d00001d&m=1473053129","list_dtime":"2016-09-04 13:27:33"},{"pk":"57c9318a9490cba60a00000c","title":"铁家小姨子SR5能否单挑陌生人妻MSR7","date":"2016-09-04 13:26:25","auther_name":"乐享派","weburl":"http://iphone.myzaker.com/l.php?l=57c9318a9490cba60a00000c","thumbnail_pic":"http://zkres.myzaker.com/201609/57c910371bc8e00c19000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c910371bc8e00c19000001_320.jpg","thumbnail_picsize":"980,649","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c9318a9490cba60a00000c&m=1473053129","list_dtime":"2016-09-04 13:26:25"},{"pk":"57ca3cb79490cb827c000003","title":"老魅友告诉你MX5还值得入手吗？","date":"2016-09-04 13:24:48","auther_name":"智能帮","weburl":"http://iphone.myzaker.com/l.php?l=57ca3cb79490cb827c000003","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca31f91bc8e02045000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca31f91bc8e02045000003_320.jpg","thumbnail_picsize":"580,435","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ca3cb79490cb827c000003&m=1473052855","list_dtime":"2016-09-04 13:24:48"},{"pk":"57ca3cb79490cb827c000002","title":"未来已来  微软Hololens全息眼镜开箱","date":"2016-09-04 13:23:03","auther_name":"雷锋网","weburl":"http://iphone.myzaker.com/l.php?l=57ca3cb79490cb827c000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57c997a51bc8e08e7200001a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c997a51bc8e08e7200001a_320.jpg","thumbnail_picsize":"880,568","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ca3cb79490cb827c000002&m=1473052855","list_dtime":"2016-09-04 13:23:03"},{"pk":"57ca6a689490cb8a68000001","title":"智能手机为何还会爆炸？看完你就懂了","date":"2016-09-04 13:21:56","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca6a689490cb8a68000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca67b71bc8e0696300002d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca67b71bc8e0696300002d_320.jpg","thumbnail_picsize":"479,300","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ca6a689490cb8a68000001&m=1473052855","list_dtime":"2016-09-04 13:21:56"},{"pk":"57cab5689490cb896f000002","title":"小物件让你的手机前置镜头变得更无敌","date":"2016-09-04 13:18:18","auther_name":"智能帮","weburl":"http://iphone.myzaker.com/l.php?l=57cab5689490cb896f000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57caad621bc8e09710000004_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57caad621bc8e09710000004_320.jpg","thumbnail_picsize":"580,435","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cab5689490cb896f000002&m=1473052583","list_dtime":"2016-09-04 13:18:18"},{"pk":"57cad3e09490cb8610000001","title":"颜值手感兼顾 nubia Z11黑金版开箱","date":"2016-09-04 13:16:49","auther_name":"机锋网","weburl":"http://iphone.myzaker.com/l.php?l=57cad3e09490cb8610000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57cad23e7f52e9e741000116_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cad23e7f52e9e741000116_320.jpg","thumbnail_picsize":"1200,900","media_count":"24","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cad3e09490cb8610000001&m=1473052583","list_dtime":"2016-09-04 13:16:49"},{"pk":"57cb90879490cb7f35000012","title":"iPhone 7/7 Plus最全曝光：配置彪悍","title_line_break":"iPhone 7/7 Plus最全曝光：\n配置彪悍","date":"2016-09-04 11:30:18","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57cb90879490cb7f35000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb790e1bc8e0d90200001f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb790e1bc8e0d90200001f_320.jpg","thumbnail_picsize":"590,543","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cb90879490cb7f35000012&m=1473046031","list_dtime":"2016-09-04 11:30:18"},{"pk":"57cb87a37f52e94842000145","title":"3000元！华为女性新机Nova","date":"2016-09-04 11:26:20","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57cb87a37f52e94842000145","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb87a27f52e9484200013f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb87a27f52e9484200013f_320.jpg","thumbnail_picsize":"800,450","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cb87a37f52e94842000145&m=1473045760","list_dtime":"2016-09-04 11:26:20"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c938409490cbd017000057,57cd20629490cb9722000033,57cd1e089490cb0a7e00003d,57cd08ef9490cb227e000035,57ccea429490cbea7d000027,57c785349490cbe92c000019","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccd6b09490cb0f7e000030,57ccd8399490cb3622000006,57ccdcd89490cbf67d00004d,57cbe0f37f52e95e3e000033,57cc951f1bc8e0cc3100009b,57ccc5b79490cbfb7d00001e","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57caee9e7f52e9db4100019a,57ccd5a89490cbe17d000023,57cc01159490cbcf2600001b,57ccbc299490cb297e000012,57cc95121bc8e0cc3100008b,57cca9fe9490cb4d7e000010","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c0ba181bc8e0aa22000004,57c9ea621bc8e0011e000148,57c8a7c71bc8e01a59000042,57c907311bc8e0e70e000037,57cb979f9490cb2009000015,57cae80a7f52e9e7410001be","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c697f49490cbc20d00001a,57c77fe29490cbea2c000028,57c768f39490cbe12c000016,57c7f6519490cbc85d00001d,57c9318a9490cba60a00000c,57ca3cb79490cb827c000003","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca6a689490cb8a68000001,57ca3cb79490cb827c000002,57cab5689490cb896f000002,57cad3e09490cb8610000001,57cb90879490cb7f35000012,57cb87a37f52e94842000145","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}}],"article_block_colors":["#232323","#232323"],"only_text_page_bgcolors":["#232323","#232323"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11542.png?t=1466068021","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11542.png?t=1466068021","hidden_time":"24","need_userinfo":"NO","block_title":"数码测评","block_color":"#232323","desktop_color_number":"5","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_b3e3ae0c73d533f7ee7b3cebad530148","selected_index":"1","list":[{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]}}
     */

    private String stat;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=11542&since_date=1472959580&nt=1&_appid=androidphone&catalog_appid=13","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=11542&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=11542&ids=5642f2aa9490cbb13200000e,51a7103481853d8f4c000143&k=201609051540"}
     * catalog :
     * articles : [{"pk":"57caee9e7f52e9db4100019a","title":"作业和手机缺一不可，开学季优惠机盘点","date":"2016-09-05 03:46:12","auther_name":"数字尾巴","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57caee9e7f52e9db4100019a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE2MV82MzE5M19XNjQwSDM2MFM0MDAzNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE2MV82MzE5M19XNjQwSDM2MFM0MDAzNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"47","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57caee9e7f52e9db4100019a&m=1473061067","list_dtime":"2016-09-05 03:46:12"},{"pk":"57ccd6b09490cb0f7e000030","title":"新款iPhone7还能成为安卓杀手吗？","date":"2016-09-05 10:21:00","auther_name":"智能硬件小站","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ccd6b09490cb0f7e000030","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDI2OV85OTQwNF9XNjQwSDM2MFMzNzkwNS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDI2OV85OTQwNF9XNjQwSDM2MFMzNzkwNS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccd6b09490cb0f7e000030&m=1473061066","list_dtime":"2016-09-05 10:21:00"},{"pk":"57ccc5b79490cbfb7d00001e","title":"iPhone 7亮光黑惊艳：工艺复杂或成新风向","title_line_break":"iPhone 7亮光黑惊艳：\n工艺复杂或成新风向","date":"2016-09-05 09:11:42","auther_name":"科客网","page":"2","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57ccc5b79490cbfb7d00001e","thumbnail_pic":"http://zkres.myzaker.com/201609/57c98f5b1bc8e0526e000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c98f5b1bc8e0526e000011_320.jpg","thumbnail_picsize":"550,412","media_count":"3","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57958aff9490cb873200002b","block_title":"2016苹果秋季发布会前瞻","title":"2016苹果秋季发布会前瞻","block_in_title":"iPhone 7亮光黑惊艳：工艺复杂或成新风向","type":"user","skey":"","need_userinfo":"NO","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=11542&topic_id=57958aff9490cb873200002b&updated=1473038298"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccc5b79490cbfb7d00001e&m=1473061066","list_dtime":"2016-09-05 09:11:42"},{"pk":"57ccd8399490cb3622000006","title":"三星Note 7全球召回，你怎么看？","title_line_break":"三星Note\n7全球召回，你怎么看？","date":"2016-09-05 10:28:09","auther_name":"数码脑残粉","page":"2","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57ccd8399490cb3622000006","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"156","title":"数码脑残粉","stitle":"数码科技达人聚集地","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=156","block_color":"","subscribe_count":"294425","post_count":"16689","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=11542&app_ids=11542&pk=57ccd8399490cb3622000006&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57ccd8399490cb3622000006","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccd8399490cb3622000006&m=1473061066","list_dtime":"2016-09-05 10:28:09"},{"pk":"57c785349490cbe92c000019","title":"原来Mac微信2.0里有这么多新功能","date":"2016-09-05 10:20:13","auther_name":"ZEALER","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c785349490cbe92c000019","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","video_inside":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c785349490cbe92c000019&title=%E5%8E%9F%E6%9D%A5Mac%E5%BE%AE%E4%BF%A12.0%E9%87%8C%E6%9C%89%E8%BF%99%E4%B9%88%E5%A4%9A%E6%96%B0%E5%8A%9F%E8%83%BD&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c785349490cbe92c000019%26app_id%3D11542%26target%3Dweb3","icon_url":"http://zkres.myzaker.com/data/image/mark2/video_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c785349490cbe92c000019&m=1473061066","list_dtime":"2016-09-05 10:20:13"},{"pk":"57c938409490cbd017000057","title":"带Surface出趟差 没砸是我脾气好","title_line_break":"带Surface出趟差\n没砸是我脾气好","date":"2016-09-05 10:28:48","auther_name":"腾讯数码","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c938409490cbd017000057","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyNzk5Ml82NDEwOF9XNjQwSDM2MFM1NDAzNS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyNzk5Ml82NDEwOF9XNjQwSDM2MFM1NDAzNS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"27","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c938409490cbd017000057&m=1473061066","list_dtime":"2016-09-05 10:28:48"},{"pk":"57cd20629490cb9722000033","title":"三星Note 7压阵! 8月新手机回顾","date":"2016-09-05 15:34:12","auther_name":"机锋网","weburl":"http://iphone.myzaker.com/l.php?l=57cd20629490cb9722000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd207aa07aecc523020b63_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd207aa07aecc523020b63_320.jpg","thumbnail_picsize":"550,412","media_count":"16","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cd20629490cb9722000033&m=1473061066","list_dtime":"2016-09-05 15:34:12"},{"pk":"57cd1e089490cb0a7e00003d","title":"这是全网首篇米家扫地机器人深度评测","date":"2016-09-05 15:24:35","auther_name":"科技犬","weburl":"http://iphone.myzaker.com/l.php?l=57cd1e089490cb0a7e00003d","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd1e17a07aecc523020a0c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd1e17a07aecc523020a0c_320.jpg","thumbnail_picsize":"730,487","media_count":"29","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cd1e089490cb0a7e00003d&m=1473061066","list_dtime":"2016-09-05 15:24:35"},{"pk":"57cd08ef9490cb227e000035","title":"看完更期待！苹果秋季发布会看点汇总","date":"2016-09-05 13:59:37","auther_name":"焯见","weburl":"http://iphone.myzaker.com/l.php?l=57cd08ef9490cb227e000035","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd08f177a3243b6400000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd08f177a3243b6400000d_320.jpg","thumbnail_picsize":"640,405","media_count":"16","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cd08ef9490cb227e000035&m=1473061066","list_dtime":"2016-09-05 13:59:37"},{"pk":"57ccea429490cbea7d000027","title":"在肾7到来之前先温习下历代iPhone吧","date":"2016-09-05 10:52:10","auther_name":"中关村","weburl":"http://iphone.myzaker.com/l.php?l=57ccea429490cbea7d000027","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca512f7f52e91b4800038f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca512f7f52e91b4800038f_320.jpg","thumbnail_picsize":"640,427","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccea429490cbea7d000027&m=1473061066","list_dtime":"2016-09-05 10:52:10"},{"pk":"57ccdcd89490cbf67d00004d","title":"你所不了解的使用智能手机十大隐患","date":"2016-09-05 10:45:32","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57ccdcd89490cbf67d00004d","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca51287f52e90a7f00023e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca51287f52e90a7f00023e_320.jpg","thumbnail_picsize":"640,454","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccdcd89490cbf67d00004d&m=1473061066","list_dtime":"2016-09-05 10:45:32"},{"pk":"57cbe0f37f52e95e3e000033","title":"7代酷睿有啥提升？戴尔燃7000评测","date":"2016-09-05 10:40:21","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57cbe0f37f52e95e3e000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbe0f17f52e95e3e00001b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbe0f17f52e95e3e00001b_320.jpg","thumbnail_picsize":"600,450","media_count":"24","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cbe0f37f52e95e3e000033&m=1473061066","list_dtime":"2016-09-05 10:40:21"},{"pk":"57cc951f1bc8e0cc3100009b","title":"行车记录仪像素潜规则 您真的知道吗","title_line_break":"行车记录仪像素潜规则\n您真的知道吗","date":"2016-09-05 10:24:44","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57cc951f1bc8e0cc3100009b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc91681bc8e0cc3100001f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc91681bc8e0cc3100001f_320.jpg","thumbnail_picsize":"500,303","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cc951f1bc8e0cc3100009b&m=1473061066","list_dtime":"2016-09-05 10:24:44"},{"pk":"57ccd5a89490cbe17d000023","title":"奇葩配置真无语 2000元主机咋选不上当","title_line_break":"奇葩配置真无语\n2000元主机咋选不上当","date":"2016-09-05 10:16:22","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57ccd5a89490cbe17d000023","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd5aea07aecc52301d841_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd5aea07aecc52301d841_320.jpg","thumbnail_picsize":"640,373","media_count":"20","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccd5a89490cbe17d000023&m=1473061066","list_dtime":"2016-09-05 10:16:22"},{"pk":"57cc01159490cbcf2600001b","title":"被你忽略的安全手机 360 Q5 Plus评测","date":"2016-09-05 10:03:11","auther_name":"智能帮","weburl":"http://iphone.myzaker.com/l.php?l=57cc01159490cbcf2600001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbf8e61bc8e0eb50000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbf8e61bc8e0eb50000000_320.jpg","thumbnail_picsize":"580,387","media_count":"38","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cc01159490cbcf2600001b&m=1473061066","list_dtime":"2016-09-05 10:03:11"},{"pk":"57ccbc299490cb297e000012","title":"什么？华为小米魅族今年竟出这么多新机","date":"2016-09-05 08:27:22","auther_name":"数字尾巴","weburl":"http://iphone.myzaker.com/l.php?l=57ccbc299490cb297e000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbc35a07aecc52301ca93_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbc35a07aecc52301ca93_320.jpg","thumbnail_picsize":"680,453","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ccbc299490cb297e000012&m=1473061066","list_dtime":"2016-09-05 08:27:22"},{"pk":"57cc95121bc8e0cc3100008b","title":"英特尔告诉你设计师电脑应该是什么样","date":"2016-09-05 07:17:48","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57cc95121bc8e0cc3100008b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc950f1bc8e0cc31000086_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc950f1bc8e0cc31000086_320.jpg","thumbnail_picsize":"568,373","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cc95121bc8e0cc3100008b&m=1473061066","list_dtime":"2016-09-05 07:17:48"},{"pk":"57cca9fe9490cb4d7e000010","title":"通俗易懂教你如何挑选一副好耳机","date":"2016-09-05 07:10:01","auther_name":"太平洋电脑网","weburl":"http://iphone.myzaker.com/l.php?l=57cca9fe9490cb4d7e000010","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccaa09a07aecc52301c59d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccaa09a07aecc52301c59d_320.jpg","thumbnail_picsize":"640,427","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cca9fe9490cb4d7e000010&m=1473061066","list_dtime":"2016-09-05 07:10:01"},{"pk":"57c9ea621bc8e0011e000148","title":"新龙种亮相 微星GTX 1070暗黑龙爵评测","date":"2016-09-05 03:59:02","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57c9ea621bc8e0011e000148","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9ea5f1bc8e0011e00012f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9ea5f1bc8e0011e00012f_320.jpg","thumbnail_picsize":"640,480","media_count":"35","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c9ea621bc8e0011e000148&m=1473061066","list_dtime":"2016-09-05 03:59:02"},{"pk":"57c0ba181bc8e0aa22000004","title":"行车记录仪都长什么样？你真的知道吗","date":"2016-09-05 03:57:33","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57c0ba181bc8e0aa22000004","thumbnail_pic":"http://zkres.myzaker.com/201608/57bf63fc1bc8e01251000023_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bf63fc1bc8e01251000023_320.jpg","thumbnail_picsize":"640,480","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c0ba181bc8e0aa22000004&m=1473061067","list_dtime":"2016-09-05 03:57:33"},{"pk":"57c8a7c71bc8e01a59000042","title":"国产货到底如何 台电TBook 16 Pro评测","date":"2016-09-05 03:52:56","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57c8a7c71bc8e01a59000042","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8a3b31bc8e00a5700003c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8a3b31bc8e00a5700003c_320.jpg","thumbnail_picsize":"640,350","media_count":"25","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c8a7c71bc8e01a59000042&m=1473061067","list_dtime":"2016-09-05 03:52:56"},{"pk":"57c907311bc8e0e70e000037","title":"搭GTX1070 微星10热管笔电GT73 VR评测","date":"2016-09-05 02:54:34","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57c907311bc8e0e70e000037","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9072b1bc8e0e70e000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9072b1bc8e0e70e000011_320.jpg","thumbnail_picsize":"640,427","media_count":"61","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c907311bc8e0e70e000037&m=1473061067","list_dtime":"2016-09-05 02:54:34"},{"pk":"57cb979f9490cb2009000015","title":"索尼新老walkman三代同堂，独家对比","date":"2016-09-05 02:26:51","auther_name":"乙迷音乐论坛","weburl":"http://iphone.myzaker.com/l.php?l=57cb979f9490cb2009000015","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb8d361bc8e07d10000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb8d361bc8e07d10000000_320.jpg","thumbnail_picsize":"640,363","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cb979f9490cb2009000015&m=1473061067","list_dtime":"2016-09-05 02:26:51"},{"pk":"57cae80a7f52e9e7410001be","title":"配得上完美二字！机皇Note 7深度评测","title_line_break":"配得上完美二字！机皇Note\n7深度评测","date":"2016-09-05 02:24:51","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57cae80a7f52e9e7410001be","thumbnail_pic":"http://zkres.myzaker.com/201609/57cae8097f52e9e741000153_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cae8097f52e9e741000153_320.jpg","thumbnail_picsize":"800,449","media_count":"108","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cae80a7f52e9e7410001be&m=1473061067","list_dtime":"2016-09-05 02:24:51"},{"pk":"57c77fe29490cbea2c000028","title":"会上瘾的机械键盘，卖两千多还抢着买","date":"2016-09-04 13:34:22","auther_name":"极果","weburl":"http://iphone.myzaker.com/l.php?l=57c77fe29490cbea2c000028","thumbnail_pic":"http://zkres.myzaker.com/201608/57c0f63ca07aecf77e015626_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c0f63ca07aecf77e015626_320.jpg","thumbnail_picsize":"640,360","media_count":"72","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c77fe29490cbea2c000028&m=1473053403","list_dtime":"2016-09-04 13:34:22"},{"pk":"57c697f49490cbc20d00001a","title":"Mini-Audio Oriolus黑黄鹂二代圈铁耳机","title_line_break":"Mini-Audio\nOriolus黑黄鹂二代圈铁耳机","date":"2016-09-04 13:31:27","auther_name":"乐享派","weburl":"http://iphone.myzaker.com/l.php?l=57c697f49490cbc20d00001a","thumbnail_pic":"http://zkres.myzaker.com/201608/57c678e31bc8e08a04000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c678e31bc8e08a04000001_320.jpg","thumbnail_picsize":"980,654","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c697f49490cbc20d00001a&m=1473053403","list_dtime":"2016-09-04 13:31:27"},{"pk":"57c768f39490cbe12c000016","title":"先定个小目标：比如说换部高颜值新机","title_line_break":"先定个小目标：\n比如说换部高颜值新机","date":"2016-09-04 13:28:57","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57c768f39490cbe12c000016","thumbnail_pic":"http://zkres.myzaker.com/201605/57325a351bc8e0a30b000036_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201605/57325a351bc8e0a30b000036_320.jpg","thumbnail_picsize":"640,480","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c768f39490cbe12c000016&m=1473053129","list_dtime":"2016-09-04 13:28:57"},{"pk":"57c7f6519490cbc85d00001d","title":"ROLIC解题，如何做一款优秀的百元手环","date":"2016-09-04 13:27:33","auther_name":"乐享派","weburl":"http://iphone.myzaker.com/l.php?l=57c7f6519490cbc85d00001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7c3051bc8e03d4e000019_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7c3051bc8e03d4e000019_320.jpg","thumbnail_picsize":"980,550","media_count":"19","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c7f6519490cbc85d00001d&m=1473053129","list_dtime":"2016-09-04 13:27:33"},{"pk":"57c9318a9490cba60a00000c","title":"铁家小姨子SR5能否单挑陌生人妻MSR7","date":"2016-09-04 13:26:25","auther_name":"乐享派","weburl":"http://iphone.myzaker.com/l.php?l=57c9318a9490cba60a00000c","thumbnail_pic":"http://zkres.myzaker.com/201609/57c910371bc8e00c19000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c910371bc8e00c19000001_320.jpg","thumbnail_picsize":"980,649","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57c9318a9490cba60a00000c&m=1473053129","list_dtime":"2016-09-04 13:26:25"},{"pk":"57ca3cb79490cb827c000003","title":"老魅友告诉你MX5还值得入手吗？","date":"2016-09-04 13:24:48","auther_name":"智能帮","weburl":"http://iphone.myzaker.com/l.php?l=57ca3cb79490cb827c000003","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca31f91bc8e02045000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca31f91bc8e02045000003_320.jpg","thumbnail_picsize":"580,435","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ca3cb79490cb827c000003&m=1473052855","list_dtime":"2016-09-04 13:24:48"},{"pk":"57ca3cb79490cb827c000002","title":"未来已来  微软Hololens全息眼镜开箱","date":"2016-09-04 13:23:03","auther_name":"雷锋网","weburl":"http://iphone.myzaker.com/l.php?l=57ca3cb79490cb827c000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57c997a51bc8e08e7200001a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c997a51bc8e08e7200001a_320.jpg","thumbnail_picsize":"880,568","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ca3cb79490cb827c000002&m=1473052855","list_dtime":"2016-09-04 13:23:03"},{"pk":"57ca6a689490cb8a68000001","title":"智能手机为何还会爆炸？看完你就懂了","date":"2016-09-04 13:21:56","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca6a689490cb8a68000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca67b71bc8e0696300002d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca67b71bc8e0696300002d_320.jpg","thumbnail_picsize":"479,300","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57ca6a689490cb8a68000001&m=1473052855","list_dtime":"2016-09-04 13:21:56"},{"pk":"57cab5689490cb896f000002","title":"小物件让你的手机前置镜头变得更无敌","date":"2016-09-04 13:18:18","auther_name":"智能帮","weburl":"http://iphone.myzaker.com/l.php?l=57cab5689490cb896f000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57caad621bc8e09710000004_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57caad621bc8e09710000004_320.jpg","thumbnail_picsize":"580,435","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cab5689490cb896f000002&m=1473052583","list_dtime":"2016-09-04 13:18:18"},{"pk":"57cad3e09490cb8610000001","title":"颜值手感兼顾 nubia Z11黑金版开箱","date":"2016-09-04 13:16:49","auther_name":"机锋网","weburl":"http://iphone.myzaker.com/l.php?l=57cad3e09490cb8610000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57cad23e7f52e9e741000116_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cad23e7f52e9e741000116_320.jpg","thumbnail_picsize":"1200,900","media_count":"24","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cad3e09490cb8610000001&m=1473052583","list_dtime":"2016-09-04 13:16:49"},{"pk":"57cb90879490cb7f35000012","title":"iPhone 7/7 Plus最全曝光：配置彪悍","title_line_break":"iPhone 7/7 Plus最全曝光：\n配置彪悍","date":"2016-09-04 11:30:18","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57cb90879490cb7f35000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb790e1bc8e0d90200001f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb790e1bc8e0d90200001f_320.jpg","thumbnail_picsize":"590,543","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cb90879490cb7f35000012&m=1473046031","list_dtime":"2016-09-04 11:30:18"},{"pk":"57cb87a37f52e94842000145","title":"3000元！华为女性新机Nova","date":"2016-09-04 11:26:20","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57cb87a37f52e94842000145","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb87a27f52e9484200013f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb87a27f52e9484200013f_320.jpg","thumbnail_picsize":"800,450","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57cb87a37f52e94842000145&m=1473045760","list_dtime":"2016-09-04 11:26:20"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c938409490cbd017000057,57cd20629490cb9722000033,57cd1e089490cb0a7e00003d,57cd08ef9490cb227e000035,57ccea429490cbea7d000027,57c785349490cbe92c000019","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccd6b09490cb0f7e000030,57ccd8399490cb3622000006,57ccdcd89490cbf67d00004d,57cbe0f37f52e95e3e000033,57cc951f1bc8e0cc3100009b,57ccc5b79490cbfb7d00001e","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57caee9e7f52e9db4100019a,57ccd5a89490cbe17d000023,57cc01159490cbcf2600001b,57ccbc299490cb297e000012,57cc95121bc8e0cc3100008b,57cca9fe9490cb4d7e000010","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c0ba181bc8e0aa22000004,57c9ea621bc8e0011e000148,57c8a7c71bc8e01a59000042,57c907311bc8e0e70e000037,57cb979f9490cb2009000015,57cae80a7f52e9e7410001be","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c697f49490cbc20d00001a,57c77fe29490cbea2c000028,57c768f39490cbe12c000016,57c7f6519490cbc85d00001d,57c9318a9490cba60a00000c,57ca3cb79490cb827c000003","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca6a689490cb8a68000001,57ca3cb79490cb827c000002,57cab5689490cb896f000002,57cad3e09490cb8610000001,57cb90879490cb7f35000012,57cb87a37f52e94842000145","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}}],"article_block_colors":["#232323","#232323"],"only_text_page_bgcolors":["#232323","#232323"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11542.png?t=1466068021","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11542.png?t=1466068021","hidden_time":"24","need_userinfo":"NO","block_title":"数码测评","block_color":"#232323","desktop_color_number":"5","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_b3e3ae0c73d533f7ee7b3cebad530148","selected_index":"1","list":[{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=11542&since_date=1472959580&nt=1&_appid=androidphone&catalog_appid=13
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=11542&need_app_integration=
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=11542&ids=5642f2aa9490cbb13200000e,51a7103481853d8f4c000143&k=201609051540
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/11542.png?t=1466068021
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/11542.png?t=1466068021
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 数码测评
         * block_color : #232323
         * desktop_color_number : 5
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_b3e3ae0c73d533f7ee7b3cebad530148
         * selected_index : 1
         * list : [{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57caee9e7f52e9db4100019a
         * title : 作业和手机缺一不可，开学季优惠机盘点
         * date : 2016-09-05 03:46:12
         * auther_name : 数字尾巴
         * page : 3
         * index : 1
         * weburl : http://iphone.myzaker.com/l.php?l=57caee9e7f52e9db4100019a
         * thumbnail_pic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE2MV82MzE5M19XNjQwSDM2MFM0MDAzNC5qcGc=_1242.jpg
         * thumbnail_mpic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE2MV82MzE5M19XNjQwSDM2MFM0MDAzNC5qcGc=_1242.jpg
         * thumbnail_picsize : 640,360
         * media_count : 47
         * is_full : NO
         * content :
         * special_info : {"show_jingcai":"Y","list_nodsp":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11542&pk=57caee9e7f52e9db4100019a&m=1473061067
         * list_dtime : 2016-09-05 03:46:12
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 2
             * articles : 57c938409490cbd017000057,57cd20629490cb9722000033,57cd1e089490cb0a7e00003d,57cd08ef9490cb227e000035,57ccea429490cbea7d000027,57c785349490cbe92c000019
             * diy : {"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * is_ad : Y
                 * stat_read_url : http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read
                 * ga_info : {"category":"AD","action":"Banner","send_after_showed":"Y"}
                 * open_type : web
                 * need_user_info : N
                 * open_confirm :
                 * ads_id : 5775c9899490cbef0300003b
                 * ads_title : 华为科技冠名160701-aPhone
                 * ad_pk : 5775c9899490cbef0300003b
                 * web_url : http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String is_ad;
                    private String stat_read_url;
                    /**
                     * category : AD
                     * action : Banner
                     * send_after_showed : Y
                     */

                    private GaInfoBean ga_info;
                    private String open_type;
                    private String need_user_info;
                    private String open_confirm;
                    private String ads_id;
                    private String ads_title;
                    private String ad_pk;
                    private String web_url;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getIs_ad() {
                        return is_ad;
                    }

                    public void setIs_ad(String is_ad) {
                        this.is_ad = is_ad;
                    }

                    public String getStat_read_url() {
                        return stat_read_url;
                    }

                    public void setStat_read_url(String stat_read_url) {
                        this.stat_read_url = stat_read_url;
                    }

                    public GaInfoBean getGa_info() {
                        return ga_info;
                    }

                    public void setGa_info(GaInfoBean ga_info) {
                        this.ga_info = ga_info;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }

                    public String getNeed_user_info() {
                        return need_user_info;
                    }

                    public void setNeed_user_info(String need_user_info) {
                        this.need_user_info = need_user_info;
                    }

                    public String getOpen_confirm() {
                        return open_confirm;
                    }

                    public void setOpen_confirm(String open_confirm) {
                        this.open_confirm = open_confirm;
                    }

                    public String getAds_id() {
                        return ads_id;
                    }

                    public void setAds_id(String ads_id) {
                        this.ads_id = ads_id;
                    }

                    public String getAds_title() {
                        return ads_title;
                    }

                    public void setAds_title(String ads_title) {
                        this.ads_title = ads_title;
                    }

                    public String getAd_pk() {
                        return ad_pk;
                    }

                    public void setAd_pk(String ad_pk) {
                        this.ad_pk = ad_pk;
                    }

                    public String getWeb_url() {
                        return web_url;
                    }

                    public void setWeb_url(String web_url) {
                        this.web_url = web_url;
                    }

                    public static class GaInfoBean {
                        private String category;
                        private String action;
                        private String send_after_showed;

                        public String getCategory() {
                            return category;
                        }

                        public void setCategory(String category) {
                            this.category = category;
                        }

                        public String getAction() {
                            return action;
                        }

                        public void setAction(String action) {
                            this.action = action;
                        }

                        public String getSend_after_showed() {
                            return send_after_showed;
                        }

                        public void setSend_after_showed(String send_after_showed) {
                            this.send_after_showed = send_after_showed;
                        }
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_13
             * title : 综合
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 13
                 * title : 科技频道
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13
                 * data_type : news
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String is_full;
            private String content;
            /**
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String show_jingcai;
                private String list_nodsp;

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }
            }
        }
    }
}
