package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class Bean_star {

    /**
     * stat : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=12348&since_date=1472781937&nt=1&_appid=androidphone&catalog_appid=9","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=12348&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12348&ids=51a7104681853dec4d00012f&k=201609051500"},"catalog":"","articles":[{"pk":"57cd06db9490cb0b7e000046","title":"佟丽娅晒仙气美照 纯白连衣裙优雅十足","title_line_break":"佟丽娅晒仙气美照\n纯白连衣裙优雅十足","date":"2016-09-05 13:47:07","auther_name":"Yes娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cd06db9490cb0b7e000046","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDUwNV81Mzc0Ml9XNjQwSDM2MFMzMDE1Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDUwNV81Mzc0Ml9XNjQwSDM2MFMzMDE1Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cd06db9490cb0b7e000046&m=1473054506","list_dtime":"2016-09-05 13:47:07"},{"pk":"57cd04409490cbe67d000027","title":"唐艺昕示范早秋Girl的正确打开方式","date":"2016-09-05 13:36:00","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cd04409490cbe67d000027","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1Mzg3OF84MTQzX1c2NDBIMzYwUzM0MzgzLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1Mzg3OF84MTQzX1c2NDBIMzYwUzM0MzgzLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cd04409490cbe67d000027&m=1473053879","list_dtime":"2016-09-05 13:36:00"},{"pk":"57cced699490cb177e000020","title":"吴昕机场秀美腿走出T范 重回17岁","title_line_break":"吴昕机场秀美腿走出T范\n重回17岁","date":"2016-09-05 11:58:33","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cced699490cb177e000020","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzk3MV80Njg0OV9XNjQwSDM2MFMzODk3MC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzk3MV80Njg0OV9XNjQwSDM2MFMzODk3MC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cced699490cb177e000020&m=1473047973","list_dtime":"2016-09-05 11:58:33"},{"pk":"57cce4799490cb1a7e000029","title":"没有PS和美瞳 她们依旧惊艳了时光","title_line_break":"没有PS和美瞳\n她们依旧惊艳了时光","date":"2016-09-05 11:20:25","auther_name":"她刊","weburl":"http://iphone.myzaker.com/l.php?l=57cce4799490cb1a7e000029","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NTk1M18xNjIyNF9XNjQwSDM2MFMyNzQxOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NTk1M18xNjIyNF9XNjQwSDM2MFMyNzQxOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"48","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cce4799490cb1a7e000029&m=1473045955","list_dtime":"2016-09-05 11:20:25"},{"pk":"57ccdfa29490cb4d7e000026","title":"颜值不高却成女神收割机 十项全能众人爱","title_line_break":"颜值不高却成女神收割机\n十项全能众人爱","date":"2016-09-05 10:59:46","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccdfa29490cb4d7e000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDkyMF81OTg0Ml9XNjQwSDM2MFMzMzg4NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDkyMF81OTg0Ml9XNjQwSDM2MFMzMzg4NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccdfa29490cb4d7e000026&m=1473044921","list_dtime":"2016-09-05 10:59:46"},{"pk":"57ccda6c9490cb1a7e000027","title":"不论古装还是现代装，蔡少芬都美的惊心","date":"2016-09-05 10:37:32","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccda6c9490cb1a7e000027","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDAwNl8zODAyMV9XNjQwSDM2MFM0MDgzOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDAwNl8zODAyMV9XNjQwSDM2MFM0MDgzOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"32","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccda6c9490cb1a7e000027&m=1473044008","list_dtime":"2016-09-05 10:37:32"},{"pk":"57ccd66b9490cbe87d00003b","title":"全智贤时尚画报公开 演绎完美秋冬时尚","title_line_break":"全智贤时尚画报公开\n演绎完美秋冬时尚","date":"2016-09-05 10:20:27","auther_name":"Yes娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd66b9490cbe87d00003b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mjc5OV85NjAwOV9XNjQwSDM2MFM2NTI2Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mjc5OV85NjAwOV9XNjQwSDM2MFM2NTI2Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccd66b9490cbe87d00003b&m=1473042801","list_dtime":"2016-09-05 10:20:27"},{"pk":"57ccd6539490cbec7d000026","title":"刘亦菲牛仔短裙秀白皙玉腿 长发飘飘迷人","title_line_break":"刘亦菲牛仔短裙秀白皙玉腿\n长发飘飘迷人","date":"2016-09-05 10:20:03","auther_name":"19楼娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd6539490cbec7d000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mjc4M18yOTQzX1c2NDBIMzYwUzY0MDc1LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mjc4M18yOTQzX1c2NDBIMzYwUzY0MDc1LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccd6539490cbec7d000026&m=1473042784","list_dtime":"2016-09-05 10:20:03"},{"pk":"57ccd3159490cb247e000036","title":"曾是TVB一姐 最红时离婚如今牵手外交官","title_line_break":"曾是TVB一姐\n最红时离婚如今牵手外交官","date":"2016-09-05 10:06:13","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57ccd3159490cb247e000036","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mjc2M18zMDY4M19XNjQwSDM2MFM0NjY3Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mjc2M18zMDY4M19XNjQwSDM2MFM0NjY3Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccd3159490cb247e000036&m=1473042765","list_dtime":"2016-09-05 10:06:13"},{"pk":"57ccd2c49490cb157e00001e","title":"49岁田震曝近照 满头白发拒与那英同台","title_line_break":"49岁田震曝近照\n满头白发拒与那英同台","date":"2016-09-05 10:04:52","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57ccd2c49490cb157e00001e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MjE4N184MzgyMF9XNjQwSDM2MFM1MTM0Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MjE4N184MzgyMF9XNjQwSDM2MFM1MTM0Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccd2c49490cb157e00001e&m=1473042190","list_dtime":"2016-09-05 10:04:52"},{"pk":"57ccd17c9490cb267e000034","title":"叶一茜牵一双儿女现身 森碟森碗乖巧可爱","title_line_break":"叶一茜牵一双儿女现身\n森碟森碗乖巧可爱","date":"2016-09-05 09:56:52","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd17c9490cb267e000034","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MDc5MF82NDM4N19XNjQwSDM2MFM1ODI4NC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MDc5MF82NDM4N19XNjQwSDM2MFM1ODI4NC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccd17c9490cb267e000034&m=1473040810","list_dtime":"2016-09-05 09:56:52"},{"pk":"57cccf2f9490cb137e000026","title":"盘点娱乐圈腿精明星 逆天长腿堪比模特","title_line_break":"盘点娱乐圈腿精明星\n逆天长腿堪比模特","date":"2016-09-05 09:49:35","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57cccf2f9490cb137e000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MDM3OV81Mzc0NF9XNjQwSDM2MFM0NzYwOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MDM3OV81Mzc0NF9XNjQwSDM2MFM0NzYwOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cccf2f9490cb137e000026&m=1473040381","list_dtime":"2016-09-05 09:49:35"},{"pk":"57cbe04e9490cbce3500003d","title":"冯德伦，从酒窝美少年到叛逆胡子大叔","date":"2016-09-04 16:50:22","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cbe04e9490cbce3500003d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTI2MV80Njg0Nl9XNjQwSDM2MFMzMDc4OS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTI2MV80Njg0Nl9XNjQwSDM2MFMzMDc4OS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cbe04e9490cbce3500003d&m=1472982116","list_dtime":"2016-09-04 16:50:22"},{"pk":"57cbb8d79490cbe03500003c","title":"本周女星穿衣榜，把衣服穿出调性更考功力","date":"2016-09-04 14:00:29","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cbb8d79490cbe03500003c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3MDk3OV80NzU3M19XNjQwSDM2MFMyNTE2Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3MDk3OV80NzU3M19XNjQwSDM2MFMyNTE2Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cbb8d79490cbe03500003c&m=1472980210","list_dtime":"2016-09-04 14:00:29"},{"pk":"57cbb4bc9490cba43500003e","title":"无预警虐汪！舒淇冯德伦恋爱密照甜炸","date":"2016-09-04 13:44:28","auther_name":"中国娱乐网","weburl":"http://iphone.myzaker.com/l.php?l=57cbb4bc9490cba43500003e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk2Nzk2OF85MDY1M19XNjQwSDM2MFM0MDY0OS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk2Nzk2OF85MDY1M19XNjQwSDM2MFM0MDY0OS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"37","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cbb4bc9490cba43500003e&m=1472968204","list_dtime":"2016-09-04 13:44:28"},{"pk":"57cb92039490cb8235000031","title":"柳岩运动写真尽显翘臀 曲线妙曼","title_line_break":"柳岩运动写真尽显翘臀\n曲线妙曼","date":"2016-09-04 11:14:35","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb92039490cb8235000031","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1OTAwMV85MzI0OF9XNjQwSDM2MFM0NDc5NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1OTAwMV85MzI0OF9XNjQwSDM2MFM0NDc5NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb92039490cb8235000031&m=1472959003","list_dtime":"2016-09-04 11:14:35"},{"pk":"57cb8e399490cbec35000023","title":"张雨绮亮相酒会 露香肩性感不失干练","title_line_break":"张雨绮亮相酒会\n露香肩性感不失干练","date":"2016-09-04 11:00:09","auther_name":"19楼娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb8e399490cbec35000023","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1ODE1Ml8xNTE2Ml9XNjQwSDM2MFMzMzUwOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1ODE1Ml8xNTE2Ml9XNjQwSDM2MFMzMzUwOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb8e399490cbec35000023&m=1472958153","list_dtime":"2016-09-04 11:00:09"},{"pk":"57cb8aed9490cbbe35000024","title":"莫文蔚沙漠帅气照片 满是文艺气息","title_line_break":"莫文蔚沙漠帅气照片\n满是文艺气息","date":"2016-09-04 10:46:05","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57cb8aed9490cbbe35000024","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NzM1MV80NDEyMV9XNjQwSDM2MFMyOTYyNS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NzM1MV80NDEyMV9XNjQwSDM2MFMyOTYyNS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb8aed9490cbbe35000024&m=1472957353","list_dtime":"2016-09-04 10:46:05"},{"pk":"57cb8aa19490cbd335000025","title":"何洁编小清新彩色麻花辫 网友：要拆多久","title_line_break":"何洁编小清新彩色麻花辫 网友：\n要拆多久","date":"2016-09-04 10:44:49","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57cb8aa19490cbd335000025","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NzM3MF83NDAzMF9XNjQwSDM2MFM0OTA1Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NzM3MF83NDAzMF9XNjQwSDM2MFM0OTA1Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb8aa19490cbd335000025&m=1472957374","list_dtime":"2016-09-04 10:44:49"},{"pk":"57cb8a0e9490cb9035000027","title":"杨丽萍穿民族风长裙 融于山水美如画","title_line_break":"杨丽萍穿民族风长裙\n融于山水美如画","date":"2016-09-04 10:39:27","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb8a0e9490cb9035000027","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NzAyM181NTU4N19XNjQwSDM2MFM4NzkyMy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NzAyM181NTU4N19XNjQwSDM2MFM4NzkyMy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb8a0e9490cb9035000027&m=1472957025","list_dtime":"2016-09-04 10:39:27"},{"pk":"57cb83c99490cba835000028","title":"相比郑爽的麻杆腿 颖儿的胸骨更恐怖","title_line_break":"相比郑爽的麻杆腿\n颖儿的胸骨更恐怖","date":"2016-09-04 10:15:37","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57cb83c99490cba835000028","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NjYxOV85Nzc4NV9XNjQwSDM2MFM1MjA2OS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NjYxOV85Nzc4NV9XNjQwSDM2MFM1MjA2OS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb83c99490cba835000028&m=1472956620","list_dtime":"2016-09-04 10:15:37"},{"pk":"57cb81d79490cb9035000018","title":"高云翔演绎三面型男 长腿魅眼雅痞范儿","title_line_break":"高云翔演绎三面型男\n长腿魅眼雅痞范儿","date":"2016-09-04 10:05:30","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb81d79490cb9035000018","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NDkwMl8zNDM2NV9XNjQwSDM2MFM1MTQ3OS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NDkwMl8zNDM2NV9XNjQwSDM2MFM1MTQ3OS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb81d79490cb9035000018&m=1472954903","list_dtime":"2016-09-04 10:05:30"},{"pk":"57cb7c2f9490cbe835000021","title":"大表姐刘雯这次要做山城辣妹子啦！","date":"2016-09-04 09:43:11","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb7c2f9490cbe835000021","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NDU3N182ODYzM19XNjQwSDM2MFM0MzQ4OS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NDU3N182ODYzM19XNjQwSDM2MFM0MzQ4OS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb7c2f9490cbe835000021&m=1472954578","list_dtime":"2016-09-04 09:43:11"},{"pk":"57cb7c269490cb933500001c","title":"舒淇嫁了，来看看她最美最性感的照片吧","date":"2016-09-04 09:43:02","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb7c269490cb933500001c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NDU1Ml8xMTk3NV9XNjQwSDM2MFMyOTY3MS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NDU1Ml8xMTk3NV9XNjQwSDM2MFMyOTY3MS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"29","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb7c269490cb933500001c&m=1472954554","list_dtime":"2016-09-04 09:43:02"},{"pk":"57c9404d9490cb091800004c","title":"张梓琳产后仍苗条 优雅白裙露纤细美腿","title_line_break":"张梓琳产后仍苗条\n优雅白裙露纤细美腿","date":"2016-09-02 17:03:09","auther_name":"19楼娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c9404d9490cb091800004c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwOTkwM183Mzg0NF9XNjQwSDM2MFMzNTcwOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwOTkwM183Mzg0NF9XNjQwSDM2MFMzNTcwOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c9404d9490cb091800004c&m=1472809905","list_dtime":"2016-09-02 17:03:09"},{"pk":"57c9209e9490cb2318000047","title":"李小璐性感写真曝光，但还是没比过柳岩","date":"2016-09-02 14:47:58","auther_name":"谈资","weburl":"http://iphone.myzaker.com/l.php?l=57c9209e9490cb2318000047","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjkxMl8xMTY5OV9XNjQwSDM2MFM0MTA3NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjkxMl8xMTY5OV9XNjQwSDM2MFM0MTA3NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c9209e9490cb2318000047&m=1472806915","list_dtime":"2016-09-02 14:47:58"},{"pk":"57c917079490cb2818000029","title":"她曾美貌惊人，红过赵雅芝，却一生未婚","date":"2016-09-02 14:07:03","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57c917079490cb2818000029","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjk1MV8xMDExOF9XNjQwSDM2MFMyNDY2OS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjk1MV8xMDExOF9XNjQwSDM2MFMyNDY2OS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c917079490cb2818000029&m=1472806953","list_dtime":"2016-09-02 14:07:03"},{"pk":"57c8f8df9490cb1018000038","title":"马伊琍抹胸装现身 太瘦了衣服一直掉","title_line_break":"马伊琍抹胸装现身\n太瘦了衣服一直掉","date":"2016-09-02 11:58:23","auther_name":"19楼娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8f8df9490cb1018000038","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8da341bc8e06c73000029_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8da341bc8e06c73000029_320.jpg","thumbnail_picsize":"480,386","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8f8df9490cb1018000038&m=1472788795","list_dtime":"2016-09-02 11:58:23"},{"pk":"57c8f65b9490cbe517000024","title":"宝宝摊！伊能静晒女儿肉嘟嘟呆萌照","date":"2016-09-02 11:47:39","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8f65b9490cbe517000024","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4ODgxNl84NDY2Nl9XNjQwSDM2MFM3MDAwMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4ODgxNl84NDY2Nl9XNjQwSDM2MFM3MDAwMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8f65b9490cbe517000024&m=1472788818","list_dtime":"2016-09-02 11:47:39"},{"pk":"57c8f6149490cbe51700001d","title":"37岁活成17岁，傻白甜也可以不讨人厌","date":"2016-09-02 11:46:28","auther_name":"芭莎娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8f6149490cbe51700001d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4ODg3MV84NjA4MV9XNjQwSDM2MFMzMzg4Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4ODg3MV84NjA4MV9XNjQwSDM2MFMzMzg4Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"50","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8f6149490cbe51700001d&m=1472788876","list_dtime":"2016-09-02 11:46:28"},{"pk":"57c8ed2a9490cb560100000c","title":"杨紫另类诠释人比花娇 最新大片惊艳上线","title_line_break":"杨紫另类诠释人比花娇\n最新大片惊艳上线","date":"2016-09-02 11:06:48","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8ed2a9490cb560100000c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4NjA2MV80MTU1X1c2NDBIMzYwUzI0ODYxLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4NjA2MV80MTU1X1c2NDBIMzYwUzI0ODYxLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8ed2a9490cb560100000c&m=1472786194","list_dtime":"2016-09-02 11:06:48"},{"pk":"57c8e4169490cbde17000029","title":"爸3孩子们大聚会，诺一已经黑得认不出","date":"2016-09-02 10:29:42","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8e4169490cbde17000029","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4NjEwMV8yNDQ3MV9XNjQwSDM2MFM2ODg3Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4NjEwMV8yNDQ3MV9XNjQwSDM2MFM2ODg3Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8e4169490cbde17000029&m=1472786169","list_dtime":"2016-09-02 10:29:42"},{"pk":"57c8e3989490cb421800001f","title":"16年13张封面，见证了章子怡的蜕变","date":"2016-09-02 10:27:36","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8e3989490cb421800001f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c81e271bc8e0bb0a00004f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c81e271bc8e0bb0a00004f_320.jpg","thumbnail_picsize":"600,390","media_count":"29","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8e3989490cb421800001f&m=1472786692","list_dtime":"2016-09-02 10:27:36"},{"pk":"57c8e02b9490cbfd1700001e","title":"48岁陈红近照 和宠物狗贴脸充满童趣","title_line_break":"48岁陈红近照\n和宠物狗贴脸充满童趣","date":"2016-09-02 10:12:59","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8e02b9490cbfd1700001e","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8dfbe7f52e9866e000087_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8dfbe7f52e9866e000087_320.jpg","thumbnail_picsize":"420,500","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8e02b9490cbfd1700001e&m=1472782484","list_dtime":"2016-09-02 10:12:59"},{"pk":"57c8dfc59490cbd117000019","title":"权志龙穿着自己的衣服拍大片简直帅飞！","date":"2016-09-02 10:11:17","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8dfc59490cbd117000019","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d2b71bc8e0786e000061_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d2b71bc8e0786e000061_320.jpg","thumbnail_picsize":"600,402","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8dfc59490cbd117000019&m=1472782513","list_dtime":"2016-09-02 10:11:17"},{"pk":"57c8de719490cbf91700002b","title":"李沁晒何润东婚礼内场照 ","title_line_break":"李沁晒何润东婚礼内场照\n","date":"2016-09-02 10:05:37","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57c8de719490cbf91700002b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d2131bc8e0896f000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d2131bc8e0896f000011_320.jpg","thumbnail_picsize":"483,493","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8de719490cbf91700002b&m=1472782033","list_dtime":"2016-09-02 10:05:37"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cd04409490cbe67d000027,57cd06db9490cb0b7e000046,57cced699490cb177e000020,57cce4799490cb1a7e000029,57ccdfa29490cb4d7e000026,57ccda6c9490cb1a7e000027","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57ccd6539490cbec7d000026,57ccd66b9490cbe87d00003b,57ccd3159490cb247e000036,57ccd2c49490cb157e00001e,57ccd17c9490cb267e000034,57cccf2f9490cb137e000026","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cbb8d79490cbe03500003c,57cbe04e9490cbce3500003d,57cbb4bc9490cba43500003e,57cb92039490cb8235000031,57cb8e399490cbec35000023,57cb8aed9490cbbe35000024","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cb8a0e9490cb9035000027,57cb8aa19490cbd335000025,57cb83c99490cba835000028,57cb81d79490cb9035000018,57cb7c2f9490cbe835000021,57cb7c269490cb933500001c","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57c9209e9490cb2318000047,57c9404d9490cb091800004c,57c917079490cb2818000029,57c8f8df9490cb1018000038,57c8f65b9490cbe517000024,57c8f6149490cbe51700001d","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c8e4169490cbde17000029,57c8ed2a9490cb560100000c,57c8e3989490cb421800001f,57c8e02b9490cbfd1700001e,57c8dfc59490cbd117000019,57c8de719490cbf91700002b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#5700b9","#5700b9"],"only_text_page_bgcolors":["#5700b9","#5700b9"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12348.png?t=1459499793","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12348.png?t=1459499793","hidden_time":"24","need_userinfo":"NO","block_title":"明星","block_color":"#5700b9","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_a554ee1915f294ad77def365f71f3e85","selected_index":"3","list":[{"pk":"zk_app_column_9","title":"娱乐","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_10530","title":"电影","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"10530_zk_app_column_block_9","title":"电影资讯","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=10530&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_11698","title":"电视","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11698_zk_app_column_block_9","title":"电视","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11698&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_12348","title":"明星","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12348_zk_app_column_block_9","title":"明星","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12348&catalog_appid=9","data_type":"news"}}]}}
     */

    private String stat;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=12348&since_date=1472781937&nt=1&_appid=androidphone&catalog_appid=9","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=12348&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12348&ids=51a7104681853dec4d00012f&k=201609051500"}
     * catalog :
     * articles : [{"pk":"57cd06db9490cb0b7e000046","title":"佟丽娅晒仙气美照 纯白连衣裙优雅十足","title_line_break":"佟丽娅晒仙气美照\n纯白连衣裙优雅十足","date":"2016-09-05 13:47:07","auther_name":"Yes娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cd06db9490cb0b7e000046","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDUwNV81Mzc0Ml9XNjQwSDM2MFMzMDE1Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDUwNV81Mzc0Ml9XNjQwSDM2MFMzMDE1Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cd06db9490cb0b7e000046&m=1473054506","list_dtime":"2016-09-05 13:47:07"},{"pk":"57cd04409490cbe67d000027","title":"唐艺昕示范早秋Girl的正确打开方式","date":"2016-09-05 13:36:00","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cd04409490cbe67d000027","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1Mzg3OF84MTQzX1c2NDBIMzYwUzM0MzgzLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1Mzg3OF84MTQzX1c2NDBIMzYwUzM0MzgzLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cd04409490cbe67d000027&m=1473053879","list_dtime":"2016-09-05 13:36:00"},{"pk":"57cced699490cb177e000020","title":"吴昕机场秀美腿走出T范 重回17岁","title_line_break":"吴昕机场秀美腿走出T范\n重回17岁","date":"2016-09-05 11:58:33","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cced699490cb177e000020","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzk3MV80Njg0OV9XNjQwSDM2MFMzODk3MC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzk3MV80Njg0OV9XNjQwSDM2MFMzODk3MC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cced699490cb177e000020&m=1473047973","list_dtime":"2016-09-05 11:58:33"},{"pk":"57cce4799490cb1a7e000029","title":"没有PS和美瞳 她们依旧惊艳了时光","title_line_break":"没有PS和美瞳\n她们依旧惊艳了时光","date":"2016-09-05 11:20:25","auther_name":"她刊","weburl":"http://iphone.myzaker.com/l.php?l=57cce4799490cb1a7e000029","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NTk1M18xNjIyNF9XNjQwSDM2MFMyNzQxOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NTk1M18xNjIyNF9XNjQwSDM2MFMyNzQxOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"48","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cce4799490cb1a7e000029&m=1473045955","list_dtime":"2016-09-05 11:20:25"},{"pk":"57ccdfa29490cb4d7e000026","title":"颜值不高却成女神收割机 十项全能众人爱","title_line_break":"颜值不高却成女神收割机\n十项全能众人爱","date":"2016-09-05 10:59:46","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccdfa29490cb4d7e000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDkyMF81OTg0Ml9XNjQwSDM2MFMzMzg4NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDkyMF81OTg0Ml9XNjQwSDM2MFMzMzg4NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccdfa29490cb4d7e000026&m=1473044921","list_dtime":"2016-09-05 10:59:46"},{"pk":"57ccda6c9490cb1a7e000027","title":"不论古装还是现代装，蔡少芬都美的惊心","date":"2016-09-05 10:37:32","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccda6c9490cb1a7e000027","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDAwNl8zODAyMV9XNjQwSDM2MFM0MDgzOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDAwNl8zODAyMV9XNjQwSDM2MFM0MDgzOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"32","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccda6c9490cb1a7e000027&m=1473044008","list_dtime":"2016-09-05 10:37:32"},{"pk":"57ccd66b9490cbe87d00003b","title":"全智贤时尚画报公开 演绎完美秋冬时尚","title_line_break":"全智贤时尚画报公开\n演绎完美秋冬时尚","date":"2016-09-05 10:20:27","auther_name":"Yes娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd66b9490cbe87d00003b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mjc5OV85NjAwOV9XNjQwSDM2MFM2NTI2Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mjc5OV85NjAwOV9XNjQwSDM2MFM2NTI2Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccd66b9490cbe87d00003b&m=1473042801","list_dtime":"2016-09-05 10:20:27"},{"pk":"57ccd6539490cbec7d000026","title":"刘亦菲牛仔短裙秀白皙玉腿 长发飘飘迷人","title_line_break":"刘亦菲牛仔短裙秀白皙玉腿\n长发飘飘迷人","date":"2016-09-05 10:20:03","auther_name":"19楼娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd6539490cbec7d000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mjc4M18yOTQzX1c2NDBIMzYwUzY0MDc1LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mjc4M18yOTQzX1c2NDBIMzYwUzY0MDc1LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccd6539490cbec7d000026&m=1473042784","list_dtime":"2016-09-05 10:20:03"},{"pk":"57ccd3159490cb247e000036","title":"曾是TVB一姐 最红时离婚如今牵手外交官","title_line_break":"曾是TVB一姐\n最红时离婚如今牵手外交官","date":"2016-09-05 10:06:13","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57ccd3159490cb247e000036","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mjc2M18zMDY4M19XNjQwSDM2MFM0NjY3Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mjc2M18zMDY4M19XNjQwSDM2MFM0NjY3Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccd3159490cb247e000036&m=1473042765","list_dtime":"2016-09-05 10:06:13"},{"pk":"57ccd2c49490cb157e00001e","title":"49岁田震曝近照 满头白发拒与那英同台","title_line_break":"49岁田震曝近照\n满头白发拒与那英同台","date":"2016-09-05 10:04:52","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57ccd2c49490cb157e00001e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MjE4N184MzgyMF9XNjQwSDM2MFM1MTM0Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MjE4N184MzgyMF9XNjQwSDM2MFM1MTM0Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccd2c49490cb157e00001e&m=1473042190","list_dtime":"2016-09-05 10:04:52"},{"pk":"57ccd17c9490cb267e000034","title":"叶一茜牵一双儿女现身 森碟森碗乖巧可爱","title_line_break":"叶一茜牵一双儿女现身\n森碟森碗乖巧可爱","date":"2016-09-05 09:56:52","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd17c9490cb267e000034","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MDc5MF82NDM4N19XNjQwSDM2MFM1ODI4NC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MDc5MF82NDM4N19XNjQwSDM2MFM1ODI4NC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57ccd17c9490cb267e000034&m=1473040810","list_dtime":"2016-09-05 09:56:52"},{"pk":"57cccf2f9490cb137e000026","title":"盘点娱乐圈腿精明星 逆天长腿堪比模特","title_line_break":"盘点娱乐圈腿精明星\n逆天长腿堪比模特","date":"2016-09-05 09:49:35","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57cccf2f9490cb137e000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MDM3OV81Mzc0NF9XNjQwSDM2MFM0NzYwOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MDM3OV81Mzc0NF9XNjQwSDM2MFM0NzYwOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cccf2f9490cb137e000026&m=1473040381","list_dtime":"2016-09-05 09:49:35"},{"pk":"57cbe04e9490cbce3500003d","title":"冯德伦，从酒窝美少年到叛逆胡子大叔","date":"2016-09-04 16:50:22","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cbe04e9490cbce3500003d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTI2MV80Njg0Nl9XNjQwSDM2MFMzMDc4OS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTI2MV80Njg0Nl9XNjQwSDM2MFMzMDc4OS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cbe04e9490cbce3500003d&m=1472982116","list_dtime":"2016-09-04 16:50:22"},{"pk":"57cbb8d79490cbe03500003c","title":"本周女星穿衣榜，把衣服穿出调性更考功力","date":"2016-09-04 14:00:29","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cbb8d79490cbe03500003c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3MDk3OV80NzU3M19XNjQwSDM2MFMyNTE2Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3MDk3OV80NzU3M19XNjQwSDM2MFMyNTE2Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cbb8d79490cbe03500003c&m=1472980210","list_dtime":"2016-09-04 14:00:29"},{"pk":"57cbb4bc9490cba43500003e","title":"无预警虐汪！舒淇冯德伦恋爱密照甜炸","date":"2016-09-04 13:44:28","auther_name":"中国娱乐网","weburl":"http://iphone.myzaker.com/l.php?l=57cbb4bc9490cba43500003e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk2Nzk2OF85MDY1M19XNjQwSDM2MFM0MDY0OS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk2Nzk2OF85MDY1M19XNjQwSDM2MFM0MDY0OS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"37","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cbb4bc9490cba43500003e&m=1472968204","list_dtime":"2016-09-04 13:44:28"},{"pk":"57cb92039490cb8235000031","title":"柳岩运动写真尽显翘臀 曲线妙曼","title_line_break":"柳岩运动写真尽显翘臀\n曲线妙曼","date":"2016-09-04 11:14:35","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb92039490cb8235000031","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1OTAwMV85MzI0OF9XNjQwSDM2MFM0NDc5NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1OTAwMV85MzI0OF9XNjQwSDM2MFM0NDc5NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb92039490cb8235000031&m=1472959003","list_dtime":"2016-09-04 11:14:35"},{"pk":"57cb8e399490cbec35000023","title":"张雨绮亮相酒会 露香肩性感不失干练","title_line_break":"张雨绮亮相酒会\n露香肩性感不失干练","date":"2016-09-04 11:00:09","auther_name":"19楼娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb8e399490cbec35000023","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1ODE1Ml8xNTE2Ml9XNjQwSDM2MFMzMzUwOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1ODE1Ml8xNTE2Ml9XNjQwSDM2MFMzMzUwOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb8e399490cbec35000023&m=1472958153","list_dtime":"2016-09-04 11:00:09"},{"pk":"57cb8aed9490cbbe35000024","title":"莫文蔚沙漠帅气照片 满是文艺气息","title_line_break":"莫文蔚沙漠帅气照片\n满是文艺气息","date":"2016-09-04 10:46:05","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57cb8aed9490cbbe35000024","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NzM1MV80NDEyMV9XNjQwSDM2MFMyOTYyNS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NzM1MV80NDEyMV9XNjQwSDM2MFMyOTYyNS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb8aed9490cbbe35000024&m=1472957353","list_dtime":"2016-09-04 10:46:05"},{"pk":"57cb8aa19490cbd335000025","title":"何洁编小清新彩色麻花辫 网友：要拆多久","title_line_break":"何洁编小清新彩色麻花辫 网友：\n要拆多久","date":"2016-09-04 10:44:49","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57cb8aa19490cbd335000025","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NzM3MF83NDAzMF9XNjQwSDM2MFM0OTA1Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NzM3MF83NDAzMF9XNjQwSDM2MFM0OTA1Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb8aa19490cbd335000025&m=1472957374","list_dtime":"2016-09-04 10:44:49"},{"pk":"57cb8a0e9490cb9035000027","title":"杨丽萍穿民族风长裙 融于山水美如画","title_line_break":"杨丽萍穿民族风长裙\n融于山水美如画","date":"2016-09-04 10:39:27","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb8a0e9490cb9035000027","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NzAyM181NTU4N19XNjQwSDM2MFM4NzkyMy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NzAyM181NTU4N19XNjQwSDM2MFM4NzkyMy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb8a0e9490cb9035000027&m=1472957025","list_dtime":"2016-09-04 10:39:27"},{"pk":"57cb83c99490cba835000028","title":"相比郑爽的麻杆腿 颖儿的胸骨更恐怖","title_line_break":"相比郑爽的麻杆腿\n颖儿的胸骨更恐怖","date":"2016-09-04 10:15:37","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57cb83c99490cba835000028","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NjYxOV85Nzc4NV9XNjQwSDM2MFM1MjA2OS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NjYxOV85Nzc4NV9XNjQwSDM2MFM1MjA2OS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb83c99490cba835000028&m=1472956620","list_dtime":"2016-09-04 10:15:37"},{"pk":"57cb81d79490cb9035000018","title":"高云翔演绎三面型男 长腿魅眼雅痞范儿","title_line_break":"高云翔演绎三面型男\n长腿魅眼雅痞范儿","date":"2016-09-04 10:05:30","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb81d79490cb9035000018","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NDkwMl8zNDM2NV9XNjQwSDM2MFM1MTQ3OS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NDkwMl8zNDM2NV9XNjQwSDM2MFM1MTQ3OS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb81d79490cb9035000018&m=1472954903","list_dtime":"2016-09-04 10:05:30"},{"pk":"57cb7c2f9490cbe835000021","title":"大表姐刘雯这次要做山城辣妹子啦！","date":"2016-09-04 09:43:11","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb7c2f9490cbe835000021","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NDU3N182ODYzM19XNjQwSDM2MFM0MzQ4OS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NDU3N182ODYzM19XNjQwSDM2MFM0MzQ4OS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb7c2f9490cbe835000021&m=1472954578","list_dtime":"2016-09-04 09:43:11"},{"pk":"57cb7c269490cb933500001c","title":"舒淇嫁了，来看看她最美最性感的照片吧","date":"2016-09-04 09:43:02","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb7c269490cb933500001c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NDU1Ml8xMTk3NV9XNjQwSDM2MFMyOTY3MS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1NDU1Ml8xMTk3NV9XNjQwSDM2MFMyOTY3MS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"29","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cb7c269490cb933500001c&m=1472954554","list_dtime":"2016-09-04 09:43:02"},{"pk":"57c9404d9490cb091800004c","title":"张梓琳产后仍苗条 优雅白裙露纤细美腿","title_line_break":"张梓琳产后仍苗条\n优雅白裙露纤细美腿","date":"2016-09-02 17:03:09","auther_name":"19楼娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c9404d9490cb091800004c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwOTkwM183Mzg0NF9XNjQwSDM2MFMzNTcwOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwOTkwM183Mzg0NF9XNjQwSDM2MFMzNTcwOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c9404d9490cb091800004c&m=1472809905","list_dtime":"2016-09-02 17:03:09"},{"pk":"57c9209e9490cb2318000047","title":"李小璐性感写真曝光，但还是没比过柳岩","date":"2016-09-02 14:47:58","auther_name":"谈资","weburl":"http://iphone.myzaker.com/l.php?l=57c9209e9490cb2318000047","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjkxMl8xMTY5OV9XNjQwSDM2MFM0MTA3NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjkxMl8xMTY5OV9XNjQwSDM2MFM0MTA3NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c9209e9490cb2318000047&m=1472806915","list_dtime":"2016-09-02 14:47:58"},{"pk":"57c917079490cb2818000029","title":"她曾美貌惊人，红过赵雅芝，却一生未婚","date":"2016-09-02 14:07:03","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57c917079490cb2818000029","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjk1MV8xMDExOF9XNjQwSDM2MFMyNDY2OS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjk1MV8xMDExOF9XNjQwSDM2MFMyNDY2OS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c917079490cb2818000029&m=1472806953","list_dtime":"2016-09-02 14:07:03"},{"pk":"57c8f8df9490cb1018000038","title":"马伊琍抹胸装现身 太瘦了衣服一直掉","title_line_break":"马伊琍抹胸装现身\n太瘦了衣服一直掉","date":"2016-09-02 11:58:23","auther_name":"19楼娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8f8df9490cb1018000038","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8da341bc8e06c73000029_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8da341bc8e06c73000029_320.jpg","thumbnail_picsize":"480,386","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8f8df9490cb1018000038&m=1472788795","list_dtime":"2016-09-02 11:58:23"},{"pk":"57c8f65b9490cbe517000024","title":"宝宝摊！伊能静晒女儿肉嘟嘟呆萌照","date":"2016-09-02 11:47:39","auther_name":"北青网娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8f65b9490cbe517000024","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4ODgxNl84NDY2Nl9XNjQwSDM2MFM3MDAwMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4ODgxNl84NDY2Nl9XNjQwSDM2MFM3MDAwMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8f65b9490cbe517000024&m=1472788818","list_dtime":"2016-09-02 11:47:39"},{"pk":"57c8f6149490cbe51700001d","title":"37岁活成17岁，傻白甜也可以不讨人厌","date":"2016-09-02 11:46:28","auther_name":"芭莎娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8f6149490cbe51700001d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4ODg3MV84NjA4MV9XNjQwSDM2MFMzMzg4Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4ODg3MV84NjA4MV9XNjQwSDM2MFMzMzg4Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"50","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8f6149490cbe51700001d&m=1472788876","list_dtime":"2016-09-02 11:46:28"},{"pk":"57c8ed2a9490cb560100000c","title":"杨紫另类诠释人比花娇 最新大片惊艳上线","title_line_break":"杨紫另类诠释人比花娇\n最新大片惊艳上线","date":"2016-09-02 11:06:48","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8ed2a9490cb560100000c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4NjA2MV80MTU1X1c2NDBIMzYwUzI0ODYxLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4NjA2MV80MTU1X1c2NDBIMzYwUzI0ODYxLmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8ed2a9490cb560100000c&m=1472786194","list_dtime":"2016-09-02 11:06:48"},{"pk":"57c8e4169490cbde17000029","title":"爸3孩子们大聚会，诺一已经黑得认不出","date":"2016-09-02 10:29:42","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8e4169490cbde17000029","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4NjEwMV8yNDQ3MV9XNjQwSDM2MFM2ODg3Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4NjEwMV8yNDQ3MV9XNjQwSDM2MFM2ODg3Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8e4169490cbde17000029&m=1472786169","list_dtime":"2016-09-02 10:29:42"},{"pk":"57c8e3989490cb421800001f","title":"16年13张封面，见证了章子怡的蜕变","date":"2016-09-02 10:27:36","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8e3989490cb421800001f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c81e271bc8e0bb0a00004f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c81e271bc8e0bb0a00004f_320.jpg","thumbnail_picsize":"600,390","media_count":"29","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8e3989490cb421800001f&m=1472786692","list_dtime":"2016-09-02 10:27:36"},{"pk":"57c8e02b9490cbfd1700001e","title":"48岁陈红近照 和宠物狗贴脸充满童趣","title_line_break":"48岁陈红近照\n和宠物狗贴脸充满童趣","date":"2016-09-02 10:12:59","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8e02b9490cbfd1700001e","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8dfbe7f52e9866e000087_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8dfbe7f52e9866e000087_320.jpg","thumbnail_picsize":"420,500","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8e02b9490cbfd1700001e&m=1472782484","list_dtime":"2016-09-02 10:12:59"},{"pk":"57c8dfc59490cbd117000019","title":"权志龙穿着自己的衣服拍大片简直帅飞！","date":"2016-09-02 10:11:17","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8dfc59490cbd117000019","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d2b71bc8e0786e000061_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d2b71bc8e0786e000061_320.jpg","thumbnail_picsize":"600,402","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8dfc59490cbd117000019&m=1472782513","list_dtime":"2016-09-02 10:11:17"},{"pk":"57c8de719490cbf91700002b","title":"李沁晒何润东婚礼内场照 ","title_line_break":"李沁晒何润东婚礼内场照\n","date":"2016-09-02 10:05:37","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57c8de719490cbf91700002b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d2131bc8e0896f000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d2131bc8e0896f000011_320.jpg","thumbnail_picsize":"483,493","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57c8de719490cbf91700002b&m=1472782033","list_dtime":"2016-09-02 10:05:37"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cd04409490cbe67d000027,57cd06db9490cb0b7e000046,57cced699490cb177e000020,57cce4799490cb1a7e000029,57ccdfa29490cb4d7e000026,57ccda6c9490cb1a7e000027","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57ccd6539490cbec7d000026,57ccd66b9490cbe87d00003b,57ccd3159490cb247e000036,57ccd2c49490cb157e00001e,57ccd17c9490cb267e000034,57cccf2f9490cb137e000026","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cbb8d79490cbe03500003c,57cbe04e9490cbce3500003d,57cbb4bc9490cba43500003e,57cb92039490cb8235000031,57cb8e399490cbec35000023,57cb8aed9490cbbe35000024","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cb8a0e9490cb9035000027,57cb8aa19490cbd335000025,57cb83c99490cba835000028,57cb81d79490cb9035000018,57cb7c2f9490cbe835000021,57cb7c269490cb933500001c","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57c9209e9490cb2318000047,57c9404d9490cb091800004c,57c917079490cb2818000029,57c8f8df9490cb1018000038,57c8f65b9490cbe517000024,57c8f6149490cbe51700001d","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c8e4169490cbde17000029,57c8ed2a9490cb560100000c,57c8e3989490cb421800001f,57c8e02b9490cbfd1700001e,57c8dfc59490cbd117000019,57c8de719490cbf91700002b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#5700b9","#5700b9"],"only_text_page_bgcolors":["#5700b9","#5700b9"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12348.png?t=1459499793","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/12348.png?t=1459499793","hidden_time":"24","need_userinfo":"NO","block_title":"明星","block_color":"#5700b9","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_a554ee1915f294ad77def365f71f3e85","selected_index":"3","list":[{"pk":"zk_app_column_9","title":"娱乐","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_10530","title":"电影","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"10530_zk_app_column_block_9","title":"电影资讯","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=10530&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_11698","title":"电视","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11698_zk_app_column_block_9","title":"电视","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11698&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_12348","title":"明星","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12348_zk_app_column_block_9","title":"明星","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12348&catalog_appid=9","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=12348&since_date=1472781937&nt=1&_appid=androidphone&catalog_appid=9
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=12348&need_app_integration=
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=12348&ids=51a7104681853dec4d00012f&k=201609051500
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/12348.png?t=1459499793
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/12348.png?t=1459499793
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 明星
         * block_color : #5700b9
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_a554ee1915f294ad77def365f71f3e85
         * selected_index : 3
         * list : [{"pk":"zk_app_column_9","title":"娱乐","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_10530","title":"电影","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"10530_zk_app_column_block_9","title":"电影资讯","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=10530&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_11698","title":"电视","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11698_zk_app_column_block_9","title":"电视","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11698&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_12348","title":"明星","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12348_zk_app_column_block_9","title":"明星","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12348&catalog_appid=9","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57cd06db9490cb0b7e000046
         * title : 佟丽娅晒仙气美照 纯白连衣裙优雅十足
         * title_line_break : 佟丽娅晒仙气美照
         纯白连衣裙优雅十足
         * date : 2016-09-05 13:47:07
         * auther_name : Yes娱乐
         * weburl : http://iphone.myzaker.com/l.php?l=57cd06db9490cb0b7e000046
         * thumbnail_pic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDUwNV81Mzc0Ml9XNjQwSDM2MFMzMDE1Mi5qcGc=_1242.jpg
         * thumbnail_mpic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDUwNV81Mzc0Ml9XNjQwSDM2MFMzMDE1Mi5qcGc=_1242.jpg
         * thumbnail_picsize : 640,360
         * media_count : 1
         * is_full : NO
         * content :
         * special_info : {"show_jingcai":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=12348&pk=57cd06db9490cb0b7e000046&m=1473054506
         * list_dtime : 2016-09-05 13:47:07
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 3
             * articles : 57cd04409490cbe67d000027,57cd06db9490cb0b7e000046,57cced699490cb177e000020,57cce4799490cb1a7e000029,57ccdfa29490cb4d7e000026,57ccda6c9490cb1a7e000027
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * open_type :
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_9
             * title : 娱乐
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 9
                 * title : 娱乐八卦
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9
                 * data_type : news
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String title_line_break;
            private String date;
            private String auther_name;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String is_full;
            private String content;
            /**
             * show_jingcai : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getTitle_line_break() {
                return title_line_break;
            }

            public void setTitle_line_break(String title_line_break) {
                this.title_line_break = title_line_break;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String show_jingcai;

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }
            }
        }
    }
}
