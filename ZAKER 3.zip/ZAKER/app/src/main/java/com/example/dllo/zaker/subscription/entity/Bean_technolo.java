package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class Bean_technolo {


    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=1039&since_date=1472691523&nt=1&next_aticle_id=57c7b5d79490cb3b0f000001&_appid=androidphone&opage=2&otimestamp=190&catalog_appid=13","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=1039&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=1039&ids=5642f2aa9490cbb13200000e,5524c7859490cbd61e000093,51a7103481853d8f4c000143&k=201609051540"},"catalog":"","articles":[{"pk":"57c855369490cbf62f000000","title":"科学家收到\u201c来自外太空的神秘强烈讯号\u201d","date":"2016-09-05 03:59:35","auther_name":"优觅小闹-科学","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c855369490cbf62f000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyODYyNl82OTg0N19XNjQwSDM2MFM2Mzc0Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyODYyNl82OTg0N19XNjQwSDM2MFM2Mzc0Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c855369490cbf62f000000&m=1473061505","list_dtime":"2016-09-05 03:59:35"},{"pk":"57c02c751bc8e0654f000014","title":"牙缝中间为什么会有黑黑的东西？","date":"2016-09-05 03:56:09","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c02c751bc8e0654f000014","thumbnail_pic":"http://zkres.myzaker.com/201608/57c02c7a7f52e9d8460000dc_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c02c7a7f52e9d8460000dc_320.jpg","thumbnail_picsize":"450,333","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c02c751bc8e0654f000014&m=1473061332","list_dtime":"2016-09-05 03:56:09"},{"pk":"57c96aff1bc8e00756000004","title":"冬天的时候苍蝇蚊子都去哪儿了？","date":"2016-09-04 23:20:00","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c96aff1bc8e00756000004","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyODQzMF82MTA4M19XNjQwSDM2MFMyNjEzNi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyODQzMF82MTA4M19XNjQwSDM2MFMyNjEzNi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c96aff1bc8e00756000004&m=1473061332","list_dtime":"2016-09-04 23:20:00"},{"pk":"57ccde899490cbd51f000004","title":"10个星期到达火星，曲速引擎即将测试","date":"2016-09-05 12:15:36","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccde899490cbd51f000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd8cb7f52e93c7f0000bd_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd8cb7f52e93c7f0000bd_320.jpg","thumbnail_picsize":"550,333","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccde899490cbd51f000004&m=1473061058","list_dtime":"2016-09-05 12:15:36"},{"pk":"57ccaaf99490cb7b0f000002","title":"中国卫星拍到美国神秘51区，曝超长跑道","date":"2016-09-05 12:59:59","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccaaf99490cb7b0f000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca89b7f52e97603000045_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca89b7f52e97603000045_320.jpg","thumbnail_picsize":"600,327","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccaaf99490cb7b0f000002&m=1473061058","list_dtime":"2016-09-05 12:59:59"},{"pk":"57ccbb619490cb6962000007","title":"科幻成真？NASA研发太空船牵引光束","date":"2016-09-05 11:12:54","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccbb619490cb6962000007","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb5be7f52e9ae52000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb5be7f52e9ae52000000_320.jpg","thumbnail_picsize":"550,359","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccbb619490cb6962000007&m=1473061058","list_dtime":"2016-09-05 11:12:54"},{"pk":"57c425f31bc8e03809000003","title":"你家有没有钱，用卫星图片一算便知","date":"2016-09-05 03:54:16","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c425f31bc8e03809000003","thumbnail_pic":"http://zkres.myzaker.com/201608/57c425f77f52e9a729000172_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c425f77f52e9a729000172_320.jpg","thumbnail_picsize":"450,269","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c425f31bc8e03809000003&m=1473061332","list_dtime":"2016-09-05 03:54:16"},{"pk":"57c2ce4a1bc8e03e47000012","title":"喝酒前吃什么不容易醉？","date":"2016-09-05 03:55:26","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c2ce4a1bc8e03e47000012","thumbnail_pic":"http://zkres.myzaker.com/201608/57c2ce4f7f52e9cd310000c2_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c2ce4f7f52e9cd310000c2_320.jpg","thumbnail_picsize":"450,279","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c2ce4a1bc8e03e47000012&m=1473061332","list_dtime":"2016-09-05 03:55:26"},{"pk":"57ccd9da9490cb1b06000004","title":"关于人类未来的20个问题","date":"2016-09-05 11:11:09","auther_name":"译言","weburl":"http://iphone.myzaker.com/l.php?l=57ccd9da9490cb1b06000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd6927f52e9577f0000ca_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd6927f52e9577f0000ca_320.jpg","thumbnail_picsize":"590,393","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccd9da9490cb1b06000004&m=1473061331","list_dtime":"2016-09-05 11:11:09"},{"pk":"57ccf3a19490cb580e000001","title":"猫王降临：狮虎豹轮番登场！","title_line_break":"猫王降临：\n狮虎豹轮番登场！","date":"2016-09-05 12:52:46","auther_name":"果壳网","weburl":"http://iphone.myzaker.com/l.php?l=57ccf3a19490cb580e000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccefe91bc8e02369000027_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccefe91bc8e02369000027_320.jpg","thumbnail_picsize":"480,318","media_count":"24","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccf3a19490cb580e000001&m=1473061058","list_dtime":"2016-09-05 12:52:46"},{"pk":"57c814f91bc8e0b506000003","title":"你必须知道的癌症\u201c八大警号\u201d","date":"2016-09-05 02:51:39","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c814f91bc8e0b506000003","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8136e7f52e9555600029d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8136e7f52e9555600029d_320.jpg","thumbnail_picsize":"450,300","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c814f91bc8e0b506000003&m=1473061332","list_dtime":"2016-09-05 02:51:39"},{"pk":"57ca38049490cb2464000002","title":"为什么我们需要三天周末","date":"2016-09-05 12:58:43","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57ca38049490cb2464000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca36977f52e91230000079_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca36977f52e91230000079_320.jpg","thumbnail_picsize":"600,399","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ca38049490cb2464000002&m=1473061058","list_dtime":"2016-09-05 12:58:43"},{"pk":"57cce20f9490cbba31000002","title":"人类真的有第六种味觉？","date":"2016-09-05 12:56:59","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57cce20f9490cbba31000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce1567f52e96231000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce1567f52e96231000000_320.jpg","thumbnail_picsize":"600,405","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cce20f9490cbba31000002&m=1473061058","list_dtime":"2016-09-05 12:56:59"},{"pk":"57ccfa1d9490cb297e00002e","title":"人类能了解的宇宙究竟有多少？","date":"2016-09-05 12:52:15","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57ccfa1d9490cb297e00002e","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccfa1d9490cb297e00002e&m=1473061058","list_dtime":"2016-09-05 12:52:15"},{"pk":"57ccfaa89490cb572f000001","title":"你知道圣诞老人的驯鹿被雷劈了吗","date":"2016-09-05 13:01:00","auther_name":"果壳网","weburl":"http://iphone.myzaker.com/l.php?l=57ccfaa89490cb572f000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccefe21bc8e0236900001b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccefe21bc8e0236900001b_320.jpg","thumbnail_picsize":"480,320","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccfaa89490cb572f000001&m=1473061058","list_dtime":"2016-09-05 13:01:00"},{"pk":"57cc0d9d1bc8e0785b00000d","title":"你家的床单可能有千万只螨虫你知道吗","date":"2016-09-05 02:48:47","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57cc0d9d1bc8e0785b00000d","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc0cd57f52e9b85200025a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc0cd57f52e9b85200025a_320.jpg","thumbnail_picsize":"450,270","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cc0d9d1bc8e0785b00000d&m=1473061332","list_dtime":"2016-09-05 02:48:47"},{"pk":"57cc3e009490cb395900000b","title":"煎蛋小学堂：你会如何死去","title_line_break":"煎蛋小学堂：\n你会如何死去","date":"2016-09-05 07:34:34","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57cc3e009490cb395900000b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc3d067f52e9b85200060e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc3d067f52e9b85200060e_320.jpg","thumbnail_picsize":"600,337","media_count":"1","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","video_inside":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57cc3e009490cb395900000b&title=%E7%85%8E%E8%9B%8B%E5%B0%8F%E5%AD%A6%E5%A0%82%EF%BC%9A%E4%BD%A0%E4%BC%9A%E5%A6%82%E4%BD%95%E6%AD%BB%E5%8E%BB&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57cc3e009490cb395900000b%26app_id%3D1039%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cc3e009490cb395900000b&m=1473061331","list_dtime":"2016-09-05 07:34:34"},{"pk":"57ccf01c9490cb127b000004","title":"柑橘打甜蜜素？\u201c农民爆料\u201d能信吗？","date":"2016-09-05 12:57:34","auther_name":"果壳网","weburl":"http://iphone.myzaker.com/l.php?l=57ccf01c9490cb127b000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccefe71bc8e02369000021_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccefe71bc8e02369000021_320.jpg","thumbnail_picsize":"555,596","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccf01c9490cb127b000004&m=1473061058","list_dtime":"2016-09-05 12:57:34"},{"pk":"57cbc9fa9490cbb609000002","title":"这篇论文的作者居然是个喵星人","date":"2016-09-05 03:58:23","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57cbc9fa9490cbb609000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbc6927f52e9e92b00026e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbc6927f52e9e92b00026e_320.jpg","thumbnail_picsize":"600,368","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cbc9fa9490cbb609000002&m=1473061332","list_dtime":"2016-09-05 03:58:23"},{"pk":"57c663651bc8e06d73000022","title":"感冒真的是\u201c无药可医\u201d吗？","date":"2016-09-05 02:53:13","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c663651bc8e06d73000022","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c663651bc8e06d73000022&m=1473061332","list_dtime":"2016-09-05 02:53:13"},{"pk":"57cd089d9490cb972200001c","title":"模拟火星生存是一种怎样的体验？","date":"2016-09-05 13:53:39","auther_name":"蝌蚪五线谱","weburl":"http://iphone.myzaker.com/l.php?l=57cd089d9490cb972200001c","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd08a4a07aecc52301fd37_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd08a4a07aecc52301fd37_320.jpg","thumbnail_picsize":"799,449","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cd089d9490cb972200001c&m=1473061058","list_dtime":"2016-09-05 13:53:39"},{"pk":"57c7c5779490cbd72c000044","title":"老婆把牙刷扔进酒精浸泡一会后惊呆了","date":"2016-09-04 14:00:01","auther_name":"央视财经","weburl":"http://iphone.myzaker.com/l.php?l=57c7c5779490cbd72c000044","thumbnail_pic":"http://zkres.myzaker.com/201608/57c65b927f52e9a875000093_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c65b927f52e9a875000093_320.jpg","thumbnail_picsize":"500,332","media_count":"25","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c7c5779490cbd72c000044&m=1473054754","list_dtime":"2016-09-04 14:00:01"},{"pk":"57c926201bc8e01127000013","title":"纳米结构让你在夏天凉爽","date":"2016-09-05 02:50:21","auther_name":"科学公园","weburl":"http://iphone.myzaker.com/l.php?l=57c926201bc8e01127000013","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9261f1bc8e01127000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9261f1bc8e01127000011_320.jpg","thumbnail_picsize":"500,337","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c926201bc8e01127000013&m=1473061332","list_dtime":"2016-09-05 02:50:21"},{"pk":"57cd15399490cb0a7e000035","title":"大熊猫已不再濒临灭绝 降级至易危","title_line_break":"大熊猫已不再濒临灭绝\n降级至易危","date":"2016-09-05 14:46:57","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57cd15399490cb0a7e000035","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd1546a07aecc5230205e2_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd1546a07aecc5230205e2_320.jpg","thumbnail_picsize":"1190,791","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cd15399490cb0a7e000035&m=1473061058","list_dtime":"2016-09-05 14:46:57"},{"pk":"57c851b69490cbb91d00000b","title":"新哥斯拉袭击东京，到底会造成多少损失","date":"2016-09-04 13:56:16","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57c851b69490cbb91d00000b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8514f7f52e9d9090003f0_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8514f7f52e9d9090003f0_320.jpg","thumbnail_picsize":"590,442","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c851b69490cbb91d00000b&m=1473054482","list_dtime":"2016-09-04 13:56:16"},{"pk":"57c827809490cb045a000000","title":"东京是日本法定首都？谷歌：这你就错了","title_line_break":"东京是日本法定首都？谷歌：\n这你就错了","date":"2016-09-04 13:57:02","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57c827809490cb045a000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57c806eb7f52e94818000017_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c806eb7f52e94818000017_320.jpg","thumbnail_picsize":"604,402","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c827809490cb045a000000&m=1473054482","list_dtime":"2016-09-04 13:57:02"},{"pk":"57cabff49490cbb628000000","title":"史前的真实猫狗大战：猫科动物占上风","title_line_break":"史前的真实猫狗大战：\n猫科动物占上风","date":"2016-09-04 13:46:21","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cabff49490cbb628000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57cab9a87f52e9d1480005bd_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cab9a87f52e9d1480005bd_320.jpg","thumbnail_picsize":"544,326","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cabff49490cbb628000000&m=1473053938","list_dtime":"2016-09-04 13:46:21"},{"pk":"57cb6fbc9490cb0d3a000004","title":"中国成功研制能耐一千度的新型耐火纸","date":"2016-09-04 13:39:12","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cb6fbc9490cb0d3a000004","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cb6fbc9490cb0d3a000004&m=1473053667","list_dtime":"2016-09-04 13:39:12"},{"pk":"57c8d2979490cb8630000000","title":"风景独好：世界上最高的墓地","title_line_break":"风景独好：\n世界上最高的墓地","date":"2016-09-04 13:54:37","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57c8d2979490cb8630000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d03f7f52e9456d000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d03f7f52e9456d000002_320.jpg","thumbnail_picsize":"600,421","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c8d2979490cb8630000000&m=1473054482","list_dtime":"2016-09-04 13:54:37"},{"pk":"57ca78779490cb6b32000001","title":"笔仙碟仙的历史：通灵板溯源","title_line_break":"笔仙碟仙的历史：\n通灵板溯源","date":"2016-09-04 13:47:08","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57ca78779490cb6b32000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca756f7f52e94b700002a5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca756f7f52e94b700002a5_320.jpg","thumbnail_picsize":"375,281","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ca78779490cb6b32000001&m=1473053938","list_dtime":"2016-09-04 13:47:08"},{"pk":"57cb65319490cbb902000005","title":"知道吗？你家床单可能有1500万只螨虫","date":"2016-09-04 11:16:58","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57cb65319490cbb902000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1OTA1OF8yMzc3NF9XNjQwSDM2MFM0OTY4Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1OTA1OF8yMzc3NF9XNjQwSDM2MFM0OTY4Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cb65319490cbb902000005&m=1473044937","list_dtime":"2016-09-04 11:16:58"},{"pk":"57caeed39490cb511b000001","title":"世界上第一对同卵双胞胎小狗","date":"2016-09-04 13:40:59","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57caeed39490cb511b000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57caee267f52e958310000ac_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57caee267f52e958310000ac_320.jpg","thumbnail_picsize":"600,379","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57caeed39490cb511b000001&m=1473053667","list_dtime":"2016-09-04 13:40:59"},{"pk":"57c93ae69490cbcb3b000002","title":"上大学了，哪些是老师不教但非常重要","date":"2016-09-04 13:52:59","auther_name":"壹心理","weburl":"http://iphone.myzaker.com/l.php?l=57c93ae69490cbcb3b000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57c938a61bc8e0ca32000048_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c938a61bc8e0ca32000048_320.jpg","thumbnail_picsize":"640,437","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c93ae69490cbcb3b000002&m=1473054482","list_dtime":"2016-09-04 13:52:59"},{"pk":"57cab8ec9490cb6103000000","title":"科普：镁离子电池为什么比锂电池牛？","title_line_break":"科普：\n镁离子电池为什么比锂电池牛？","date":"2016-09-04 13:40:04","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cab8ec9490cb6103000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57cab5da7f52e97d22000504_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cab5da7f52e97d22000504_320.jpg","thumbnail_picsize":"296,223","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cab8ec9490cb6103000000&m=1473053667","list_dtime":"2016-09-04 13:40:04"},{"pk":"57cb87c11bc8e07d3f000020","title":"太美了！美国宇航局首次公布木星高清照片","date":"2016-09-04 10:32:33","auther_name":"国际在线","weburl":"http://iphone.myzaker.com/l.php?l=57cb87c11bc8e07d3f000020","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb881ea07aecc5230108a8_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb881ea07aecc5230108a8_320.jpg","thumbnail_picsize":"640,640","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cb87c11bc8e07d3f000020&m=1473042237","list_dtime":"2016-09-04 10:32:33"},{"pk":"57c2ce4b1bc8e03e47000013","title":"如何让异性对你有感觉？","date":"2016-09-04 06:09:26","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c2ce4b1bc8e03e47000013","thumbnail_pic":"http://zkres.myzaker.com/201608/57c2ce517f52e9cf310000a9_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c2ce517f52e9cf310000a9_320.jpg","thumbnail_picsize":"440,295","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c2ce4b1bc8e03e47000013&m=1473026644","list_dtime":"2016-09-04 06:09:26"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c855369490cbf62f000000,57c02c751bc8e0654f000014,57c96aff1bc8e00756000004,57ccde899490cbd51f000004,57ccaaf99490cb7b0f000002,57ccbb619490cb6962000007","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c2ce4a1bc8e03e47000012,57c425f31bc8e03809000003,57ccd9da9490cb1b06000004,57ccf3a19490cb580e000001,57c814f91bc8e0b506000003,57ca38049490cb2464000002","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ccfaa89490cb572f000001,57ccfa1d9490cb297e00002e,57cce20f9490cbba31000002,57cc0d9d1bc8e0785b00000d,57cc3e009490cb395900000b,57ccf01c9490cb127b000004","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cd089d9490cb972200001c,57c663651bc8e06d73000022,57cbc9fa9490cbb609000002,57c7c5779490cbd72c000044,57c926201bc8e01127000013,57cd15399490cb0a7e000035","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c827809490cb045a000000,57c851b69490cbb91d00000b,57cabff49490cbb628000000,57cb6fbc9490cb0d3a000004,57c8d2979490cb8630000000,57ca78779490cb6b32000001","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57caeed39490cb511b000001,57cb65319490cbb902000005,57c93ae69490cbcb3b000002,57cab8ec9490cb6103000000,57cb87c11bc8e07d3f000020,57c2ce4b1bc8e03e47000013","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}}],"article_block_colors":["#5c6675","#5c6675"],"only_text_page_bgcolors":["#5c6675","#5c6675"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/1039.png?1420357676","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/1039.png?1420357676","hidden_time":"24","need_userinfo":"NO","block_title":"科学频道","block_color":"#5c6675","desktop_color_number":"5","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_52fd79cc1dcd068c2376a8943140714b","selected_index":"3","list":[{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]}}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=1039&since_date=1472691523&nt=1&next_aticle_id=57c7b5d79490cb3b0f000001&_appid=androidphone&opage=2&otimestamp=190&catalog_appid=13","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=1039&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=1039&ids=5642f2aa9490cbb13200000e,5524c7859490cbd61e000093,51a7103481853d8f4c000143&k=201609051540"}
     * catalog :
     * articles : [{"pk":"57c855369490cbf62f000000","title":"科学家收到\u201c来自外太空的神秘强烈讯号\u201d","date":"2016-09-05 03:59:35","auther_name":"优觅小闹-科学","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c855369490cbf62f000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyODYyNl82OTg0N19XNjQwSDM2MFM2Mzc0Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyODYyNl82OTg0N19XNjQwSDM2MFM2Mzc0Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c855369490cbf62f000000&m=1473061505","list_dtime":"2016-09-05 03:59:35"},{"pk":"57c02c751bc8e0654f000014","title":"牙缝中间为什么会有黑黑的东西？","date":"2016-09-05 03:56:09","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c02c751bc8e0654f000014","thumbnail_pic":"http://zkres.myzaker.com/201608/57c02c7a7f52e9d8460000dc_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c02c7a7f52e9d8460000dc_320.jpg","thumbnail_picsize":"450,333","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c02c751bc8e0654f000014&m=1473061332","list_dtime":"2016-09-05 03:56:09"},{"pk":"57c96aff1bc8e00756000004","title":"冬天的时候苍蝇蚊子都去哪儿了？","date":"2016-09-04 23:20:00","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c96aff1bc8e00756000004","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyODQzMF82MTA4M19XNjQwSDM2MFMyNjEzNi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyODQzMF82MTA4M19XNjQwSDM2MFMyNjEzNi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c96aff1bc8e00756000004&m=1473061332","list_dtime":"2016-09-04 23:20:00"},{"pk":"57ccde899490cbd51f000004","title":"10个星期到达火星，曲速引擎即将测试","date":"2016-09-05 12:15:36","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccde899490cbd51f000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd8cb7f52e93c7f0000bd_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd8cb7f52e93c7f0000bd_320.jpg","thumbnail_picsize":"550,333","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccde899490cbd51f000004&m=1473061058","list_dtime":"2016-09-05 12:15:36"},{"pk":"57ccaaf99490cb7b0f000002","title":"中国卫星拍到美国神秘51区，曝超长跑道","date":"2016-09-05 12:59:59","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccaaf99490cb7b0f000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca89b7f52e97603000045_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca89b7f52e97603000045_320.jpg","thumbnail_picsize":"600,327","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccaaf99490cb7b0f000002&m=1473061058","list_dtime":"2016-09-05 12:59:59"},{"pk":"57ccbb619490cb6962000007","title":"科幻成真？NASA研发太空船牵引光束","date":"2016-09-05 11:12:54","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccbb619490cb6962000007","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb5be7f52e9ae52000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb5be7f52e9ae52000000_320.jpg","thumbnail_picsize":"550,359","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccbb619490cb6962000007&m=1473061058","list_dtime":"2016-09-05 11:12:54"},{"pk":"57c425f31bc8e03809000003","title":"你家有没有钱，用卫星图片一算便知","date":"2016-09-05 03:54:16","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c425f31bc8e03809000003","thumbnail_pic":"http://zkres.myzaker.com/201608/57c425f77f52e9a729000172_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c425f77f52e9a729000172_320.jpg","thumbnail_picsize":"450,269","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c425f31bc8e03809000003&m=1473061332","list_dtime":"2016-09-05 03:54:16"},{"pk":"57c2ce4a1bc8e03e47000012","title":"喝酒前吃什么不容易醉？","date":"2016-09-05 03:55:26","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c2ce4a1bc8e03e47000012","thumbnail_pic":"http://zkres.myzaker.com/201608/57c2ce4f7f52e9cd310000c2_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c2ce4f7f52e9cd310000c2_320.jpg","thumbnail_picsize":"450,279","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c2ce4a1bc8e03e47000012&m=1473061332","list_dtime":"2016-09-05 03:55:26"},{"pk":"57ccd9da9490cb1b06000004","title":"关于人类未来的20个问题","date":"2016-09-05 11:11:09","auther_name":"译言","weburl":"http://iphone.myzaker.com/l.php?l=57ccd9da9490cb1b06000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd6927f52e9577f0000ca_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd6927f52e9577f0000ca_320.jpg","thumbnail_picsize":"590,393","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccd9da9490cb1b06000004&m=1473061331","list_dtime":"2016-09-05 11:11:09"},{"pk":"57ccf3a19490cb580e000001","title":"猫王降临：狮虎豹轮番登场！","title_line_break":"猫王降临：\n狮虎豹轮番登场！","date":"2016-09-05 12:52:46","auther_name":"果壳网","weburl":"http://iphone.myzaker.com/l.php?l=57ccf3a19490cb580e000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccefe91bc8e02369000027_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccefe91bc8e02369000027_320.jpg","thumbnail_picsize":"480,318","media_count":"24","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccf3a19490cb580e000001&m=1473061058","list_dtime":"2016-09-05 12:52:46"},{"pk":"57c814f91bc8e0b506000003","title":"你必须知道的癌症\u201c八大警号\u201d","date":"2016-09-05 02:51:39","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c814f91bc8e0b506000003","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8136e7f52e9555600029d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8136e7f52e9555600029d_320.jpg","thumbnail_picsize":"450,300","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c814f91bc8e0b506000003&m=1473061332","list_dtime":"2016-09-05 02:51:39"},{"pk":"57ca38049490cb2464000002","title":"为什么我们需要三天周末","date":"2016-09-05 12:58:43","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57ca38049490cb2464000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca36977f52e91230000079_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca36977f52e91230000079_320.jpg","thumbnail_picsize":"600,399","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ca38049490cb2464000002&m=1473061058","list_dtime":"2016-09-05 12:58:43"},{"pk":"57cce20f9490cbba31000002","title":"人类真的有第六种味觉？","date":"2016-09-05 12:56:59","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57cce20f9490cbba31000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce1567f52e96231000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce1567f52e96231000000_320.jpg","thumbnail_picsize":"600,405","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cce20f9490cbba31000002&m=1473061058","list_dtime":"2016-09-05 12:56:59"},{"pk":"57ccfa1d9490cb297e00002e","title":"人类能了解的宇宙究竟有多少？","date":"2016-09-05 12:52:15","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57ccfa1d9490cb297e00002e","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccfa1d9490cb297e00002e&m=1473061058","list_dtime":"2016-09-05 12:52:15"},{"pk":"57ccfaa89490cb572f000001","title":"你知道圣诞老人的驯鹿被雷劈了吗","date":"2016-09-05 13:01:00","auther_name":"果壳网","weburl":"http://iphone.myzaker.com/l.php?l=57ccfaa89490cb572f000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccefe21bc8e0236900001b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccefe21bc8e0236900001b_320.jpg","thumbnail_picsize":"480,320","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccfaa89490cb572f000001&m=1473061058","list_dtime":"2016-09-05 13:01:00"},{"pk":"57cc0d9d1bc8e0785b00000d","title":"你家的床单可能有千万只螨虫你知道吗","date":"2016-09-05 02:48:47","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57cc0d9d1bc8e0785b00000d","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc0cd57f52e9b85200025a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc0cd57f52e9b85200025a_320.jpg","thumbnail_picsize":"450,270","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cc0d9d1bc8e0785b00000d&m=1473061332","list_dtime":"2016-09-05 02:48:47"},{"pk":"57cc3e009490cb395900000b","title":"煎蛋小学堂：你会如何死去","title_line_break":"煎蛋小学堂：\n你会如何死去","date":"2016-09-05 07:34:34","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57cc3e009490cb395900000b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc3d067f52e9b85200060e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc3d067f52e9b85200060e_320.jpg","thumbnail_picsize":"600,337","media_count":"1","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","video_inside":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57cc3e009490cb395900000b&title=%E7%85%8E%E8%9B%8B%E5%B0%8F%E5%AD%A6%E5%A0%82%EF%BC%9A%E4%BD%A0%E4%BC%9A%E5%A6%82%E4%BD%95%E6%AD%BB%E5%8E%BB&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57cc3e009490cb395900000b%26app_id%3D1039%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cc3e009490cb395900000b&m=1473061331","list_dtime":"2016-09-05 07:34:34"},{"pk":"57ccf01c9490cb127b000004","title":"柑橘打甜蜜素？\u201c农民爆料\u201d能信吗？","date":"2016-09-05 12:57:34","auther_name":"果壳网","weburl":"http://iphone.myzaker.com/l.php?l=57ccf01c9490cb127b000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccefe71bc8e02369000021_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccefe71bc8e02369000021_320.jpg","thumbnail_picsize":"555,596","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ccf01c9490cb127b000004&m=1473061058","list_dtime":"2016-09-05 12:57:34"},{"pk":"57cbc9fa9490cbb609000002","title":"这篇论文的作者居然是个喵星人","date":"2016-09-05 03:58:23","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57cbc9fa9490cbb609000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbc6927f52e9e92b00026e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbc6927f52e9e92b00026e_320.jpg","thumbnail_picsize":"600,368","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cbc9fa9490cbb609000002&m=1473061332","list_dtime":"2016-09-05 03:58:23"},{"pk":"57c663651bc8e06d73000022","title":"感冒真的是\u201c无药可医\u201d吗？","date":"2016-09-05 02:53:13","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c663651bc8e06d73000022","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c663651bc8e06d73000022&m=1473061332","list_dtime":"2016-09-05 02:53:13"},{"pk":"57cd089d9490cb972200001c","title":"模拟火星生存是一种怎样的体验？","date":"2016-09-05 13:53:39","auther_name":"蝌蚪五线谱","weburl":"http://iphone.myzaker.com/l.php?l=57cd089d9490cb972200001c","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd08a4a07aecc52301fd37_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd08a4a07aecc52301fd37_320.jpg","thumbnail_picsize":"799,449","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cd089d9490cb972200001c&m=1473061058","list_dtime":"2016-09-05 13:53:39"},{"pk":"57c7c5779490cbd72c000044","title":"老婆把牙刷扔进酒精浸泡一会后惊呆了","date":"2016-09-04 14:00:01","auther_name":"央视财经","weburl":"http://iphone.myzaker.com/l.php?l=57c7c5779490cbd72c000044","thumbnail_pic":"http://zkres.myzaker.com/201608/57c65b927f52e9a875000093_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c65b927f52e9a875000093_320.jpg","thumbnail_picsize":"500,332","media_count":"25","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c7c5779490cbd72c000044&m=1473054754","list_dtime":"2016-09-04 14:00:01"},{"pk":"57c926201bc8e01127000013","title":"纳米结构让你在夏天凉爽","date":"2016-09-05 02:50:21","auther_name":"科学公园","weburl":"http://iphone.myzaker.com/l.php?l=57c926201bc8e01127000013","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9261f1bc8e01127000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9261f1bc8e01127000011_320.jpg","thumbnail_picsize":"500,337","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c926201bc8e01127000013&m=1473061332","list_dtime":"2016-09-05 02:50:21"},{"pk":"57cd15399490cb0a7e000035","title":"大熊猫已不再濒临灭绝 降级至易危","title_line_break":"大熊猫已不再濒临灭绝\n降级至易危","date":"2016-09-05 14:46:57","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57cd15399490cb0a7e000035","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd1546a07aecc5230205e2_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd1546a07aecc5230205e2_320.jpg","thumbnail_picsize":"1190,791","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cd15399490cb0a7e000035&m=1473061058","list_dtime":"2016-09-05 14:46:57"},{"pk":"57c851b69490cbb91d00000b","title":"新哥斯拉袭击东京，到底会造成多少损失","date":"2016-09-04 13:56:16","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57c851b69490cbb91d00000b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8514f7f52e9d9090003f0_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8514f7f52e9d9090003f0_320.jpg","thumbnail_picsize":"590,442","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c851b69490cbb91d00000b&m=1473054482","list_dtime":"2016-09-04 13:56:16"},{"pk":"57c827809490cb045a000000","title":"东京是日本法定首都？谷歌：这你就错了","title_line_break":"东京是日本法定首都？谷歌：\n这你就错了","date":"2016-09-04 13:57:02","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57c827809490cb045a000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57c806eb7f52e94818000017_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c806eb7f52e94818000017_320.jpg","thumbnail_picsize":"604,402","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c827809490cb045a000000&m=1473054482","list_dtime":"2016-09-04 13:57:02"},{"pk":"57cabff49490cbb628000000","title":"史前的真实猫狗大战：猫科动物占上风","title_line_break":"史前的真实猫狗大战：\n猫科动物占上风","date":"2016-09-04 13:46:21","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cabff49490cbb628000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57cab9a87f52e9d1480005bd_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cab9a87f52e9d1480005bd_320.jpg","thumbnail_picsize":"544,326","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cabff49490cbb628000000&m=1473053938","list_dtime":"2016-09-04 13:46:21"},{"pk":"57cb6fbc9490cb0d3a000004","title":"中国成功研制能耐一千度的新型耐火纸","date":"2016-09-04 13:39:12","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cb6fbc9490cb0d3a000004","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cb6fbc9490cb0d3a000004&m=1473053667","list_dtime":"2016-09-04 13:39:12"},{"pk":"57c8d2979490cb8630000000","title":"风景独好：世界上最高的墓地","title_line_break":"风景独好：\n世界上最高的墓地","date":"2016-09-04 13:54:37","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57c8d2979490cb8630000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d03f7f52e9456d000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d03f7f52e9456d000002_320.jpg","thumbnail_picsize":"600,421","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c8d2979490cb8630000000&m=1473054482","list_dtime":"2016-09-04 13:54:37"},{"pk":"57ca78779490cb6b32000001","title":"笔仙碟仙的历史：通灵板溯源","title_line_break":"笔仙碟仙的历史：\n通灵板溯源","date":"2016-09-04 13:47:08","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57ca78779490cb6b32000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca756f7f52e94b700002a5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca756f7f52e94b700002a5_320.jpg","thumbnail_picsize":"375,281","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57ca78779490cb6b32000001&m=1473053938","list_dtime":"2016-09-04 13:47:08"},{"pk":"57cb65319490cbb902000005","title":"知道吗？你家床单可能有1500万只螨虫","date":"2016-09-04 11:16:58","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57cb65319490cbb902000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1OTA1OF8yMzc3NF9XNjQwSDM2MFM0OTY4Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk1OTA1OF8yMzc3NF9XNjQwSDM2MFM0OTY4Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cb65319490cbb902000005&m=1473044937","list_dtime":"2016-09-04 11:16:58"},{"pk":"57caeed39490cb511b000001","title":"世界上第一对同卵双胞胎小狗","date":"2016-09-04 13:40:59","auther_name":"煎蛋","weburl":"http://iphone.myzaker.com/l.php?l=57caeed39490cb511b000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57caee267f52e958310000ac_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57caee267f52e958310000ac_320.jpg","thumbnail_picsize":"600,379","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57caeed39490cb511b000001&m=1473053667","list_dtime":"2016-09-04 13:40:59"},{"pk":"57c93ae69490cbcb3b000002","title":"上大学了，哪些是老师不教但非常重要","date":"2016-09-04 13:52:59","auther_name":"壹心理","weburl":"http://iphone.myzaker.com/l.php?l=57c93ae69490cbcb3b000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57c938a61bc8e0ca32000048_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c938a61bc8e0ca32000048_320.jpg","thumbnail_picsize":"640,437","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c93ae69490cbcb3b000002&m=1473054482","list_dtime":"2016-09-04 13:52:59"},{"pk":"57cab8ec9490cb6103000000","title":"科普：镁离子电池为什么比锂电池牛？","title_line_break":"科普：\n镁离子电池为什么比锂电池牛？","date":"2016-09-04 13:40:04","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cab8ec9490cb6103000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57cab5da7f52e97d22000504_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cab5da7f52e97d22000504_320.jpg","thumbnail_picsize":"296,223","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cab8ec9490cb6103000000&m=1473053667","list_dtime":"2016-09-04 13:40:04"},{"pk":"57cb87c11bc8e07d3f000020","title":"太美了！美国宇航局首次公布木星高清照片","date":"2016-09-04 10:32:33","auther_name":"国际在线","weburl":"http://iphone.myzaker.com/l.php?l=57cb87c11bc8e07d3f000020","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb881ea07aecc5230108a8_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb881ea07aecc5230108a8_320.jpg","thumbnail_picsize":"640,640","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57cb87c11bc8e07d3f000020&m=1473042237","list_dtime":"2016-09-04 10:32:33"},{"pk":"57c2ce4b1bc8e03e47000013","title":"如何让异性对你有感觉？","date":"2016-09-04 06:09:26","auther_name":"百度知道日报","weburl":"http://iphone.myzaker.com/l.php?l=57c2ce4b1bc8e03e47000013","thumbnail_pic":"http://zkres.myzaker.com/201608/57c2ce517f52e9cf310000a9_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c2ce517f52e9cf310000a9_320.jpg","thumbnail_picsize":"440,295","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c2ce4b1bc8e03e47000013&m=1473026644","list_dtime":"2016-09-04 06:09:26"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c855369490cbf62f000000,57c02c751bc8e0654f000014,57c96aff1bc8e00756000004,57ccde899490cbd51f000004,57ccaaf99490cb7b0f000002,57ccbb619490cb6962000007","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c2ce4a1bc8e03e47000012,57c425f31bc8e03809000003,57ccd9da9490cb1b06000004,57ccf3a19490cb580e000001,57c814f91bc8e0b506000003,57ca38049490cb2464000002","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ccfaa89490cb572f000001,57ccfa1d9490cb297e00002e,57cce20f9490cbba31000002,57cc0d9d1bc8e0785b00000d,57cc3e009490cb395900000b,57ccf01c9490cb127b000004","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cd089d9490cb972200001c,57c663651bc8e06d73000022,57cbc9fa9490cbb609000002,57c7c5779490cbd72c000044,57c926201bc8e01127000013,57cd15399490cb0a7e000035","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c827809490cb045a000000,57c851b69490cbb91d00000b,57cabff49490cbb628000000,57cb6fbc9490cb0d3a000004,57c8d2979490cb8630000000,57ca78779490cb6b32000001","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57caeed39490cb511b000001,57cb65319490cbb902000005,57c93ae69490cbcb3b000002,57cab8ec9490cb6103000000,57cb87c11bc8e07d3f000020,57c2ce4b1bc8e03e47000013","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}}],"article_block_colors":["#5c6675","#5c6675"],"only_text_page_bgcolors":["#5c6675","#5c6675"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/1039.png?1420357676","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/1039.png?1420357676","hidden_time":"24","need_userinfo":"NO","block_title":"科学频道","block_color":"#5c6675","desktop_color_number":"5","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_52fd79cc1dcd068c2376a8943140714b","selected_index":"3","list":[{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=1039&since_date=1472691523&nt=1&next_aticle_id=57c7b5d79490cb3b0f000001&_appid=androidphone&opage=2&otimestamp=190&catalog_appid=13
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=1039&need_app_integration=
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=1039&ids=5642f2aa9490cbb13200000e,5524c7859490cbd61e000093,51a7103481853d8f4c000143&k=201609051540
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/1039.png?1420357676
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/1039.png?1420357676
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 科学频道
         * block_color : #5c6675
         * desktop_color_number : 5
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_52fd79cc1dcd068c2376a8943140714b
         * selected_index : 3
         * list : [{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57c855369490cbf62f000000
         * title : 科学家收到“来自外太空的神秘强烈讯号”
         * date : 2016-09-05 03:59:35
         * auther_name : 优觅小闹-科学
         * page : 1
         * index : 1
         * weburl : http://iphone.myzaker.com/l.php?l=57c855369490cbf62f000000
         * thumbnail_pic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyODYyNl82OTg0N19XNjQwSDM2MFM2Mzc0Ny5qcGc=_1242.jpg
         * thumbnail_mpic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgyODYyNl82OTg0N19XNjQwSDM2MFM2Mzc0Ny5qcGc=_1242.jpg
         * thumbnail_picsize : 640,360
         * media_count : 3
         * is_full : NO
         * content :
         * special_info : {"show_jingcai":"Y","list_nodsp":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1039&pk=57c855369490cbf62f000000&m=1473061505
         * list_dtime : 2016-09-05 03:59:35
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 3
             * articles : 57c855369490cbf62f000000,57c02c751bc8e0654f000014,57c96aff1bc8e00756000004,57ccde899490cbd51f000004,57ccaaf99490cb7b0f000002,57ccbb619490cb6962000007
             * diy : {"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * is_ad : Y
                 * stat_read_url : http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read
                 * ga_info : {"category":"AD","action":"Banner","send_after_showed":"Y"}
                 * open_type : web
                 * need_user_info : N
                 * open_confirm :
                 * ads_id : 5775c9899490cbef0300003b
                 * ads_title : 华为科技冠名160701-aPhone
                 * ad_pk : 5775c9899490cbef0300003b
                 * web_url : http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String is_ad;
                    private String stat_read_url;
                    /**
                     * category : AD
                     * action : Banner
                     * send_after_showed : Y
                     */

                    private GaInfoBean ga_info;
                    private String open_type;
                    private String need_user_info;
                    private String open_confirm;
                    private String ads_id;
                    private String ads_title;
                    private String ad_pk;
                    private String web_url;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getIs_ad() {
                        return is_ad;
                    }

                    public void setIs_ad(String is_ad) {
                        this.is_ad = is_ad;
                    }

                    public String getStat_read_url() {
                        return stat_read_url;
                    }

                    public void setStat_read_url(String stat_read_url) {
                        this.stat_read_url = stat_read_url;
                    }

                    public GaInfoBean getGa_info() {
                        return ga_info;
                    }

                    public void setGa_info(GaInfoBean ga_info) {
                        this.ga_info = ga_info;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }

                    public String getNeed_user_info() {
                        return need_user_info;
                    }

                    public void setNeed_user_info(String need_user_info) {
                        this.need_user_info = need_user_info;
                    }

                    public String getOpen_confirm() {
                        return open_confirm;
                    }

                    public void setOpen_confirm(String open_confirm) {
                        this.open_confirm = open_confirm;
                    }

                    public String getAds_id() {
                        return ads_id;
                    }

                    public void setAds_id(String ads_id) {
                        this.ads_id = ads_id;
                    }

                    public String getAds_title() {
                        return ads_title;
                    }

                    public void setAds_title(String ads_title) {
                        this.ads_title = ads_title;
                    }

                    public String getAd_pk() {
                        return ad_pk;
                    }

                    public void setAd_pk(String ad_pk) {
                        this.ad_pk = ad_pk;
                    }

                    public String getWeb_url() {
                        return web_url;
                    }

                    public void setWeb_url(String web_url) {
                        this.web_url = web_url;
                    }

                    public static class GaInfoBean {
                        private String category;
                        private String action;
                        private String send_after_showed;

                        public String getCategory() {
                            return category;
                        }

                        public void setCategory(String category) {
                            this.category = category;
                        }

                        public String getAction() {
                            return action;
                        }

                        public void setAction(String action) {
                            this.action = action;
                        }

                        public String getSend_after_showed() {
                            return send_after_showed;
                        }

                        public void setSend_after_showed(String send_after_showed) {
                            this.send_after_showed = send_after_showed;
                        }
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_13
             * title : 综合
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 13
                 * title : 科技频道
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13
                 * data_type : news
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String is_full;
            private String content;
            /**
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String show_jingcai;
                private String list_nodsp;

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }
            }
        }
    }
}
