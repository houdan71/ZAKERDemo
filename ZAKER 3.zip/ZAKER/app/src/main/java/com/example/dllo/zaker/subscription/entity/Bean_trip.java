package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/3.
 */
public class Bean_trip {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=981&since_date=1472456364&nt=1&next_aticle_id=57c6b6519490cbe04a00007e&_appid=androidphone&opage=2&otimestamp=177","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=981&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=981&ids=5642f2aa9490cbb13200000e,5472a9b69490cb48180000f9,51a7107581853dac4b000161&k=201609031440"},"catalog":"","articles":[{"pk":"57c931459490cbf817000063","title":"她有一张金喜善的脸，却在山西寺庙修壁画","date":"","auther_name":"大卫传奇艺术","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c931459490cbf817000063","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMTk2Nl80NjMzMV9XNjQwSDM2MFM1NDI4Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMTk2Nl80NjMzMV9XNjQwSDM2MFM1NDI4Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"41","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c931459490cbf817000063&m=1472884804","list_dtime":""},{"pk":"57ca41239490cbf93e000037","title":"颜值不够高不必担心，这样拍旅游照统统都会点赞","date":"","auther_name":"谈资","weburl":"http://iphone.myzaker.com/l.php?l=57ca41239490cbf93e000037","thumbnail_pic":"http://zkres.myzaker.com/201609/57c949931bc8e0c340000042_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c949931bc8e0c340000042_320.jpg","thumbnail_picsize":"500,482","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca41239490cbf93e000037&m=1472884591","list_dtime":""},{"pk":"57ca48199490cb1f3f000025","title":"国内有哪些冷门但有特色的旅游地点？","date":"","auther_name":"慢时间-旅游","weburl":"http://iphone.myzaker.com/l.php?l=57ca48199490cb1f3f000025","thumbnail_pic":"http://zkres.myzaker.com/201608/57c10cfa1bc8e0524f000009_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c10cfa1bc8e0524f000009_320.jpg","thumbnail_picsize":"441,329","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca48199490cb1f3f000025&m=1472884591","list_dtime":""},{"pk":"57ca44cb9490cb2b3f00001d","title":"中国有一个300万年的神奇冰洞，万古不化！","date":"","auther_name":"慢时间-旅游","weburl":"http://iphone.myzaker.com/l.php?l=57ca44cb9490cb2b3f00001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7738e1bc8e0a319000017_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7738e1bc8e0a319000017_320.jpg","thumbnail_picsize":"500,333","media_count":"37","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca44cb9490cb2b3f00001d&m=1472884591","list_dtime":""},{"pk":"57ca2aaf9490cbe33e000035","title":"如果你在云南，千万别错过云南中秋美食5日游","date":"","auther_name":"蚂蜂窝","weburl":"http://iphone.myzaker.com/l.php?l=57ca2aaf9490cbe33e000035","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9502b1bc8e00843000005_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9502b1bc8e00843000005_320.jpg","thumbnail_picsize":"600,402","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca2aaf9490cbe33e000035&m=1472884591","list_dtime":""},{"pk":"57c918cd9490cbde17000057","title":" 绝壁上的郭亮村成为世界上\u201c网红最险村庄\u201d","title_line_break":"\n绝壁上的郭亮村成为世界上\u201c网红最险村庄\u201d","date":"","auther_name":"凤凰旅游","weburl":"http://iphone.myzaker.com/l.php?l=57c918cd9490cbde17000057","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8c93a7f52e9b50c00003b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8c93a7f52e9b50c00003b_320.jpg","thumbnail_picsize":"981,627","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c918cd9490cbde17000057&m=1472884591","list_dtime":""},{"pk":"57ca2b1e9490cb273f00000e","title":"每年此时，好色之徒都会聚集到这里\u2026","date":"","auther_name":"阿里旅行","weburl":"http://iphone.myzaker.com/l.php?l=57ca2b1e9490cb273f00000e","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7e4a51bc8e095640000b9_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7e4a51bc8e095640000b9_320.jpg","thumbnail_picsize":"640,387","media_count":"13","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca2b1e9490cb273f00000e&m=1472884591","list_dtime":""},{"pk":"57ca2bd79490cb443f00002f","title":"这些忍不住让人吐槽的异形建筑，你见过几个？","date":"","auther_name":"GEO视界","weburl":"http://iphone.myzaker.com/l.php?l=57ca2bd79490cb443f00002f","thumbnail_pic":"http://zkres.myzaker.com/201608/57c66b707f52e9225e00023d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c66b707f52e9225e00023d_320.jpg","thumbnail_picsize":"496,626","media_count":"58","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca2bd79490cb443f00002f&m=1472884591","list_dtime":""},{"pk":"57c7f2591bc8e06261000062","title":"蓝色星球上还有最后的一片净土在这里等你","date":"","auther_name":"带你去看好风光","weburl":"http://iphone.myzaker.com/l.php?l=57c7f2591bc8e06261000062","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7f241a07aecf77e0483f1_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7f241a07aecf77e0483f1_320.jpg","thumbnail_picsize":"500,281","media_count":"22","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c7f2591bc8e06261000062&m=1472884591","list_dtime":""},{"pk":"57ca48b29490cbe23e000036","title":"世上最美的涂鸦胡同","date":"","auther_name":"楚鹏博客","weburl":"http://iphone.myzaker.com/l.php?l=57ca48b29490cbe23e000036","thumbnail_pic":"http://zkres.myzaker.com/201608/57c66bbb1bc8e0bc7a00000a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c66bbb1bc8e0bc7a00000a_320.jpg","thumbnail_picsize":"460,690","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca48b29490cbe23e000036&m=1472884591","list_dtime":""},{"pk":"57ca2a969490cbda3e00002e","title":"寻找一片净土，就去甘南朝圣吧！","date":"","auther_name":"蚂蜂窝","weburl":"http://iphone.myzaker.com/l.php?l=57ca2a969490cbda3e00002e","thumbnail_pic":"http://zkres.myzaker.com/201607/5799eea8a07aec6048011502_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201607/5799eea8a07aec6048011502_320.jpg","thumbnail_picsize":"600,328","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca2a969490cbda3e00002e&m=1472884591","list_dtime":""},{"pk":"57c8f0de9490cb5601000010","title":"新疆为什么不包邮？看了你就明白了","date":"","auther_name":"京内网","weburl":"http://iphone.myzaker.com/l.php?l=57c8f0de9490cb5601000010","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODAwM181OTUzMV9XNjQwSDM2MFM4MzY4My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODAwM181OTUzMV9XNjQwSDM2MFM4MzY4My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8f0de9490cb5601000010&m=1472797667","list_dtime":""},{"pk":"57c93d699490cb0218000071","title":"如何在旅行路上做一只高冷的单身狗？","date":"","auther_name":"星球研究所","weburl":"http://iphone.myzaker.com/l.php?l=57c93d699490cb0218000071","thumbnail_pic":"http://zkres.myzaker.com/201608/57b672497f52e9d5200001ec_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b672497f52e9d5200001ec_320.jpg","thumbnail_picsize":"1024,669","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c93d699490cb0218000071&m=1472884591","list_dtime":""},{"pk":"57c9185d9490cb2b1800003a","title":"中国有个被抛弃的小岛，美成了绿野仙踪！","date":"","auther_name":"环球旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c9185d9490cb2b1800003a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODIzN180OTk1Ml9XNjQwSDM2MFM4NTcwOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODIzN180OTk1Ml9XNjQwSDM2MFM4NTcwOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"40","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c9185d9490cb2b1800003a&m=1472798143","list_dtime":""},{"pk":"57c935249490cbeb1700004e","title":"96岁奶奶亏本买卖55年，温暖了所有人","date":"","auther_name":"佳人网","weburl":"http://iphone.myzaker.com/l.php?l=57c935249490cbeb1700004e","thumbnail_pic":"http://zkres.myzaker.com/201608/57c5f2701bc8e02e2e00001d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c5f2701bc8e02e2e00001d_320.jpg","thumbnail_picsize":"480,331","media_count":"29","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c935249490cbeb1700004e&m=1472804738","list_dtime":""},{"pk":"57c92beb9490cbdd1700004e","title":"都说说，中国最美的大学是哪儿？","date":"","auther_name":"ZAKER话题","weburl":"http://iphone.myzaker.com/l.php?l=57c92beb9490cbdd1700004e","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"61","title":"On the Road","stitle":"灵魂和身体总有一个在路上","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd42739490cb197b0000f8.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd42739490cb197b0000f8.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=61","block_color":"","subscribe_count":"193830","post_count":"8104","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=981&app_ids=981&pk=57c92beb9490cbdd1700004e&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c92beb9490cbdd1700004e","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c92beb9490cbdd1700004e&m=1472884592","list_dtime":""},{"pk":"57c91a4c9490cb351800004c","title":"不知道去哪儿，就去大理啊！","date":"","auther_name":"Feekr旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c91a4c9490cb351800004c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODM3Nl84NTA1Ml9XNjQwSDM2MFM3MzY4MC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODM3Nl84NTA1Ml9XNjQwSDM2MFM3MzY4MC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"22","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c91a4c9490cb351800004c&m=1472884592","list_dtime":""},{"pk":"57c912f89490cbd01700003c","title":"这些国外旅行地竟然比国内的还便宜！","date":"","auther_name":"京内网","weburl":"http://iphone.myzaker.com/l.php?l=57c912f89490cbd01700003c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODQxNl84MTU3OV9XNjQwSDM2MFM3MDU5My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODQxNl84MTU3OV9XNjQwSDM2MFM3MDU5My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"45","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c912f89490cbd01700003c&m=1472798438","list_dtime":""},{"pk":"57c918cd9490cbde17000058","title":"在活火山口上潜水是怎样一种体验？","date":"","auther_name":"凤凰旅游","weburl":"http://iphone.myzaker.com/l.php?l=57c918cd9490cbde17000058","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5Nzk1Ml82MjEzMV9XNjQwSDM2MFMzOTUwMi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5Nzk1Ml82MjEzMV9XNjQwSDM2MFMzOTUwMi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c918cd9490cbde17000058&m=1472798264","list_dtime":""},{"pk":"57c8df4f1bc8e07b3000002e","title":"张家界玻璃桥刚开放12天 被紧急叫停","title_line_break":"张家界玻璃桥刚开放12天\n被紧急叫停","date":"","auther_name":"红网","weburl":"http://iphone.myzaker.com/l.php?l=57c8df4f1bc8e07b3000002e","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8df3fa07aec13520022ea_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8df3fa07aec13520022ea_320.jpg","thumbnail_picsize":"495,329","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8df4f1bc8e07b3000002e&m=1472793596","list_dtime":""},{"pk":"57c91a4c9490cb351800004d","title":"先定一个小目标，比如说去看看初秋最美的地方","date":"","auther_name":"Feekr旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c91a4c9490cb351800004d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODQ4MF8zNjkwNV9XNjQwSDM2MFM2NDI3OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODQ4MF8zNjkwNV9XNjQwSDM2MFM2NDI3OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c91a4c9490cb351800004d&m=1472798741","list_dtime":""},{"pk":"57c91c871bc8e07630000045","title":"上天入地！全球那些脑洞大开的酒店","date":"","auther_name":" 带你去看好风光","weburl":"http://iphone.myzaker.com/l.php?l=57c91c871bc8e07630000045","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5NzkyN185NjE4OF9XNjQwSDM2MFMzMDA0NC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5NzkyN185NjE4OF9XNjQwSDM2MFMzMDA0NC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"30","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c91c871bc8e07630000045&m=1472798141","list_dtime":""},{"pk":"57c8f4d59490cbeb1700002f","title":"秋高气爽，正是动物们体检卖萌的好时机","date":"","auther_name":"iWeekly周末画报","weburl":"http://iphone.myzaker.com/l.php?l=57c8f4d59490cbeb1700002f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5Nzk2OV81NTUxOF9XNjQwSDM2MFM1MjA3Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5Nzk2OV81NTUxOF9XNjQwSDM2MFM1MjA3Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8f4d59490cbeb1700002f&m=1472797838","list_dtime":""},{"pk":"57c8dcc99490cbe41700001b","title":"英国一口被诅咒的井？物体接触井水后全变石头","date":"","auther_name":"蚂蜂窝","weburl":"http://iphone.myzaker.com/l.php?l=57c8dcc99490cbe41700001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c83ebc1bc8e0951e000009_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c83ebc1bc8e0951e000009_320.jpg","thumbnail_picsize":"600,364","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8dcc99490cbe41700001b&m=1472793596","list_dtime":""},{"pk":"57c8dcca9490cbe41700001c","title":"出了桂林，广西美景多了去了，关键是人少","date":"","auther_name":"蚂蜂窝","weburl":"http://iphone.myzaker.com/l.php?l=57c8dcca9490cbe41700001c","thumbnail_pic":"http://zkres.myzaker.com/201608/57a42263a07aec7c1001291f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57a42263a07aec7c1001291f_320.jpg","thumbnail_picsize":"600,389","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8dcca9490cbe41700001c&m=1472793596","list_dtime":""},{"pk":"57c80a839490cbb32c000066","title":"重庆的一个草原，美翻了一年四季！","date":"","auther_name":"阿里旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c80a839490cbb32c000066","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7e49c1bc8e09564000049_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7e49c1bc8e09564000049_320.jpg","thumbnail_picsize":"639,371","media_count":"52","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c80a839490cbb32c000066&m=1472793596","list_dtime":""},{"pk":"57c8dcca9490cbe41700001d","title":"迪拜已成过去，阿布扎比更富有更大气","date":"","auther_name":"蚂蜂窝","weburl":"http://iphone.myzaker.com/l.php?l=57c8dcca9490cbe41700001d","thumbnail_pic":"http://zkres.myzaker.com/201604/5705e17f1bc8e0991c000027_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201604/5705e17f1bc8e0991c000027_320.jpg","thumbnail_picsize":"600,382","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8dcca9490cbe41700001d&m=1472793596","list_dtime":""},{"pk":"57c8009e9490cbb12c00006b","title":"他们住在地球上最值钱的钻石坑边，却是最苦的穷鬼","date":"","auther_name":"ChokStick 骚货","weburl":"http://iphone.myzaker.com/l.php?l=57c8009e9490cbb12c00006b","thumbnail_pic":"http://zkres.myzaker.com/201608/57c675811bc8e08703000013_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c675811bc8e08703000013_320.jpg","thumbnail_picsize":"800,570","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8009e9490cbb12c00006b&m=1472793597","list_dtime":""},{"pk":"57c80a839490cbb32c000067","title":"\u200b 茶马古道上唯一幸存的千年古镇，山美水美","date":"","auther_name":"阿里旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c80a839490cbb32c000067","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7e4a21bc8e09564000090_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7e4a21bc8e09564000090_320.jpg","thumbnail_picsize":"640,426","media_count":"41","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c80a839490cbb32c000067&m=1472793596","list_dtime":""},{"pk":"57c80b239490cbca2c000078","title":"世界最长儿童铁路，工作人员全是儿童哦","date":"","auther_name":"蚂蜂窝","weburl":"http://iphone.myzaker.com/l.php?l=57c80b239490cbca2c000078","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4MDM1Nl82MjY4Ml9XNjQwSDM2MFM5MTYwMy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4MDM1Nl82MjY4Ml9XNjQwSDM2MFM5MTYwMy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c80b239490cbca2c000078&m=1472793596","list_dtime":""},{"pk":"57c7f7609490cbb22c00004c","title":"他们用2万块环游中国边境，风尘仆仆但美呆","date":"","auther_name":"一介","weburl":"http://iphone.myzaker.com/l.php?l=57c7f7609490cbb22c00004c","thumbnail_pic":"http://zkres.myzaker.com/201608/57b72af67f52e9047100028d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b72af67f52e9047100028d_320.jpg","thumbnail_picsize":"640,427","media_count":"29","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=981&pk=57c7f7609490cbb22c00004c&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c7f7609490cbb22c00004c%26app_id%3D981%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c7f7609490cbb22c00004c&m=1472793597","list_dtime":""},{"pk":"57c7f7609490cbb22c00004b","title":"你走过的路看过的风景，都会变成你","date":"","auther_name":"一介","weburl":"http://iphone.myzaker.com/l.php?l=57c7f7609490cbb22c00004b","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6f30c7f52e95b02000170_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6f30c7f52e95b02000170_320.jpg","thumbnail_picsize":"1280,1090","media_count":"17","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=981&pk=57c7f7609490cbb22c00004b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c7f7609490cbb22c00004b%26app_id%3D981%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c7f7609490cbb22c00004b&m=1472793597","list_dtime":""},{"pk":"57c808ea9490cb8d2c00009a","title":"澳大利亚美如画？胡说！明明比画还美","date":"","auther_name":" KLOOK客路旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c808ea9490cb8d2c00009a","thumbnail_pic":"http://zkres.myzaker.com/201609/57c808fda07aecf77e048f4b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c808fda07aecf77e048f4b_320.jpg","thumbnail_picsize":"600,400","media_count":"62","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c808ea9490cb8d2c00009a&m=1472793597","list_dtime":""},{"pk":"57c807039490cbaa2c000062","title":"世界十大顶尖建筑，有一个在中国！","date":"","auther_name":" KLOOK客路旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c807039490cbaa2c000062","thumbnail_pic":"http://zkres.myzaker.com/201609/57c80708a07aecf77e048d48_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c80708a07aecf77e048d48_320.jpg","thumbnail_picsize":"1006,764","media_count":"22","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c807039490cbaa2c000062&m=1472793597","list_dtime":""},{"pk":"57c7f9669490cb822c00008c","title":"日本其实没有\u201c首都\u201d！","date":"","auther_name":"奇趣发现","weburl":"http://iphone.myzaker.com/l.php?l=57c7f9669490cb822c00008c","thumbnail_pic":"http://zkres.myzaker.com/201609/57c78f5c1bc8e0592a000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c78f5c1bc8e0592a000000_320.jpg","thumbnail_picsize":"594,378","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c7f9669490cb822c00008c&m=1472793597","list_dtime":""},{"pk":"57c7f1079490cbd82c00004f","title":"90后男孩用轮椅推78岁奶奶来北京旅游","date":"","auther_name":"凤凰网","weburl":"http://iphone.myzaker.com/l.php?l=57c7f1079490cbd82c00004f","thumbnail_pic":"http://zkres.myzaker.com/201608/57c62b2577a3242c21000041_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c62b2577a3242c21000041_320.jpg","thumbnail_picsize":"797,598","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c7f1079490cbd82c00004f&m=1472793597","list_dtime":""}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c931459490cbf817000063,57ca41239490cbf93e000037,57ca48199490cb1f3f000025,57ca44cb9490cb2b3f00001d,57ca2aaf9490cbe33e000035,57c918cd9490cbde17000057","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca2bd79490cb443f00002f,57ca2b1e9490cb273f00000e,57c7f2591bc8e06261000062,57ca48b29490cbe23e000036,57ca2a969490cbda3e00002e,57c8f0de9490cb5601000010","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c9185d9490cb2b1800003a,57c93d699490cb0218000071,57c935249490cbeb1700004e,57c92beb9490cbdd1700004e,57c91a4c9490cb351800004c,57c912f89490cbd01700003c","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c8df4f1bc8e07b3000002e,57c918cd9490cbde17000058,57c91a4c9490cb351800004d,57c91c871bc8e07630000045,57c8f4d59490cbeb1700002f,57c8dcc99490cbe41700001b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c80a839490cbb32c000066,57c8dcca9490cbe41700001c,57c8dcca9490cbe41700001d,57c8009e9490cbb12c00006b,57c80a839490cbb32c000067,57c80b239490cbca2c000078","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c7f7609490cbb22c00004b,57c7f7609490cbb22c00004c,57c808ea9490cb8d2c00009a,57c807039490cbaa2c000062,57c7f9669490cb822c00008c,57c7f1079490cbd82c00004f","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#6cb2d2","#6cb2d2"],"only_text_page_bgcolors":["#6cb2d2","#6cb2d2"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/981.png?t=1450850826","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/981.png?t=1450850826","hidden_time":"24","need_userinfo":"NO","block_title":"旅游频道","block_color":"#6cb2d2","desktop_color_number":"6","use_original_icon":"N"}}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=981&since_date=1472456364&nt=1&next_aticle_id=57c6b6519490cbe04a00007e&_appid=androidphone&opage=2&otimestamp=177","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=981&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=981&ids=5642f2aa9490cbb13200000e,5472a9b69490cb48180000f9,51a7107581853dac4b000161&k=201609031440"}
     * catalog :
     * articles : [{"pk":"57c931459490cbf817000063","title":"她有一张金喜善的脸，却在山西寺庙修壁画","date":"","auther_name":"大卫传奇艺术","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c931459490cbf817000063","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMTk2Nl80NjMzMV9XNjQwSDM2MFM1NDI4Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMTk2Nl80NjMzMV9XNjQwSDM2MFM1NDI4Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"41","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c931459490cbf817000063&m=1472884804","list_dtime":""},{"pk":"57ca41239490cbf93e000037","title":"颜值不够高不必担心，这样拍旅游照统统都会点赞","date":"","auther_name":"谈资","weburl":"http://iphone.myzaker.com/l.php?l=57ca41239490cbf93e000037","thumbnail_pic":"http://zkres.myzaker.com/201609/57c949931bc8e0c340000042_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c949931bc8e0c340000042_320.jpg","thumbnail_picsize":"500,482","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca41239490cbf93e000037&m=1472884591","list_dtime":""},{"pk":"57ca48199490cb1f3f000025","title":"国内有哪些冷门但有特色的旅游地点？","date":"","auther_name":"慢时间-旅游","weburl":"http://iphone.myzaker.com/l.php?l=57ca48199490cb1f3f000025","thumbnail_pic":"http://zkres.myzaker.com/201608/57c10cfa1bc8e0524f000009_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c10cfa1bc8e0524f000009_320.jpg","thumbnail_picsize":"441,329","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca48199490cb1f3f000025&m=1472884591","list_dtime":""},{"pk":"57ca44cb9490cb2b3f00001d","title":"中国有一个300万年的神奇冰洞，万古不化！","date":"","auther_name":"慢时间-旅游","weburl":"http://iphone.myzaker.com/l.php?l=57ca44cb9490cb2b3f00001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7738e1bc8e0a319000017_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7738e1bc8e0a319000017_320.jpg","thumbnail_picsize":"500,333","media_count":"37","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca44cb9490cb2b3f00001d&m=1472884591","list_dtime":""},{"pk":"57ca2aaf9490cbe33e000035","title":"如果你在云南，千万别错过云南中秋美食5日游","date":"","auther_name":"蚂蜂窝","weburl":"http://iphone.myzaker.com/l.php?l=57ca2aaf9490cbe33e000035","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9502b1bc8e00843000005_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9502b1bc8e00843000005_320.jpg","thumbnail_picsize":"600,402","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca2aaf9490cbe33e000035&m=1472884591","list_dtime":""},{"pk":"57c918cd9490cbde17000057","title":" 绝壁上的郭亮村成为世界上\u201c网红最险村庄\u201d","title_line_break":"\n绝壁上的郭亮村成为世界上\u201c网红最险村庄\u201d","date":"","auther_name":"凤凰旅游","weburl":"http://iphone.myzaker.com/l.php?l=57c918cd9490cbde17000057","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8c93a7f52e9b50c00003b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8c93a7f52e9b50c00003b_320.jpg","thumbnail_picsize":"981,627","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c918cd9490cbde17000057&m=1472884591","list_dtime":""},{"pk":"57ca2b1e9490cb273f00000e","title":"每年此时，好色之徒都会聚集到这里\u2026","date":"","auther_name":"阿里旅行","weburl":"http://iphone.myzaker.com/l.php?l=57ca2b1e9490cb273f00000e","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7e4a51bc8e095640000b9_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7e4a51bc8e095640000b9_320.jpg","thumbnail_picsize":"640,387","media_count":"13","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca2b1e9490cb273f00000e&m=1472884591","list_dtime":""},{"pk":"57ca2bd79490cb443f00002f","title":"这些忍不住让人吐槽的异形建筑，你见过几个？","date":"","auther_name":"GEO视界","weburl":"http://iphone.myzaker.com/l.php?l=57ca2bd79490cb443f00002f","thumbnail_pic":"http://zkres.myzaker.com/201608/57c66b707f52e9225e00023d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c66b707f52e9225e00023d_320.jpg","thumbnail_picsize":"496,626","media_count":"58","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca2bd79490cb443f00002f&m=1472884591","list_dtime":""},{"pk":"57c7f2591bc8e06261000062","title":"蓝色星球上还有最后的一片净土在这里等你","date":"","auther_name":"带你去看好风光","weburl":"http://iphone.myzaker.com/l.php?l=57c7f2591bc8e06261000062","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7f241a07aecf77e0483f1_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7f241a07aecf77e0483f1_320.jpg","thumbnail_picsize":"500,281","media_count":"22","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c7f2591bc8e06261000062&m=1472884591","list_dtime":""},{"pk":"57ca48b29490cbe23e000036","title":"世上最美的涂鸦胡同","date":"","auther_name":"楚鹏博客","weburl":"http://iphone.myzaker.com/l.php?l=57ca48b29490cbe23e000036","thumbnail_pic":"http://zkres.myzaker.com/201608/57c66bbb1bc8e0bc7a00000a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c66bbb1bc8e0bc7a00000a_320.jpg","thumbnail_picsize":"460,690","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca48b29490cbe23e000036&m=1472884591","list_dtime":""},{"pk":"57ca2a969490cbda3e00002e","title":"寻找一片净土，就去甘南朝圣吧！","date":"","auther_name":"蚂蜂窝","weburl":"http://iphone.myzaker.com/l.php?l=57ca2a969490cbda3e00002e","thumbnail_pic":"http://zkres.myzaker.com/201607/5799eea8a07aec6048011502_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201607/5799eea8a07aec6048011502_320.jpg","thumbnail_picsize":"600,328","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57ca2a969490cbda3e00002e&m=1472884591","list_dtime":""},{"pk":"57c8f0de9490cb5601000010","title":"新疆为什么不包邮？看了你就明白了","date":"","auther_name":"京内网","weburl":"http://iphone.myzaker.com/l.php?l=57c8f0de9490cb5601000010","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODAwM181OTUzMV9XNjQwSDM2MFM4MzY4My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODAwM181OTUzMV9XNjQwSDM2MFM4MzY4My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8f0de9490cb5601000010&m=1472797667","list_dtime":""},{"pk":"57c93d699490cb0218000071","title":"如何在旅行路上做一只高冷的单身狗？","date":"","auther_name":"星球研究所","weburl":"http://iphone.myzaker.com/l.php?l=57c93d699490cb0218000071","thumbnail_pic":"http://zkres.myzaker.com/201608/57b672497f52e9d5200001ec_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b672497f52e9d5200001ec_320.jpg","thumbnail_picsize":"1024,669","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c93d699490cb0218000071&m=1472884591","list_dtime":""},{"pk":"57c9185d9490cb2b1800003a","title":"中国有个被抛弃的小岛，美成了绿野仙踪！","date":"","auther_name":"环球旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c9185d9490cb2b1800003a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODIzN180OTk1Ml9XNjQwSDM2MFM4NTcwOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODIzN180OTk1Ml9XNjQwSDM2MFM4NTcwOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"40","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c9185d9490cb2b1800003a&m=1472798143","list_dtime":""},{"pk":"57c935249490cbeb1700004e","title":"96岁奶奶亏本买卖55年，温暖了所有人","date":"","auther_name":"佳人网","weburl":"http://iphone.myzaker.com/l.php?l=57c935249490cbeb1700004e","thumbnail_pic":"http://zkres.myzaker.com/201608/57c5f2701bc8e02e2e00001d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c5f2701bc8e02e2e00001d_320.jpg","thumbnail_picsize":"480,331","media_count":"29","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c935249490cbeb1700004e&m=1472804738","list_dtime":""},{"pk":"57c92beb9490cbdd1700004e","title":"都说说，中国最美的大学是哪儿？","date":"","auther_name":"ZAKER话题","weburl":"http://iphone.myzaker.com/l.php?l=57c92beb9490cbdd1700004e","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"61","title":"On the Road","stitle":"灵魂和身体总有一个在路上","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd42739490cb197b0000f8.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd42739490cb197b0000f8.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=61","block_color":"","subscribe_count":"193830","post_count":"8104","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=981&app_ids=981&pk=57c92beb9490cbdd1700004e&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c92beb9490cbdd1700004e","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c92beb9490cbdd1700004e&m=1472884592","list_dtime":""},{"pk":"57c91a4c9490cb351800004c","title":"不知道去哪儿，就去大理啊！","date":"","auther_name":"Feekr旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c91a4c9490cb351800004c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODM3Nl84NTA1Ml9XNjQwSDM2MFM3MzY4MC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODM3Nl84NTA1Ml9XNjQwSDM2MFM3MzY4MC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"22","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c91a4c9490cb351800004c&m=1472884592","list_dtime":""},{"pk":"57c912f89490cbd01700003c","title":"这些国外旅行地竟然比国内的还便宜！","date":"","auther_name":"京内网","weburl":"http://iphone.myzaker.com/l.php?l=57c912f89490cbd01700003c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODQxNl84MTU3OV9XNjQwSDM2MFM3MDU5My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODQxNl84MTU3OV9XNjQwSDM2MFM3MDU5My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"45","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c912f89490cbd01700003c&m=1472798438","list_dtime":""},{"pk":"57c918cd9490cbde17000058","title":"在活火山口上潜水是怎样一种体验？","date":"","auther_name":"凤凰旅游","weburl":"http://iphone.myzaker.com/l.php?l=57c918cd9490cbde17000058","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5Nzk1Ml82MjEzMV9XNjQwSDM2MFMzOTUwMi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5Nzk1Ml82MjEzMV9XNjQwSDM2MFMzOTUwMi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c918cd9490cbde17000058&m=1472798264","list_dtime":""},{"pk":"57c8df4f1bc8e07b3000002e","title":"张家界玻璃桥刚开放12天 被紧急叫停","title_line_break":"张家界玻璃桥刚开放12天\n被紧急叫停","date":"","auther_name":"红网","weburl":"http://iphone.myzaker.com/l.php?l=57c8df4f1bc8e07b3000002e","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8df3fa07aec13520022ea_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8df3fa07aec13520022ea_320.jpg","thumbnail_picsize":"495,329","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8df4f1bc8e07b3000002e&m=1472793596","list_dtime":""},{"pk":"57c91a4c9490cb351800004d","title":"先定一个小目标，比如说去看看初秋最美的地方","date":"","auther_name":"Feekr旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c91a4c9490cb351800004d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODQ4MF8zNjkwNV9XNjQwSDM2MFM2NDI3OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODQ4MF8zNjkwNV9XNjQwSDM2MFM2NDI3OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c91a4c9490cb351800004d&m=1472798741","list_dtime":""},{"pk":"57c91c871bc8e07630000045","title":"上天入地！全球那些脑洞大开的酒店","date":"","auther_name":" 带你去看好风光","weburl":"http://iphone.myzaker.com/l.php?l=57c91c871bc8e07630000045","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5NzkyN185NjE4OF9XNjQwSDM2MFMzMDA0NC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5NzkyN185NjE4OF9XNjQwSDM2MFMzMDA0NC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"30","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c91c871bc8e07630000045&m=1472798141","list_dtime":""},{"pk":"57c8f4d59490cbeb1700002f","title":"秋高气爽，正是动物们体检卖萌的好时机","date":"","auther_name":"iWeekly周末画报","weburl":"http://iphone.myzaker.com/l.php?l=57c8f4d59490cbeb1700002f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5Nzk2OV81NTUxOF9XNjQwSDM2MFM1MjA3Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5Nzk2OV81NTUxOF9XNjQwSDM2MFM1MjA3Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8f4d59490cbeb1700002f&m=1472797838","list_dtime":""},{"pk":"57c8dcc99490cbe41700001b","title":"英国一口被诅咒的井？物体接触井水后全变石头","date":"","auther_name":"蚂蜂窝","weburl":"http://iphone.myzaker.com/l.php?l=57c8dcc99490cbe41700001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c83ebc1bc8e0951e000009_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c83ebc1bc8e0951e000009_320.jpg","thumbnail_picsize":"600,364","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8dcc99490cbe41700001b&m=1472793596","list_dtime":""},{"pk":"57c8dcca9490cbe41700001c","title":"出了桂林，广西美景多了去了，关键是人少","date":"","auther_name":"蚂蜂窝","weburl":"http://iphone.myzaker.com/l.php?l=57c8dcca9490cbe41700001c","thumbnail_pic":"http://zkres.myzaker.com/201608/57a42263a07aec7c1001291f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57a42263a07aec7c1001291f_320.jpg","thumbnail_picsize":"600,389","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8dcca9490cbe41700001c&m=1472793596","list_dtime":""},{"pk":"57c80a839490cbb32c000066","title":"重庆的一个草原，美翻了一年四季！","date":"","auther_name":"阿里旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c80a839490cbb32c000066","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7e49c1bc8e09564000049_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7e49c1bc8e09564000049_320.jpg","thumbnail_picsize":"639,371","media_count":"52","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c80a839490cbb32c000066&m=1472793596","list_dtime":""},{"pk":"57c8dcca9490cbe41700001d","title":"迪拜已成过去，阿布扎比更富有更大气","date":"","auther_name":"蚂蜂窝","weburl":"http://iphone.myzaker.com/l.php?l=57c8dcca9490cbe41700001d","thumbnail_pic":"http://zkres.myzaker.com/201604/5705e17f1bc8e0991c000027_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201604/5705e17f1bc8e0991c000027_320.jpg","thumbnail_picsize":"600,382","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8dcca9490cbe41700001d&m=1472793596","list_dtime":""},{"pk":"57c8009e9490cbb12c00006b","title":"他们住在地球上最值钱的钻石坑边，却是最苦的穷鬼","date":"","auther_name":"ChokStick 骚货","weburl":"http://iphone.myzaker.com/l.php?l=57c8009e9490cbb12c00006b","thumbnail_pic":"http://zkres.myzaker.com/201608/57c675811bc8e08703000013_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c675811bc8e08703000013_320.jpg","thumbnail_picsize":"800,570","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c8009e9490cbb12c00006b&m=1472793597","list_dtime":""},{"pk":"57c80a839490cbb32c000067","title":"\u200b 茶马古道上唯一幸存的千年古镇，山美水美","date":"","auther_name":"阿里旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c80a839490cbb32c000067","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7e4a21bc8e09564000090_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7e4a21bc8e09564000090_320.jpg","thumbnail_picsize":"640,426","media_count":"41","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c80a839490cbb32c000067&m=1472793596","list_dtime":""},{"pk":"57c80b239490cbca2c000078","title":"世界最长儿童铁路，工作人员全是儿童哦","date":"","auther_name":"蚂蜂窝","weburl":"http://iphone.myzaker.com/l.php?l=57c80b239490cbca2c000078","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4MDM1Nl82MjY4Ml9XNjQwSDM2MFM5MTYwMy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4MDM1Nl82MjY4Ml9XNjQwSDM2MFM5MTYwMy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c80b239490cbca2c000078&m=1472793596","list_dtime":""},{"pk":"57c7f7609490cbb22c00004c","title":"他们用2万块环游中国边境，风尘仆仆但美呆","date":"","auther_name":"一介","weburl":"http://iphone.myzaker.com/l.php?l=57c7f7609490cbb22c00004c","thumbnail_pic":"http://zkres.myzaker.com/201608/57b72af67f52e9047100028d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b72af67f52e9047100028d_320.jpg","thumbnail_picsize":"640,427","media_count":"29","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=981&pk=57c7f7609490cbb22c00004c&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c7f7609490cbb22c00004c%26app_id%3D981%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c7f7609490cbb22c00004c&m=1472793597","list_dtime":""},{"pk":"57c7f7609490cbb22c00004b","title":"你走过的路看过的风景，都会变成你","date":"","auther_name":"一介","weburl":"http://iphone.myzaker.com/l.php?l=57c7f7609490cbb22c00004b","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6f30c7f52e95b02000170_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6f30c7f52e95b02000170_320.jpg","thumbnail_picsize":"1280,1090","media_count":"17","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=981&pk=57c7f7609490cbb22c00004b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c7f7609490cbb22c00004b%26app_id%3D981%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c7f7609490cbb22c00004b&m=1472793597","list_dtime":""},{"pk":"57c808ea9490cb8d2c00009a","title":"澳大利亚美如画？胡说！明明比画还美","date":"","auther_name":" KLOOK客路旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c808ea9490cb8d2c00009a","thumbnail_pic":"http://zkres.myzaker.com/201609/57c808fda07aecf77e048f4b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c808fda07aecf77e048f4b_320.jpg","thumbnail_picsize":"600,400","media_count":"62","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c808ea9490cb8d2c00009a&m=1472793597","list_dtime":""},{"pk":"57c807039490cbaa2c000062","title":"世界十大顶尖建筑，有一个在中国！","date":"","auther_name":" KLOOK客路旅行","weburl":"http://iphone.myzaker.com/l.php?l=57c807039490cbaa2c000062","thumbnail_pic":"http://zkres.myzaker.com/201609/57c80708a07aecf77e048d48_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c80708a07aecf77e048d48_320.jpg","thumbnail_picsize":"1006,764","media_count":"22","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c807039490cbaa2c000062&m=1472793597","list_dtime":""},{"pk":"57c7f9669490cb822c00008c","title":"日本其实没有\u201c首都\u201d！","date":"","auther_name":"奇趣发现","weburl":"http://iphone.myzaker.com/l.php?l=57c7f9669490cb822c00008c","thumbnail_pic":"http://zkres.myzaker.com/201609/57c78f5c1bc8e0592a000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c78f5c1bc8e0592a000000_320.jpg","thumbnail_picsize":"594,378","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c7f9669490cb822c00008c&m=1472793597","list_dtime":""},{"pk":"57c7f1079490cbd82c00004f","title":"90后男孩用轮椅推78岁奶奶来北京旅游","date":"","auther_name":"凤凰网","weburl":"http://iphone.myzaker.com/l.php?l=57c7f1079490cbd82c00004f","thumbnail_pic":"http://zkres.myzaker.com/201608/57c62b2577a3242c21000041_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c62b2577a3242c21000041_320.jpg","thumbnail_picsize":"797,598","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c7f1079490cbd82c00004f&m=1472793597","list_dtime":""}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c931459490cbf817000063,57ca41239490cbf93e000037,57ca48199490cb1f3f000025,57ca44cb9490cb2b3f00001d,57ca2aaf9490cbe33e000035,57c918cd9490cbde17000057","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca2bd79490cb443f00002f,57ca2b1e9490cb273f00000e,57c7f2591bc8e06261000062,57ca48b29490cbe23e000036,57ca2a969490cbda3e00002e,57c8f0de9490cb5601000010","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c9185d9490cb2b1800003a,57c93d699490cb0218000071,57c935249490cbeb1700004e,57c92beb9490cbdd1700004e,57c91a4c9490cb351800004c,57c912f89490cbd01700003c","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c8df4f1bc8e07b3000002e,57c918cd9490cbde17000058,57c91a4c9490cb351800004d,57c91c871bc8e07630000045,57c8f4d59490cbeb1700002f,57c8dcc99490cbe41700001b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c80a839490cbb32c000066,57c8dcca9490cbe41700001c,57c8dcca9490cbe41700001d,57c8009e9490cbb12c00006b,57c80a839490cbb32c000067,57c80b239490cbca2c000078","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c7f7609490cbb22c00004b,57c7f7609490cbb22c00004c,57c808ea9490cb8d2c00009a,57c807039490cbaa2c000062,57c7f9669490cb822c00008c,57c7f1079490cbd82c00004f","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#6cb2d2","#6cb2d2"],"only_text_page_bgcolors":["#6cb2d2","#6cb2d2"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/981.png?t=1450850826","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/981.png?t=1450850826","hidden_time":"24","need_userinfo":"NO","block_title":"旅游频道","block_color":"#6cb2d2","desktop_color_number":"6","use_original_icon":"N"}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=981&since_date=1472456364&nt=1&next_aticle_id=57c6b6519490cbe04a00007e&_appid=androidphone&opage=2&otimestamp=177
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=981&need_app_integration=0
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=981&ids=5642f2aa9490cbb13200000e,5472a9b69490cb48180000f9,51a7107581853dac4b000161&k=201609031440
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/981.png?t=1450850826
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/981.png?t=1450850826
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 旅游频道
         * block_color : #6cb2d2
         * desktop_color_number : 6
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57c931459490cbf817000063
         * title : 她有一张金喜善的脸，却在山西寺庙修壁画
         * date :
         * auther_name : 大卫传奇艺术
         * page : 1
         * index : 1
         * weburl : http://iphone.myzaker.com/l.php?l=57c931459490cbf817000063
         * thumbnail_pic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMTk2Nl80NjMzMV9XNjQwSDM2MFM1NDI4Ny5qcGc=_1242.jpg
         * thumbnail_mpic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMTk2Nl80NjMzMV9XNjQwSDM2MFM1NDI4Ny5qcGc=_1242.jpg
         * thumbnail_picsize : 640,360
         * media_count : 41
         * is_full : NO
         * content :
         * special_info : {"show_jingcai":"Y","list_nodsp":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=981&pk=57c931459490cbf817000063&m=1472884804
         * list_dtime :
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 2
             * articles : 57c931459490cbf817000063,57ca41239490cbf93e000037,57ca48199490cb1f3f000025,57ca44cb9490cb2b3f00001d,57ca2aaf9490cbe33e000035,57c918cd9490cbde17000057
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/981.png?t=1450850826
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * open_type :
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String is_full;
            private String content;
            /**
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String show_jingcai;
                private String list_nodsp;

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }
            }
        }
    }
}
