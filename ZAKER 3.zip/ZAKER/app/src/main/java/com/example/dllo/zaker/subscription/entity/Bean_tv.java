package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class Bean_tv {

    /**
     * stat : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=11698&since_date=1472722415&nt=1&_appid=androidphone&catalog_appid=9","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=11698&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=11698&ids=51a7104681853dec4d00012f&k=201609051500"},"catalog":"","articles":[{"pk":"57cd0c819490cb057e000040","title":"《微微》火到越南，我担心他们会翻拍！","date":"2016-09-05 14:11:13","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cd0c819490cb057e000040","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NjA4OV8xNTg4X1c2NDBIMzYwUzUwNDk3LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NjA4OV8xNTg4X1c2NDBIMzYwUzUwNDk3LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"22","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cd0c819490cb057e000040&m=1473056090","list_dtime":"2016-09-05 14:11:13"},{"pk":"57cd06439490cb497e000026","title":"《青云志》易烊千玺登场 与李易峰互动多","title_line_break":"《青云志》易烊千玺登场\n与李易峰互动多","date":"2016-09-05 13:42:09","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cd06439490cb497e000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDg0N185MjA5OV9XNjQwSDM2MFM0NDAwNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDg0N185MjA5OV9XNjQwSDM2MFM0NDAwNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cd06439490cb497e000026&m=1473054849","list_dtime":"2016-09-05 13:42:09"},{"pk":"57ccd5e19490cb037e00002f","title":"《麻雀》今开播 李易峰周冬雨为国隐忍","title_line_break":"《麻雀》今开播\n李易峰周冬雨为国隐忍","date":"2016-09-05 13:16:48","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd5e19490cb037e00002f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1Mzk0M182NTM4MV9XNjQwSDM2MFM2NjY2NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1Mzk0M182NTM4MV9XNjQwSDM2MFM2NjY2NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccd5e19490cb037e00002f&m=1473053946","list_dtime":"2016-09-05 13:16:48"},{"pk":"57ccd56d9490cb4d7e000020","title":"《康熙》家族再合体 粉丝直呼好怀念","title_line_break":"《康熙》家族再合体\n粉丝直呼好怀念","date":"2016-09-05 11:15:37","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd56d9490cb4d7e000020","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NTY0OF84MTY0OF9XNjQwSDM2MFM3NTU3MC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NTY0OF84MTY0OF9XNjQwSDM2MFM3NTU3MC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccd56d9490cb4d7e000020&m=1473045650","list_dtime":"2016-09-05 11:15:37"},{"pk":"57ccdd359490cbf27d000026","title":"周冬雨登《快本》 方言版星语心愿引爆笑","title_line_break":"周冬雨登《快本》\n方言版星语心愿引爆笑","date":"2016-09-05 10:49:25","auther_name":"Yes娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd359490cbf27d000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDA1M180NTA5OF9XNjQwSDM2MFM0MTc3Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDA1M180NTA5OF9XNjQwSDM2MFM0MTc3Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccdd359490cbf27d000026&m=1473044056","list_dtime":"2016-09-05 10:49:25"},{"pk":"57ccdb9c9490cb157e000024","title":"混搭偶像和玄幻的电视剧不只《微微》一部","date":"2016-09-05 10:42:36","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccdb9c9490cb157e000024","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDExNl81NDA3Nl9XNjQwSDM2MFMzNTczMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDExNl81NDA3Nl9XNjQwSDM2MFMzNTczMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"84","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccdb9c9490cb157e000024&m=1473044119","list_dtime":"2016-09-05 10:42:36"},{"pk":"57ccd4b59490cb6358000001","title":"静香穿泳衣洗澡 观众狂批：矫枉过正","title_line_break":"静香穿泳衣洗澡 观众狂批：\n矫枉过正","date":"2016-09-05 10:42:15","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd4b59490cb6358000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDEzMF80NzExMV9XNjQwSDM2MFM0NTYzMi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDEzMF80NzExMV9XNjQwSDM2MFM0NTYzMi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccd4b59490cb6358000001&m=1473044133","list_dtime":"2016-09-05 10:42:15"},{"pk":"57ccd2ab9490cb507e000030","title":"一见肖奈误终身！《微微一笑》甜蜜不断","date":"2016-09-05 10:03:30","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd2ab9490cb507e000030","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE1MV83OTUyOV9XNjQwSDM2MFM0MTUzNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE1MV83OTUyOV9XNjQwSDM2MFM0MTUzNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccd2ab9490cb507e000030&m=1473044153","list_dtime":"2016-09-05 10:03:30"},{"pk":"57ccce2e9490cbd77d00000c","title":"张曼玉加盟谢霆锋节目 被赞专业，认真","title_line_break":"张曼玉加盟谢霆锋节目\n被赞专业，认真","date":"2016-09-05 09:45:18","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccce2e9490cbd77d00000c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE5OF80NDU3OV9XNjQwSDM2MFMyNjYzOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE5OF80NDU3OV9XNjQwSDM2MFMyNjYzOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccce2e9490cbd77d00000c&m=1473044200","list_dtime":"2016-09-05 09:45:18"},{"pk":"57cbe0089490cba435000059","title":"《爱情万万岁》导演玩颠覆 赞刘涛爷们","title_line_break":"《爱情万万岁》导演玩颠覆\n赞刘涛爷们","date":"2016-09-04 16:48:15","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cbe0089490cba435000059","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTY0Ml80MzUyX1c2NDBIMzYwUzQzOTI0LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTY0Ml80MzUyX1c2NDBIMzYwUzQzOTI0LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cbe0089490cba435000059&m=1472979644","list_dtime":"2016-09-04 16:48:15"},{"pk":"57cbdd659490cb9935000030","title":"这一定是我看过最三观不正的电视剧！","date":"2016-09-04 16:37:57","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cbdd659490cb9935000030","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTYxM181NjEzNF9XNjQwSDM2MFMyODgwMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTYxM181NjEzNF9XNjQwSDM2MFMyODgwMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"32","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cbdd659490cb9935000030&m=1472979614","list_dtime":"2016-09-04 16:37:57"},{"pk":"57cbbc2f9490cbaa3500003d","title":"万万想不到，这些角色竟然是一个人演的","date":"2016-09-04 14:14:52","auther_name":"芭莎娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cbbc2f9490cbaa3500003d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTc1MF8yMjc1OF9XNjQwSDM2MFMzODM0Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTc1MF8yMjc1OF9XNjQwSDM2MFMzODM0Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"42","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cbbc2f9490cbaa3500003d&m=1472979752","list_dtime":"2016-09-04 14:14:52"},{"pk":"57cbb85f9490cba935000040","title":"传黄晓明夫妇、王俊凯王源出演《凉生》？","date":"2016-09-04 13:58:47","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cbb85f9490cba935000040","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTc4OF83MTczN19XNjQwSDM2MFMyMjQ4My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTc4OF83MTczN19XNjQwSDM2MFMyMjQ4My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"19","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cbb85f9490cba935000040&m=1472979789","list_dtime":"2016-09-04 13:58:47"},{"pk":"57cb8e039490cbe63500001a","title":"范冰冰PK林志玲 谁才是T台女王？","title_line_break":"范冰冰PK林志玲\n谁才是T台女王？","date":"2016-09-04 10:59:15","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb8e039490cbe63500001a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTgxOV8yNzk1Ml9XNjQwSDM2MFM2NTkzMC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTgxOV8yNzk1Ml9XNjQwSDM2MFM2NTkzMC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cb8e039490cbe63500001a&m=1472979821","list_dtime":"2016-09-04 10:59:15"},{"pk":"57cb83ac1bc8e0000b000021","title":"那些年我们一起追过的偶像剧男神","date":"2016-09-04 10:56:34","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57cb83ac1bc8e0000b000021","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTg0Ml8xMTU3NF9XNjQwSDM2MFM0NzM0Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTg0Ml8xMTU3NF9XNjQwSDM2MFM0NzM0Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cb83ac1bc8e0000b000021&m=1472979844","list_dtime":"2016-09-04 10:56:34"},{"pk":"57cb8cc89490cbb93500002c","title":"《莽荒纪》王鸥携手刘恺威演绎东方传奇","date":"2016-09-04 10:53:18","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb8cc89490cbb93500002c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTg2Ml84Njk1Ml9XNjQwSDM2MFM0ODUwMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTg2Ml84Njk1Ml9XNjQwSDM2MFM0ODUwMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cb8cc89490cbb93500002c&m=1472979864","list_dtime":"2016-09-04 10:53:18"},{"pk":"57cb8c209490cbdf35000020","title":"《唐伯虎点秋香》花絮照 杀马特好抢镜","title_line_break":"《唐伯虎点秋香》花絮照\n杀马特好抢镜","date":"2016-09-04 10:50:22","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb8c209490cbdf35000020","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTg3OF84MjE3MF9XNjQwSDM2MFM2ODMzOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTg3OF84MjE3MF9XNjQwSDM2MFM2ODMzOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cb8c209490cbdf35000020&m=1472979879","list_dtime":"2016-09-04 10:50:22"},{"pk":"57cb7d0a9490cbdc35000027","title":"青春片编剧为什么总对校花充满恶意？","date":"2016-09-04 09:46:50","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb7d0a9490cbdc35000027","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk4MDE1MF8xNzgxMl9XNjQwSDM2MFMzNzA0MS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk4MDE1MF8xNzgxMl9XNjQwSDM2MFMzNzA0MS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"63","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cb7d0a9490cbdc35000027&m=1472980152","list_dtime":"2016-09-04 09:46:50"},{"pk":"57cabf169490cb0b3f000055","title":"VIP尊贵体验：没想到你是这样的鹅厂","title_line_break":"VIP尊贵体验：\n没想到你是这样的鹅厂","date":"2016-09-03 20:14:01","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cabf169490cb0b3f000055","thumbnail_pic":"http://zkres.myzaker.com/201609/57cabf40a07aecc52300bf43_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cabf40a07aecc52300bf43_320.jpg","thumbnail_picsize":"600,450","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cabf169490cb0b3f000055&m=1472905122","list_dtime":"2016-09-03 20:14:01"},{"pk":"57ca6b569490cb4c3f000028","title":"《跨界喜剧王》首播 费玉清再出新段子","title_line_break":"《跨界喜剧王》首播\n费玉清再出新段子","date":"2016-09-03 14:18:16","auther_name":"中国新闻网","weburl":"http://iphone.myzaker.com/l.php?l=57ca6b569490cb4c3f000028","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca34af1bc8e02248000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca34af1bc8e02248000007_320.jpg","thumbnail_picsize":"500,333","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ca6b569490cb4c3f000028&m=1472883557","list_dtime":"2016-09-03 14:18:16"},{"pk":"57c947819490cb0818000084","title":"《职场健康课》:强迫症了怎么办？","title_line_break":"《职场健康课》:\n强迫症了怎么办？","date":"2016-09-02 17:32:33","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c947819490cb0818000084","thumbnail_pic":"http://zkres.myzaker.com/201609/57c94791a07aecc523001e84_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c94791a07aecc523001e84_320.jpg","thumbnail_picsize":"337,224","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c947819490cb0818000084&m=1472808999","list_dtime":"2016-09-02 17:32:33"},{"pk":"57c946ed9490cb4218000062","title":"《亲爱的公主病》不只有毒 还炸裂少女心","title_line_break":"《亲爱的公主病》不只有毒\n还炸裂少女心","date":"2016-09-02 17:29:03","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c946ed9490cb4218000062","thumbnail_pic":"http://zkres.myzaker.com/201609/57c94700a07aecc523001e0f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c94700a07aecc523001e0f_320.jpg","thumbnail_picsize":"533,327","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c946ed9490cb4218000062&m=1472808804","list_dtime":"2016-09-02 17:29:03"},{"pk":"57c946339490cb2c1800005b","title":"黄磊立足脱口秀  美食档诠释有爱生活","date":"2016-09-02 17:22:59","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c946339490cb2c1800005b","thumbnail_pic":"http://zkres.myzaker.com/data/attachment/editor/2016/09/02/1472808462.png","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c94660a07aecc523001dfc_320.jpg","thumbnail_picsize":"507,301","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c946339490cb2c1800005b&m=1472808637","list_dtime":"2016-09-02 17:22:59"},{"pk":"57c920659490cbf117000048","title":"《麻雀》即将开播 李易峰周冬雨隐忍爱恋","title_line_break":"《麻雀》即将开播\n李易峰周冬雨隐忍爱恋","date":"2016-09-02 14:46:03","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c920659490cbf117000048","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9207ea07aecc52300043f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9207ea07aecc52300043f_320.jpg","thumbnail_picsize":"500,333","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c920659490cbf117000048&m=1472798867","list_dtime":"2016-09-02 14:46:03"},{"pk":"57c91fd49490cb3b18000055","title":"《百变吧星居》曝宣传片 明星阵容公布","title_line_break":"《百变吧星居》曝宣传片\n明星阵容公布","date":"2016-09-02 14:43:05","auther_name":"网易娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c91fd49490cb3b18000055","thumbnail_pic":"http://zkres.myzaker.com/201609/57c91ff2a07aecc523000429_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c91ff2a07aecc523000429_320.jpg","thumbnail_picsize":"550,367","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c91fd49490cb3b18000055&m=1472798788","list_dtime":"2016-09-02 14:43:05"},{"pk":"57c91f469490cbfb17000036","title":"《黄金单身汉》 \u201c正经\u201d女主播跨国求爱","title_line_break":"《黄金单身汉》\n\u201c正经\u201d女主播跨国求爱","date":"2016-09-02 14:38:22","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c91f469490cbfb17000036","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c91f469490cbfb17000036&m=1472798583","list_dtime":"2016-09-02 14:38:22"},{"pk":"57c91dc19490cbfe17000043","title":"超女决赛冠军夜将启 \u201c超女红\u201d引回忆","title_line_break":"超女决赛冠军夜将启\n\u201c超女红\u201d引回忆","date":"2016-09-02 14:32:29","auther_name":"网易娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c91dc19490cbfe17000043","thumbnail_pic":"http://zkres.myzaker.com/201609/57c91dcba07aecc52300039c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c91dcba07aecc52300039c_320.jpg","thumbnail_picsize":"780,517","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c91dc19490cbfe17000043&m=1472798185","list_dtime":"2016-09-02 14:32:29"},{"pk":"57c91ca19490cb2b18000043","title":"大咖空降慈善晚会 加拿大少年泪别中国","title_line_break":"大咖空降慈善晚会\n加拿大少年泪别中国","date":"2016-09-02 14:30:02","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c91ca19490cb2b18000043","thumbnail_pic":"http://zkres.myzaker.com/201609/57c91ca9a07aecc523000351_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c91ca9a07aecc523000351_320.jpg","thumbnail_picsize":"500,278","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c91ca19490cb2b18000043&m=1472797919","list_dtime":"2016-09-02 14:30:02"},{"pk":"57c91b999490cb1f18000036","title":"江苏卫视联手乐视开启\u201c919狂欢夜\u201d","date":"2016-09-02 14:23:57","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c91b999490cb1f18000036","thumbnail_pic":"http://zkres.myzaker.com/201609/57c91bafa07aecc523000218_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c91bafa07aecc523000218_320.jpg","thumbnail_picsize":"600,909","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c91b999490cb1f18000036&m=1472797633","list_dtime":"2016-09-02 14:23:57"},{"pk":"57c9172e9490cbfb1700002b","title":"说好《W》甜蜜结局，最后竟让女主死了","date":"2016-09-02 14:07:42","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c9172e9490cbfb1700002b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8fd851bc8e0a70600005a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8fd851bc8e0a70600005a_320.jpg","thumbnail_picsize":"350,194","media_count":"38","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c9172e9490cbfb1700002b&m=1472796629","list_dtime":"2016-09-02 14:07:42"},{"pk":"57c8edad9490cbcd17000035","title":"蒋欣颠覆熟女形象 不惜为角色增加体重","title_line_break":"蒋欣颠覆熟女形象\n不惜为角色增加体重","date":"2016-09-02 11:09:35","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8edad9490cbcd17000035","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8edb4a07aec1352002e9f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8edb4a07aec1352002e9f_320.jpg","thumbnail_picsize":"600,400","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c8edad9490cbcd17000035&m=1472785975","list_dtime":"2016-09-02 11:09:35"},{"pk":"57c8eae09490cb2718000030","title":"《极速》晶刚夫妇：我们从来没有秀恩爱","title_line_break":"《极速》晶刚夫妇：\n我们从来没有秀恩爱","date":"2016-09-02 10:57:53","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8eae09490cb2718000030","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8eaeca07aec1352002be2_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8eaeca07aec1352002be2_320.jpg","thumbnail_picsize":"600,400","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c8eae09490cb2718000030&m=1472785304","list_dtime":"2016-09-02 10:57:53"},{"pk":"57c8e7ab9490cbda1700004a","title":"肖奈微微鸳鸯浴被删，没事，有地咚花絮！","date":"2016-09-02 10:44:59","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8e7ab9490cbda1700004a","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d2b51bc8e0786e00003f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d2b51bc8e0786e00003f_320.jpg","thumbnail_picsize":"600,424","media_count":"32","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c8e7ab9490cbda1700004a&m=1472784637","list_dtime":"2016-09-02 10:44:59"},{"pk":"57c8e4369490cb151800002d","title":"《美人为馅》预告 这带感的剧情不看不行","title_line_break":"《美人为馅》预告\n这带感的剧情不看不行","date":"2016-09-02 10:30:14","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8e4369490cb151800002d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c82a9f1bc8e0b111000022_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c82a9f1bc8e0b111000022_320.jpg","thumbnail_picsize":"350,197","media_count":"35","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c8e4369490cb151800002d&m=1472784947","list_dtime":"2016-09-02 10:30:14"},{"pk":"57c8d2f91bc8e0f66f000035","title":"红极一时的古装花旦，为爱甘当家庭主妇","date":"2016-09-02 10:16:17","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57c8d2f91bc8e0f66f000035","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d2171bc8e0896f000031_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d2171bc8e0896f000031_320.jpg","thumbnail_picsize":"450,281","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c8d2f91bc8e0f66f000035&m=1472782757","list_dtime":"2016-09-02 10:16:17"},{"pk":"57c7f5b19490cbd62c000066","title":"马东柳岩遭肥胖危机加盟《拜拜啦肉肉》","date":"2016-09-01 17:33:35","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c7f5b19490cbd62c000066","thumbnail_pic":"http://zkres.myzaker.com/data/attachment/editor/2016/09/01/1472722288.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7f5c1a07aecf77e048559_320.jpg","thumbnail_picsize":"1459,957","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c7f5b19490cbd62c000066&m=1472722510","list_dtime":"2016-09-01 17:33:35"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cd06439490cb497e000026,57cd0c819490cb057e000040,57ccd5e19490cb037e00002f,57ccd56d9490cb4d7e000020,57ccdd359490cbf27d000026,57ccdb9c9490cb157e000024","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccd2ab9490cb507e000030,57ccd4b59490cb6358000001,57ccce2e9490cbd77d00000c,57cbe0089490cba435000059,57cbdd659490cb9935000030,57cbbc2f9490cbaa3500003d","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cb8e039490cbe63500001a,57cbb85f9490cba935000040,57cb83ac1bc8e0000b000021,57cb8cc89490cbb93500002c,57cb8c209490cbdf35000020,57cb7d0a9490cbdc35000027","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ca6b569490cb4c3f000028,57cabf169490cb0b3f000055,57c947819490cb0818000084,57c946ed9490cb4218000062,57c946339490cb2c1800005b,57c920659490cbf117000048","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c91dc19490cbfe17000043,57c91f469490cbfb17000036,57c91fd49490cb3b18000055,57c91ca19490cb2b18000043,57c91b999490cb1f18000036,57c9172e9490cbfb1700002b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c8eae09490cb2718000030,57c8edad9490cbcd17000035,57c8e7ab9490cbda1700004a,57c8e4369490cb151800002d,57c8d2f91bc8e0f66f000035,57c7f5b19490cbd62c000066","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#35b8c8","#35b8c8"],"only_text_page_bgcolors":["#35b8c8","#35b8c8"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11698.png?1420439444","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11698.png?1420439444","hidden_time":"24","need_userinfo":"NO","block_title":"电视","block_color":"#35b8c8","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_316b60b95df0bb647100087dc3e47e4c","selected_index":"2","list":[{"pk":"zk_app_column_9","title":"娱乐","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_10530","title":"电影","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"10530_zk_app_column_block_9","title":"电影资讯","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=10530&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_11698","title":"电视","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11698_zk_app_column_block_9","title":"电视","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11698&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_12348","title":"明星","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12348_zk_app_column_block_9","title":"明星","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12348&catalog_appid=9","data_type":"news"}}]}}
     */

    private String stat;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=11698&since_date=1472722415&nt=1&_appid=androidphone&catalog_appid=9","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=11698&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=11698&ids=51a7104681853dec4d00012f&k=201609051500"}
     * catalog :
     * articles : [{"pk":"57cd0c819490cb057e000040","title":"《微微》火到越南，我担心他们会翻拍！","date":"2016-09-05 14:11:13","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cd0c819490cb057e000040","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NjA4OV8xNTg4X1c2NDBIMzYwUzUwNDk3LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NjA4OV8xNTg4X1c2NDBIMzYwUzUwNDk3LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"22","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cd0c819490cb057e000040&m=1473056090","list_dtime":"2016-09-05 14:11:13"},{"pk":"57cd06439490cb497e000026","title":"《青云志》易烊千玺登场 与李易峰互动多","title_line_break":"《青云志》易烊千玺登场\n与李易峰互动多","date":"2016-09-05 13:42:09","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cd06439490cb497e000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDg0N185MjA5OV9XNjQwSDM2MFM0NDAwNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NDg0N185MjA5OV9XNjQwSDM2MFM0NDAwNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cd06439490cb497e000026&m=1473054849","list_dtime":"2016-09-05 13:42:09"},{"pk":"57ccd5e19490cb037e00002f","title":"《麻雀》今开播 李易峰周冬雨为国隐忍","title_line_break":"《麻雀》今开播\n李易峰周冬雨为国隐忍","date":"2016-09-05 13:16:48","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd5e19490cb037e00002f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1Mzk0M182NTM4MV9XNjQwSDM2MFM2NjY2NS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1Mzk0M182NTM4MV9XNjQwSDM2MFM2NjY2NS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccd5e19490cb037e00002f&m=1473053946","list_dtime":"2016-09-05 13:16:48"},{"pk":"57ccd56d9490cb4d7e000020","title":"《康熙》家族再合体 粉丝直呼好怀念","title_line_break":"《康熙》家族再合体\n粉丝直呼好怀念","date":"2016-09-05 11:15:37","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd56d9490cb4d7e000020","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NTY0OF84MTY0OF9XNjQwSDM2MFM3NTU3MC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NTY0OF84MTY0OF9XNjQwSDM2MFM3NTU3MC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccd56d9490cb4d7e000020&m=1473045650","list_dtime":"2016-09-05 11:15:37"},{"pk":"57ccdd359490cbf27d000026","title":"周冬雨登《快本》 方言版星语心愿引爆笑","title_line_break":"周冬雨登《快本》\n方言版星语心愿引爆笑","date":"2016-09-05 10:49:25","auther_name":"Yes娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccdd359490cbf27d000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDA1M180NTA5OF9XNjQwSDM2MFM0MTc3Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDA1M180NTA5OF9XNjQwSDM2MFM0MTc3Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccdd359490cbf27d000026&m=1473044056","list_dtime":"2016-09-05 10:49:25"},{"pk":"57ccdb9c9490cb157e000024","title":"混搭偶像和玄幻的电视剧不只《微微》一部","date":"2016-09-05 10:42:36","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccdb9c9490cb157e000024","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDExNl81NDA3Nl9XNjQwSDM2MFMzNTczMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDExNl81NDA3Nl9XNjQwSDM2MFMzNTczMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"84","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccdb9c9490cb157e000024&m=1473044119","list_dtime":"2016-09-05 10:42:36"},{"pk":"57ccd4b59490cb6358000001","title":"静香穿泳衣洗澡 观众狂批：矫枉过正","title_line_break":"静香穿泳衣洗澡 观众狂批：\n矫枉过正","date":"2016-09-05 10:42:15","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd4b59490cb6358000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDEzMF80NzExMV9XNjQwSDM2MFM0NTYzMi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDEzMF80NzExMV9XNjQwSDM2MFM0NTYzMi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccd4b59490cb6358000001&m=1473044133","list_dtime":"2016-09-05 10:42:15"},{"pk":"57ccd2ab9490cb507e000030","title":"一见肖奈误终身！《微微一笑》甜蜜不断","date":"2016-09-05 10:03:30","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccd2ab9490cb507e000030","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE1MV83OTUyOV9XNjQwSDM2MFM0MTUzNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE1MV83OTUyOV9XNjQwSDM2MFM0MTUzNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccd2ab9490cb507e000030&m=1473044153","list_dtime":"2016-09-05 10:03:30"},{"pk":"57ccce2e9490cbd77d00000c","title":"张曼玉加盟谢霆锋节目 被赞专业，认真","title_line_break":"张曼玉加盟谢霆锋节目\n被赞专业，认真","date":"2016-09-05 09:45:18","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57ccce2e9490cbd77d00000c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE5OF80NDU3OV9XNjQwSDM2MFMyNjYzOC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NDE5OF80NDU3OV9XNjQwSDM2MFMyNjYzOC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ccce2e9490cbd77d00000c&m=1473044200","list_dtime":"2016-09-05 09:45:18"},{"pk":"57cbe0089490cba435000059","title":"《爱情万万岁》导演玩颠覆 赞刘涛爷们","title_line_break":"《爱情万万岁》导演玩颠覆\n赞刘涛爷们","date":"2016-09-04 16:48:15","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cbe0089490cba435000059","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTY0Ml80MzUyX1c2NDBIMzYwUzQzOTI0LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTY0Ml80MzUyX1c2NDBIMzYwUzQzOTI0LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cbe0089490cba435000059&m=1472979644","list_dtime":"2016-09-04 16:48:15"},{"pk":"57cbdd659490cb9935000030","title":"这一定是我看过最三观不正的电视剧！","date":"2016-09-04 16:37:57","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cbdd659490cb9935000030","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTYxM181NjEzNF9XNjQwSDM2MFMyODgwMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTYxM181NjEzNF9XNjQwSDM2MFMyODgwMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"32","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cbdd659490cb9935000030&m=1472979614","list_dtime":"2016-09-04 16:37:57"},{"pk":"57cbbc2f9490cbaa3500003d","title":"万万想不到，这些角色竟然是一个人演的","date":"2016-09-04 14:14:52","auther_name":"芭莎娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cbbc2f9490cbaa3500003d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTc1MF8yMjc1OF9XNjQwSDM2MFMzODM0Ny5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTc1MF8yMjc1OF9XNjQwSDM2MFMzODM0Ny5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"42","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cbbc2f9490cbaa3500003d&m=1472979752","list_dtime":"2016-09-04 14:14:52"},{"pk":"57cbb85f9490cba935000040","title":"传黄晓明夫妇、王俊凯王源出演《凉生》？","date":"2016-09-04 13:58:47","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cbb85f9490cba935000040","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTc4OF83MTczN19XNjQwSDM2MFMyMjQ4My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTc4OF83MTczN19XNjQwSDM2MFMyMjQ4My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"19","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cbb85f9490cba935000040&m=1472979789","list_dtime":"2016-09-04 13:58:47"},{"pk":"57cb8e039490cbe63500001a","title":"范冰冰PK林志玲 谁才是T台女王？","title_line_break":"范冰冰PK林志玲\n谁才是T台女王？","date":"2016-09-04 10:59:15","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb8e039490cbe63500001a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTgxOV8yNzk1Ml9XNjQwSDM2MFM2NTkzMC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTgxOV8yNzk1Ml9XNjQwSDM2MFM2NTkzMC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cb8e039490cbe63500001a&m=1472979821","list_dtime":"2016-09-04 10:59:15"},{"pk":"57cb83ac1bc8e0000b000021","title":"那些年我们一起追过的偶像剧男神","date":"2016-09-04 10:56:34","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57cb83ac1bc8e0000b000021","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTg0Ml8xMTU3NF9XNjQwSDM2MFM0NzM0Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTg0Ml8xMTU3NF9XNjQwSDM2MFM0NzM0Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cb83ac1bc8e0000b000021&m=1472979844","list_dtime":"2016-09-04 10:56:34"},{"pk":"57cb8cc89490cbb93500002c","title":"《莽荒纪》王鸥携手刘恺威演绎东方传奇","date":"2016-09-04 10:53:18","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb8cc89490cbb93500002c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTg2Ml84Njk1Ml9XNjQwSDM2MFM0ODUwMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTg2Ml84Njk1Ml9XNjQwSDM2MFM0ODUwMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cb8cc89490cbb93500002c&m=1472979864","list_dtime":"2016-09-04 10:53:18"},{"pk":"57cb8c209490cbdf35000020","title":"《唐伯虎点秋香》花絮照 杀马特好抢镜","title_line_break":"《唐伯虎点秋香》花絮照\n杀马特好抢镜","date":"2016-09-04 10:50:22","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb8c209490cbdf35000020","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTg3OF84MjE3MF9XNjQwSDM2MFM2ODMzOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk3OTg3OF84MjE3MF9XNjQwSDM2MFM2ODMzOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cb8c209490cbdf35000020&m=1472979879","list_dtime":"2016-09-04 10:50:22"},{"pk":"57cb7d0a9490cbdc35000027","title":"青春片编剧为什么总对校花充满恶意？","date":"2016-09-04 09:46:50","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cb7d0a9490cbdc35000027","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk4MDE1MF8xNzgxMl9XNjQwSDM2MFMzNzA0MS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDQvdXBfMTQ3Mjk4MDE1MF8xNzgxMl9XNjQwSDM2MFMzNzA0MS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"63","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cb7d0a9490cbdc35000027&m=1472980152","list_dtime":"2016-09-04 09:46:50"},{"pk":"57cabf169490cb0b3f000055","title":"VIP尊贵体验：没想到你是这样的鹅厂","title_line_break":"VIP尊贵体验：\n没想到你是这样的鹅厂","date":"2016-09-03 20:14:01","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57cabf169490cb0b3f000055","thumbnail_pic":"http://zkres.myzaker.com/201609/57cabf40a07aecc52300bf43_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cabf40a07aecc52300bf43_320.jpg","thumbnail_picsize":"600,450","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cabf169490cb0b3f000055&m=1472905122","list_dtime":"2016-09-03 20:14:01"},{"pk":"57ca6b569490cb4c3f000028","title":"《跨界喜剧王》首播 费玉清再出新段子","title_line_break":"《跨界喜剧王》首播\n费玉清再出新段子","date":"2016-09-03 14:18:16","auther_name":"中国新闻网","weburl":"http://iphone.myzaker.com/l.php?l=57ca6b569490cb4c3f000028","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca34af1bc8e02248000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca34af1bc8e02248000007_320.jpg","thumbnail_picsize":"500,333","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57ca6b569490cb4c3f000028&m=1472883557","list_dtime":"2016-09-03 14:18:16"},{"pk":"57c947819490cb0818000084","title":"《职场健康课》:强迫症了怎么办？","title_line_break":"《职场健康课》:\n强迫症了怎么办？","date":"2016-09-02 17:32:33","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c947819490cb0818000084","thumbnail_pic":"http://zkres.myzaker.com/201609/57c94791a07aecc523001e84_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c94791a07aecc523001e84_320.jpg","thumbnail_picsize":"337,224","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c947819490cb0818000084&m=1472808999","list_dtime":"2016-09-02 17:32:33"},{"pk":"57c946ed9490cb4218000062","title":"《亲爱的公主病》不只有毒 还炸裂少女心","title_line_break":"《亲爱的公主病》不只有毒\n还炸裂少女心","date":"2016-09-02 17:29:03","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c946ed9490cb4218000062","thumbnail_pic":"http://zkres.myzaker.com/201609/57c94700a07aecc523001e0f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c94700a07aecc523001e0f_320.jpg","thumbnail_picsize":"533,327","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c946ed9490cb4218000062&m=1472808804","list_dtime":"2016-09-02 17:29:03"},{"pk":"57c946339490cb2c1800005b","title":"黄磊立足脱口秀  美食档诠释有爱生活","date":"2016-09-02 17:22:59","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c946339490cb2c1800005b","thumbnail_pic":"http://zkres.myzaker.com/data/attachment/editor/2016/09/02/1472808462.png","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c94660a07aecc523001dfc_320.jpg","thumbnail_picsize":"507,301","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c946339490cb2c1800005b&m=1472808637","list_dtime":"2016-09-02 17:22:59"},{"pk":"57c920659490cbf117000048","title":"《麻雀》即将开播 李易峰周冬雨隐忍爱恋","title_line_break":"《麻雀》即将开播\n李易峰周冬雨隐忍爱恋","date":"2016-09-02 14:46:03","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c920659490cbf117000048","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9207ea07aecc52300043f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9207ea07aecc52300043f_320.jpg","thumbnail_picsize":"500,333","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c920659490cbf117000048&m=1472798867","list_dtime":"2016-09-02 14:46:03"},{"pk":"57c91fd49490cb3b18000055","title":"《百变吧星居》曝宣传片 明星阵容公布","title_line_break":"《百变吧星居》曝宣传片\n明星阵容公布","date":"2016-09-02 14:43:05","auther_name":"网易娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c91fd49490cb3b18000055","thumbnail_pic":"http://zkres.myzaker.com/201609/57c91ff2a07aecc523000429_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c91ff2a07aecc523000429_320.jpg","thumbnail_picsize":"550,367","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c91fd49490cb3b18000055&m=1472798788","list_dtime":"2016-09-02 14:43:05"},{"pk":"57c91f469490cbfb17000036","title":"《黄金单身汉》 \u201c正经\u201d女主播跨国求爱","title_line_break":"《黄金单身汉》\n\u201c正经\u201d女主播跨国求爱","date":"2016-09-02 14:38:22","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c91f469490cbfb17000036","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c91f469490cbfb17000036&m=1472798583","list_dtime":"2016-09-02 14:38:22"},{"pk":"57c91dc19490cbfe17000043","title":"超女决赛冠军夜将启 \u201c超女红\u201d引回忆","title_line_break":"超女决赛冠军夜将启\n\u201c超女红\u201d引回忆","date":"2016-09-02 14:32:29","auther_name":"网易娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c91dc19490cbfe17000043","thumbnail_pic":"http://zkres.myzaker.com/201609/57c91dcba07aecc52300039c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c91dcba07aecc52300039c_320.jpg","thumbnail_picsize":"780,517","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c91dc19490cbfe17000043&m=1472798185","list_dtime":"2016-09-02 14:32:29"},{"pk":"57c91ca19490cb2b18000043","title":"大咖空降慈善晚会 加拿大少年泪别中国","title_line_break":"大咖空降慈善晚会\n加拿大少年泪别中国","date":"2016-09-02 14:30:02","auther_name":"腾讯娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c91ca19490cb2b18000043","thumbnail_pic":"http://zkres.myzaker.com/201609/57c91ca9a07aecc523000351_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c91ca9a07aecc523000351_320.jpg","thumbnail_picsize":"500,278","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c91ca19490cb2b18000043&m=1472797919","list_dtime":"2016-09-02 14:30:02"},{"pk":"57c91b999490cb1f18000036","title":"江苏卫视联手乐视开启\u201c919狂欢夜\u201d","date":"2016-09-02 14:23:57","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c91b999490cb1f18000036","thumbnail_pic":"http://zkres.myzaker.com/201609/57c91bafa07aecc523000218_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c91bafa07aecc523000218_320.jpg","thumbnail_picsize":"600,909","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c91b999490cb1f18000036&m=1472797633","list_dtime":"2016-09-02 14:23:57"},{"pk":"57c9172e9490cbfb1700002b","title":"说好《W》甜蜜结局，最后竟让女主死了","date":"2016-09-02 14:07:42","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c9172e9490cbfb1700002b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8fd851bc8e0a70600005a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8fd851bc8e0a70600005a_320.jpg","thumbnail_picsize":"350,194","media_count":"38","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c9172e9490cbfb1700002b&m=1472796629","list_dtime":"2016-09-02 14:07:42"},{"pk":"57c8edad9490cbcd17000035","title":"蒋欣颠覆熟女形象 不惜为角色增加体重","title_line_break":"蒋欣颠覆熟女形象\n不惜为角色增加体重","date":"2016-09-02 11:09:35","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8edad9490cbcd17000035","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8edb4a07aec1352002e9f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8edb4a07aec1352002e9f_320.jpg","thumbnail_picsize":"600,400","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c8edad9490cbcd17000035&m=1472785975","list_dtime":"2016-09-02 11:09:35"},{"pk":"57c8eae09490cb2718000030","title":"《极速》晶刚夫妇：我们从来没有秀恩爱","title_line_break":"《极速》晶刚夫妇：\n我们从来没有秀恩爱","date":"2016-09-02 10:57:53","auther_name":"凤凰娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8eae09490cb2718000030","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8eaeca07aec1352002be2_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8eaeca07aec1352002be2_320.jpg","thumbnail_picsize":"600,400","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c8eae09490cb2718000030&m=1472785304","list_dtime":"2016-09-02 10:57:53"},{"pk":"57c8e7ab9490cbda1700004a","title":"肖奈微微鸳鸯浴被删，没事，有地咚花絮！","date":"2016-09-02 10:44:59","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8e7ab9490cbda1700004a","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d2b51bc8e0786e00003f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d2b51bc8e0786e00003f_320.jpg","thumbnail_picsize":"600,424","media_count":"32","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c8e7ab9490cbda1700004a&m=1472784637","list_dtime":"2016-09-02 10:44:59"},{"pk":"57c8e4369490cb151800002d","title":"《美人为馅》预告 这带感的剧情不看不行","title_line_break":"《美人为馅》预告\n这带感的剧情不看不行","date":"2016-09-02 10:30:14","auther_name":"橘子娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c8e4369490cb151800002d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c82a9f1bc8e0b111000022_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c82a9f1bc8e0b111000022_320.jpg","thumbnail_picsize":"350,197","media_count":"35","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c8e4369490cb151800002d&m=1472784947","list_dtime":"2016-09-02 10:30:14"},{"pk":"57c8d2f91bc8e0f66f000035","title":"红极一时的古装花旦，为爱甘当家庭主妇","date":"2016-09-02 10:16:17","auther_name":"北青网","weburl":"http://iphone.myzaker.com/l.php?l=57c8d2f91bc8e0f66f000035","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d2171bc8e0896f000031_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d2171bc8e0896f000031_320.jpg","thumbnail_picsize":"450,281","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c8d2f91bc8e0f66f000035&m=1472782757","list_dtime":"2016-09-02 10:16:17"},{"pk":"57c7f5b19490cbd62c000066","title":"马东柳岩遭肥胖危机加盟《拜拜啦肉肉》","date":"2016-09-01 17:33:35","auther_name":"ZAKER娱乐","weburl":"http://iphone.myzaker.com/l.php?l=57c7f5b19490cbd62c000066","thumbnail_pic":"http://zkres.myzaker.com/data/attachment/editor/2016/09/01/1472722288.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7f5c1a07aecf77e048559_320.jpg","thumbnail_picsize":"1459,957","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57c7f5b19490cbd62c000066&m=1472722510","list_dtime":"2016-09-01 17:33:35"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cd06439490cb497e000026,57cd0c819490cb057e000040,57ccd5e19490cb037e00002f,57ccd56d9490cb4d7e000020,57ccdd359490cbf27d000026,57ccdb9c9490cb157e000024","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccd2ab9490cb507e000030,57ccd4b59490cb6358000001,57ccce2e9490cbd77d00000c,57cbe0089490cba435000059,57cbdd659490cb9935000030,57cbbc2f9490cbaa3500003d","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cb8e039490cbe63500001a,57cbb85f9490cba935000040,57cb83ac1bc8e0000b000021,57cb8cc89490cbb93500002c,57cb8c209490cbdf35000020,57cb7d0a9490cbdc35000027","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ca6b569490cb4c3f000028,57cabf169490cb0b3f000055,57c947819490cb0818000084,57c946ed9490cb4218000062,57c946339490cb2c1800005b,57c920659490cbf117000048","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c91dc19490cbfe17000043,57c91f469490cbfb17000036,57c91fd49490cb3b18000055,57c91ca19490cb2b18000043,57c91b999490cb1f18000036,57c9172e9490cbfb1700002b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c8eae09490cb2718000030,57c8edad9490cbcd17000035,57c8e7ab9490cbda1700004a,57c8e4369490cb151800002d,57c8d2f91bc8e0f66f000035,57c7f5b19490cbd62c000066","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#35b8c8","#35b8c8"],"only_text_page_bgcolors":["#35b8c8","#35b8c8"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11698.png?1420439444","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11698.png?1420439444","hidden_time":"24","need_userinfo":"NO","block_title":"电视","block_color":"#35b8c8","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_316b60b95df0bb647100087dc3e47e4c","selected_index":"2","list":[{"pk":"zk_app_column_9","title":"娱乐","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_10530","title":"电影","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"10530_zk_app_column_block_9","title":"电影资讯","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=10530&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_11698","title":"电视","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11698_zk_app_column_block_9","title":"电视","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11698&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_12348","title":"明星","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12348_zk_app_column_block_9","title":"明星","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12348&catalog_appid=9","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=11698&since_date=1472722415&nt=1&_appid=androidphone&catalog_appid=9
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=11698&need_app_integration=
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=11698&ids=51a7104681853dec4d00012f&k=201609051500
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/11698.png?1420439444
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/11698.png?1420439444
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 电视
         * block_color : #35b8c8
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_316b60b95df0bb647100087dc3e47e4c
         * selected_index : 2
         * list : [{"pk":"zk_app_column_9","title":"娱乐","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_10530","title":"电影","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"10530_zk_app_column_block_9","title":"电影资讯","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=10530&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_11698","title":"电视","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11698_zk_app_column_block_9","title":"电视","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11698&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_12348","title":"明星","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12348_zk_app_column_block_9","title":"明星","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12348&catalog_appid=9","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57cd0c819490cb057e000040
         * title : 《微微》火到越南，我担心他们会翻拍！
         * date : 2016-09-05 14:11:13
         * auther_name : 橘子娱乐
         * weburl : http://iphone.myzaker.com/l.php?l=57cd0c819490cb057e000040
         * thumbnail_pic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NjA4OV8xNTg4X1c2NDBIMzYwUzUwNDk3LmpwZw==_1242.jpg
         * thumbnail_mpic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NjA4OV8xNTg4X1c2NDBIMzYwUzUwNDk3LmpwZw==_1242.jpg
         * thumbnail_picsize : 640,360
         * media_count : 22
         * is_full : NO
         * content :
         * special_info : {"show_jingcai":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11698&pk=57cd0c819490cb057e000040&m=1473056090
         * list_dtime : 2016-09-05 14:11:13
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 2
             * articles : 57cd06439490cb497e000026,57cd0c819490cb057e000040,57ccd5e19490cb037e00002f,57ccd56d9490cb4d7e000020,57ccdd359490cbf27d000026,57ccdb9c9490cb157e000024
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * open_type :
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_9
             * title : 娱乐
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 9
                 * title : 娱乐八卦
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9
                 * data_type : news
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String is_full;
            private String content;
            /**
             * show_jingcai : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String show_jingcai;

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }
            }
        }
    }
}
