package com.example.dllo.zaker.welcome;

import com.example.dllo.zaker.base.BaseActivity;

/**
 * Created by dllo on 16/9/5.
 */
public class WelcomeActivity extends BaseActivity{
    @Override
    protected int getLayout() {
        return 0;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
