package com.example.dllo.zaker.hotspot.sec.comments;

import java.util.List;

/**
 * Created by dllo on 16/9/1.
 */
public class HotspotSecCommentBean {


    /**
     * stat : 1
     * msg : ok
     * data : {"article_like_counts":"0","comment_counts":"35","comments":[{"title":"最热评论","id":"hot_comment","list":[{"pk":"3C91A586-FB5A-9605-4BEE-CE538D24480F","auther_pk":"0","auther_name":"福建泉州用户*0154","auther_icon":"","content":"广州一江之隔是香港？阿里请的这水军写手太不走心了😂","date":"2016-08-27","time":"12:53:37","like_num":"40"},{"pk":"D2FA1CF1-5392-F6DF-C9EC-E357B24832D3","auther_pk":"11104330","auther_name":"阿纯","auther_icon":"http://q.qlogo.cn/qqapp/100318686/265A35292AEFD7717AB396DCF12FF509/40","content":"阿里黑卡俱乐部最终就是刷单俱乐部","date":"2016-08-27","time":"11:41:14","like_num":"30","is_zakeruser":"Y"},{"pk":"600B0EDC-4D67-0C85-6C9B-5ABE3CBAF496","auther_pk":"11298111","auther_name":"TonyHom","auther_icon":"http://q.qlogo.cn/qqapp/100318686/ACDB7B7B26726558D04260AEDB0FD822/40","content":"这是阿里内部宣传报上的文章吧？","date":"2016-08-27","time":"12:35:07","like_num":"25","is_zakeruser":"Y"},{"pk":"F14EA952-88D9-E3C2-E086-E126A40C9F4B","auther_pk":"10454231","auther_name":"EMC方","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5228/10454231_1426382422.jpg.210.jpg","content":"啰里八嗦一大堆屁话。三个字：能花钱。可是，能花不代表会花。","date":"2016-08-27","time":"11:37:54","like_num":"22","is_zakeruser":"Y"},{"pk":"0B75C0EB-9012-CB9F-B58C-0868BB5334E6","auther_pk":"0","auther_name":"浙江杭州用户*7035","auther_icon":"","content":"都是假货虚荣心造成货币大量印刷","date":"2016-08-27","time":"12:34:32","like_num":"12"},{"pk":"A28E4514-7BA7-82DF-336E-CF66FF013340","auther_pk":"0","auther_name":"上海用户*3468","auther_icon":"","content":"每年花上百万买假货？？？？","date":"2016-08-27","time":"17:31:22","like_num":"9"},{"pk":"D5C0665D-DE7C-328E-CA75-BF652AF26AB2","auther_pk":"0","auther_name":"甘肃兰州用户*0903","auther_icon":"","content":"这种垃圾软文出现在这里，你们收了多少钱？","date":"2016-08-27","time":"21:16:34","like_num":"6"},{"pk":"85427F2F-025C-936E-4E87-733A5D90C9B7","auther_pk":"1102262","auther_name":"百态庖丁","auther_icon":"http://tva4.sinaimg.cn/crop.0.6.1125.1125.50/65a8fa17jw8f5kp4obwq3j20v90vl77m.jpg","content":"腾讯也有 游戏心悦俱乐部，呵呵，都是一年几百万几千万的主","date":"2016-08-27","time":"22:30:36","like_num":"4","is_zakeruser":"Y"},{"pk":"505C054B-2E1D-A912-0975-E97E0AEC5294","auther_pk":"10809304","auther_name":"你说呢","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5405/10809304_1467903659.jpg.210.jpg","content":"莫名其妙扯出玛莎拉蒂，法拉利，跟什么什么apass摆在一起，想干嘛？ap屁股到底是什么意思？这软文可以。","date":"2016-08-28","time":"01:06:19","like_num":"4","is_zakeruser":"Y"},{"pk":"87F6D151-0ABB-335F-ABF6-706B6CECD8B9","auther_pk":"1726767","auther_name":"LeFlaneur","auther_icon":"http://tp4.sinaimg.cn/1252753151/50/40011421835/1","content":"我也有apass，从不觉得有啥用","date":"2016-08-27","time":"12:09:26","like_num":"3","is_zakeruser":"Y"}],"next_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=hot&pk=57c0f0dc1bc8e04a7a000018&comment_pk=87F6D151-0ABB-335F-ABF6-706B6CECD8B9&hot_page=1"},{"title":"最新评论","id":"new_comment","list":[{"pk":"B20BE8D7-8A98-9D07-FA32-95AF1E62E0D3","auther_pk":"10454231","auther_name":"EMC方","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5228/10454231_1426382422.jpg.210.jpg","content":"承认自己是会员并不是多么丢脸的事，所以不用抱歉。","date":"2016-08-30","time":"10:12:20","like_num":"0","is_zakeruser":"Y","reply_comment":{"pk":"E8183527-89F6-E10E-4557-7B579210E8AB","auther_pk":"1704541","auther_name":"养金毛的熊猫先生","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/853/1704541_1453021389.jpg.210.jpg","content":"抱歉，我就是黑卡会员，肯定比你会花","date":"2016-08-28","time":"14:19:59","like_num":"1","is_zakeruser":"Y"}},{"pk":"84E2BB6B-C2AA-8496-8FAE-0AC9DF52E5AB","auther_pk":"0","auther_name":"浙江温州用户*0184","auther_icon":"","content":"法克","date":"2016-08-28","time":"20:32:53","like_num":"0"},{"pk":"E8183527-89F6-E10E-4557-7B579210E8AB","auther_pk":"1704541","auther_name":"养金毛的熊猫先生","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/853/1704541_1453021389.jpg.210.jpg","content":"抱歉，我就是黑卡会员，肯定比你会花","date":"2016-08-28","time":"14:19:59","like_num":"1","is_zakeruser":"Y","reply_comment":{"pk":"F14EA952-88D9-E3C2-E086-E126A40C9F4B","auther_pk":"10454231","auther_name":"EMC方","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5228/10454231_1426382422.jpg.210.jpg","content":"啰里八嗦一大堆屁话。三个字：能花钱。可是，能花不代表会花。","date":"2016-08-27","time":"11:37:54","like_num":"22","is_zakeruser":"Y"}},{"pk":"B9DFE5D5-47EC-AB75-0D7A-732336A19AEF","auther_pk":"0","auther_name":"山东烟台用户*8645","auther_icon":"","content":"小编知道的真多","date":"2016-08-28","time":"10:56:15","like_num":"0"},{"pk":"6670E94E-9986-A85D-F08D-4924B2EE0F2A","auther_pk":"1967372","auther_name":"AmoreT","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/984/1967372_1443664925.jpg.210.jpg","content":"ˊ_>ˋ我的第一反应是刷单俱乐部。","date":"2016-08-28","time":"10:14:23","like_num":"0","is_zakeruser":"Y"},{"pk":"CD9B0848-5D42-5288-C5DB-8932ED6F7091","auther_pk":"0","auther_name":"江苏用户*2815","auther_icon":"","content":"不好意思，我就是心悦会员，没你说的那么豪","date":"2016-08-28","time":"09:06:29","like_num":"1","reply_comment":{"pk":"85427F2F-025C-936E-4E87-733A5D90C9B7","auther_pk":"1102262","auther_name":"百态庖丁","auther_icon":"http://tva4.sinaimg.cn/crop.0.6.1125.1125.50/65a8fa17jw8f5kp4obwq3j20v90vl77m.jpg","content":"腾讯也有 游戏心悦俱乐部，呵呵，都是一年几百万几千万的主","date":"2016-08-27","time":"22:30:36","like_num":"4","is_zakeruser":"Y"}},{"pk":"3301A56E-AEB4-6FC6-B1AF-CDD27735F228","auther_pk":"11659460","auther_name":"身骑白马走西口","auther_icon":"http://tva2.sinaimg.cn/crop.0.0.640.640.50/699c73dbjw8f2yrmtfsn6j20hs0hsq3e.jpg","content":"北京电影学院的学生，黑卡，有意思～","date":"2016-08-28","time":"09:00:36","like_num":"1","is_zakeruser":"Y"},{"pk":"069E7515-033E-F761-1FA1-DD61F9ABF18D","auther_pk":"11735482","auther_name":"佳徵*信:bbc972有刺激","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5868/11735482_1472000292.jpg.210.jpg","content":"我连金卡都没有","date":"2016-08-28","time":"07:11:21","like_num":"0","is_zakeruser":"Y"},{"pk":"2F8EF2A5-A6E0-A142-61E9-49841D4A05D1","auther_pk":"0","auther_name":"广东深圳用户*8854","auther_icon":"","content":"活久见！！","date":"2016-08-28","time":"05:20:10","like_num":"0"},{"pk":"EBF05B16-F9AF-C31F-C1BE-A3529D83635D","auther_pk":"10393789","auther_name":"≮Ｓheng√◎","auther_icon":"http://q.qlogo.cn/qqapp/100318686/F3555F766C100490073FE00208C674A6/40","content":"阿里的黑卡也相当于银行的黑卡，那些喷的人，你觉得是剁手可在别人眼里只不过九牛一毛，层次决定看法","date":"2016-08-28","time":"02:38:48","like_num":"1","is_zakeruser":"Y"}],"next_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=new&pk=57c0f0dc1bc8e04a7a000018&comment_pk=EBF05B16-F9AF-C31F-C1BE-A3529D83635D&new_page=1"}],"info":{"comment_like_url":"http://c.myzaker.com/weibo/api_comment_article_like.php","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply"}}
     */

    private String stat;
    private String msg;
    /**
     * article_like_counts : 0
     * comment_counts : 35
     * comments : [{"title":"最热评论","id":"hot_comment","list":[{"pk":"3C91A586-FB5A-9605-4BEE-CE538D24480F","auther_pk":"0","auther_name":"福建泉州用户*0154","auther_icon":"","content":"广州一江之隔是香港？阿里请的这水军写手太不走心了😂","date":"2016-08-27","time":"12:53:37","like_num":"40"},{"pk":"D2FA1CF1-5392-F6DF-C9EC-E357B24832D3","auther_pk":"11104330","auther_name":"阿纯","auther_icon":"http://q.qlogo.cn/qqapp/100318686/265A35292AEFD7717AB396DCF12FF509/40","content":"阿里黑卡俱乐部最终就是刷单俱乐部","date":"2016-08-27","time":"11:41:14","like_num":"30","is_zakeruser":"Y"},{"pk":"600B0EDC-4D67-0C85-6C9B-5ABE3CBAF496","auther_pk":"11298111","auther_name":"TonyHom","auther_icon":"http://q.qlogo.cn/qqapp/100318686/ACDB7B7B26726558D04260AEDB0FD822/40","content":"这是阿里内部宣传报上的文章吧？","date":"2016-08-27","time":"12:35:07","like_num":"25","is_zakeruser":"Y"},{"pk":"F14EA952-88D9-E3C2-E086-E126A40C9F4B","auther_pk":"10454231","auther_name":"EMC方","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5228/10454231_1426382422.jpg.210.jpg","content":"啰里八嗦一大堆屁话。三个字：能花钱。可是，能花不代表会花。","date":"2016-08-27","time":"11:37:54","like_num":"22","is_zakeruser":"Y"},{"pk":"0B75C0EB-9012-CB9F-B58C-0868BB5334E6","auther_pk":"0","auther_name":"浙江杭州用户*7035","auther_icon":"","content":"都是假货虚荣心造成货币大量印刷","date":"2016-08-27","time":"12:34:32","like_num":"12"},{"pk":"A28E4514-7BA7-82DF-336E-CF66FF013340","auther_pk":"0","auther_name":"上海用户*3468","auther_icon":"","content":"每年花上百万买假货？？？？","date":"2016-08-27","time":"17:31:22","like_num":"9"},{"pk":"D5C0665D-DE7C-328E-CA75-BF652AF26AB2","auther_pk":"0","auther_name":"甘肃兰州用户*0903","auther_icon":"","content":"这种垃圾软文出现在这里，你们收了多少钱？","date":"2016-08-27","time":"21:16:34","like_num":"6"},{"pk":"85427F2F-025C-936E-4E87-733A5D90C9B7","auther_pk":"1102262","auther_name":"百态庖丁","auther_icon":"http://tva4.sinaimg.cn/crop.0.6.1125.1125.50/65a8fa17jw8f5kp4obwq3j20v90vl77m.jpg","content":"腾讯也有 游戏心悦俱乐部，呵呵，都是一年几百万几千万的主","date":"2016-08-27","time":"22:30:36","like_num":"4","is_zakeruser":"Y"},{"pk":"505C054B-2E1D-A912-0975-E97E0AEC5294","auther_pk":"10809304","auther_name":"你说呢","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5405/10809304_1467903659.jpg.210.jpg","content":"莫名其妙扯出玛莎拉蒂，法拉利，跟什么什么apass摆在一起，想干嘛？ap屁股到底是什么意思？这软文可以。","date":"2016-08-28","time":"01:06:19","like_num":"4","is_zakeruser":"Y"},{"pk":"87F6D151-0ABB-335F-ABF6-706B6CECD8B9","auther_pk":"1726767","auther_name":"LeFlaneur","auther_icon":"http://tp4.sinaimg.cn/1252753151/50/40011421835/1","content":"我也有apass，从不觉得有啥用","date":"2016-08-27","time":"12:09:26","like_num":"3","is_zakeruser":"Y"}],"next_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=hot&pk=57c0f0dc1bc8e04a7a000018&comment_pk=87F6D151-0ABB-335F-ABF6-706B6CECD8B9&hot_page=1"},{"title":"最新评论","id":"new_comment","list":[{"pk":"B20BE8D7-8A98-9D07-FA32-95AF1E62E0D3","auther_pk":"10454231","auther_name":"EMC方","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5228/10454231_1426382422.jpg.210.jpg","content":"承认自己是会员并不是多么丢脸的事，所以不用抱歉。","date":"2016-08-30","time":"10:12:20","like_num":"0","is_zakeruser":"Y","reply_comment":{"pk":"E8183527-89F6-E10E-4557-7B579210E8AB","auther_pk":"1704541","auther_name":"养金毛的熊猫先生","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/853/1704541_1453021389.jpg.210.jpg","content":"抱歉，我就是黑卡会员，肯定比你会花","date":"2016-08-28","time":"14:19:59","like_num":"1","is_zakeruser":"Y"}},{"pk":"84E2BB6B-C2AA-8496-8FAE-0AC9DF52E5AB","auther_pk":"0","auther_name":"浙江温州用户*0184","auther_icon":"","content":"法克","date":"2016-08-28","time":"20:32:53","like_num":"0"},{"pk":"E8183527-89F6-E10E-4557-7B579210E8AB","auther_pk":"1704541","auther_name":"养金毛的熊猫先生","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/853/1704541_1453021389.jpg.210.jpg","content":"抱歉，我就是黑卡会员，肯定比你会花","date":"2016-08-28","time":"14:19:59","like_num":"1","is_zakeruser":"Y","reply_comment":{"pk":"F14EA952-88D9-E3C2-E086-E126A40C9F4B","auther_pk":"10454231","auther_name":"EMC方","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5228/10454231_1426382422.jpg.210.jpg","content":"啰里八嗦一大堆屁话。三个字：能花钱。可是，能花不代表会花。","date":"2016-08-27","time":"11:37:54","like_num":"22","is_zakeruser":"Y"}},{"pk":"B9DFE5D5-47EC-AB75-0D7A-732336A19AEF","auther_pk":"0","auther_name":"山东烟台用户*8645","auther_icon":"","content":"小编知道的真多","date":"2016-08-28","time":"10:56:15","like_num":"0"},{"pk":"6670E94E-9986-A85D-F08D-4924B2EE0F2A","auther_pk":"1967372","auther_name":"AmoreT","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/984/1967372_1443664925.jpg.210.jpg","content":"ˊ_>ˋ我的第一反应是刷单俱乐部。","date":"2016-08-28","time":"10:14:23","like_num":"0","is_zakeruser":"Y"},{"pk":"CD9B0848-5D42-5288-C5DB-8932ED6F7091","auther_pk":"0","auther_name":"江苏用户*2815","auther_icon":"","content":"不好意思，我就是心悦会员，没你说的那么豪","date":"2016-08-28","time":"09:06:29","like_num":"1","reply_comment":{"pk":"85427F2F-025C-936E-4E87-733A5D90C9B7","auther_pk":"1102262","auther_name":"百态庖丁","auther_icon":"http://tva4.sinaimg.cn/crop.0.6.1125.1125.50/65a8fa17jw8f5kp4obwq3j20v90vl77m.jpg","content":"腾讯也有 游戏心悦俱乐部，呵呵，都是一年几百万几千万的主","date":"2016-08-27","time":"22:30:36","like_num":"4","is_zakeruser":"Y"}},{"pk":"3301A56E-AEB4-6FC6-B1AF-CDD27735F228","auther_pk":"11659460","auther_name":"身骑白马走西口","auther_icon":"http://tva2.sinaimg.cn/crop.0.0.640.640.50/699c73dbjw8f2yrmtfsn6j20hs0hsq3e.jpg","content":"北京电影学院的学生，黑卡，有意思～","date":"2016-08-28","time":"09:00:36","like_num":"1","is_zakeruser":"Y"},{"pk":"069E7515-033E-F761-1FA1-DD61F9ABF18D","auther_pk":"11735482","auther_name":"佳徵*信:bbc972有刺激","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5868/11735482_1472000292.jpg.210.jpg","content":"我连金卡都没有","date":"2016-08-28","time":"07:11:21","like_num":"0","is_zakeruser":"Y"},{"pk":"2F8EF2A5-A6E0-A142-61E9-49841D4A05D1","auther_pk":"0","auther_name":"广东深圳用户*8854","auther_icon":"","content":"活久见！！","date":"2016-08-28","time":"05:20:10","like_num":"0"},{"pk":"EBF05B16-F9AF-C31F-C1BE-A3529D83635D","auther_pk":"10393789","auther_name":"≮Ｓheng√◎","auther_icon":"http://q.qlogo.cn/qqapp/100318686/F3555F766C100490073FE00208C674A6/40","content":"阿里的黑卡也相当于银行的黑卡，那些喷的人，你觉得是剁手可在别人眼里只不过九牛一毛，层次决定看法","date":"2016-08-28","time":"02:38:48","like_num":"1","is_zakeruser":"Y"}],"next_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=new&pk=57c0f0dc1bc8e04a7a000018&comment_pk=EBF05B16-F9AF-C31F-C1BE-A3529D83635D&new_page=1"}]
     * info : {"comment_like_url":"http://c.myzaker.com/weibo/api_comment_article_like.php","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply"}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String article_like_counts;
        private String comment_counts;
        /**
         * comment_like_url : http://c.myzaker.com/weibo/api_comment_article_like.php
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         */

        private InfoBean info;
        /**
         * title : 最热评论
         * id : hot_comment
         * list : [{"pk":"3C91A586-FB5A-9605-4BEE-CE538D24480F","auther_pk":"0","auther_name":"福建泉州用户*0154","auther_icon":"","content":"广州一江之隔是香港？阿里请的这水军写手太不走心了😂","date":"2016-08-27","time":"12:53:37","like_num":"40"},{"pk":"D2FA1CF1-5392-F6DF-C9EC-E357B24832D3","auther_pk":"11104330","auther_name":"阿纯","auther_icon":"http://q.qlogo.cn/qqapp/100318686/265A35292AEFD7717AB396DCF12FF509/40","content":"阿里黑卡俱乐部最终就是刷单俱乐部","date":"2016-08-27","time":"11:41:14","like_num":"30","is_zakeruser":"Y"},{"pk":"600B0EDC-4D67-0C85-6C9B-5ABE3CBAF496","auther_pk":"11298111","auther_name":"TonyHom","auther_icon":"http://q.qlogo.cn/qqapp/100318686/ACDB7B7B26726558D04260AEDB0FD822/40","content":"这是阿里内部宣传报上的文章吧？","date":"2016-08-27","time":"12:35:07","like_num":"25","is_zakeruser":"Y"},{"pk":"F14EA952-88D9-E3C2-E086-E126A40C9F4B","auther_pk":"10454231","auther_name":"EMC方","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5228/10454231_1426382422.jpg.210.jpg","content":"啰里八嗦一大堆屁话。三个字：能花钱。可是，能花不代表会花。","date":"2016-08-27","time":"11:37:54","like_num":"22","is_zakeruser":"Y"},{"pk":"0B75C0EB-9012-CB9F-B58C-0868BB5334E6","auther_pk":"0","auther_name":"浙江杭州用户*7035","auther_icon":"","content":"都是假货虚荣心造成货币大量印刷","date":"2016-08-27","time":"12:34:32","like_num":"12"},{"pk":"A28E4514-7BA7-82DF-336E-CF66FF013340","auther_pk":"0","auther_name":"上海用户*3468","auther_icon":"","content":"每年花上百万买假货？？？？","date":"2016-08-27","time":"17:31:22","like_num":"9"},{"pk":"D5C0665D-DE7C-328E-CA75-BF652AF26AB2","auther_pk":"0","auther_name":"甘肃兰州用户*0903","auther_icon":"","content":"这种垃圾软文出现在这里，你们收了多少钱？","date":"2016-08-27","time":"21:16:34","like_num":"6"},{"pk":"85427F2F-025C-936E-4E87-733A5D90C9B7","auther_pk":"1102262","auther_name":"百态庖丁","auther_icon":"http://tva4.sinaimg.cn/crop.0.6.1125.1125.50/65a8fa17jw8f5kp4obwq3j20v90vl77m.jpg","content":"腾讯也有 游戏心悦俱乐部，呵呵，都是一年几百万几千万的主","date":"2016-08-27","time":"22:30:36","like_num":"4","is_zakeruser":"Y"},{"pk":"505C054B-2E1D-A912-0975-E97E0AEC5294","auther_pk":"10809304","auther_name":"你说呢","auther_icon":"http://ucres.myzaker.com/img_upload/user_avatar/2016/5405/10809304_1467903659.jpg.210.jpg","content":"莫名其妙扯出玛莎拉蒂，法拉利，跟什么什么apass摆在一起，想干嘛？ap屁股到底是什么意思？这软文可以。","date":"2016-08-28","time":"01:06:19","like_num":"4","is_zakeruser":"Y"},{"pk":"87F6D151-0ABB-335F-ABF6-706B6CECD8B9","auther_pk":"1726767","auther_name":"LeFlaneur","auther_icon":"http://tp4.sinaimg.cn/1252753151/50/40011421835/1","content":"我也有apass，从不觉得有啥用","date":"2016-08-27","time":"12:09:26","like_num":"3","is_zakeruser":"Y"}]
         * next_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=hot&pk=57c0f0dc1bc8e04a7a000018&comment_pk=87F6D151-0ABB-335F-ABF6-706B6CECD8B9&hot_page=1
         */

        private List<CommentsBean> comments;

        public String getArticle_like_counts() {
            return article_like_counts;
        }

        public void setArticle_like_counts(String article_like_counts) {
            this.article_like_counts = article_like_counts;
        }

        public String getComment_counts() {
            return comment_counts;
        }

        public void setComment_counts(String comment_counts) {
            this.comment_counts = comment_counts;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public List<CommentsBean> getComments() {
            return comments;
        }

        public void setComments(List<CommentsBean> comments) {
            this.comments = comments;
        }

        public static class InfoBean {
            private String comment_like_url;
            private String comment_reply_url;

            public String getComment_like_url() {
                return comment_like_url;
            }

            public void setComment_like_url(String comment_like_url) {
                this.comment_like_url = comment_like_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }
        }

        public static class CommentsBean {
            private String title;
            private String id;
            private String next_url;
            /**
             * pk : 3C91A586-FB5A-9605-4BEE-CE538D24480F
             * auther_pk : 0
             * auther_name : 福建泉州用户*0154
             * auther_icon :
             * content : 广州一江之隔是香港？阿里请的这水军写手太不走心了😂
             * date : 2016-08-27
             * time : 12:53:37
             * like_num : 40
             */

            private List<ListBean> list;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String auther_pk;
                private String auther_name;
                private String auther_icon;
                private String content;
                private String date;
                private String time;
                private String like_num;

                private List<Reply_commentBean> mList;

                public List<Reply_commentBean> getList() {
                    return mList;
                }

                public void setList(List<Reply_commentBean> list) {
                    mList = list;
                }

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getAuther_pk() {
                    return auther_pk;
                }

                public void setAuther_pk(String auther_pk) {
                    this.auther_pk = auther_pk;
                }

                public String getAuther_name() {
                    return auther_name;
                }

                public void setAuther_name(String auther_name) {
                    this.auther_name = auther_name;
                }

                public String getAuther_icon() {
                    return auther_icon;
                }

                public void setAuther_icon(String auther_icon) {
                    this.auther_icon = auther_icon;
                }

                public String getContent() {
                    return content;
                }

                public void setContent(String content) {
                    this.content = content;
                }

                public String getDate() {
                    return date;
                }

                public void setDate(String date) {
                    this.date = date;
                }

                public String getTime() {
                    return time;
                }

                public void setTime(String time) {
                    this.time = time;
                }

                public String getLike_num() {
                    return like_num;
                }

                public void setLike_num(String like_num) {
                    this.like_num = like_num;
                }
            }

            public static class Reply_commentBean {
              private String pk;
                private String auther_pk;
                private String auther_name;
                private String auther_icon;
                private String content;
                private String date;
                private String time;
                private String like_num;
                private String is_zakeruser;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getAuther_pk() {
                    return auther_pk;
                }

                public void setAuther_pk(String auther_pk) {
                    this.auther_pk = auther_pk;
                }

                public String getAuther_name() {
                    return auther_name;
                }

                public void setAuther_name(String auther_name) {
                    this.auther_name = auther_name;
                }

                public String getAuther_icon() {
                    return auther_icon;
                }

                public void setAuther_icon(String auther_icon) {
                    this.auther_icon = auther_icon;
                }

                public String getContent() {
                    return content;
                }

                public void setContent(String content) {
                    this.content = content;
                }

                public String getDate() {
                    return date;
                }

                public void setDate(String date) {
                    this.date = date;
                }

                public String getTime() {
                    return time;
                }

                public void setTime(String time) {
                    this.time = time;
                }

                public String getLike_num() {
                    return like_num;
                }

                public void setLike_num(String like_num) {
                    this.like_num = like_num;
                }

                public String getIs_zakeruser() {
                    return is_zakeruser;
                }

                public void setIs_zakeruser(String is_zakeruser) {
                    this.is_zakeruser = is_zakeruser;
                }
            }
        }
    }
}
