package com.example.dllo.zaker.subscription;

import java.util.List;

/**
 * Created by dllo on 16/8/30.
 */
public class Bean_subscription {


    /**
     * stat : 1
     * msg : OK
     * data : {"info":{"common_api_url":"http://iphone.myzaker.com/zaker/common_api.php","readstat":"http://stat.myzaker.com/stat.php"},"message_info":{"refresh_key":"1472551201","show_key":"1398073055"},"list":[{"pk":"57c54cd5e292b2447f00000f","promotion_img":"http://zkres3.myzaker.com/img_upload/editor/img_upload/20160830/up_1472548137_74209_W1242H699S165860.jpg","img_height":"699","img_width":"1242","title":"黑龙江黑河气温逼近零度 市民穿棉袄","end_time":"1472558400","type":"topic","pop_type":"","hide_mask":"N","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c54cd5e292b2447f00000f&position=my_subscriptions_promotion&click_stat=1","stat_read_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c54cd5e292b2447f00000f&position=my_subscriptions_promotion_read&action=read","tag_info":{"type":"img","text":"top10","image_url":"http://zkres.myzaker.com/data/image/mark/top10_2x.png","img_height":"26","img_width":"46","tag_position":"1"},"start_time":"1472549430","topic":{"pk":"57c49441a07aecef2a000006","block_title":"20160830十说今日","title":"20160830十说今日","block_in_title":"20160830十说今日","type":"user","skey":"1472548149","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=660&topic_id=57c49441a07aecef2a000006"}},{"pk":"57c552a89490cba113000074","promotion_img":"http://zkres3.myzaker.com/img_upload/editor/img_upload/20160830/up_1472549538_40416_W640H360S66804.jpg","img_height":"360","img_width":"640","title":"令人垂涎！谷歌食堂的21道免费美食","end_time":"1472558400","type":"block","pop_type":"","hide_mask":"N","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c552a89490cba113000074&position=my_subscriptions_promotion&click_stat=1","stat_read_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c552a89490cba113000074&position=my_subscriptions_promotion_read&action=read","tag_info":{"type":"img","text":"频道","image_url":"http://zkres.myzaker.com/data/image/mark/channel_2x.png","img_height":"26","img_width":"46","tag_position":"1"},"start_time":"1472551200","block_info":{"pk":"13","title":"科技频道","stitle":"","block_title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=13","data_type":"rss","pic":"http://zkres.myzaker.com/data/image/logo/13.png?1413770585","large_pic":"http://zkres.myzaker.com/data/image/logo/ipad3/13.png?1413770585"}},{"pk":"57c543139490cb911300007b","promotion_img":"http://zkres3.myzaker.com/img_upload/editor/img_upload/20160830/up_1472545377_85814_W640H360S45301.jpg","img_height":"360","img_width":"640","title":"没想到女人全身最难瘦下来的部位竟然是它","end_time":"1472558400","type":"block","pop_type":"","hide_mask":"Y","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c543139490cb911300007b&position=my_subscriptions_promotion&click_stat=1","stat_read_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c543139490cb911300007b&position=my_subscriptions_promotion_read&action=read","tag_info":{"type":"img","text":"频道","image_url":"http://zkres.myzaker.com/data/image/mark/channel_2x.png","img_height":"26","img_width":"46","tag_position":"1"},"start_time":"1472551200","block_info":{"pk":"12","title":"时尚频道","stitle":"","block_title":"时尚频道","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=12","data_type":"rss","pic":"http://zkres.myzaker.com/data/image/logo/12.png?1383291556","large_pic":"http://zkres.myzaker.com/data/image/logo/ipad3/12.png?1383291556"}},{"pk":"57c557749490cb4e13000061","promotion_img":"http://zkres3.myzaker.com/img_upload/editor/img_upload/20160830/up_1472550763_55694_W1242H699S120413.jpg","img_height":"699","img_width":"1242","title":"哪件护肤品是你的换季必备呢？","end_time":"1472554800","type":"post","pop_type":"","hide_mask":"N","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c557749490cb4e13000061&position=my_subscriptions_promotion&click_stat=1","stat_read_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c557749490cb4e13000061&position=my_subscriptions_promotion_read&action=read","tag_info":{"type":"img","text":"话题","image_url":"http://zkres.myzaker.com/data/image/mark/huati_2x.png","img_height":"26","img_width":"46","tag_position":"1"},"start_time":"1472551200","post":{"pk":"57c556cf1716cf8a5d0000b5","discussion_id":"181","auther":{"name":"二十三姨","uid":"10967830","user_flag":[{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user.png"}],"icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5484/10967830_1446456066.jpg.210.jpg"},"title":"","date":"2016-08-30 17:50:07","comment_count":"1","hot_num":"0","post_tag":[],"content":"哪件护肤品是你的换季必备呢？\n\n夏末初秋，季节交替，一言不合就过敏的肌肤问题高发啊~过敏、泛红、痘痘这些烦人的肌肤烦恼，要靠哪件神器来拯救呢？","medias":[{"type":"image","id":"57c556cf1716cf6b5d0000d3","w":"640","h":"632","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c556cf1716cf6b5d0000d3.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c556cf1716cf6b5d0000d3.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c556cf1716cf6b5d0000d3.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c556cf1716cf6b5d0000d3.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c556cf1716cf6b5d0000d3.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=181&post_id=57c556cf1716cf8a5d0000b5","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=181&post_id=57c556cf1716cf8a5d0000b5&_appid=&_version=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=181&post_id=57c556cf1716cf8a5d0000b5","discussion":{"pk":"181","title":"我们都爱化妆品","stitle":"化妆护肤不分贵贱，效果是王道！","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd425b9490cb107b0000ee.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd425b9490cb107b0000ee.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=181","block_color":"","subscribe_count":"209715","post_count":"11403"}}},{"pk":"57c535db9490cbec7500003c","promotion_img":"http://zkres3.myzaker.com/img_upload/editor/img_upload/20160830/up_1472542154_97971_W640H360S95871.jpg","img_height":"360","img_width":"640","title":"除了调味，Ta们还是家里排忧解难的能手","end_time":"1472558580","type":"block","pop_type":"","hide_mask":"N","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c535db9490cbec7500003c&position=my_subscriptions_promotion&click_stat=1","stat_read_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c535db9490cbec7500003c&position=my_subscriptions_promotion_read&action=read","tag_info":{"type":"img","text":"频道","image_url":"http://zkres.myzaker.com/data/image/mark/channel_2x.png","img_height":"26","img_width":"46","tag_position":"1"},"start_time":"1472551200","block_info":{"pk":"11603","title":"生活达人","stitle":"","block_title":"生活达人","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=11603","data_type":"rss","pic":"http://zkres.myzaker.com/data/image/logo/11603.png?1417686974","large_pic":"http://zkres.myzaker.com/data/image/logo/ipad3/11603.png?1417686974"}}]}
     */

    private String stat;
    private String msg;
    /**
     * info : {"common_api_url":"http://iphone.myzaker.com/zaker/common_api.php","readstat":"http://stat.myzaker.com/stat.php"}
     * message_info : {"refresh_key":"1472551201","show_key":"1398073055"}
     * list : [{"pk":"57c54cd5e292b2447f00000f","promotion_img":"http://zkres3.myzaker.com/img_upload/editor/img_upload/20160830/up_1472548137_74209_W1242H699S165860.jpg","img_height":"699","img_width":"1242","title":"黑龙江黑河气温逼近零度 市民穿棉袄","end_time":"1472558400","type":"topic","pop_type":"","hide_mask":"N","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c54cd5e292b2447f00000f&position=my_subscriptions_promotion&click_stat=1","stat_read_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c54cd5e292b2447f00000f&position=my_subscriptions_promotion_read&action=read","tag_info":{"type":"img","text":"top10","image_url":"http://zkres.myzaker.com/data/image/mark/top10_2x.png","img_height":"26","img_width":"46","tag_position":"1"},"start_time":"1472549430","topic":{"pk":"57c49441a07aecef2a000006","block_title":"20160830十说今日","title":"20160830十说今日","block_in_title":"20160830十说今日","type":"user","skey":"1472548149","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=660&topic_id=57c49441a07aecef2a000006"}},{"pk":"57c552a89490cba113000074","promotion_img":"http://zkres3.myzaker.com/img_upload/editor/img_upload/20160830/up_1472549538_40416_W640H360S66804.jpg","img_height":"360","img_width":"640","title":"令人垂涎！谷歌食堂的21道免费美食","end_time":"1472558400","type":"block","pop_type":"","hide_mask":"N","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c552a89490cba113000074&position=my_subscriptions_promotion&click_stat=1","stat_read_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c552a89490cba113000074&position=my_subscriptions_promotion_read&action=read","tag_info":{"type":"img","text":"频道","image_url":"http://zkres.myzaker.com/data/image/mark/channel_2x.png","img_height":"26","img_width":"46","tag_position":"1"},"start_time":"1472551200","block_info":{"pk":"13","title":"科技频道","stitle":"","block_title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=13","data_type":"rss","pic":"http://zkres.myzaker.com/data/image/logo/13.png?1413770585","large_pic":"http://zkres.myzaker.com/data/image/logo/ipad3/13.png?1413770585"}},{"pk":"57c543139490cb911300007b","promotion_img":"http://zkres3.myzaker.com/img_upload/editor/img_upload/20160830/up_1472545377_85814_W640H360S45301.jpg","img_height":"360","img_width":"640","title":"没想到女人全身最难瘦下来的部位竟然是它","end_time":"1472558400","type":"block","pop_type":"","hide_mask":"Y","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c543139490cb911300007b&position=my_subscriptions_promotion&click_stat=1","stat_read_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c543139490cb911300007b&position=my_subscriptions_promotion_read&action=read","tag_info":{"type":"img","text":"频道","image_url":"http://zkres.myzaker.com/data/image/mark/channel_2x.png","img_height":"26","img_width":"46","tag_position":"1"},"start_time":"1472551200","block_info":{"pk":"12","title":"时尚频道","stitle":"","block_title":"时尚频道","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=12","data_type":"rss","pic":"http://zkres.myzaker.com/data/image/logo/12.png?1383291556","large_pic":"http://zkres.myzaker.com/data/image/logo/ipad3/12.png?1383291556"}},{"pk":"57c557749490cb4e13000061","promotion_img":"http://zkres3.myzaker.com/img_upload/editor/img_upload/20160830/up_1472550763_55694_W1242H699S120413.jpg","img_height":"699","img_width":"1242","title":"哪件护肤品是你的换季必备呢？","end_time":"1472554800","type":"post","pop_type":"","hide_mask":"N","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c557749490cb4e13000061&position=my_subscriptions_promotion&click_stat=1","stat_read_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c557749490cb4e13000061&position=my_subscriptions_promotion_read&action=read","tag_info":{"type":"img","text":"话题","image_url":"http://zkres.myzaker.com/data/image/mark/huati_2x.png","img_height":"26","img_width":"46","tag_position":"1"},"start_time":"1472551200","post":{"pk":"57c556cf1716cf8a5d0000b5","discussion_id":"181","auther":{"name":"二十三姨","uid":"10967830","user_flag":[{"pic":"http://zkres.myzaker.com/data/image/discussion/img/ic_official_user.png"}],"icon":"http://ucres.myzaker.com/img_upload/user_avatar/2015/5484/10967830_1446456066.jpg.210.jpg"},"title":"","date":"2016-08-30 17:50:07","comment_count":"1","hot_num":"0","post_tag":[],"content":"哪件护肤品是你的换季必备呢？\n\n夏末初秋，季节交替，一言不合就过敏的肌肤问题高发啊~过敏、泛红、痘痘这些烦人的肌肤烦恼，要靠哪件神器来拯救呢？","medias":[{"type":"image","id":"57c556cf1716cf6b5d0000d3","w":"640","h":"632","url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c556cf1716cf6b5d0000d3.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c556cf1716cf6b5d0000d3.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c556cf1716cf6b5d0000d3.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c556cf1716cf6b5d0000d3.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/08/30/57c556cf1716cf6b5d0000d3.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=181&post_id=57c556cf1716cf8a5d0000b5","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=181&post_id=57c556cf1716cf8a5d0000b5&_appid=&_version=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=181&post_id=57c556cf1716cf8a5d0000b5","discussion":{"pk":"181","title":"我们都爱化妆品","stitle":"化妆护肤不分贵贱，效果是王道！","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd425b9490cb107b0000ee.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd425b9490cb107b0000ee.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=181","block_color":"","subscribe_count":"209715","post_count":"11403"}}},{"pk":"57c535db9490cbec7500003c","promotion_img":"http://zkres3.myzaker.com/img_upload/editor/img_upload/20160830/up_1472542154_97971_W640H360S95871.jpg","img_height":"360","img_width":"640","title":"除了调味，Ta们还是家里排忧解难的能手","end_time":"1472558580","type":"block","pop_type":"","hide_mask":"N","ads_stat_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c535db9490cbec7500003c&position=my_subscriptions_promotion&click_stat=1","stat_read_url":"http://adm.myzaker.com/ads_stat.php?ads_id=57c535db9490cbec7500003c&position=my_subscriptions_promotion_read&action=read","tag_info":{"type":"img","text":"频道","image_url":"http://zkres.myzaker.com/data/image/mark/channel_2x.png","img_height":"26","img_width":"46","tag_position":"1"},"start_time":"1472551200","block_info":{"pk":"11603","title":"生活达人","stitle":"","block_title":"生活达人","api_url":"http://iphone.myzaker.com/zaker/news.php?app_id=11603","data_type":"rss","pic":"http://zkres.myzaker.com/data/image/logo/11603.png?1417686974","large_pic":"http://zkres.myzaker.com/data/image/logo/ipad3/11603.png?1417686974"}}]
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * common_api_url : http://iphone.myzaker.com/zaker/common_api.php
         * readstat : http://stat.myzaker.com/stat.php
         */

        private InfoBean info;
        /**
         * refresh_key : 1472551201
         * show_key : 1398073055
         */

        private MessageInfoBean message_info;
        /**
         * pk : 57c54cd5e292b2447f00000f
         * promotion_img : http://zkres3.myzaker.com/img_upload/editor/img_upload/20160830/up_1472548137_74209_W1242H699S165860.jpg
         * img_height : 699
         * img_width : 1242
         * title : 黑龙江黑河气温逼近零度 市民穿棉袄
         * end_time : 1472558400
         * type : topic
         * pop_type :
         * hide_mask : N
         * ads_stat_url : http://adm.myzaker.com/ads_stat.php?ads_id=57c54cd5e292b2447f00000f&position=my_subscriptions_promotion&click_stat=1
         * stat_read_url : http://adm.myzaker.com/ads_stat.php?ads_id=57c54cd5e292b2447f00000f&position=my_subscriptions_promotion_read&action=read
         * tag_info : {"type":"img","text":"top10","image_url":"http://zkres.myzaker.com/data/image/mark/top10_2x.png","img_height":"26","img_width":"46","tag_position":"1"}
         * start_time : 1472549430
         * topic : {"pk":"57c49441a07aecef2a000006","block_title":"20160830十说今日","title":"20160830十说今日","block_in_title":"20160830十说今日","type":"user","skey":"1472548149","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=660&topic_id=57c49441a07aecef2a000006"}
         */

        private List<ListBean> list;

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public MessageInfoBean getMessage_info() {
            return message_info;
        }

        public void setMessage_info(MessageInfoBean message_info) {
            this.message_info = message_info;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class InfoBean {
            private String common_api_url;
            private String readstat;

            public String getCommon_api_url() {
                return common_api_url;
            }

            public void setCommon_api_url(String common_api_url) {
                this.common_api_url = common_api_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }
        }

        public static class MessageInfoBean {
            private String refresh_key;
            private String show_key;

            public String getRefresh_key() {
                return refresh_key;
            }

            public void setRefresh_key(String refresh_key) {
                this.refresh_key = refresh_key;
            }

            public String getShow_key() {
                return show_key;
            }

            public void setShow_key(String show_key) {
                this.show_key = show_key;
            }
        }

        public static class ListBean {
            private String pk;
            private String promotion_img;
            private String img_height;
            private String img_width;
            private String title;
            private String end_time;
            private String type;
            private String pop_type;
            private String hide_mask;
            private String ads_stat_url;
            private String stat_read_url;
            /**
             * type : img
             * text : top10
             * image_url : http://zkres.myzaker.com/data/image/mark/top10_2x.png
             * img_height : 26
             * img_width : 46
             * tag_position : 1
             */

            private TagInfoBean tag_info;
            private String start_time;
            /**
             * pk : 57c49441a07aecef2a000006
             * block_title : 20160830十说今日
             * title : 20160830十说今日
             * block_in_title : 20160830十说今日
             * type : user
             * skey : 1472548149
             * api_url : http://iphone.myzaker.com/zaker/topic.php?app_id=660&topic_id=57c49441a07aecef2a000006
             */

            private TopicBean topic;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getPromotion_img() {
                return promotion_img;
            }

            public void setPromotion_img(String promotion_img) {
                this.promotion_img = promotion_img;
            }

            public String getImg_height() {
                return img_height;
            }

            public void setImg_height(String img_height) {
                this.img_height = img_height;
            }

            public String getImg_width() {
                return img_width;
            }

            public void setImg_width(String img_width) {
                this.img_width = img_width;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getEnd_time() {
                return end_time;
            }

            public void setEnd_time(String end_time) {
                this.end_time = end_time;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getPop_type() {
                return pop_type;
            }

            public void setPop_type(String pop_type) {
                this.pop_type = pop_type;
            }

            public String getHide_mask() {
                return hide_mask;
            }

            public void setHide_mask(String hide_mask) {
                this.hide_mask = hide_mask;
            }

            public String getAds_stat_url() {
                return ads_stat_url;
            }

            public void setAds_stat_url(String ads_stat_url) {
                this.ads_stat_url = ads_stat_url;
            }

            public String getStat_read_url() {
                return stat_read_url;
            }

            public void setStat_read_url(String stat_read_url) {
                this.stat_read_url = stat_read_url;
            }

            public TagInfoBean getTag_info() {
                return tag_info;
            }

            public void setTag_info(TagInfoBean tag_info) {
                this.tag_info = tag_info;
            }

            public String getStart_time() {
                return start_time;
            }

            public void setStart_time(String start_time) {
                this.start_time = start_time;
            }

            public TopicBean getTopic() {
                return topic;
            }

            public void setTopic(TopicBean topic) {
                this.topic = topic;
            }

            public static class TagInfoBean {
                private String type;
                private String text;
                private String image_url;
                private String img_height;
                private String img_width;
                private String tag_position;

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public String getText() {
                    return text;
                }

                public void setText(String text) {
                    this.text = text;
                }

                public String getImage_url() {
                    return image_url;
                }

                public void setImage_url(String image_url) {
                    this.image_url = image_url;
                }

                public String getImg_height() {
                    return img_height;
                }

                public void setImg_height(String img_height) {
                    this.img_height = img_height;
                }

                public String getImg_width() {
                    return img_width;
                }

                public void setImg_width(String img_width) {
                    this.img_width = img_width;
                }

                public String getTag_position() {
                    return tag_position;
                }

                public void setTag_position(String tag_position) {
                    this.tag_position = tag_position;
                }
            }

            public static class TopicBean {
                private String pk;
                private String block_title;
                private String title;
                private String block_in_title;
                private String type;
                private String skey;
                private String api_url;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getBlock_title() {
                    return block_title;
                }

                public void setBlock_title(String block_title) {
                    this.block_title = block_title;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getBlock_in_title() {
                    return block_in_title;
                }

                public void setBlock_in_title(String block_in_title) {
                    this.block_in_title = block_in_title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public String getSkey() {
                    return skey;
                }

                public void setSkey(String skey) {
                    this.skey = skey;
                }

                public String getApi_url() {
                    return api_url;
                }

                public void setApi_url(String api_url) {
                    this.api_url = api_url;
                }
            }
        }
    }
}
