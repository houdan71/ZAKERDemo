package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/3.
 */
public class Bean_car {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=7&since_date=1472710386&nt=1&next_aticle_id=57c84e6d7f780bf00f00098f&_appid=androidphone&opage=2&otimestamp=140","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=7&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=7&ids=5642f2aa9490cbb13200000e,5472a9b69490cb48180000f9,51a7105381853db050000146&k=201609031130"},"catalog":"","articles":[{"pk":"57c6c4f77f780bf00f00005b","title":"我们用特斯拉Model X斗了回911，还闹出了个BUG","title_line_break":"我们用特斯拉Model\nX斗了回911，还闹出了个BUG","date":"2016-09-03 10:29:47","auther_name":"吴佩频道","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c6c4f77f780bf00f00005b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MDA0NF83MzY1MF9XNjQwSDM2MFMxNTY1NDUuanBn_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MDA0NF83MzY1MF9XNjQwSDM2MFMxNTY1NDUuanBn_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=7&pk=57c6c4f77f780bf00f00005b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c6c4f77f780bf00f00005b%26app_id%3D7%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c6c4f77f780bf00f00005b&m=1472873704","list_dtime":"2016-09-03 10:29:47"},{"pk":"57ca374b9490cbc33e000039","title":"公平之战 ：911  VS  AMG GT S","title_line_break":"公平之战 ：\n911  VS  AMG GT S","date":"2016-09-03 10:38:33","auther_name":"中国汽车画报","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ca374b9490cbc33e000039","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MDM3OV8zMTg0OV9XNjQwSDM2MFMxODgwODkuanBn_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MDM3OV8zMTg0OV9XNjQwSDM2MFMxODgwODkuanBn_1242.jpg","thumbnail_picsize":"640,360","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57ca374b9490cbc33e000039&m=1472873704","list_dtime":"2016-09-03 10:38:33"},{"pk":"57c918989490cbe61700002d","title":"#全民Z试驾# 全新宝马2系旅行车试驾火热招募中！","title_line_break":"#全民Z试驾#\n全新宝马2系旅行车试驾火热招募中！","date":"2016-09-02 14:12:43","auther_name":"ZAKER社区","page":"2","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c918989490cbe61700002d","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"185","title":"汽车总动员","stitle":"随心所欲畅聊关于汽车的一切","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=185","block_color":"","subscribe_count":"548327","post_count":"11644","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=7&app_ids=7&pk=57c918989490cbe61700002d&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c918989490cbe61700002d","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c918989490cbe61700002d&m=1472873704","list_dtime":"2016-09-02 14:12:43"},{"pk":"57ca36ff9490cb273f000015","title":"时光荏苒，青春不再，但终有你陪伴","date":"2016-09-03 10:47:24","auther_name":"汽车画刊AUTOBILD","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ca36ff9490cb273f000015","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTI5Nl82ODY2MF9XNjAwSDM0MFMxNjkyNTYuanBn_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTI5Nl82ODY2MF9XNjAwSDM0MFMxNjkyNTYuanBn_1242.jpg","thumbnail_picsize":"600,340","media_count":"13","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57ca36ff9490cb273f000015&m=1472873704","list_dtime":"2016-09-03 10:47:24"},{"pk":"57c768f77f52e96b5f00016c","title":"大咖点评成都车展上市新车，真的值得购买吗？","date":"2016-09-01 07:32:06","auther_name":"腾讯汽车","page":"1","index":"3","weburl":"http://iphone.myzaker.com/l.php?l=57c768f77f52e96b5f00016c","thumbnail_pic":"http://zkres.myzaker.com/201609/57c767917f52e9cb550001e3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c767917f52e9cb550001e3_320.jpg","thumbnail_picsize":"620,465","media_count":"2","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c780379490cb9d2c000027","block_title":"第十九届成都国际汽车展","title":"第十九届成都国际汽车展","block_in_title":"成都车展来临，这些新车消息你不能不知！","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=7&topic_id=57c780379490cb9d2c000027&updated=1472871420"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c768f77f52e96b5f00016c&m=1472873405","list_dtime":"2016-09-01 07:32:06"},{"pk":"57c91ccc9490cbf117000044","title":"外资车国产后质量真的会变差吗？","date":"2016-09-02 14:30:41","auther_name":"ZAKER社区","page":"4","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c91ccc9490cbf117000044","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"post","post":{"pk":"57c8042e9490cb306c00001a","discussion_id":"185","auther":{"name":"我系CK","uid":"3000666","icon":"http://zkres.myzaker.com/data/image/user_icon/icon_u2_666.jpg"},"title":"","date":"2016-09-01 18:34:22","comment_count":"8","hot_num":"46","post_tag":[{"name":"置顶","icon":"http://zkres.myzaker.com/data/image/mark2/stick3_2x.png"}],"content":"【外资品牌车国产后质量真的会变差吗？ 】\r\n最近捷豹XFL国产车上市挺轰动的，这让我想起一个问题：总有人会说外国品牌的车国产后质量终究是不如全进口车好的。甚至有人说宝马车国产了就不再是宝马了。但我觉得没那么严重。想问，外资品牌的国产车质量真的不如进口吗？","medias":[{"type":"image","id":"57c8042b9490cb306c000017","w":"1024","h":"682","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042b9490cb306c000017.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042b9490cb306c000017.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042b9490cb306c000017.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042b9490cb306c000017.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042b9490cb306c000017.jpg"},{"type":"image","id":"57c8042e9490cb306c000018","w":"800","h":"600","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000018.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000018.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000018.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000018.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000018.jpg"},{"type":"image","id":"57c8042e9490cb306c000019","w":"1026","h":"685","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000019.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000019.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000019.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000019.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000019.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=185&post_id=57c8042e9490cb306c00001a","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=185&post_id=57c8042e9490cb306c00001a&_appid=&_version=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=185&post_id=57c8042e9490cb306c00001a","discussion":{"pk":"185","title":"汽车总动员","stitle":"随心所欲畅聊关于汽车的一切","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=185","block_color":"","subscribe_count":"548326","post_count":"11644"},"need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=7&app_ids=7&pk=57c91ccc9490cbf117000044&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c91ccc9490cbf117000044","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c91ccc9490cbf117000044&m=1472873704","list_dtime":"2016-09-02 14:30:41"},{"pk":"57c930f59490cb1018000059","title":"源于赛道！静态体验奥迪R8 V10","title_line_break":"源于赛道！静态体验奥迪R8\nV10","date":"2016-09-02 16:12:20","auther_name":"太平洋汽车网","page":"5","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c930f59490cb1018000059","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjMzNl81MDA2MF9XNjEwSDM2MVMzNzcxMDIucG5n_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjMzNl81MDA2MF9XNjEwSDM2MVMzNzcxMDIucG5n_1242.jpg","thumbnail_picsize":"610,361","media_count":"50","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c930f59490cb1018000059&m=1472873704","list_dtime":"2016-09-02 16:12:20"},{"pk":"57c940569490cb0d18000065","title":"看了这些，下半赛季的F1就有得吹牛逼了！","date":"2016-09-02 17:10:17","auther_name":"赛车头条","page":"4","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c940569490cb0d18000065","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNzU2M183OTY5M19XNTQySDI4MlMxODU1NjkucG5n_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNzU2M183OTY5M19XNTQySDI4MlMxODU1NjkucG5n_1242.jpg","thumbnail_picsize":"542,282","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c940569490cb0d18000065&m=1472873704","list_dtime":"2016-09-02 17:10:17"},{"pk":"57ca310a1bc8e0777b000022","title":"扬州市一中门前斑马线上，轿车撞倒师生\u2026司机却怪阳光！","date":"2016-09-03 10:22:39","auther_name":" 扬州晚报","weburl":"http://iphone.myzaker.com/l.php?l=57ca310a1bc8e0777b000022","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca30eda07aecc523006c60_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca30eda07aecc523006c60_320.jpg","thumbnail_picsize":"409,251","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57ca310a1bc8e0777b000022&m=1472873665","list_dtime":"2016-09-03 10:22:39"},{"pk":"57c8ec779490cbf61700001d","title":"10款修起来最贵的轿车(紧凑型) 换车比修车更划算?","title_line_break":"10款修起来最贵的轿车(紧凑型)\n换车比修车更划算?","date":"2016-09-03 10:26:30","auther_name":"AutoMan","weburl":"http://iphone.myzaker.com/l.php?l=57c8ec779490cbf61700001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8351a7f52e96a7b000219_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8351a7f52e96a7b000219_320.jpg","thumbnail_picsize":"588,460","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8ec779490cbf61700001d&m=1472873665","list_dtime":"2016-09-03 10:26:30"},{"pk":"57c6c4fa7f780bf00f00005c","title":"在加拿大百里狂追全世界第一台Giulia ","title_line_break":"在加拿大百里狂追全世界第一台Giulia\n","date":"2016-09-03 10:30:10","auther_name":"吴佩频道","weburl":"http://iphone.myzaker.com/l.php?l=57c6c4fa7f780bf00f00005c","thumbnail_pic":"http://zkres.myzaker.com/201608/57c5eb897f52e9d973000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c5eb897f52e9d973000000_320.jpg","thumbnail_picsize":"1000,750","media_count":"29","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c6c4fa7f780bf00f00005c&m=1472873665","list_dtime":"2016-09-03 10:30:10"},{"pk":"57c8ebbc9490cb1d18000024","title":"新E级上市，会碾压5系和A6吗？","date":"2016-09-03 10:27:14","auther_name":"赛雷话车","weburl":"http://iphone.myzaker.com/l.php?l=57c8ebbc9490cb1d18000024","thumbnail_pic":"http://zkres.myzaker.com/201609/57c70d1d7f52e90d61000120_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c70d1d7f52e90d61000120_320.jpg","thumbnail_picsize":"701,586","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8ebbc9490cb1d18000024&m=1472873665","list_dtime":"2016-09-03 10:27:14"},{"pk":"57c136517f780be06700483a","title":"在自动驾驶的大潮前，马自达依旧玩心不改 ","title_line_break":"在自动驾驶的大潮前，马自达依旧玩心不改\n","date":"2016-09-03 10:29:20","auther_name":"吴佩频道","weburl":"http://iphone.myzaker.com/l.php?l=57c136517f780be06700483a","thumbnail_pic":"http://zkres.myzaker.com/201608/57c061b17f52e9ab110000cd_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c061b17f52e9ab110000cd_320.jpg","thumbnail_picsize":"1024,576","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c136517f780be06700483a&m=1472873665","list_dtime":"2016-09-03 10:29:20"},{"pk":"57c927671bc8e03f25000049","title":"加价买车是向4S店行贿，别这么干","date":"2016-09-03 10:28:01","auther_name":"车聚网","weburl":"http://iphone.myzaker.com/l.php?l=57c927671bc8e03f25000049","thumbnail_pic":"http://zkres.myzaker.com/201609/57c927651bc8e03f25000046_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c927651bc8e03f25000046_320.jpg","thumbnail_picsize":"672,497","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c927671bc8e03f25000049&m=1472873665","list_dtime":"2016-09-03 10:28:01"},{"pk":"57ca33439490cbde3e000034","title":"看看美媒试驾稿如何用2/3篇幅\u201c批评\u201d2016款大众途锐","date":"2016-09-03 10:20:12","auther_name":"东方早报咚咚买车","weburl":"http://iphone.myzaker.com/l.php?l=57ca33439490cbde3e000034","thumbnail_pic":"http://zkres.myzaker.com/201609/57c85c147f52e9320a0004f3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c85c147f52e9320a0004f3_320.jpg","thumbnail_picsize":"600,366","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57ca33439490cbde3e000034&m=1472873665","list_dtime":"2016-09-03 10:20:12"},{"pk":"57c949219490cb3a7e000012","title":"7座SUV市场要开战了，原来GS8有这么多对手！","date":"2016-09-02 17:50:44","auther_name":"车早茶","weburl":"http://iphone.myzaker.com/l.php?l=57c949219490cb3a7e000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57c90a9c7f52e91d1600023a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c90a9c7f52e91d1600023a_320.jpg","thumbnail_picsize":"600,400","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c949219490cb3a7e000012&m=1472873665","list_dtime":"2016-09-02 17:50:44"},{"pk":"57c944a19490cbe51700004a","title":"别克GL8将添兄弟车GL6 通杀一大片？","title_line_break":"别克GL8将添兄弟车GL6\n通杀一大片？","date":"2016-09-02 17:29:17","auther_name":"新浪汽车","weburl":"http://iphone.myzaker.com/l.php?l=57c944a19490cbe51700004a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwODU5Ml81MzAxM19XNjE0SDMyN1MyNDQ1MDUucG5n_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwODU5Ml81MzAxM19XNjE0SDMyN1MyNDQ1MDUucG5n_1242.jpg","thumbnail_picsize":"614,327","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c944a19490cbe51700004a&m=1472873665","list_dtime":"2016-09-02 17:29:17"},{"pk":"57ca331b9490cbf43e00003d","title":"如何在试驾中体验动力性？ 一味地轰油门并非正解","title_line_break":"如何在试驾中体验动力性？\n一味地轰油门并非正解","date":"2016-09-03 10:22:09","auther_name":"车辙","weburl":"http://iphone.myzaker.com/l.php?l=57ca331b9490cbf43e00003d","thumbnail_pic":"http://zkres.myzaker.com/201608/57c4fe517f52e9f3160000ec_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c4fe517f52e9f3160000ec_320.jpg","thumbnail_picsize":"526,405","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57ca331b9490cbf43e00003d&m=1472873665","list_dtime":"2016-09-03 10:22:09"},{"pk":"57ca33339490cbdd3e000029","title":"三菱\u201c燃效门\u201d升级：日媒曝光还有8款车燃油性能夸大其实","title_line_break":"三菱\u201c燃效门\u201d升级：\n日媒曝光还有8款车燃油性能夸大其实","date":"2016-09-03 10:21:43","auther_name":"东方早报咚咚买车","weburl":"http://iphone.myzaker.com/l.php?l=57ca33339490cbdd3e000029","thumbnail_pic":"http://zkres.myzaker.com/201609/57c85c1b7f52e92f0a0005b8_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c85c1b7f52e92f0a0005b8_320.jpg","thumbnail_picsize":"600,366","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57ca33339490cbdd3e000029&m=1472873665","list_dtime":"2016-09-03 10:21:43"},{"pk":"57c947f99490cb071800005f","title":"众泰新SUV内饰图曝光，你看它是自主还是模仿","date":"2016-09-02 17:38:43","auther_name":"快车报","weburl":"http://iphone.myzaker.com/l.php?l=57c947f99490cb071800005f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8665e7f52e9d909000613_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8665e7f52e9d909000613_320.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c947f99490cb071800005f&m=1472809146","list_dtime":"2016-09-02 17:38:43"},{"pk":"57c93b349490cb0118000088","title":"这就是全球十大最快车型 最高时速达442公里","title_line_break":"这就是全球十大最快车型\n最高时速达442公里","date":"2016-09-02 16:44:39","auther_name":"车迷杂志","weburl":"http://iphone.myzaker.com/l.php?l=57c93b349490cb0118000088","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjAzNF80ODMyNl9XNTMwSDI5NVMxNTIzNjEucG5n_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjAzNF80ODMyNl9XNTMwSDI5NVMxNTIzNjEucG5n_1242.jpg","thumbnail_picsize":"530,295","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c93b349490cb0118000088&m=1472873665","list_dtime":"2016-09-02 16:44:39"},{"pk":"57c8d2a41bc8e07630000014","title":"当车速超过100km/h时 车上哪些功能会失效","title_line_break":"当车速超过100km/h时\n车上哪些功能会失效","date":"2016-09-02 09:23:03","auther_name":" 车车世纪 ","weburl":"http://iphone.myzaker.com/l.php?l=57c8d2a41bc8e07630000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d29ca07aec1352001860_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d29ca07aec1352001860_320.jpg","thumbnail_picsize":"400,258","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8d2a41bc8e07630000014&m=1472793584","list_dtime":"2016-09-02 09:23:03"},{"pk":"57c7f4879490cba02c00006e","title":"酷炫的地铁的士来了，但它更像是游乐园观光车","date":"2016-09-02 16:24:05","auther_name":"GeekCar","weburl":"http://iphone.myzaker.com/l.php?l=57c7f4879490cba02c00006e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4MjQwOF85MDQ4Nl9XNjQwSDM2MFMxNzg3MjIuanBn_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4MjQwOF85MDQ4Nl9XNjQwSDM2MFMxNzg3MjIuanBn_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=7&pk=57c7f4879490cba02c00006e&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c7f4879490cba02c00006e%26app_id%3D7%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c7f4879490cba02c00006e&m=1472873665","list_dtime":"2016-09-02 16:24:05"},{"pk":"57c93f379490cb051800006d","title":"自主品牌要\u201c吊打\u201d韩系，法系要来抢地盘？","date":"2016-09-02 17:16:45","auther_name":"路由社","weburl":"http://iphone.myzaker.com/l.php?l=57c93f379490cb051800006d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8c5837f52e9d607000048_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8c5837f52e9d607000048_320.jpg","thumbnail_picsize":"640,439","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c93f379490cb051800006d&m=1472807870","list_dtime":"2016-09-02 17:16:45"},{"pk":"57c947629490cb0c18000059","title":"街游利器丰田86重口味改装，慎入！","date":"2016-09-02 17:39:42","auther_name":"跑车网","weburl":"http://iphone.myzaker.com/l.php?l=57c947629490cb0c18000059","thumbnail_pic":"http://zkres.myzaker.com/201608/57c46f597f52e9a729000b72_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c46f597f52e9a729000b72_320.jpg","thumbnail_picsize":"600,400","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c947629490cb0c18000059&m=1472809222","list_dtime":"2016-09-02 17:39:42"},{"pk":"57c93f549490cbdd1700006a","title":"低调！偷偷告诉你 哪些摄像头遇上也不用怕！","title_line_break":"低调！偷偷告诉你\n哪些摄像头遇上也不用怕！","date":"2016-09-02 17:14:47","auther_name":"玩车教授","weburl":"http://iphone.myzaker.com/l.php?l=57c93f549490cbdd1700006a","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c93f549490cbdd1700006a&m=1472807751","list_dtime":"2016-09-02 17:14:47"},{"pk":"57c93b779490cb2218000072","title":"一个亿不多？没错有时还不能买到一辆车！","date":"2016-09-02 16:48:00","auther_name":"汽车网评","weburl":"http://iphone.myzaker.com/l.php?l=57c93b779490cb2218000072","thumbnail_pic":"http://zkres.myzaker.com/201609/57c864bf1bc8e0393d000015_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c864bf1bc8e0393d000015_320.jpg","thumbnail_picsize":"547,422","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c93b779490cb2218000072&m=1472806224","list_dtime":"2016-09-02 16:48:00"},{"pk":"57c947989490cb2918000049","title":"我能骂街么？看国人驾车7大恶习","date":"2016-09-02 17:39:13","auther_name":"12缸汽车网","weburl":"http://iphone.myzaker.com/l.php?l=57c947989490cb2918000049","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8db871bc8e0e374000013_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8db871bc8e0e374000013_320.jpg","thumbnail_picsize":"500,374","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c947989490cb2918000049&m=1472809359","list_dtime":"2016-09-02 17:39:13"},{"pk":"57c8ea0a9490cb8127000015","title":"特斯拉准备向Model 3车主收取充电费","title_line_break":"特斯拉准备向Model\n3车主收取充电费","date":"2016-09-02 17:52:26","auther_name":"腾讯汽车","weburl":"http://iphone.myzaker.com/l.php?l=57c8ea0a9490cb8127000015","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8e5e17f52e9906e00019a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8e5e17f52e9906e00019a_320.jpg","thumbnail_picsize":"580,374","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8ea0a9490cb8127000015&m=1472809968","list_dtime":"2016-09-02 17:52:26"},{"pk":"57c93ad89490cb1b1800005a","title":"百度的大动作：除了无人驾驶，他们也要做自动驾驶了","title_line_break":"百度的大动作：\n除了无人驾驶，他们也要做自动驾驶了","date":"2016-09-03 10:25:11","auther_name":"GeekCar","weburl":"http://iphone.myzaker.com/l.php?l=57c93ad89490cb1b1800005a","thumbnail_pic":"http://zkres.myzaker.com/201609/57c835b61bc8e0d11a000005_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c835b61bc8e0d11a000005_320.jpg","thumbnail_picsize":"1000,750","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c93ad89490cb1b1800005a&m=1472873665","list_dtime":"2016-09-03 10:25:11"},{"pk":"57c844e91bc8e06d6100006b","title":"首台奔驰S级皮卡只为拖运一辆摩托车","date":"2016-09-02 09:36:36","auther_name":"改装车","weburl":"http://iphone.myzaker.com/l.php?l=57c844e91bc8e06d6100006b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c844cda07aecf77e04ab54_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c844cda07aecf77e04ab54_320.jpg","thumbnail_picsize":"960,622","media_count":"48","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c844e91bc8e06d6100006b&m=1472793584","list_dtime":"2016-09-02 09:36:36"},{"pk":"57c8d2241bc8e07230000011","title":"凯迪拉克核燃料汽车 无油可开足一百年","title_line_break":"凯迪拉克核燃料汽车\n无油可开足一百年","date":"2016-09-02 09:23:32","auther_name":"腾讯汽车 ","weburl":"http://iphone.myzaker.com/l.php?l=57c8d2241bc8e07230000011","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d21aa07aec135200183d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d21aa07aec135200183d_320.jpg","thumbnail_picsize":"980,698","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8d2241bc8e07230000011&m=1472793584","list_dtime":"2016-09-02 09:23:32"},{"pk":"57c949389490cb0c1800005a","title":"喜欢买SUV竟然是因为安全感缺失？","date":"2016-09-02 17:50:06","auther_name":"啊车网","weburl":"http://iphone.myzaker.com/l.php?l=57c949389490cb0c1800005a","thumbnail_pic":"http://zkres.myzaker.com/201609/57c802cf1bc8e0fe74000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c802cf1bc8e0fe74000001_320.jpg","thumbnail_picsize":"600,338","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c949389490cb0c1800005a&m=1472809852","list_dtime":"2016-09-02 17:50:06"},{"pk":"57c9450b9490cbe217000045","title":"看完这些霸气侧漏的路名 连老司机都懵逼了","title_line_break":"看完这些霸气侧漏的路名\n连老司机都懵逼了","date":"2016-09-02 17:30:40","auther_name":"汽车报","weburl":"http://iphone.myzaker.com/l.php?l=57c9450b9490cbe217000045","thumbnail_pic":"http://zkres.myzaker.com/201609/57c802bf7f52e95556000119_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c802bf7f52e95556000119_320.jpg","thumbnail_picsize":"640,427","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c9450b9490cbe217000045&m=1472808655","list_dtime":"2016-09-02 17:30:40"},{"pk":"57c8e48c9490cbd917000042","title":"德媒来中国试驾大众辉昂后 总结出九大特点","title_line_break":"德媒来中国试驾大众辉昂后\n总结出九大特点","date":"2016-09-02 10:54:48","auther_name":"DearAuto","weburl":"http://iphone.myzaker.com/l.php?l=57c8e48c9490cbd917000042","thumbnail_pic":"http://zkres.myzaker.com/201609/57c845d77f52e9d9090001af_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c845d77f52e9d9090001af_320.jpg","thumbnail_picsize":"170,197","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8e48c9490cbd917000042&m=1472793584","list_dtime":"2016-09-02 10:54:48"},{"pk":"57c8d1a91bc8e07d3000001d","title":"阿斯顿马丁最新跑车入华 暴降30万","title_line_break":"阿斯顿马丁最新跑车入华\n暴降30万","date":"2016-09-02 09:31:20","auther_name":"驱动之家 ","weburl":"http://iphone.myzaker.com/l.php?l=57c8d1a91bc8e07d3000001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d1a2a07aec13520017d5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d1a2a07aec13520017d5_320.jpg","thumbnail_picsize":"980,551","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8d1a91bc8e07d3000001d&m=1472793584","list_dtime":"2016-09-02 09:31:20"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c6c4f77f780bf00f00005b,57ca310a1bc8e0777b000022,57c768f77f52e96b5f00016c,57c8ec779490cbf61700001d,57c6c4fa7f780bf00f00005c,57c8ebbc9490cb1d18000024","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57ca374b9490cbc33e000039,57c136517f780be06700483a,57c927671bc8e03f25000049,57ca33439490cbde3e000034,57c949219490cb3a7e000012,57c918989490cbe61700002d","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca36ff9490cb273f000015,57c944a19490cbe51700004a,57ca331b9490cbf43e00003d,57ca33339490cbdd3e000029,57c947f99490cb071800005f,57c93b349490cb0118000088","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c940569490cb0d18000065,57c8d2a41bc8e07630000014,57c7f4879490cba02c00006e,57c93f379490cb051800006d,57c947629490cb0c18000059,57c91ccc9490cbf117000044","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c930f59490cb1018000059,57c93f549490cbdd1700006a,57c93b779490cb2218000072,57c947989490cb2918000049,57c8ea0a9490cb8127000015,57c93ad89490cb1b1800005a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c8d2241bc8e07230000011,57c844e91bc8e06d6100006b,57c949389490cb0c1800005a,57c9450b9490cbe217000045,57c8e48c9490cbd917000042,57c8d1a91bc8e07d3000001d","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#be4547","#be4547"],"only_text_page_bgcolors":["#be4547","#be4547"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/7.png?t=1463319366","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/7.png?t=1463319366","hidden_time":"24","need_userinfo":"NO","block_title":"汽车频道","block_color":"#be4547","desktop_color_number":"9","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_442b126ea6ff0336b46e335a46017113","selected_index":"0","list":[{"pk":"zk_app_column_7","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"7","title":"汽车频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=7&catalog_appid=7","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_web_288","title":"报价","type":"web","web":{"url":"http://iphone.myzaker.com/zaker/hezuo/cheshi/","need_user_info":"Y","type":""}},{"pk":"zk_app_column_11645","title":"导购","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11645_zk_app_column_block_7","title":"汽车频道-导购","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11645&catalog_appid=7","data_type":"news"}},{"pk":"zk_app_column_11646","title":"试驾","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11646_zk_app_column_block_7","title":"汽车频道-试驾","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11646&catalog_appid=7","data_type":"news"}},{"pk":"zk_app_column_discussion_273","title":"社区","type":"discussion","discussion":{"pk":"185","title":"汽车总动员","stitle":"随心所欲畅聊关于汽车的一切","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=185","block_color":"","subscribe_count":"493992","post_count":"8160"}}]}}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=7&since_date=1472710386&nt=1&next_aticle_id=57c84e6d7f780bf00f00098f&_appid=androidphone&opage=2&otimestamp=140","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=7&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=7&ids=5642f2aa9490cbb13200000e,5472a9b69490cb48180000f9,51a7105381853db050000146&k=201609031130"}
     * catalog :
     * articles : [{"pk":"57c6c4f77f780bf00f00005b","title":"我们用特斯拉Model X斗了回911，还闹出了个BUG","title_line_break":"我们用特斯拉Model\nX斗了回911，还闹出了个BUG","date":"2016-09-03 10:29:47","auther_name":"吴佩频道","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c6c4f77f780bf00f00005b","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MDA0NF83MzY1MF9XNjQwSDM2MFMxNTY1NDUuanBn_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MDA0NF83MzY1MF9XNjQwSDM2MFMxNTY1NDUuanBn_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=7&pk=57c6c4f77f780bf00f00005b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c6c4f77f780bf00f00005b%26app_id%3D7%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c6c4f77f780bf00f00005b&m=1472873704","list_dtime":"2016-09-03 10:29:47"},{"pk":"57ca374b9490cbc33e000039","title":"公平之战 ：911  VS  AMG GT S","title_line_break":"公平之战 ：\n911  VS  AMG GT S","date":"2016-09-03 10:38:33","auther_name":"中国汽车画报","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ca374b9490cbc33e000039","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MDM3OV8zMTg0OV9XNjQwSDM2MFMxODgwODkuanBn_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MDM3OV8zMTg0OV9XNjQwSDM2MFMxODgwODkuanBn_1242.jpg","thumbnail_picsize":"640,360","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57ca374b9490cbc33e000039&m=1472873704","list_dtime":"2016-09-03 10:38:33"},{"pk":"57c918989490cbe61700002d","title":"#全民Z试驾# 全新宝马2系旅行车试驾火热招募中！","title_line_break":"#全民Z试驾#\n全新宝马2系旅行车试驾火热招募中！","date":"2016-09-02 14:12:43","auther_name":"ZAKER社区","page":"2","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c918989490cbe61700002d","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"185","title":"汽车总动员","stitle":"随心所欲畅聊关于汽车的一切","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=185","block_color":"","subscribe_count":"548327","post_count":"11644","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=7&app_ids=7&pk=57c918989490cbe61700002d&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c918989490cbe61700002d","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c918989490cbe61700002d&m=1472873704","list_dtime":"2016-09-02 14:12:43"},{"pk":"57ca36ff9490cb273f000015","title":"时光荏苒，青春不再，但终有你陪伴","date":"2016-09-03 10:47:24","auther_name":"汽车画刊AUTOBILD","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ca36ff9490cb273f000015","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTI5Nl82ODY2MF9XNjAwSDM0MFMxNjkyNTYuanBn_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTI5Nl82ODY2MF9XNjAwSDM0MFMxNjkyNTYuanBn_1242.jpg","thumbnail_picsize":"600,340","media_count":"13","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57ca36ff9490cb273f000015&m=1472873704","list_dtime":"2016-09-03 10:47:24"},{"pk":"57c768f77f52e96b5f00016c","title":"大咖点评成都车展上市新车，真的值得购买吗？","date":"2016-09-01 07:32:06","auther_name":"腾讯汽车","page":"1","index":"3","weburl":"http://iphone.myzaker.com/l.php?l=57c768f77f52e96b5f00016c","thumbnail_pic":"http://zkres.myzaker.com/201609/57c767917f52e9cb550001e3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c767917f52e9cb550001e3_320.jpg","thumbnail_picsize":"620,465","media_count":"2","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c780379490cb9d2c000027","block_title":"第十九届成都国际汽车展","title":"第十九届成都国际汽车展","block_in_title":"成都车展来临，这些新车消息你不能不知！","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=7&topic_id=57c780379490cb9d2c000027&updated=1472871420"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c768f77f52e96b5f00016c&m=1472873405","list_dtime":"2016-09-01 07:32:06"},{"pk":"57c91ccc9490cbf117000044","title":"外资车国产后质量真的会变差吗？","date":"2016-09-02 14:30:41","auther_name":"ZAKER社区","page":"4","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c91ccc9490cbf117000044","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"post","post":{"pk":"57c8042e9490cb306c00001a","discussion_id":"185","auther":{"name":"我系CK","uid":"3000666","icon":"http://zkres.myzaker.com/data/image/user_icon/icon_u2_666.jpg"},"title":"","date":"2016-09-01 18:34:22","comment_count":"8","hot_num":"46","post_tag":[{"name":"置顶","icon":"http://zkres.myzaker.com/data/image/mark2/stick3_2x.png"}],"content":"【外资品牌车国产后质量真的会变差吗？ 】\r\n最近捷豹XFL国产车上市挺轰动的，这让我想起一个问题：总有人会说外国品牌的车国产后质量终究是不如全进口车好的。甚至有人说宝马车国产了就不再是宝马了。但我觉得没那么严重。想问，外资品牌的国产车质量真的不如进口吗？","medias":[{"type":"image","id":"57c8042b9490cb306c000017","w":"1024","h":"682","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042b9490cb306c000017.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042b9490cb306c000017.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042b9490cb306c000017.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042b9490cb306c000017.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042b9490cb306c000017.jpg"},{"type":"image","id":"57c8042e9490cb306c000018","w":"800","h":"600","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000018.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000018.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000018.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000018.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000018.jpg"},{"type":"image","id":"57c8042e9490cb306c000019","w":"1026","h":"685","url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000019.jpg.h800.jpg","m_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000019.jpg.h400.jpg","s_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000019.jpg.h200.jpg","min_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000019.jpg.h120.jpg","raw_url":"http://disres.myzaker.com/img_upload/discussion/2016/09/01/57c8042e9490cb306c000019.jpg"}],"weburl":"http://dis.myzaker.com/api/l.php?discussion_id=185&post_id=57c8042e9490cb306c00001a","content_url":"http://dis.myzaker.com/api/view_post.php?discussion_id=185&post_id=57c8042e9490cb306c00001a&_appid=&_version=","comment_list_url":"http://dis.myzaker.com/api/get_comment.php?discussion_id=185&post_id=57c8042e9490cb306c00001a","discussion":{"pk":"185","title":"汽车总动员","stitle":"随心所欲畅聊关于汽车的一切","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=185","block_color":"","subscribe_count":"548326","post_count":"11644"},"need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=7&app_ids=7&pk=57c91ccc9490cbf117000044&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c91ccc9490cbf117000044","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c91ccc9490cbf117000044&m=1472873704","list_dtime":"2016-09-02 14:30:41"},{"pk":"57c930f59490cb1018000059","title":"源于赛道！静态体验奥迪R8 V10","title_line_break":"源于赛道！静态体验奥迪R8\nV10","date":"2016-09-02 16:12:20","auther_name":"太平洋汽车网","page":"5","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c930f59490cb1018000059","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjMzNl81MDA2MF9XNjEwSDM2MVMzNzcxMDIucG5n_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjMzNl81MDA2MF9XNjEwSDM2MVMzNzcxMDIucG5n_1242.jpg","thumbnail_picsize":"610,361","media_count":"50","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c930f59490cb1018000059&m=1472873704","list_dtime":"2016-09-02 16:12:20"},{"pk":"57c940569490cb0d18000065","title":"看了这些，下半赛季的F1就有得吹牛逼了！","date":"2016-09-02 17:10:17","auther_name":"赛车头条","page":"4","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c940569490cb0d18000065","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNzU2M183OTY5M19XNTQySDI4MlMxODU1NjkucG5n_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNzU2M183OTY5M19XNTQySDI4MlMxODU1NjkucG5n_1242.jpg","thumbnail_picsize":"542,282","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c940569490cb0d18000065&m=1472873704","list_dtime":"2016-09-02 17:10:17"},{"pk":"57ca310a1bc8e0777b000022","title":"扬州市一中门前斑马线上，轿车撞倒师生\u2026司机却怪阳光！","date":"2016-09-03 10:22:39","auther_name":" 扬州晚报","weburl":"http://iphone.myzaker.com/l.php?l=57ca310a1bc8e0777b000022","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca30eda07aecc523006c60_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca30eda07aecc523006c60_320.jpg","thumbnail_picsize":"409,251","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57ca310a1bc8e0777b000022&m=1472873665","list_dtime":"2016-09-03 10:22:39"},{"pk":"57c8ec779490cbf61700001d","title":"10款修起来最贵的轿车(紧凑型) 换车比修车更划算?","title_line_break":"10款修起来最贵的轿车(紧凑型)\n换车比修车更划算?","date":"2016-09-03 10:26:30","auther_name":"AutoMan","weburl":"http://iphone.myzaker.com/l.php?l=57c8ec779490cbf61700001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8351a7f52e96a7b000219_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8351a7f52e96a7b000219_320.jpg","thumbnail_picsize":"588,460","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8ec779490cbf61700001d&m=1472873665","list_dtime":"2016-09-03 10:26:30"},{"pk":"57c6c4fa7f780bf00f00005c","title":"在加拿大百里狂追全世界第一台Giulia ","title_line_break":"在加拿大百里狂追全世界第一台Giulia\n","date":"2016-09-03 10:30:10","auther_name":"吴佩频道","weburl":"http://iphone.myzaker.com/l.php?l=57c6c4fa7f780bf00f00005c","thumbnail_pic":"http://zkres.myzaker.com/201608/57c5eb897f52e9d973000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c5eb897f52e9d973000000_320.jpg","thumbnail_picsize":"1000,750","media_count":"29","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c6c4fa7f780bf00f00005c&m=1472873665","list_dtime":"2016-09-03 10:30:10"},{"pk":"57c8ebbc9490cb1d18000024","title":"新E级上市，会碾压5系和A6吗？","date":"2016-09-03 10:27:14","auther_name":"赛雷话车","weburl":"http://iphone.myzaker.com/l.php?l=57c8ebbc9490cb1d18000024","thumbnail_pic":"http://zkres.myzaker.com/201609/57c70d1d7f52e90d61000120_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c70d1d7f52e90d61000120_320.jpg","thumbnail_picsize":"701,586","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8ebbc9490cb1d18000024&m=1472873665","list_dtime":"2016-09-03 10:27:14"},{"pk":"57c136517f780be06700483a","title":"在自动驾驶的大潮前，马自达依旧玩心不改 ","title_line_break":"在自动驾驶的大潮前，马自达依旧玩心不改\n","date":"2016-09-03 10:29:20","auther_name":"吴佩频道","weburl":"http://iphone.myzaker.com/l.php?l=57c136517f780be06700483a","thumbnail_pic":"http://zkres.myzaker.com/201608/57c061b17f52e9ab110000cd_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c061b17f52e9ab110000cd_320.jpg","thumbnail_picsize":"1024,576","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c136517f780be06700483a&m=1472873665","list_dtime":"2016-09-03 10:29:20"},{"pk":"57c927671bc8e03f25000049","title":"加价买车是向4S店行贿，别这么干","date":"2016-09-03 10:28:01","auther_name":"车聚网","weburl":"http://iphone.myzaker.com/l.php?l=57c927671bc8e03f25000049","thumbnail_pic":"http://zkres.myzaker.com/201609/57c927651bc8e03f25000046_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c927651bc8e03f25000046_320.jpg","thumbnail_picsize":"672,497","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c927671bc8e03f25000049&m=1472873665","list_dtime":"2016-09-03 10:28:01"},{"pk":"57ca33439490cbde3e000034","title":"看看美媒试驾稿如何用2/3篇幅\u201c批评\u201d2016款大众途锐","date":"2016-09-03 10:20:12","auther_name":"东方早报咚咚买车","weburl":"http://iphone.myzaker.com/l.php?l=57ca33439490cbde3e000034","thumbnail_pic":"http://zkres.myzaker.com/201609/57c85c147f52e9320a0004f3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c85c147f52e9320a0004f3_320.jpg","thumbnail_picsize":"600,366","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57ca33439490cbde3e000034&m=1472873665","list_dtime":"2016-09-03 10:20:12"},{"pk":"57c949219490cb3a7e000012","title":"7座SUV市场要开战了，原来GS8有这么多对手！","date":"2016-09-02 17:50:44","auther_name":"车早茶","weburl":"http://iphone.myzaker.com/l.php?l=57c949219490cb3a7e000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57c90a9c7f52e91d1600023a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c90a9c7f52e91d1600023a_320.jpg","thumbnail_picsize":"600,400","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c949219490cb3a7e000012&m=1472873665","list_dtime":"2016-09-02 17:50:44"},{"pk":"57c944a19490cbe51700004a","title":"别克GL8将添兄弟车GL6 通杀一大片？","title_line_break":"别克GL8将添兄弟车GL6\n通杀一大片？","date":"2016-09-02 17:29:17","auther_name":"新浪汽车","weburl":"http://iphone.myzaker.com/l.php?l=57c944a19490cbe51700004a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwODU5Ml81MzAxM19XNjE0SDMyN1MyNDQ1MDUucG5n_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwODU5Ml81MzAxM19XNjE0SDMyN1MyNDQ1MDUucG5n_1242.jpg","thumbnail_picsize":"614,327","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c944a19490cbe51700004a&m=1472873665","list_dtime":"2016-09-02 17:29:17"},{"pk":"57ca331b9490cbf43e00003d","title":"如何在试驾中体验动力性？ 一味地轰油门并非正解","title_line_break":"如何在试驾中体验动力性？\n一味地轰油门并非正解","date":"2016-09-03 10:22:09","auther_name":"车辙","weburl":"http://iphone.myzaker.com/l.php?l=57ca331b9490cbf43e00003d","thumbnail_pic":"http://zkres.myzaker.com/201608/57c4fe517f52e9f3160000ec_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c4fe517f52e9f3160000ec_320.jpg","thumbnail_picsize":"526,405","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57ca331b9490cbf43e00003d&m=1472873665","list_dtime":"2016-09-03 10:22:09"},{"pk":"57ca33339490cbdd3e000029","title":"三菱\u201c燃效门\u201d升级：日媒曝光还有8款车燃油性能夸大其实","title_line_break":"三菱\u201c燃效门\u201d升级：\n日媒曝光还有8款车燃油性能夸大其实","date":"2016-09-03 10:21:43","auther_name":"东方早报咚咚买车","weburl":"http://iphone.myzaker.com/l.php?l=57ca33339490cbdd3e000029","thumbnail_pic":"http://zkres.myzaker.com/201609/57c85c1b7f52e92f0a0005b8_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c85c1b7f52e92f0a0005b8_320.jpg","thumbnail_picsize":"600,366","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57ca33339490cbdd3e000029&m=1472873665","list_dtime":"2016-09-03 10:21:43"},{"pk":"57c947f99490cb071800005f","title":"众泰新SUV内饰图曝光，你看它是自主还是模仿","date":"2016-09-02 17:38:43","auther_name":"快车报","weburl":"http://iphone.myzaker.com/l.php?l=57c947f99490cb071800005f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8665e7f52e9d909000613_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8665e7f52e9d909000613_320.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c947f99490cb071800005f&m=1472809146","list_dtime":"2016-09-02 17:38:43"},{"pk":"57c93b349490cb0118000088","title":"这就是全球十大最快车型 最高时速达442公里","title_line_break":"这就是全球十大最快车型\n最高时速达442公里","date":"2016-09-02 16:44:39","auther_name":"车迷杂志","weburl":"http://iphone.myzaker.com/l.php?l=57c93b349490cb0118000088","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjAzNF80ODMyNl9XNTMwSDI5NVMxNTIzNjEucG5n_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgwNjAzNF80ODMyNl9XNTMwSDI5NVMxNTIzNjEucG5n_1242.jpg","thumbnail_picsize":"530,295","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c93b349490cb0118000088&m=1472873665","list_dtime":"2016-09-02 16:44:39"},{"pk":"57c8d2a41bc8e07630000014","title":"当车速超过100km/h时 车上哪些功能会失效","title_line_break":"当车速超过100km/h时\n车上哪些功能会失效","date":"2016-09-02 09:23:03","auther_name":" 车车世纪 ","weburl":"http://iphone.myzaker.com/l.php?l=57c8d2a41bc8e07630000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d29ca07aec1352001860_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d29ca07aec1352001860_320.jpg","thumbnail_picsize":"400,258","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8d2a41bc8e07630000014&m=1472793584","list_dtime":"2016-09-02 09:23:03"},{"pk":"57c7f4879490cba02c00006e","title":"酷炫的地铁的士来了，但它更像是游乐园观光车","date":"2016-09-02 16:24:05","auther_name":"GeekCar","weburl":"http://iphone.myzaker.com/l.php?l=57c7f4879490cba02c00006e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4MjQwOF85MDQ4Nl9XNjQwSDM2MFMxNzg3MjIuanBn_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc4MjQwOF85MDQ4Nl9XNjQwSDM2MFMxNzg3MjIuanBn_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=7&pk=57c7f4879490cba02c00006e&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c7f4879490cba02c00006e%26app_id%3D7%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c7f4879490cba02c00006e&m=1472873665","list_dtime":"2016-09-02 16:24:05"},{"pk":"57c93f379490cb051800006d","title":"自主品牌要\u201c吊打\u201d韩系，法系要来抢地盘？","date":"2016-09-02 17:16:45","auther_name":"路由社","weburl":"http://iphone.myzaker.com/l.php?l=57c93f379490cb051800006d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8c5837f52e9d607000048_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8c5837f52e9d607000048_320.jpg","thumbnail_picsize":"640,439","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c93f379490cb051800006d&m=1472807870","list_dtime":"2016-09-02 17:16:45"},{"pk":"57c947629490cb0c18000059","title":"街游利器丰田86重口味改装，慎入！","date":"2016-09-02 17:39:42","auther_name":"跑车网","weburl":"http://iphone.myzaker.com/l.php?l=57c947629490cb0c18000059","thumbnail_pic":"http://zkres.myzaker.com/201608/57c46f597f52e9a729000b72_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c46f597f52e9a729000b72_320.jpg","thumbnail_picsize":"600,400","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c947629490cb0c18000059&m=1472809222","list_dtime":"2016-09-02 17:39:42"},{"pk":"57c93f549490cbdd1700006a","title":"低调！偷偷告诉你 哪些摄像头遇上也不用怕！","title_line_break":"低调！偷偷告诉你\n哪些摄像头遇上也不用怕！","date":"2016-09-02 17:14:47","auther_name":"玩车教授","weburl":"http://iphone.myzaker.com/l.php?l=57c93f549490cbdd1700006a","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c93f549490cbdd1700006a&m=1472807751","list_dtime":"2016-09-02 17:14:47"},{"pk":"57c93b779490cb2218000072","title":"一个亿不多？没错有时还不能买到一辆车！","date":"2016-09-02 16:48:00","auther_name":"汽车网评","weburl":"http://iphone.myzaker.com/l.php?l=57c93b779490cb2218000072","thumbnail_pic":"http://zkres.myzaker.com/201609/57c864bf1bc8e0393d000015_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c864bf1bc8e0393d000015_320.jpg","thumbnail_picsize":"547,422","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c93b779490cb2218000072&m=1472806224","list_dtime":"2016-09-02 16:48:00"},{"pk":"57c947989490cb2918000049","title":"我能骂街么？看国人驾车7大恶习","date":"2016-09-02 17:39:13","auther_name":"12缸汽车网","weburl":"http://iphone.myzaker.com/l.php?l=57c947989490cb2918000049","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8db871bc8e0e374000013_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8db871bc8e0e374000013_320.jpg","thumbnail_picsize":"500,374","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c947989490cb2918000049&m=1472809359","list_dtime":"2016-09-02 17:39:13"},{"pk":"57c8ea0a9490cb8127000015","title":"特斯拉准备向Model 3车主收取充电费","title_line_break":"特斯拉准备向Model\n3车主收取充电费","date":"2016-09-02 17:52:26","auther_name":"腾讯汽车","weburl":"http://iphone.myzaker.com/l.php?l=57c8ea0a9490cb8127000015","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8e5e17f52e9906e00019a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8e5e17f52e9906e00019a_320.jpg","thumbnail_picsize":"580,374","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8ea0a9490cb8127000015&m=1472809968","list_dtime":"2016-09-02 17:52:26"},{"pk":"57c93ad89490cb1b1800005a","title":"百度的大动作：除了无人驾驶，他们也要做自动驾驶了","title_line_break":"百度的大动作：\n除了无人驾驶，他们也要做自动驾驶了","date":"2016-09-03 10:25:11","auther_name":"GeekCar","weburl":"http://iphone.myzaker.com/l.php?l=57c93ad89490cb1b1800005a","thumbnail_pic":"http://zkres.myzaker.com/201609/57c835b61bc8e0d11a000005_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c835b61bc8e0d11a000005_320.jpg","thumbnail_picsize":"1000,750","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c93ad89490cb1b1800005a&m=1472873665","list_dtime":"2016-09-03 10:25:11"},{"pk":"57c844e91bc8e06d6100006b","title":"首台奔驰S级皮卡只为拖运一辆摩托车","date":"2016-09-02 09:36:36","auther_name":"改装车","weburl":"http://iphone.myzaker.com/l.php?l=57c844e91bc8e06d6100006b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c844cda07aecf77e04ab54_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c844cda07aecf77e04ab54_320.jpg","thumbnail_picsize":"960,622","media_count":"48","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c844e91bc8e06d6100006b&m=1472793584","list_dtime":"2016-09-02 09:36:36"},{"pk":"57c8d2241bc8e07230000011","title":"凯迪拉克核燃料汽车 无油可开足一百年","title_line_break":"凯迪拉克核燃料汽车\n无油可开足一百年","date":"2016-09-02 09:23:32","auther_name":"腾讯汽车 ","weburl":"http://iphone.myzaker.com/l.php?l=57c8d2241bc8e07230000011","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d21aa07aec135200183d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d21aa07aec135200183d_320.jpg","thumbnail_picsize":"980,698","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8d2241bc8e07230000011&m=1472793584","list_dtime":"2016-09-02 09:23:32"},{"pk":"57c949389490cb0c1800005a","title":"喜欢买SUV竟然是因为安全感缺失？","date":"2016-09-02 17:50:06","auther_name":"啊车网","weburl":"http://iphone.myzaker.com/l.php?l=57c949389490cb0c1800005a","thumbnail_pic":"http://zkres.myzaker.com/201609/57c802cf1bc8e0fe74000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c802cf1bc8e0fe74000001_320.jpg","thumbnail_picsize":"600,338","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c949389490cb0c1800005a&m=1472809852","list_dtime":"2016-09-02 17:50:06"},{"pk":"57c9450b9490cbe217000045","title":"看完这些霸气侧漏的路名 连老司机都懵逼了","title_line_break":"看完这些霸气侧漏的路名\n连老司机都懵逼了","date":"2016-09-02 17:30:40","auther_name":"汽车报","weburl":"http://iphone.myzaker.com/l.php?l=57c9450b9490cbe217000045","thumbnail_pic":"http://zkres.myzaker.com/201609/57c802bf7f52e95556000119_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c802bf7f52e95556000119_320.jpg","thumbnail_picsize":"640,427","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c9450b9490cbe217000045&m=1472808655","list_dtime":"2016-09-02 17:30:40"},{"pk":"57c8e48c9490cbd917000042","title":"德媒来中国试驾大众辉昂后 总结出九大特点","title_line_break":"德媒来中国试驾大众辉昂后\n总结出九大特点","date":"2016-09-02 10:54:48","auther_name":"DearAuto","weburl":"http://iphone.myzaker.com/l.php?l=57c8e48c9490cbd917000042","thumbnail_pic":"http://zkres.myzaker.com/201609/57c845d77f52e9d9090001af_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c845d77f52e9d9090001af_320.jpg","thumbnail_picsize":"170,197","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8e48c9490cbd917000042&m=1472793584","list_dtime":"2016-09-02 10:54:48"},{"pk":"57c8d1a91bc8e07d3000001d","title":"阿斯顿马丁最新跑车入华 暴降30万","title_line_break":"阿斯顿马丁最新跑车入华\n暴降30万","date":"2016-09-02 09:31:20","auther_name":"驱动之家 ","weburl":"http://iphone.myzaker.com/l.php?l=57c8d1a91bc8e07d3000001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8d1a2a07aec13520017d5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8d1a2a07aec13520017d5_320.jpg","thumbnail_picsize":"980,551","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c8d1a91bc8e07d3000001d&m=1472793584","list_dtime":"2016-09-02 09:31:20"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c6c4f77f780bf00f00005b,57ca310a1bc8e0777b000022,57c768f77f52e96b5f00016c,57c8ec779490cbf61700001d,57c6c4fa7f780bf00f00005c,57c8ebbc9490cb1d18000024","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57ca374b9490cbc33e000039,57c136517f780be06700483a,57c927671bc8e03f25000049,57ca33439490cbde3e000034,57c949219490cb3a7e000012,57c918989490cbe61700002d","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca36ff9490cb273f000015,57c944a19490cbe51700004a,57ca331b9490cbf43e00003d,57ca33339490cbdd3e000029,57c947f99490cb071800005f,57c93b349490cb0118000088","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c940569490cb0d18000065,57c8d2a41bc8e07630000014,57c7f4879490cba02c00006e,57c93f379490cb051800006d,57c947629490cb0c18000059,57c91ccc9490cbf117000044","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c930f59490cb1018000059,57c93f549490cbdd1700006a,57c93b779490cb2218000072,57c947989490cb2918000049,57c8ea0a9490cb8127000015,57c93ad89490cb1b1800005a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c8d2241bc8e07230000011,57c844e91bc8e06d6100006b,57c949389490cb0c1800005a,57c9450b9490cbe217000045,57c8e48c9490cbd917000042,57c8d1a91bc8e07d3000001d","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#be4547","#be4547"],"only_text_page_bgcolors":["#be4547","#be4547"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/7.png?t=1463319366","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/7.png?t=1463319366","hidden_time":"24","need_userinfo":"NO","block_title":"汽车频道","block_color":"#be4547","desktop_color_number":"9","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_442b126ea6ff0336b46e335a46017113","selected_index":"0","list":[{"pk":"zk_app_column_7","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"7","title":"汽车频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=7&catalog_appid=7","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_web_288","title":"报价","type":"web","web":{"url":"http://iphone.myzaker.com/zaker/hezuo/cheshi/","need_user_info":"Y","type":""}},{"pk":"zk_app_column_11645","title":"导购","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11645_zk_app_column_block_7","title":"汽车频道-导购","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11645&catalog_appid=7","data_type":"news"}},{"pk":"zk_app_column_11646","title":"试驾","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11646_zk_app_column_block_7","title":"汽车频道-试驾","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11646&catalog_appid=7","data_type":"news"}},{"pk":"zk_app_column_discussion_273","title":"社区","type":"discussion","discussion":{"pk":"185","title":"汽车总动员","stitle":"随心所欲畅聊关于汽车的一切","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=185","block_color":"","subscribe_count":"493992","post_count":"8160"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=7&since_date=1472710386&nt=1&next_aticle_id=57c84e6d7f780bf00f00098f&_appid=androidphone&opage=2&otimestamp=140
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=7&need_app_integration=0
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=7&ids=5642f2aa9490cbb13200000e,5472a9b69490cb48180000f9,51a7105381853db050000146&k=201609031130
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/7.png?t=1463319366
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/7.png?t=1463319366
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 汽车频道
         * block_color : #be4547
         * desktop_color_number : 9
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_442b126ea6ff0336b46e335a46017113
         * selected_index : 0
         * list : [{"pk":"zk_app_column_7","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"7","title":"汽车频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=7&catalog_appid=7","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_web_288","title":"报价","type":"web","web":{"url":"http://iphone.myzaker.com/zaker/hezuo/cheshi/","need_user_info":"Y","type":""}},{"pk":"zk_app_column_11645","title":"导购","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11645_zk_app_column_block_7","title":"汽车频道-导购","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11645&catalog_appid=7","data_type":"news"}},{"pk":"zk_app_column_11646","title":"试驾","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11646_zk_app_column_block_7","title":"汽车频道-试驾","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11646&catalog_appid=7","data_type":"news"}},{"pk":"zk_app_column_discussion_273","title":"社区","type":"discussion","discussion":{"pk":"185","title":"汽车总动员","stitle":"随心所欲畅聊关于汽车的一切","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3d4c9490cbee7a000101.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=185","block_color":"","subscribe_count":"493992","post_count":"8160"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57c6c4f77f780bf00f00005b
         * title : 我们用特斯拉Model X斗了回911，还闹出了个BUG
         * title_line_break : 我们用特斯拉Model
         X斗了回911，还闹出了个BUG
         * date : 2016-09-03 10:29:47
         * auther_name : 吴佩频道
         * page : 1
         * index : 1
         * weburl : http://iphone.myzaker.com/l.php?l=57c6c4f77f780bf00f00005b
         * thumbnail_pic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MDA0NF83MzY1MF9XNjQwSDM2MFMxNTY1NDUuanBn_1242.jpg
         * thumbnail_mpic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MDA0NF83MzY1MF9XNjQwSDM2MFMxNTY1NDUuanBn_1242.jpg
         * thumbnail_picsize : 640,360
         * media_count : 6
         * is_full : NO
         * content :
         * type : web3
         * special_info : {"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=7&pk=57c6c4f77f780bf00f00005b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c6c4f77f780bf00f00005b%26app_id%3D7%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","list_nodsp":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=7&pk=57c6c4f77f780bf00f00005b&m=1472873704
         * list_dtime : 2016-09-03 10:29:47
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 1
             * articles : 57c6c4f77f780bf00f00005b,57ca310a1bc8e0777b000022,57c768f77f52e96b5f00016c,57c8ec779490cbf61700001d,57c6c4fa7f780bf00f00005c,57c8ebbc9490cb1d18000024
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/7.png?t=1463319366
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * open_type :
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_7
             * title : 综合
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"7","title":"汽车频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=7&catalog_appid=7","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 7
                 * title : 汽车频道
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=7&catalog_appid=7
                 * data_type : news
                 * skey : eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;
                    private String skey;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }

                    public String getSkey() {
                        return skey;
                    }

                    public void setSkey(String skey) {
                        this.skey = skey;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String title_line_break;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String is_full;
            private String content;
            private String type;
            /**
             * open_type : web3
             * need_user_info : Y
             * web_url : http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=7&pk=57c6c4f77f780bf00f00005b&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c6c4f77f780bf00f00005b%26app_id%3D7%26_appid%3Dandroidphone%26target%3Dweb3
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getTitle_line_break() {
                return title_line_break;
            }

            public void setTitle_line_break(String title_line_break) {
                this.title_line_break = title_line_break;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String open_type;
                private String need_user_info;
                private String web_url;
                private String show_jingcai;
                private String list_nodsp;

                public String getOpen_type() {
                    return open_type;
                }

                public void setOpen_type(String open_type) {
                    this.open_type = open_type;
                }

                public String getNeed_user_info() {
                    return need_user_info;
                }

                public void setNeed_user_info(String need_user_info) {
                    this.need_user_info = need_user_info;
                }

                public String getWeb_url() {
                    return web_url;
                }

                public void setWeb_url(String web_url) {
                    this.web_url = web_url;
                }

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }
            }
        }
    }
}
