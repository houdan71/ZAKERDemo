package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class Bean_film {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=10530&since_date=1472696863&nt=1&next_aticle_id=57c9c7839490cb4910000002&_appid=androidphone&opage=2&otimestamp=179&catalog_appid=9","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=10530&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=10530&ids=5642f2aa9490cbb13200000e,51a7104681853dec4d00012f&k=201609051450"},"catalog":"","articles":[{"pk":"57c9b0189490cbe40a000007","title":"拒绝烂片，九月就等这七部新片","date":"2016-09-05 11:45:26","auther_name":"独立鱼电影","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c9b0189490cbe40a000007","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTE0N185NzY4OV9XNjQwSDM2MFMzNTQxOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTE0N185NzY4OV9XNjQwSDM2MFMzNTQxOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"44","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c9b0189490cbe40a000007&m=1473058049","list_dtime":"2016-09-05 11:45:26"},{"pk":"57c8fdf59490cbd609000008","title":"《大话西游3》提档9.14上映","date":"2016-09-05 10:53:48","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57c8fdf59490cbd609000008","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccde4aa07aecc52301e1f4_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccde4aa07aecc52301e1f4_320.jpg","thumbnail_picsize":"1000,667","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c8fdf59490cbd609000008&m=1473057774","list_dtime":"2016-09-05 10:53:48"},{"pk":"57ccb0d49490cb622d000001","title":"他是不老男神，没想到会是这样的老司机","date":"2016-09-05 10:35:35","auther_name":"电影那点事儿","weburl":"http://iphone.myzaker.com/l.php?l=57ccb0d49490cb622d000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYThiMDdmNTJlOWQxNjYwMDAwNzNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYThiMDdmNTJlOWQxNjYwMDAwNzNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,400","media_count":"35","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccb0d49490cb622d000001&m=1473057774","list_dtime":"2016-09-05 10:35:35"},{"pk":"57cc5c7d9490cb517f00000d","title":"TVB电影悉数扑街，《使徒》大胜秘诀是","date":"2016-09-05 10:37:28","auther_name":"抠电影","weburl":"http://iphone.myzaker.com/l.php?l=57cc5c7d9490cb517f00000d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mzc0OF8yNDgzM19XNjQwSDM2MFMzMDE0NC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mzc0OF8yNDgzM19XNjQwSDM2MFMzMDE0NC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"33","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cc5c7d9490cb517f00000d&m=1473057914","list_dtime":"2016-09-05 10:37:28"},{"pk":"57c93bfd1bc8e0e335000007","title":"《怪屋女孩》动态海报 众角色阴森恐怖","title_line_break":"《怪屋女孩》动态海报\n众角色阴森恐怖","date":"2016-09-05 10:27:16","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c93bfd1bc8e0e335000007","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MjQ5MF8xMDMwOV9XNjQwSDM2MFM1MzUyNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MjQ5MF8xMDMwOV9XNjQwSDM2MFM1MzUyNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c93bfd1bc8e0e335000007&m=1473057774","list_dtime":"2016-09-05 10:27:16"},{"pk":"57cbd8099490cb9c51000009","title":"《雷神3》曝全新片场照","date":"2016-09-05 10:54:56","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57cbd8099490cb9c51000009","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccde8ca07aecc52301e29f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccde8ca07aecc52301e29f_320.jpg","thumbnail_picsize":"540,675","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cbd8099490cb9c51000009&m=1473057774","list_dtime":"2016-09-05 10:54:56"},{"pk":"57ccd45d1bc8e0235800004a","title":"因为这部作品 冯德伦婚后马上投入工作","title_line_break":"因为这部作品\n冯德伦婚后马上投入工作","date":"2016-09-05 10:32:15","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57ccd45d1bc8e0235800004a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd9529490cb0e7e00003b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd9529490cb0e7e00003b_320.jpg","thumbnail_picsize":"647,431","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccd45d1bc8e0235800004a&m=1473057774","list_dtime":"2016-09-05 10:32:15"},{"pk":"57cbf0c11bc8e0184b000002","title":"曝《踏血寻梅》将申奥 角逐最佳外语片","title_line_break":"曝《踏血寻梅》将申奥\n角逐最佳外语片","date":"2016-09-05 10:45:59","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57cbf0c11bc8e0184b000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdcaaa07aecc52301dd40_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdcaaa07aecc52301dd40_320.jpg","thumbnail_picsize":"600,419","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cbf0c11bc8e0184b000002&m=1473057774","list_dtime":"2016-09-05 10:45:59"},{"pk":"57cb885e9490cb5c39000010","title":"\u201c超人前传\u201d《氪星》曝光女主人选","date":"2016-09-05 10:57:03","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57cb885e9490cb5c39000010","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cb885e9490cb5c39000010&m=1473057774","list_dtime":"2016-09-05 10:57:03"},{"pk":"57cc3e029490cb395900000d","title":"这部神作，是我见过最致郁的喜剧","date":"2016-09-05 14:48:32","auther_name":"独立鱼电影","weburl":"http://iphone.myzaker.com/l.php?l=57cc3e029490cb395900000d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NjY1M185NDY1NF9XNjQwSDM2MFMyODQ1MC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NjY1M185NDY1NF9XNjQwSDM2MFMyODQ1MC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"34","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cc3e029490cb395900000d&m=1473046654","list_dtime":"2016-09-05 14:48:32"},{"pk":"57ccc00f9490cb7e7a000000","title":"这部口碑炸裂的新片，或将横扫奥斯卡","date":"2016-09-05 14:44:45","auther_name":"独立鱼电影","weburl":"http://iphone.myzaker.com/l.php?l=57ccc00f9490cb7e7a000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4NTdmNDdmNTJlOTMyMGEwMDA0NWZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4NTdmNDdmNTJlOTMyMGEwMDA0NWZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,378","media_count":"31","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccc00f9490cb7e7a000000&m=1473057887","list_dtime":"2016-09-05 14:44:45"},{"pk":"57c8dd279490cbc765000008","title":"看完这片，我感觉自己的青春白过了！","date":"2016-09-05 14:45:35","auther_name":"电影头条","weburl":"http://iphone.myzaker.com/l.php?l=57c8dd279490cbc765000008","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZDU2YTdmNTJlOWY3N2QwMDAwMWVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZDU2YTdmNTJlOWY3N2QwMDAwMWVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,361","media_count":"41","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c8dd279490cbc765000008&m=1473057940","list_dtime":"2016-09-05 14:45:35"},{"pk":"57c95cdf9490cb9b65000000","title":"《我们的十年》：少气无力的烂俗","title_line_break":"《我们的十年》：\n少气无力的烂俗","date":"2016-09-05 10:25:45","auther_name":"时光天堂电影小组","weburl":"http://iphone.myzaker.com/l.php?l=57c95cdf9490cb9b65000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9552d1bc8e05748000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9552d1bc8e05748000001_320.jpg","thumbnail_picsize":"600,399","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c95cdf9490cb9b65000000&m=1473057774","list_dtime":"2016-09-05 10:25:45"},{"pk":"57ccdcd91bc8e07f5d000051","title":"一周新片推荐：大白鲨对战深海寻宝","title_line_break":"一周新片推荐：\n大白鲨对战深海寻宝","date":"2016-09-05 14:34:27","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57ccdcd91bc8e07f5d000051","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzM1MF81NzM3Ml9XNjQwSDM2MFMzODU0Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzM1MF81NzM3Ml9XNjQwSDM2MFMzODU0Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccdcd91bc8e07f5d000051&m=1473057774","list_dtime":"2016-09-05 14:34:27"},{"pk":"57ccfd019490cb413b000005","title":"拯救人类就是灭杀人口？这逻辑不是很懂","date":"2016-09-05 14:33:45","auther_name":"纵贯电影公社","weburl":"http://iphone.myzaker.com/l.php?l=57ccfd019490cb413b000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzM5OV81Mjk2NV9XNjQwSDM2MFMzOTEzNy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzM5OV81Mjk2NV9XNjQwSDM2MFMzOTEzNy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"17","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57ccfd019490cb413b000005&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57ccfd019490cb413b000005%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccfd019490cb413b000005&m=1473057774","list_dtime":"2016-09-05 14:33:45"},{"pk":"57cce5561bc8e0a064000004","title":"《欧洲攻略》：唐嫣携梁朝伟吴亦凡征战","title_line_break":"《欧洲攻略》：\n唐嫣携梁朝伟吴亦凡征战","date":"2016-09-05 14:32:46","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57cce5561bc8e0a064000004","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzQ2OV81NDA3MF9XNjQwSDM2MFMyMjgzNy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzQ2OV81NDA3MF9XNjQwSDM2MFMyMjgzNy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cce5561bc8e0a064000004&m=1473057774","list_dtime":"2016-09-05 14:32:46"},{"pk":"57ca3a601bc8e02a4a00001e","title":"凯奇新片再现美国军事史上最大海难","date":"2016-09-05 14:31:25","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57ca3a601bc8e02a4a00001e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzQ1Nl83ODYyNV9XNjQwSDM2MFM1MDU2Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzQ1Nl83ODYyNV9XNjQwSDM2MFM1MDU2Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ca3a601bc8e02a4a00001e&m=1473057774","list_dtime":"2016-09-05 14:31:25"},{"pk":"57ccf4d59490cb9813000024","title":"漫威剧《神盾局特工》曝恶灵骑士照","date":"2016-09-05 14:31:57","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57ccf4d59490cb9813000024","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZWJkZTFiYzhlMGE0NjcwMDAwMGZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZWJkZTFiYzhlMGE0NjcwMDAwMGZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"620,396","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccf4d59490cb9813000024&m=1473057774","list_dtime":"2016-09-05 14:31:57"},{"pk":"57ccf1e41bc8e0696800001a","title":"韩国果然把《步步惊心》拍得好...","date":"2016-09-05 14:30:50","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57ccf1e41bc8e0696800001a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzQ0Ml8xMzQ4X1c2NDBIMzYwUzY4Nzk1LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzQ0Ml8xMzQ4X1c2NDBIMzYwUzY4Nzk1LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"57","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccf1e41bc8e0696800001a&m=1473057774","list_dtime":"2016-09-05 14:30:50"},{"pk":"57cd0c3f9490cb160c000006","title":"周冬雨搭档张一山出演冯唐小说改编新剧","date":"2016-09-05 14:28:30","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57cd0c3f9490cb160c000006","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NkMDUyOTFiYzhlMDRmN2EwMDAwMDBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NkMDUyOTFiYzhlMDRmN2EwMDAwMDBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"620,422","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cd0c3f9490cb160c000006&m=1473057774","list_dtime":"2016-09-05 14:28:30"},{"pk":"57cba2a61bc8e0fd1d000004","title":"说个预言，明年奥斯卡就从这几部片里产生","date":"2016-09-04 17:20:07","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57cba2a61bc8e0fd1d000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57cba2a77f52e9ac06000272_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cba2a77f52e9ac06000272_320.jpg","thumbnail_picsize":"600,398","media_count":"31","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57cba2a61bc8e0fd1d000004&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57cba2a61bc8e0fd1d000004%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cba2a61bc8e0fd1d000004&m=1473057914","list_dtime":"2016-09-04 17:20:07"},{"pk":"57cba2a61bc8e0fd1d000002","title":"如果你是片中的姐姐，你会原谅她吗？","date":"2016-09-04 15:20:07","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57cba2a61bc8e0fd1d000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57cba2a77f52e97b29000318_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cba2a77f52e97b29000318_320.jpg","thumbnail_picsize":"640,349","media_count":"23","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cba2a61bc8e0fd1d000002&m=1473057774","list_dtime":"2016-09-04 15:20:07"},{"pk":"57cba6d59490cb1357000014","title":"好莱坞欠他的不止一座小金人","date":"2016-09-04 15:45:09","auther_name":"纵贯电影公社","weburl":"http://iphone.myzaker.com/l.php?l=57cba6d59490cb1357000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57cba3857f52e9667600002f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cba3857f52e9667600002f_320.jpg","thumbnail_picsize":"1200,674","media_count":"22","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cba6d59490cb1357000014&m=1473057774","list_dtime":"2016-09-04 15:45:09"},{"pk":"57c9046d1bc8e0140e00000f","title":"别的「青春剧」像小说，这部剧才是生活","date":"2016-09-04 16:50:05","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57c9046d1bc8e0140e00000f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9010d7f52e94b15000263_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9010d7f52e94b15000263_320.jpg","thumbnail_picsize":"294,220","media_count":"24","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c9046d1bc8e0140e00000f&m=1473057774","list_dtime":"2016-09-04 16:50:05"},{"pk":"57c65edb1bc8e02473000001","title":"本世纪最佳电影是这一部，你肯定猜不到","date":"2016-09-04 11:45:45","auther_name":"电影集结号","weburl":"http://iphone.myzaker.com/l.php?l=57c65edb1bc8e02473000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODIwN180NzU2Ml9XNjQwSDM2MFM1MDk1My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODIwN180NzU2Ml9XNjQwSDM2MFM1MDk1My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"21","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c65edb1bc8e02473000001&m=1473046846","list_dtime":"2016-09-04 11:45:45"},{"pk":"57cbbf719490cbba57000006","title":"相信我，看完它你会哭泣，也会相信爱情","date":"2016-09-04 15:30:09","auther_name":"剧角映画","weburl":"http://iphone.myzaker.com/l.php?l=57cbbf719490cbba57000006","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbbe197f52e9dc200000a7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbbe197f52e9dc200000a7_320.jpg","thumbnail_picsize":"600,400","media_count":"21","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cbbf719490cbba57000006&m=1473057774","list_dtime":"2016-09-04 15:30:09"},{"pk":"57caff469490cbaf73000005","title":"科幻片很多，但能让人\u201c装逼\u201d的只有这部","date":"2016-09-04 10:50:14","auther_name":"独立鱼电影","weburl":"http://iphone.myzaker.com/l.php?l=57caff469490cbaf73000005","thumbnail_pic":"http://zkres.myzaker.com/201609/57caf9527f52e9d10d0003e9_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57caf9527f52e9d10d0003e9_320.jpg","thumbnail_picsize":"600,400","media_count":"37","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57caff469490cbaf73000005&m=1473043318","list_dtime":"2016-09-04 10:50:14"},{"pk":"57ca83ab1bc8e05078000000","title":"《幸运是我》：不幸的，或者是幸运的我","title_line_break":"《幸运是我》：\n不幸的，或者是幸运的我","date":"2016-09-04 12:42:30","auther_name":"豆瓣影评","weburl":"http://iphone.myzaker.com/l.php?l=57ca83ab1bc8e05078000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca83917f52e98d63000178_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca83917f52e98d63000178_320.jpg","thumbnail_picsize":"600,400","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ca83ab1bc8e05078000000&m=1473050123","list_dtime":"2016-09-04 12:42:30"},{"pk":"57cad18d9490cb7104000006","title":"感谢你赠与最好时光","date":"2016-09-04 10:35:09","auther_name":"时光天堂电影小组","weburl":"http://iphone.myzaker.com/l.php?l=57cad18d9490cb7104000006","thumbnail_pic":"http://zkres.myzaker.com/201609/57caccbe1bc8e0c726000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57caccbe1bc8e0c726000001_320.jpg","thumbnail_picsize":"500,334","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cad18d9490cb7104000006&m=1473042511","list_dtime":"2016-09-04 10:35:09"},{"pk":"57cb07709490cb2823000003","title":"这部电影，才是我心中的宫崎骏最佳","date":"2016-09-04 01:25:04","auther_name":"毒舌电影","weburl":"http://iphone.myzaker.com/l.php?l=57cb07709490cb2823000003","thumbnail_pic":"http://zkres.myzaker.com/201609/57caf8107f52e9d10d0003b7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57caf8107f52e9d10d0003b7_320.jpg","thumbnail_picsize":"616,485","media_count":"34","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cb07709490cb2823000003&m=1473009596","list_dtime":"2016-09-04 01:25:04"},{"pk":"57c900b81bc8e0d00b00000d","title":"上映三天变禁片，这片遇到什么禁忌？","date":"2016-09-03 13:59:16","auther_name":"电影集结号","weburl":"http://iphone.myzaker.com/l.php?l=57c900b81bc8e0d00b00000d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODAxMl82MTA3MF9XNjQwSDM2MFMzODQzMC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODAxMl82MTA3MF9XNjQwSDM2MFMzODQzMC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c900b81bc8e0d00b00000d&m=1472968482","list_dtime":"2016-09-03 13:59:16"},{"pk":"57c900b81bc8e0d00b00000e","title":"这部全世界女性都期待的电影终于来了！","date":"2016-09-03 14:01:25","auther_name":"电影集结号","weburl":"http://iphone.myzaker.com/l.php?l=57c900b81bc8e0d00b00000e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODA3MF8xNTk0Ml9XNjQwSDM2MFM0MTA1Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODA3MF8xNTk0Ml9XNjQwSDM2MFM0MTA1Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"23","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c900b81bc8e0d00b00000e&m=1472968482","list_dtime":"2016-09-03 14:01:25"},{"pk":"57c83b709490cbb332000003","title":"9月观片避雷指南，不想被恶心的赶紧收","date":"2016-09-03 11:45:01","auther_name":"热门电影","weburl":"http://iphone.myzaker.com/l.php?l=57c83b709490cbb332000003","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODU0MF84NzcxMV9XNjQwSDM2MFM2MTEzMy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODU0MF84NzcxMV9XNjQwSDM2MFM2MTEzMy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"30","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c83b709490cbb332000003&m=1472960189","list_dtime":"2016-09-03 11:45:01"},{"pk":"57c9c7839490cb4910000005","title":"她是台湾第一美女，如今却难敌岁月摧残","date":"2016-09-03 10:43:46","auther_name":"电影那点事儿","weburl":"http://iphone.myzaker.com/l.php?l=57c9c7839490cb4910000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTY0NV8zNTI3OF9XNjQwSDM2MFMyOTY2OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTY0NV8zNTI3OF9XNjQwSDM2MFMyOTY2OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"30","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c9c7839490cb4910000005&m=1472956711","list_dtime":"2016-09-03 10:43:46"},{"pk":"57c814c49490cb227c000011","title":"九月就看这九部片","date":"2016-09-03 14:09:39","auther_name":"毒舌电影","weburl":"http://iphone.myzaker.com/l.php?l=57c814c49490cb227c000011","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MTI5YTdmNTJlOTFlNjEwMDAxMjhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MTI5YTdmNTJlOTFlNjEwMDAxMjhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,337","media_count":"43","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c814c49490cb227c000011&m=1472969018","list_dtime":"2016-09-03 14:09:39"},{"pk":"57c903c31bc8e0a90e000000","title":"近十年最棒的零差评歌舞片已出现","date":"2016-09-03 14:04:29","auther_name":"知影","weburl":"http://iphone.myzaker.com/l.php?l=57c903c31bc8e0a90e000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODE0M184MzgzOF9XNjQwSDM2MFM1OTM1My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODE0M184MzgzOF9XNjQwSDM2MFM1OTM1My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c903c31bc8e0a90e000000&m=1472968751","list_dtime":"2016-09-03 14:04:29"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c9b0189490cbe40a000007,57c8fdf59490cbd609000008,57ccb0d49490cb622d000001,57cc5c7d9490cb517f00000d,57c93bfd1bc8e0e335000007,57cbd8099490cb9c51000009","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57cbf0c11bc8e0184b000002,57ccd45d1bc8e0235800004a,57cb885e9490cb5c39000010,57cc3e029490cb395900000d,57ccc00f9490cb7e7a000000,57c8dd279490cbc765000008","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57ccdcd91bc8e07f5d000051,57c95cdf9490cb9b65000000,57ccfd019490cb413b000005,57cce5561bc8e0a064000004,57ca3a601bc8e02a4a00001e,57ccf4d59490cb9813000024","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cd0c3f9490cb160c000006,57ccf1e41bc8e0696800001a,57cba2a61bc8e0fd1d000004,57cba2a61bc8e0fd1d000002,57cba6d59490cb1357000014,57c9046d1bc8e0140e00000f","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cbbf719490cbba57000006,57c65edb1bc8e02473000001,57caff469490cbaf73000005,57ca83ab1bc8e05078000000,57cad18d9490cb7104000006,57cb07709490cb2823000003","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c900b81bc8e0d00b00000e,57c900b81bc8e0d00b00000d,57c83b709490cbb332000003,57c9c7839490cb4910000005,57c814c49490cb227c000011,57c903c31bc8e0a90e000000","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#f77762","#f77762"],"only_text_page_bgcolors":["#f77762","#f77762"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/10530.png?t=1458284157","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/10530.png?t=1458284157","hidden_time":"24","need_userinfo":"NO","block_title":"电影资讯","block_color":"#f77762","desktop_color_number":"20","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_531c9c601ebc06b87cf6dc1ab37dae55","selected_index":"1","list":[{"pk":"zk_app_column_9","title":"娱乐","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_10530","title":"电影","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"10530_zk_app_column_block_9","title":"电影资讯","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=10530&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_11698","title":"电视","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11698_zk_app_column_block_9","title":"电视","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11698&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_12348","title":"明星","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12348_zk_app_column_block_9","title":"明星","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12348&catalog_appid=9","data_type":"news"}}]}}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=10530&since_date=1472696863&nt=1&next_aticle_id=57c9c7839490cb4910000002&_appid=androidphone&opage=2&otimestamp=179&catalog_appid=9","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=10530&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=10530&ids=5642f2aa9490cbb13200000e,51a7104681853dec4d00012f&k=201609051450"}
     * catalog :
     * articles : [{"pk":"57c9b0189490cbe40a000007","title":"拒绝烂片，九月就等这七部新片","date":"2016-09-05 11:45:26","auther_name":"独立鱼电影","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c9b0189490cbe40a000007","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTE0N185NzY4OV9XNjQwSDM2MFMzNTQxOS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTE0N185NzY4OV9XNjQwSDM2MFMzNTQxOS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"44","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c9b0189490cbe40a000007&m=1473058049","list_dtime":"2016-09-05 11:45:26"},{"pk":"57c8fdf59490cbd609000008","title":"《大话西游3》提档9.14上映","date":"2016-09-05 10:53:48","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57c8fdf59490cbd609000008","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccde4aa07aecc52301e1f4_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccde4aa07aecc52301e1f4_320.jpg","thumbnail_picsize":"1000,667","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c8fdf59490cbd609000008&m=1473057774","list_dtime":"2016-09-05 10:53:48"},{"pk":"57ccb0d49490cb622d000001","title":"他是不老男神，没想到会是这样的老司机","date":"2016-09-05 10:35:35","auther_name":"电影那点事儿","weburl":"http://iphone.myzaker.com/l.php?l=57ccb0d49490cb622d000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYThiMDdmNTJlOWQxNjYwMDAwNzNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYThiMDdmNTJlOWQxNjYwMDAwNzNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,400","media_count":"35","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccb0d49490cb622d000001&m=1473057774","list_dtime":"2016-09-05 10:35:35"},{"pk":"57cc5c7d9490cb517f00000d","title":"TVB电影悉数扑街，《使徒》大胜秘诀是","date":"2016-09-05 10:37:28","auther_name":"抠电影","weburl":"http://iphone.myzaker.com/l.php?l=57cc5c7d9490cb517f00000d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mzc0OF8yNDgzM19XNjQwSDM2MFMzMDE0NC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Mzc0OF8yNDgzM19XNjQwSDM2MFMzMDE0NC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"33","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cc5c7d9490cb517f00000d&m=1473057914","list_dtime":"2016-09-05 10:37:28"},{"pk":"57c93bfd1bc8e0e335000007","title":"《怪屋女孩》动态海报 众角色阴森恐怖","title_line_break":"《怪屋女孩》动态海报\n众角色阴森恐怖","date":"2016-09-05 10:27:16","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57c93bfd1bc8e0e335000007","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MjQ5MF8xMDMwOV9XNjQwSDM2MFM1MzUyNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0MjQ5MF8xMDMwOV9XNjQwSDM2MFM1MzUyNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c93bfd1bc8e0e335000007&m=1473057774","list_dtime":"2016-09-05 10:27:16"},{"pk":"57cbd8099490cb9c51000009","title":"《雷神3》曝全新片场照","date":"2016-09-05 10:54:56","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57cbd8099490cb9c51000009","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccde8ca07aecc52301e29f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccde8ca07aecc52301e29f_320.jpg","thumbnail_picsize":"540,675","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cbd8099490cb9c51000009&m=1473057774","list_dtime":"2016-09-05 10:54:56"},{"pk":"57ccd45d1bc8e0235800004a","title":"因为这部作品 冯德伦婚后马上投入工作","title_line_break":"因为这部作品\n冯德伦婚后马上投入工作","date":"2016-09-05 10:32:15","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57ccd45d1bc8e0235800004a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd9529490cb0e7e00003b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd9529490cb0e7e00003b_320.jpg","thumbnail_picsize":"647,431","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccd45d1bc8e0235800004a&m=1473057774","list_dtime":"2016-09-05 10:32:15"},{"pk":"57cbf0c11bc8e0184b000002","title":"曝《踏血寻梅》将申奥 角逐最佳外语片","title_line_break":"曝《踏血寻梅》将申奥\n角逐最佳外语片","date":"2016-09-05 10:45:59","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57cbf0c11bc8e0184b000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdcaaa07aecc52301dd40_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdcaaa07aecc52301dd40_320.jpg","thumbnail_picsize":"600,419","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cbf0c11bc8e0184b000002&m=1473057774","list_dtime":"2016-09-05 10:45:59"},{"pk":"57cb885e9490cb5c39000010","title":"\u201c超人前传\u201d《氪星》曝光女主人选","date":"2016-09-05 10:57:03","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57cb885e9490cb5c39000010","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cb885e9490cb5c39000010&m=1473057774","list_dtime":"2016-09-05 10:57:03"},{"pk":"57cc3e029490cb395900000d","title":"这部神作，是我见过最致郁的喜剧","date":"2016-09-05 14:48:32","auther_name":"独立鱼电影","weburl":"http://iphone.myzaker.com/l.php?l=57cc3e029490cb395900000d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NjY1M185NDY1NF9XNjQwSDM2MFMyODQ1MC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0NjY1M185NDY1NF9XNjQwSDM2MFMyODQ1MC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"34","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cc3e029490cb395900000d&m=1473046654","list_dtime":"2016-09-05 14:48:32"},{"pk":"57ccc00f9490cb7e7a000000","title":"这部口碑炸裂的新片，或将横扫奥斯卡","date":"2016-09-05 14:44:45","auther_name":"独立鱼电影","weburl":"http://iphone.myzaker.com/l.php?l=57ccc00f9490cb7e7a000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4NTdmNDdmNTJlOTMyMGEwMDA0NWZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4NTdmNDdmNTJlOTMyMGEwMDA0NWZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,378","media_count":"31","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccc00f9490cb7e7a000000&m=1473057887","list_dtime":"2016-09-05 14:44:45"},{"pk":"57c8dd279490cbc765000008","title":"看完这片，我感觉自己的青春白过了！","date":"2016-09-05 14:45:35","auther_name":"电影头条","weburl":"http://iphone.myzaker.com/l.php?l=57c8dd279490cbc765000008","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZDU2YTdmNTJlOWY3N2QwMDAwMWVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M4ZDU2YTdmNTJlOWY3N2QwMDAwMWVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,361","media_count":"41","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c8dd279490cbc765000008&m=1473057940","list_dtime":"2016-09-05 14:45:35"},{"pk":"57c95cdf9490cb9b65000000","title":"《我们的十年》：少气无力的烂俗","title_line_break":"《我们的十年》：\n少气无力的烂俗","date":"2016-09-05 10:25:45","auther_name":"时光天堂电影小组","weburl":"http://iphone.myzaker.com/l.php?l=57c95cdf9490cb9b65000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9552d1bc8e05748000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9552d1bc8e05748000001_320.jpg","thumbnail_picsize":"600,399","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c95cdf9490cb9b65000000&m=1473057774","list_dtime":"2016-09-05 10:25:45"},{"pk":"57ccdcd91bc8e07f5d000051","title":"一周新片推荐：大白鲨对战深海寻宝","title_line_break":"一周新片推荐：\n大白鲨对战深海寻宝","date":"2016-09-05 14:34:27","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57ccdcd91bc8e07f5d000051","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzM1MF81NzM3Ml9XNjQwSDM2MFMzODU0Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzM1MF81NzM3Ml9XNjQwSDM2MFMzODU0Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccdcd91bc8e07f5d000051&m=1473057774","list_dtime":"2016-09-05 14:34:27"},{"pk":"57ccfd019490cb413b000005","title":"拯救人类就是灭杀人口？这逻辑不是很懂","date":"2016-09-05 14:33:45","auther_name":"纵贯电影公社","weburl":"http://iphone.myzaker.com/l.php?l=57ccfd019490cb413b000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzM5OV81Mjk2NV9XNjQwSDM2MFMzOTEzNy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzM5OV81Mjk2NV9XNjQwSDM2MFMzOTEzNy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"17","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57ccfd019490cb413b000005&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57ccfd019490cb413b000005%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccfd019490cb413b000005&m=1473057774","list_dtime":"2016-09-05 14:33:45"},{"pk":"57cce5561bc8e0a064000004","title":"《欧洲攻略》：唐嫣携梁朝伟吴亦凡征战","title_line_break":"《欧洲攻略》：\n唐嫣携梁朝伟吴亦凡征战","date":"2016-09-05 14:32:46","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57cce5561bc8e0a064000004","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzQ2OV81NDA3MF9XNjQwSDM2MFMyMjgzNy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzQ2OV81NDA3MF9XNjQwSDM2MFMyMjgzNy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cce5561bc8e0a064000004&m=1473057774","list_dtime":"2016-09-05 14:32:46"},{"pk":"57ca3a601bc8e02a4a00001e","title":"凯奇新片再现美国军事史上最大海难","date":"2016-09-05 14:31:25","auther_name":"1905电影网","weburl":"http://iphone.myzaker.com/l.php?l=57ca3a601bc8e02a4a00001e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzQ1Nl83ODYyNV9XNjQwSDM2MFM1MDU2Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzQ1Nl83ODYyNV9XNjQwSDM2MFM1MDU2Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ca3a601bc8e02a4a00001e&m=1473057774","list_dtime":"2016-09-05 14:31:25"},{"pk":"57ccf4d59490cb9813000024","title":"漫威剧《神盾局特工》曝恶灵骑士照","date":"2016-09-05 14:31:57","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57ccf4d59490cb9813000024","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZWJkZTFiYzhlMGE0NjcwMDAwMGZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZWJkZTFiYzhlMGE0NjcwMDAwMGZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"620,396","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccf4d59490cb9813000024&m=1473057774","list_dtime":"2016-09-05 14:31:57"},{"pk":"57ccf1e41bc8e0696800001a","title":"韩国果然把《步步惊心》拍得好...","date":"2016-09-05 14:30:50","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57ccf1e41bc8e0696800001a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzQ0Ml8xMzQ4X1c2NDBIMzYwUzY4Nzk1LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1NzQ0Ml8xMzQ4X1c2NDBIMzYwUzY4Nzk1LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"57","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ccf1e41bc8e0696800001a&m=1473057774","list_dtime":"2016-09-05 14:30:50"},{"pk":"57cd0c3f9490cb160c000006","title":"周冬雨搭档张一山出演冯唐小说改编新剧","date":"2016-09-05 14:28:30","auther_name":"Mtime电影资讯","weburl":"http://iphone.myzaker.com/l.php?l=57cd0c3f9490cb160c000006","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NkMDUyOTFiYzhlMDRmN2EwMDAwMDBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NkMDUyOTFiYzhlMDRmN2EwMDAwMDBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"620,422","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cd0c3f9490cb160c000006&m=1473057774","list_dtime":"2016-09-05 14:28:30"},{"pk":"57cba2a61bc8e0fd1d000004","title":"说个预言，明年奥斯卡就从这几部片里产生","date":"2016-09-04 17:20:07","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57cba2a61bc8e0fd1d000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57cba2a77f52e9ac06000272_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cba2a77f52e9ac06000272_320.jpg","thumbnail_picsize":"600,398","media_count":"31","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10530&pk=57cba2a61bc8e0fd1d000004&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57cba2a61bc8e0fd1d000004%26app_id%3D10530%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cba2a61bc8e0fd1d000004&m=1473057914","list_dtime":"2016-09-04 17:20:07"},{"pk":"57cba2a61bc8e0fd1d000002","title":"如果你是片中的姐姐，你会原谅她吗？","date":"2016-09-04 15:20:07","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57cba2a61bc8e0fd1d000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57cba2a77f52e97b29000318_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cba2a77f52e97b29000318_320.jpg","thumbnail_picsize":"640,349","media_count":"23","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cba2a61bc8e0fd1d000002&m=1473057774","list_dtime":"2016-09-04 15:20:07"},{"pk":"57cba6d59490cb1357000014","title":"好莱坞欠他的不止一座小金人","date":"2016-09-04 15:45:09","auther_name":"纵贯电影公社","weburl":"http://iphone.myzaker.com/l.php?l=57cba6d59490cb1357000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57cba3857f52e9667600002f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cba3857f52e9667600002f_320.jpg","thumbnail_picsize":"1200,674","media_count":"22","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cba6d59490cb1357000014&m=1473057774","list_dtime":"2016-09-04 15:45:09"},{"pk":"57c9046d1bc8e0140e00000f","title":"别的「青春剧」像小说，这部剧才是生活","date":"2016-09-04 16:50:05","auther_name":"十点电影","weburl":"http://iphone.myzaker.com/l.php?l=57c9046d1bc8e0140e00000f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9010d7f52e94b15000263_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9010d7f52e94b15000263_320.jpg","thumbnail_picsize":"294,220","media_count":"24","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c9046d1bc8e0140e00000f&m=1473057774","list_dtime":"2016-09-04 16:50:05"},{"pk":"57c65edb1bc8e02473000001","title":"本世纪最佳电影是这一部，你肯定猜不到","date":"2016-09-04 11:45:45","auther_name":"电影集结号","weburl":"http://iphone.myzaker.com/l.php?l=57c65edb1bc8e02473000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODIwN180NzU2Ml9XNjQwSDM2MFM1MDk1My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODIwN180NzU2Ml9XNjQwSDM2MFM1MDk1My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"21","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c65edb1bc8e02473000001&m=1473046846","list_dtime":"2016-09-04 11:45:45"},{"pk":"57cbbf719490cbba57000006","title":"相信我，看完它你会哭泣，也会相信爱情","date":"2016-09-04 15:30:09","auther_name":"剧角映画","weburl":"http://iphone.myzaker.com/l.php?l=57cbbf719490cbba57000006","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbbe197f52e9dc200000a7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbbe197f52e9dc200000a7_320.jpg","thumbnail_picsize":"600,400","media_count":"21","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cbbf719490cbba57000006&m=1473057774","list_dtime":"2016-09-04 15:30:09"},{"pk":"57caff469490cbaf73000005","title":"科幻片很多，但能让人\u201c装逼\u201d的只有这部","date":"2016-09-04 10:50:14","auther_name":"独立鱼电影","weburl":"http://iphone.myzaker.com/l.php?l=57caff469490cbaf73000005","thumbnail_pic":"http://zkres.myzaker.com/201609/57caf9527f52e9d10d0003e9_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57caf9527f52e9d10d0003e9_320.jpg","thumbnail_picsize":"600,400","media_count":"37","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57caff469490cbaf73000005&m=1473043318","list_dtime":"2016-09-04 10:50:14"},{"pk":"57ca83ab1bc8e05078000000","title":"《幸运是我》：不幸的，或者是幸运的我","title_line_break":"《幸运是我》：\n不幸的，或者是幸运的我","date":"2016-09-04 12:42:30","auther_name":"豆瓣影评","weburl":"http://iphone.myzaker.com/l.php?l=57ca83ab1bc8e05078000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca83917f52e98d63000178_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca83917f52e98d63000178_320.jpg","thumbnail_picsize":"600,400","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57ca83ab1bc8e05078000000&m=1473050123","list_dtime":"2016-09-04 12:42:30"},{"pk":"57cad18d9490cb7104000006","title":"感谢你赠与最好时光","date":"2016-09-04 10:35:09","auther_name":"时光天堂电影小组","weburl":"http://iphone.myzaker.com/l.php?l=57cad18d9490cb7104000006","thumbnail_pic":"http://zkres.myzaker.com/201609/57caccbe1bc8e0c726000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57caccbe1bc8e0c726000001_320.jpg","thumbnail_picsize":"500,334","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cad18d9490cb7104000006&m=1473042511","list_dtime":"2016-09-04 10:35:09"},{"pk":"57cb07709490cb2823000003","title":"这部电影，才是我心中的宫崎骏最佳","date":"2016-09-04 01:25:04","auther_name":"毒舌电影","weburl":"http://iphone.myzaker.com/l.php?l=57cb07709490cb2823000003","thumbnail_pic":"http://zkres.myzaker.com/201609/57caf8107f52e9d10d0003b7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57caf8107f52e9d10d0003b7_320.jpg","thumbnail_picsize":"616,485","media_count":"34","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57cb07709490cb2823000003&m=1473009596","list_dtime":"2016-09-04 01:25:04"},{"pk":"57c900b81bc8e0d00b00000d","title":"上映三天变禁片，这片遇到什么禁忌？","date":"2016-09-03 13:59:16","auther_name":"电影集结号","weburl":"http://iphone.myzaker.com/l.php?l=57c900b81bc8e0d00b00000d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODAxMl82MTA3MF9XNjQwSDM2MFMzODQzMC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODAxMl82MTA3MF9XNjQwSDM2MFMzODQzMC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c900b81bc8e0d00b00000d&m=1472968482","list_dtime":"2016-09-03 13:59:16"},{"pk":"57c900b81bc8e0d00b00000e","title":"这部全世界女性都期待的电影终于来了！","date":"2016-09-03 14:01:25","auther_name":"电影集结号","weburl":"http://iphone.myzaker.com/l.php?l=57c900b81bc8e0d00b00000e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODA3MF8xNTk0Ml9XNjQwSDM2MFM0MTA1Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODA3MF8xNTk0Ml9XNjQwSDM2MFM0MTA1Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"23","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c900b81bc8e0d00b00000e&m=1472968482","list_dtime":"2016-09-03 14:01:25"},{"pk":"57c83b709490cbb332000003","title":"9月观片避雷指南，不想被恶心的赶紧收","date":"2016-09-03 11:45:01","auther_name":"热门电影","weburl":"http://iphone.myzaker.com/l.php?l=57c83b709490cbb332000003","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODU0MF84NzcxMV9XNjQwSDM2MFM2MTEzMy5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODU0MF84NzcxMV9XNjQwSDM2MFM2MTEzMy5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"30","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c83b709490cbb332000003&m=1472960189","list_dtime":"2016-09-03 11:45:01"},{"pk":"57c9c7839490cb4910000005","title":"她是台湾第一美女，如今却难敌岁月摧残","date":"2016-09-03 10:43:46","auther_name":"电影那点事儿","weburl":"http://iphone.myzaker.com/l.php?l=57c9c7839490cb4910000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTY0NV8zNTI3OF9XNjQwSDM2MFMyOTY2OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTY0NV8zNTI3OF9XNjQwSDM2MFMyOTY2OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"30","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c9c7839490cb4910000005&m=1472956711","list_dtime":"2016-09-03 10:43:46"},{"pk":"57c814c49490cb227c000011","title":"九月就看这九部片","date":"2016-09-03 14:09:39","auther_name":"毒舌电影","weburl":"http://iphone.myzaker.com/l.php?l=57c814c49490cb227c000011","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MTI5YTdmNTJlOTFlNjEwMDAxMjhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MTI5YTdmNTJlOTFlNjEwMDAxMjhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,337","media_count":"43","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c814c49490cb227c000011&m=1472969018","list_dtime":"2016-09-03 14:09:39"},{"pk":"57c903c31bc8e0a90e000000","title":"近十年最棒的零差评歌舞片已出现","date":"2016-09-03 14:04:29","auther_name":"知影","weburl":"http://iphone.myzaker.com/l.php?l=57c903c31bc8e0a90e000000","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODE0M184MzgzOF9XNjQwSDM2MFM1OTM1My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5ODE0M184MzgzOF9XNjQwSDM2MFM1OTM1My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c903c31bc8e0a90e000000&m=1472968751","list_dtime":"2016-09-03 14:04:29"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c9b0189490cbe40a000007,57c8fdf59490cbd609000008,57ccb0d49490cb622d000001,57cc5c7d9490cb517f00000d,57c93bfd1bc8e0e335000007,57cbd8099490cb9c51000009","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57cbf0c11bc8e0184b000002,57ccd45d1bc8e0235800004a,57cb885e9490cb5c39000010,57cc3e029490cb395900000d,57ccc00f9490cb7e7a000000,57c8dd279490cbc765000008","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57ccdcd91bc8e07f5d000051,57c95cdf9490cb9b65000000,57ccfd019490cb413b000005,57cce5561bc8e0a064000004,57ca3a601bc8e02a4a00001e,57ccf4d59490cb9813000024","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cd0c3f9490cb160c000006,57ccf1e41bc8e0696800001a,57cba2a61bc8e0fd1d000004,57cba2a61bc8e0fd1d000002,57cba6d59490cb1357000014,57c9046d1bc8e0140e00000f","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cbbf719490cbba57000006,57c65edb1bc8e02473000001,57caff469490cbaf73000005,57ca83ab1bc8e05078000000,57cad18d9490cb7104000006,57cb07709490cb2823000003","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c900b81bc8e0d00b00000e,57c900b81bc8e0d00b00000d,57c83b709490cbb332000003,57c9c7839490cb4910000005,57c814c49490cb227c000011,57c903c31bc8e0a90e000000","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#f77762","#f77762"],"only_text_page_bgcolors":["#f77762","#f77762"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/10530.png?t=1458284157","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/10530.png?t=1458284157","hidden_time":"24","need_userinfo":"NO","block_title":"电影资讯","block_color":"#f77762","desktop_color_number":"20","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_531c9c601ebc06b87cf6dc1ab37dae55","selected_index":"1","list":[{"pk":"zk_app_column_9","title":"娱乐","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_10530","title":"电影","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"10530_zk_app_column_block_9","title":"电影资讯","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=10530&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_11698","title":"电视","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11698_zk_app_column_block_9","title":"电视","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11698&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_12348","title":"明星","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12348_zk_app_column_block_9","title":"明星","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12348&catalog_appid=9","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=10530&since_date=1472696863&nt=1&next_aticle_id=57c9c7839490cb4910000002&_appid=androidphone&opage=2&otimestamp=179&catalog_appid=9
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=10530&need_app_integration=
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=10530&ids=5642f2aa9490cbb13200000e,51a7104681853dec4d00012f&k=201609051450
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/10530.png?t=1458284157
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/10530.png?t=1458284157
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 电影资讯
         * block_color : #f77762
         * desktop_color_number : 20
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_531c9c601ebc06b87cf6dc1ab37dae55
         * selected_index : 1
         * list : [{"pk":"zk_app_column_9","title":"娱乐","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_10530","title":"电影","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"10530_zk_app_column_block_9","title":"电影资讯","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=10530&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_11698","title":"电视","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11698_zk_app_column_block_9","title":"电视","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11698&catalog_appid=9","data_type":"news"}},{"pk":"zk_app_column_12348","title":"明星","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12348_zk_app_column_block_9","title":"明星","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12348&catalog_appid=9","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57c9b0189490cbe40a000007
         * title : 拒绝烂片，九月就等这七部新片
         * date : 2016-09-05 11:45:26
         * auther_name : 独立鱼电影
         * page : 1
         * index : 1
         * weburl : http://iphone.myzaker.com/l.php?l=57c9b0189490cbe40a000007
         * thumbnail_pic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTE0N185NzY4OV9XNjQwSDM2MFMzNTQxOS5qcGc=_1242.jpg
         * thumbnail_mpic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg3MTE0N185NzY4OV9XNjQwSDM2MFMzNTQxOS5qcGc=_1242.jpg
         * thumbnail_picsize : 640,360
         * media_count : 44
         * is_full : NO
         * content :
         * special_info : {"show_jingcai":"Y","list_nodsp":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10530&pk=57c9b0189490cbe40a000007&m=1473058049
         * list_dtime : 2016-09-05 11:45:26
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 4
             * articles : 57c9b0189490cbe40a000007,57c8fdf59490cbd609000008,57ccb0d49490cb622d000001,57cc5c7d9490cb517f00000d,57c93bfd1bc8e0e335000007,57cbd8099490cb9c51000009
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/9.png?t=1457432249
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * open_type :
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_9
             * title : 娱乐
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"9","title":"娱乐八卦","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9","data_type":"news"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 9
                 * title : 娱乐八卦
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=9&catalog_appid=9
                 * data_type : news
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String is_full;
            private String content;
            /**
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String show_jingcai;
                private String list_nodsp;

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }
            }
        }
    }
}
