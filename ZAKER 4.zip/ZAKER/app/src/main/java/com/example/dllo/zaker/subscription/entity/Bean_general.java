package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class Bean_general {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=13&since_date=1472925254&nt=1&next_aticle_id=57ccacdb1bc8e0d83f000002&_appid=androidphone&opage=2&otimestamp=188","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=13&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=13&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,5472a9b69490cb48180000f9,51a7103481853d8f4c000143&k=201609051530"},"catalog":"","articles":[{"pk":"57c7f5749490cb7a2c000058","title":"遗憾！酷开829粉丝节电视总销量险超618","date":"2016-09-05 10:00:00","auther_name":"科技频道","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c7f5749490cb7a2c000058","thumbnail_title":"遗憾！酷开829粉丝节电视总销量险超618","media_count":"1","hide_mask":"Y","is_full":"NO","content":"","special_type":"tag","special_info":{"icon_url":"http://zkres.myzaker.com/data/image/mark2/ad_2x.png?v=2015061216","tag_position":"1","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo_nocache.php?app_id=13&pk=57c7f5749490cb7a2c000058&ad=1","ga_info":{"category":"AD","action":"Article"},"is_ad":"Y","list_dtime":"2016-09-05 10:00:00"},{"pk":"57c92ac19490cbd71700005d","title":"商用设备新选择助力高效办公","date":"2016-09-05 10:00:00","auther_name":"科技频道","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c92ac19490cbd71700005d","thumbnail_pic":"http://zkres3.myzaker.com/data/attachment/editor/2016/09/02/14728016421278.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/data/attachment/editor/2016/09/02/14728016421278.jpg","thumbnail_min_pic":"http://zkres.myzaker.com/201609/aHR0cDovL3prcmVzMy5teXpha2VyLmNvbS9kYXRhL2F0dGFjaG1lbnQvZWRpdG9yLzIwMTYvMDkvMDIvMTQ3MjgwMTY0MjEyNzguanBn_640.jpg","thumbnail_picsize":"1242,700","thumbnail_title":"","media_count":"1","hide_mask":"Y","is_full":"NO","content":"","type":"web2","special_info":{"open_type":"web","need_user_info":"N","web_show_arg":{"toolbar_position":"top"},"web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c92ac19490cbd71700005d&title=%E5%95%86%E7%94%A8%E8%AE%BE%E5%A4%87%E6%96%B0%E9%80%89%E6%8B%A9%E5%8A%A9%E5%8A%9B%E9%AB%98%E6%95%88%E5%8A%9E%E5%85%AC&open_type=web&_appid=androidphone&need_userinfo=N&url=http%3A%2F%2Fad.doubleclick.net%2Fddm%2Ftrackclk%2FN5751.2300100ZAKER%2FB10076812.135223113%3Bdc_trk_aid%3D307751190%3Bdc_trk_cid%3D72643219%3Fhttp%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa71057%2Cb1189233%2Cc1665%2Ci0%2Cm101%2Ch","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=13&app_ids=13&pk=57c92ac19490cbd71700005d&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c92ac19490cbd71700005d","stat_read_url":"http://api.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=57c92ac19490cbd71700005d&action=read&url=http%3A%2F%2Fad.doubleclick.net%2Fddm%2Ftrackimp%2FN5751.2300100ZAKER%2FB10076812.135223113%3Bdc_trk_aid%3D307751190%3Bdc_trk_cid%3D72643219%3Bord%3D%5Btimestamp%5D%3Fhttp%3A%2F%2Fv.admaster.com.cn%2Fi%2Fa71057%2Cb1189233%2Cc1665%2Ci0%2Cm202%2Ch%2Cuhttps%3A%2F%2Ftracker.samplicio.us%2Ftracker%2F2b768a6a-dd9b-45a8-9db0-17ca75e84fb5%2Fpixel.gif%3Fsid%3D273442%26pid%3D135223113%26crid%3D726432191%26idfa%3D%25%25ADVERTISING_IDENTIFIER_PLAIN%25%25%26cachebuster%3D%25n","icon_url":"http://zkres.myzaker.com/data/image/mark/ad_2x.png","tag_position":"3","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo_nocache.php?app_id=13&pk=57c92ac19490cbd71700005d&ad=1","ga_info":{"category":"AD","action":"Article"},"is_ad":"Y","list_dtime":"2016-09-05 10:00:00"},{"pk":"57c9234f9490cbee17000042","title":"一封来自ZAKER的苹果发布会邀请函","date":"2016-09-05 09:18:24","auther_name":"ZAKER","page":"1","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57c9234f9490cbee17000042","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5OTYxM183NzQxMl9XNjQwSDM2MFMzMTc4MC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5OTYxM183NzQxMl9XNjQwSDM2MFMzMTc4MC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","type":"web2","special_info":{"open_type":"web","need_user_info":"N","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c9234f9490cbee17000042&title=%E4%B8%80%E5%B0%81%E6%9D%A5%E8%87%AAZAKER%E7%9A%84%E8%8B%B9%E6%9E%9C%E5%8F%91%E5%B8%83%E4%BC%9A%E9%82%80%E8%AF%B7%E5%87%BD&open_type=web&_appid=androidphone&need_userinfo=N&url=http%3A%2F%2Fadweb.myzaker.com%2Fh%2FAppleEvents_v2%2F","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=13&app_ids=13&pk=57c9234f9490cbee17000042&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c9234f9490cbee17000042","icon_url":"http://zkres.myzaker.com/data/image/mark2/dujia_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9234f9490cbee17000042&m=1473060777","list_dtime":"2016-09-05 09:18:24"},{"pk":"57cbfcdc1bc8e07751000022","title":"直击：苹果iPhone7发布会现场开始装饰","title_line_break":"直击：\n苹果iPhone7发布会现场开始装饰","date":"2016-09-05 09:07:52","auther_name":"IT之家","page":"2","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57cbfcdc1bc8e07751000022","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbf9317f52e96b47000072_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbf9317f52e96b47000072_320.jpg","thumbnail_picsize":"550,413","media_count":"8","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57958aff9490cb873200002b","block_title":"2016苹果秋季发布会前瞻","title":"2016苹果秋季发布会前瞻","block_in_title":"直击：苹果iPhone7发布会现场开始装饰","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=13&topic_id=57958aff9490cb873200002b&updated=1473038298"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cbfcdc1bc8e07751000022&m=1473060777","list_dtime":"2016-09-05 09:07:52"},{"pk":"57ccd8039490cb227e000024","title":"三星Note 7全球召回，你怎么看？","title_line_break":"三星Note\n7全球召回，你怎么看？","date":"2016-09-05 10:25:11","auther_name":"数码脑残粉","page":"2","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57ccd8039490cb227e000024","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"156","title":"数码脑残粉","stitle":"数码科技达人聚集地","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=156","block_color":"","subscribe_count":"294424","post_count":"16689","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=13&app_ids=13&pk=57ccd8039490cb227e000024&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57ccd8039490cb227e000024","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccd8039490cb227e000024&m=1473060777","list_dtime":"2016-09-05 10:25:11"},{"pk":"57cca8a19490cbc303000004","title":"全球首部人工智能手机来了！竟然出自它","date":"2016-09-05 07:25:38","auther_name":"凤凰科技","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57cca8a19490cbc303000004","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzc5N18xNDYxMV9XNjQwSDM2MFM2OTc2MS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzc5N18xNDYxMV9XNjQwSDM2MFM2OTc2MS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cca8a19490cbc303000004&m=1473060777","list_dtime":"2016-09-05 07:25:38"},{"pk":"57cc386c1bc8e0cd7f000002","title":"索尼黑科技投影仪：可直接触控影像","title_line_break":"索尼黑科技投影仪：\n可直接触控影像","date":"2016-09-05 00:01:48","auther_name":"IT之家","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57cc386c1bc8e0cd7f000002","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzg3NF8yMzgyOF9XNjQwSDM2MFMzMDYxNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzg3NF8yMzgyOF9XNjQwSDM2MFMzMDYxNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cc386c1bc8e0cd7f000002&m=1473060604","list_dtime":"2016-09-05 00:01:48"},{"pk":"57cbacb11bc8e07a3f000034","title":"沉迷于VR的日本年轻人，已不需要男女朋友","date":"2016-09-05 15:01:09","auther_name":"南七道","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57cbacb11bc8e07a3f000034","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1ODk2Nl8zMTYxMF9XNjQwSDM2MFM0MTI4Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1ODk2Nl8zMTYxMF9XNjQwSDM2MFM0MTI4Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cbacb11bc8e07a3f000034&m=1473060776","list_dtime":"2016-09-05 15:01:09"},{"pk":"57ccf4d19490cb9813000012","title":"锤子T3最清晰真机照曝光！老罗玩暧昧","date":"2016-09-05 14:04:12","auther_name":"Techweb","weburl":"http://iphone.myzaker.com/l.php?l=57ccf4d19490cb9813000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce8c61bc8e0de6500000b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce8c61bc8e0de6500000b_320.jpg","thumbnail_picsize":"375,500","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccf4d19490cb9813000012&m=1473060504","list_dtime":"2016-09-05 14:04:12"},{"pk":"57cd1b029490cb4d7e000038","title":"魅蓝Max原生默认系统壁纸抢先体验","date":"2016-09-05 15:13:55","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd1b029490cb4d7e000038","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd1b029490cb4d7e000038&m=1473060504","list_dtime":"2016-09-05 15:13:55"},{"pk":"57cd040b9490cb155f00000e","title":"手机还没发布：iPhone 7耳机上线众筹","title_line_break":"手机还没发布：\niPhone 7耳机上线众筹","date":"2016-09-05 14:05:09","auther_name":"手机之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd040b9490cb155f00000e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccffbd1bc8e08676000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccffbd1bc8e08676000000_320.jpg","thumbnail_picsize":"500,328","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd040b9490cb155f00000e&m=1473060504","list_dtime":"2016-09-05 14:05:09"},{"pk":"57ccf4d19490cb9813000011","title":"iPad Air 3可能只是小号iPad Pro","date":"2016-09-05 14:27:22","auther_name":"威锋网","weburl":"http://iphone.myzaker.com/l.php?l=57ccf4d19490cb9813000011","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce81a1bc8e0cc64000093_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce81a1bc8e0cc64000093_320.jpg","thumbnail_picsize":"730,500","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccf4d19490cb9813000011&m=1473060504","list_dtime":"2016-09-05 14:27:22"},{"pk":"57cd040b9490cb155f00000b","title":"世界因iPhone 4而变","title_line_break":"世界因iPhone\n4而变","date":"2016-09-05 14:23:22","auther_name":"爱活网","weburl":"http://iphone.myzaker.com/l.php?l=57cd040b9490cb155f00000b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce94e1bc8e0bd65000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce94e1bc8e0bd65000003_320.jpg","thumbnail_picsize":"660,440","media_count":"39","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd040b9490cb155f00000b&m=1473060504","list_dtime":"2016-09-05 14:23:22"},{"pk":"57cd13469490cb613100000b","title":"张继科微博晒新机：C罗签名加持","title_line_break":"张继科微博晒新机：\nC罗签名加持","date":"2016-09-05 14:54:27","auther_name":"Techweb","weburl":"http://iphone.myzaker.com/l.php?l=57cd13469490cb613100000b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd12f91bc8e07205000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd12f91bc8e07205000000_320.jpg","thumbnail_picsize":"500,718","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd13469490cb613100000b&m=1473060504","list_dtime":"2016-09-05 14:54:27"},{"pk":"57cd00501bc8e02f0c000032","title":"460元起！三星居然开始卖起腰带","date":"2016-09-05 14:25:42","auther_name":"TechWeb","weburl":"http://iphone.myzaker.com/l.php?l=57cd00501bc8e02f0c000032","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd0047a07aecc52301f98e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd0047a07aecc52301f98e_320.jpg","thumbnail_picsize":"500,319","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd00501bc8e02f0c000032&m=1473060504","list_dtime":"2016-09-05 14:25:42"},{"pk":"57cd14071bc8e08e06000016","title":"召回的三星Note 7要当翻新机卖","title_line_break":"召回的三星Note\n7要当翻新机卖","date":"2016-09-05 14:47:51","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd14071bc8e08e06000016","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca29ba7f52e91030000015_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca29ba7f52e91030000015_320.jpg","thumbnail_picsize":"600,338","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd14071bc8e08e06000016&m=1473060504","list_dtime":"2016-09-05 14:47:51"},{"pk":"57cd14081bc8e08e0600001b","title":"SSD容量10年后可达100TB","date":"2016-09-05 14:44:22","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd14081bc8e08e0600001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd10187f52e97431000088_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd10187f52e97431000088_320.jpg","thumbnail_picsize":"600,424","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd14081bc8e08e0600001b&m=1473060504","list_dtime":"2016-09-05 14:44:22"},{"pk":"57ccf65a9490cb4c7e000031","title":"马云给全球工商大佬展示哪五张照片","date":"2016-09-05 12:36:42","auther_name":"新华视界","weburl":"http://iphone.myzaker.com/l.php?l=57ccf65a9490cb4c7e000031","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc3111f5a2247e47000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc3111f5a2247e47000001_320.jpg","thumbnail_picsize":"640,426","media_count":"16","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccf65a9490cb4c7e000031&m=1473060504","list_dtime":"2016-09-05 12:36:42"},{"pk":"57cd1b029490cb4d7e00003b","title":"这所高校要\u201c刷脸签到\u201d：逃课党哭吧","title_line_break":"这所高校要\u201c刷脸签到\u201d：\n逃课党哭吧","date":"2016-09-05 15:13:20","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd1b029490cb4d7e00003b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd18617f52e97431000133_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd18617f52e97431000133_320.jpg","thumbnail_picsize":"564,310","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd1b029490cb4d7e00003b&m=1473060504","list_dtime":"2016-09-05 15:13:20"},{"pk":"57ccf2401bc8e0b369000012","title":"Edge难救场，微软浏览器份额加速下滑","date":"2016-09-05 14:22:13","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccf2401bc8e0b369000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccee387f52e962310000d1_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccee387f52e962310000d1_320.jpg","thumbnail_picsize":"600,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccf2401bc8e0b369000012&m=1473060504","list_dtime":"2016-09-05 14:22:13"},{"pk":"57ccb7dd9490cb9151000008","title":"华为Mate 8大降价：Mate 9在路上？","title_line_break":"华为Mate 8大降价：\nMate 9在路上？","date":"2016-09-05 11:45:51","auther_name":"Techweb","weburl":"http://iphone.myzaker.com/l.php?l=57ccb7dd9490cb9151000008","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb49a1bc8e0504600000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb49a1bc8e0504600000d_320.jpg","thumbnail_picsize":"600,372","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccb7dd9490cb9151000008&m=1473060504","list_dtime":"2016-09-05 11:45:51"},{"pk":"57cceab59490cb057e000034","title":"苹果躺赢？三星Note 7这次麻烦大了","title_line_break":"苹果躺赢？三星Note\n7这次麻烦大了","date":"2016-09-05 11:47:08","auther_name":"爱范儿","weburl":"http://iphone.myzaker.com/l.php?l=57cceab59490cb057e000034","thumbnail_pic":"http://zkres.myzaker.com/201608/57c316801bc8e0bd72000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c316801bc8e0bd72000000_320.jpg","thumbnail_picsize":"1200,750","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cceab59490cb057e000034&m=1473060504","list_dtime":"2016-09-05 11:47:08"},{"pk":"57cce1571bc8e01461000002","title":"小米众筹新品再曝：羽绒服要来了","title_line_break":"小米众筹新品再曝：\n羽绒服要来了","date":"2016-09-05 11:11:27","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cce1571bc8e01461000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdd3c7f52e988640001b3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdd3c7f52e988640001b3_320.jpg","thumbnail_picsize":"594,459","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cce1571bc8e01461000002&m=1473060505","list_dtime":"2016-09-05 11:11:27"},{"pk":"57cce5929490cbd84400000f","title":"很快，那台经典的 iPhone 4 就要隐退了","date":"2016-09-05 11:42:15","auther_name":"鸵鸟电台","weburl":"http://iphone.myzaker.com/l.php?l=57cce5929490cbd84400000f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce9cef5a2248e64000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce9cef5a2248e64000000_320.jpg","thumbnail_picsize":"1200,874","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cce5929490cbd84400000f&m=1473060504","list_dtime":"2016-09-05 11:42:15"},{"pk":"57cce5929490cbd844000012","title":"国内外一视同仁 一加合并氢OS和氧OS","title_line_break":"国内外一视同仁\n一加合并氢OS和氧OS","date":"2016-09-05 11:32:47","auther_name":"cnBeta","weburl":"http://iphone.myzaker.com/l.php?l=57cce5929490cbd844000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce2627f52e988640001ef_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce2627f52e988640001ef_320.jpg","thumbnail_picsize":"600,337","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cce5929490cbd844000012&m=1473060504","list_dtime":"2016-09-05 11:32:47"},{"pk":"57ccd8ca1bc8e07f5a00000e","title":"1299元起：小米Max官方大降价","title_line_break":"1299元起：\n小米Max官方大降价","date":"2016-09-05 11:06:44","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccd8ca1bc8e07f5a00000e","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccd8ca1bc8e07f5a00000e&m=1473060505","list_dtime":"2016-09-05 11:06:44"},{"pk":"57ccd8ca1bc8e07f5a00000f","title":"说到iPhone爆料，怎能少了这个男人","date":"2016-09-05 11:09:40","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccd8ca1bc8e07f5a00000f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce00ea07aecc52301e568_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce00ea07aecc52301e568_320.jpg","thumbnail_picsize":"600,400","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccd8ca1bc8e07f5a00000f&m=1473060505","list_dtime":"2016-09-05 11:09:40"},{"pk":"57ccd65a9490cb6d7100000c","title":"LG新旗舰V20真机亮相：黑边感人","title_line_break":"LG新旗舰V20真机亮相：\n黑边感人","date":"2016-09-05 10:24:12","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57ccd65a9490cb6d7100000c","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccec71bc8e0a657000005_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccec71bc8e0a657000005_320.jpg","thumbnail_picsize":"640,386","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccd65a9490cb6d7100000c&m=1473060505","list_dtime":"2016-09-05 10:24:12"},{"pk":"57ccb9931bc8e00049000046","title":"行业标杆：三星Gear S3有啥不同？","title_line_break":"行业标杆：\n三星Gear S3有啥不同？","date":"2016-09-05 10:41:04","auther_name":"腾讯数码","weburl":"http://iphone.myzaker.com/l.php?l=57ccb9931bc8e00049000046","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb9911bc8e00049000040_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb9911bc8e00049000040_320.jpg","thumbnail_picsize":"640,426","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccb9931bc8e00049000046&m=1473060505","list_dtime":"2016-09-05 10:41:04"},{"pk":"57ccb9981bc8e0004900005d","title":"雷蛇发布全新\u201c机械薄膜\u201d键盘","date":"2016-09-05 10:11:56","auther_name":"腾讯数码","weburl":"http://iphone.myzaker.com/l.php?l=57ccb9981bc8e0004900005d","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb9981bc8e0004900005b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb9981bc8e0004900005b_320.jpg","thumbnail_picsize":"640,427","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccb9981bc8e0004900005d&m=1473060505","list_dtime":"2016-09-05 10:11:56"},{"pk":"57cc15811bc8e00a64000014","title":"又一款Win 10手机曝光：纤薄金属设计","title_line_break":"又一款Win 10手机曝光：\n纤薄金属设计","date":"2016-09-05 08:54:30","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cc15811bc8e00a64000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc11a37f52e9b8520002c5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc11a37f52e9b8520002c5_320.jpg","thumbnail_picsize":"600,436","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cc15811bc8e00a64000014&m=1473060505","list_dtime":"2016-09-05 08:54:30"},{"pk":"57ccc5859490cb147e00003b","title":"9月5日科技要闻：苹果不再支持iPhone 4","title_line_break":"9月5日科技要闻：\n苹果不再支持iPhone 4","date":"2016-09-05 09:08:55","auther_name":"爱范儿","weburl":"http://iphone.myzaker.com/l.php?l=57ccc5859490cb147e00003b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb7621bc8e07748000025_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb7621bc8e07748000025_320.jpg","thumbnail_picsize":"1830,1238","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccc5859490cb147e00003b&m=1473060505","list_dtime":"2016-09-05 09:08:55"},{"pk":"57cc27411bc8e0c071000003","title":"小米公关该找雷军谈谈了","date":"2016-09-05 07:47:50","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cc27411bc8e0c071000003","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc23187f52e94006000116_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc23187f52e94006000116_320.jpg","thumbnail_picsize":"600,476","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cc27411bc8e0c071000003&m=1473060505","list_dtime":"2016-09-05 07:47:50"},{"pk":"57ccb9951bc8e0004900004b","title":"真正的远程无线充电技术 极限范围5m","title_line_break":"真正的远程无线充电技术\n极限范围5m","date":"2016-09-05 08:25:58","auther_name":"腾讯数码","weburl":"http://iphone.myzaker.com/l.php?l=57ccb9951bc8e0004900004b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb9941bc8e00049000048_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb9941bc8e00049000048_320.jpg","thumbnail_picsize":"640,427","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccb9951bc8e0004900004b&m=1473060505","list_dtime":"2016-09-05 08:25:58"},{"pk":"57ccacdd1bc8e0d83f000004","title":"iPhone7值得期待：一直被借鉴，还未被超越","title_line_break":"iPhone7值得期待：\n一直被借鉴，还未被超越","date":"2016-09-05 07:27:12","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccacdd1bc8e0d83f000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca89a7f52e9fe26000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca89a7f52e9fe26000003_320.jpg","thumbnail_picsize":"600,374","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccacdd1bc8e0d83f000004&m=1473060505","list_dtime":"2016-09-05 07:27:12"},{"pk":"57ccacdb1bc8e0d83f000001","title":"核多不一定管用：820与X25对比实测","title_line_break":"核多不一定管用：\n820与X25对比实测","date":"2016-09-05 07:32:37","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccacdb1bc8e0d83f000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccacdd7f52e9fe26000069_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccacdd7f52e9fe26000069_320.jpg","thumbnail_picsize":"600,404","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccacdb1bc8e0d83f000001&m=1473060505","list_dtime":"2016-09-05 07:32:37"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","is_ad":"Y","focus_photo_size":{"width":"1242","height":"700"},"tpl_style":"2","articles":"57c92ac19490cbd71700005d,57c9234f9490cbee17000042,57cbacb11bc8e07a3f000034,57ccf4d19490cb9813000012,57cd1b029490cb4d7e000038,57c7f5749490cb7a2c000058","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cca8a19490cbc303000004,57ccd8039490cb227e000024,57cd040b9490cb155f00000e,57ccf4d19490cb9813000011,57cd040b9490cb155f00000b,57cbfcdc1bc8e07751000022","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cc386c1bc8e0cd7f000002,57cd13469490cb613100000b,57cd00501bc8e02f0c000032,57cd14071bc8e08e06000016,57cd14081bc8e08e0600001b,57ccf65a9490cb4c7e000031","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccf2401bc8e0b369000012,57cd1b029490cb4d7e00003b,57ccb7dd9490cb9151000008,57cceab59490cb057e000034,57cce1571bc8e01461000002,57cce5929490cbd84400000f","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccd8ca1bc8e07f5a00000f,57ccd8ca1bc8e07f5a00000e,57cce5929490cbd844000012,57ccd65a9490cb6d7100000c,57ccb9931bc8e00049000046,57ccb9981bc8e0004900005d","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccc5859490cb147e00003b,57cc15811bc8e00a64000014,57cc27411bc8e0c071000003,57ccb9951bc8e0004900004b,57ccacdd1bc8e0d83f000004,57ccacdb1bc8e0d83f000001","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}}],"article_block_colors":["#4fa7ab","#4fa7ab"],"only_text_page_bgcolors":["#4fa7ab","#4fa7ab"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/13.png?1413770585","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/13.png?1413770585","hidden_time":"24","need_userinfo":"NO","block_title":"科技频道","block_color":"#4fa7ab","desktop_color_number":"5","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_0b2dc7e97cc3795280b652a7a278839d","selected_index":"0","list":[{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]}}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=13&since_date=1472925254&nt=1&next_aticle_id=57ccacdb1bc8e0d83f000002&_appid=androidphone&opage=2&otimestamp=188","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=13&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=13&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,5472a9b69490cb48180000f9,51a7103481853d8f4c000143&k=201609051530"}
     * catalog :
     * articles : [{"pk":"57c7f5749490cb7a2c000058","title":"遗憾！酷开829粉丝节电视总销量险超618","date":"2016-09-05 10:00:00","auther_name":"科技频道","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c7f5749490cb7a2c000058","thumbnail_title":"遗憾！酷开829粉丝节电视总销量险超618","media_count":"1","hide_mask":"Y","is_full":"NO","content":"","special_type":"tag","special_info":{"icon_url":"http://zkres.myzaker.com/data/image/mark2/ad_2x.png?v=2015061216","tag_position":"1","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo_nocache.php?app_id=13&pk=57c7f5749490cb7a2c000058&ad=1","ga_info":{"category":"AD","action":"Article"},"is_ad":"Y","list_dtime":"2016-09-05 10:00:00"},{"pk":"57c92ac19490cbd71700005d","title":"商用设备新选择助力高效办公","date":"2016-09-05 10:00:00","auther_name":"科技频道","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c92ac19490cbd71700005d","thumbnail_pic":"http://zkres3.myzaker.com/data/attachment/editor/2016/09/02/14728016421278.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/data/attachment/editor/2016/09/02/14728016421278.jpg","thumbnail_min_pic":"http://zkres.myzaker.com/201609/aHR0cDovL3prcmVzMy5teXpha2VyLmNvbS9kYXRhL2F0dGFjaG1lbnQvZWRpdG9yLzIwMTYvMDkvMDIvMTQ3MjgwMTY0MjEyNzguanBn_640.jpg","thumbnail_picsize":"1242,700","thumbnail_title":"","media_count":"1","hide_mask":"Y","is_full":"NO","content":"","type":"web2","special_info":{"open_type":"web","need_user_info":"N","web_show_arg":{"toolbar_position":"top"},"web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c92ac19490cbd71700005d&title=%E5%95%86%E7%94%A8%E8%AE%BE%E5%A4%87%E6%96%B0%E9%80%89%E6%8B%A9%E5%8A%A9%E5%8A%9B%E9%AB%98%E6%95%88%E5%8A%9E%E5%85%AC&open_type=web&_appid=androidphone&need_userinfo=N&url=http%3A%2F%2Fad.doubleclick.net%2Fddm%2Ftrackclk%2FN5751.2300100ZAKER%2FB10076812.135223113%3Bdc_trk_aid%3D307751190%3Bdc_trk_cid%3D72643219%3Fhttp%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa71057%2Cb1189233%2Cc1665%2Ci0%2Cm101%2Ch","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=13&app_ids=13&pk=57c92ac19490cbd71700005d&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c92ac19490cbd71700005d","stat_read_url":"http://api.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=57c92ac19490cbd71700005d&action=read&url=http%3A%2F%2Fad.doubleclick.net%2Fddm%2Ftrackimp%2FN5751.2300100ZAKER%2FB10076812.135223113%3Bdc_trk_aid%3D307751190%3Bdc_trk_cid%3D72643219%3Bord%3D%5Btimestamp%5D%3Fhttp%3A%2F%2Fv.admaster.com.cn%2Fi%2Fa71057%2Cb1189233%2Cc1665%2Ci0%2Cm202%2Ch%2Cuhttps%3A%2F%2Ftracker.samplicio.us%2Ftracker%2F2b768a6a-dd9b-45a8-9db0-17ca75e84fb5%2Fpixel.gif%3Fsid%3D273442%26pid%3D135223113%26crid%3D726432191%26idfa%3D%25%25ADVERTISING_IDENTIFIER_PLAIN%25%25%26cachebuster%3D%25n","icon_url":"http://zkres.myzaker.com/data/image/mark/ad_2x.png","tag_position":"3","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo_nocache.php?app_id=13&pk=57c92ac19490cbd71700005d&ad=1","ga_info":{"category":"AD","action":"Article"},"is_ad":"Y","list_dtime":"2016-09-05 10:00:00"},{"pk":"57c9234f9490cbee17000042","title":"一封来自ZAKER的苹果发布会邀请函","date":"2016-09-05 09:18:24","auther_name":"ZAKER","page":"1","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57c9234f9490cbee17000042","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5OTYxM183NzQxMl9XNjQwSDM2MFMzMTc4MC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3Mjc5OTYxM183NzQxMl9XNjQwSDM2MFMzMTc4MC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","type":"web2","special_info":{"open_type":"web","need_user_info":"N","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c9234f9490cbee17000042&title=%E4%B8%80%E5%B0%81%E6%9D%A5%E8%87%AAZAKER%E7%9A%84%E8%8B%B9%E6%9E%9C%E5%8F%91%E5%B8%83%E4%BC%9A%E9%82%80%E8%AF%B7%E5%87%BD&open_type=web&_appid=androidphone&need_userinfo=N&url=http%3A%2F%2Fadweb.myzaker.com%2Fh%2FAppleEvents_v2%2F","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=13&app_ids=13&pk=57c9234f9490cbee17000042&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c9234f9490cbee17000042","icon_url":"http://zkres.myzaker.com/data/image/mark2/dujia_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9234f9490cbee17000042&m=1473060777","list_dtime":"2016-09-05 09:18:24"},{"pk":"57cbfcdc1bc8e07751000022","title":"直击：苹果iPhone7发布会现场开始装饰","title_line_break":"直击：\n苹果iPhone7发布会现场开始装饰","date":"2016-09-05 09:07:52","auther_name":"IT之家","page":"2","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57cbfcdc1bc8e07751000022","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbf9317f52e96b47000072_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbf9317f52e96b47000072_320.jpg","thumbnail_picsize":"550,413","media_count":"8","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57958aff9490cb873200002b","block_title":"2016苹果秋季发布会前瞻","title":"2016苹果秋季发布会前瞻","block_in_title":"直击：苹果iPhone7发布会现场开始装饰","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=13&topic_id=57958aff9490cb873200002b&updated=1473038298"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cbfcdc1bc8e07751000022&m=1473060777","list_dtime":"2016-09-05 09:07:52"},{"pk":"57ccd8039490cb227e000024","title":"三星Note 7全球召回，你怎么看？","title_line_break":"三星Note\n7全球召回，你怎么看？","date":"2016-09-05 10:25:11","auther_name":"数码脑残粉","page":"2","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57ccd8039490cb227e000024","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"156","title":"数码脑残粉","stitle":"数码科技达人聚集地","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=156","block_color":"","subscribe_count":"294424","post_count":"16689","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=13&app_ids=13&pk=57ccd8039490cb227e000024&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57ccd8039490cb227e000024","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccd8039490cb227e000024&m=1473060777","list_dtime":"2016-09-05 10:25:11"},{"pk":"57cca8a19490cbc303000004","title":"全球首部人工智能手机来了！竟然出自它","date":"2016-09-05 07:25:38","auther_name":"凤凰科技","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57cca8a19490cbc303000004","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzc5N18xNDYxMV9XNjQwSDM2MFM2OTc2MS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzc5N18xNDYxMV9XNjQwSDM2MFM2OTc2MS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cca8a19490cbc303000004&m=1473060777","list_dtime":"2016-09-05 07:25:38"},{"pk":"57cc386c1bc8e0cd7f000002","title":"索尼黑科技投影仪：可直接触控影像","title_line_break":"索尼黑科技投影仪：\n可直接触控影像","date":"2016-09-05 00:01:48","auther_name":"IT之家","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57cc386c1bc8e0cd7f000002","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzg3NF8yMzgyOF9XNjQwSDM2MFMzMDYxNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA0Nzg3NF8yMzgyOF9XNjQwSDM2MFMzMDYxNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cc386c1bc8e0cd7f000002&m=1473060604","list_dtime":"2016-09-05 00:01:48"},{"pk":"57cbacb11bc8e07a3f000034","title":"沉迷于VR的日本年轻人，已不需要男女朋友","date":"2016-09-05 15:01:09","auther_name":"南七道","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57cbacb11bc8e07a3f000034","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1ODk2Nl8zMTYxMF9XNjQwSDM2MFM0MTI4Mi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDUvdXBfMTQ3MzA1ODk2Nl8zMTYxMF9XNjQwSDM2MFM0MTI4Mi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cbacb11bc8e07a3f000034&m=1473060776","list_dtime":"2016-09-05 15:01:09"},{"pk":"57ccf4d19490cb9813000012","title":"锤子T3最清晰真机照曝光！老罗玩暧昧","date":"2016-09-05 14:04:12","auther_name":"Techweb","weburl":"http://iphone.myzaker.com/l.php?l=57ccf4d19490cb9813000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce8c61bc8e0de6500000b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce8c61bc8e0de6500000b_320.jpg","thumbnail_picsize":"375,500","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccf4d19490cb9813000012&m=1473060504","list_dtime":"2016-09-05 14:04:12"},{"pk":"57cd1b029490cb4d7e000038","title":"魅蓝Max原生默认系统壁纸抢先体验","date":"2016-09-05 15:13:55","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd1b029490cb4d7e000038","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd1b029490cb4d7e000038&m=1473060504","list_dtime":"2016-09-05 15:13:55"},{"pk":"57cd040b9490cb155f00000e","title":"手机还没发布：iPhone 7耳机上线众筹","title_line_break":"手机还没发布：\niPhone 7耳机上线众筹","date":"2016-09-05 14:05:09","auther_name":"手机之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd040b9490cb155f00000e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccffbd1bc8e08676000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccffbd1bc8e08676000000_320.jpg","thumbnail_picsize":"500,328","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd040b9490cb155f00000e&m=1473060504","list_dtime":"2016-09-05 14:05:09"},{"pk":"57ccf4d19490cb9813000011","title":"iPad Air 3可能只是小号iPad Pro","date":"2016-09-05 14:27:22","auther_name":"威锋网","weburl":"http://iphone.myzaker.com/l.php?l=57ccf4d19490cb9813000011","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce81a1bc8e0cc64000093_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce81a1bc8e0cc64000093_320.jpg","thumbnail_picsize":"730,500","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccf4d19490cb9813000011&m=1473060504","list_dtime":"2016-09-05 14:27:22"},{"pk":"57cd040b9490cb155f00000b","title":"世界因iPhone 4而变","title_line_break":"世界因iPhone\n4而变","date":"2016-09-05 14:23:22","auther_name":"爱活网","weburl":"http://iphone.myzaker.com/l.php?l=57cd040b9490cb155f00000b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce94e1bc8e0bd65000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce94e1bc8e0bd65000003_320.jpg","thumbnail_picsize":"660,440","media_count":"39","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd040b9490cb155f00000b&m=1473060504","list_dtime":"2016-09-05 14:23:22"},{"pk":"57cd13469490cb613100000b","title":"张继科微博晒新机：C罗签名加持","title_line_break":"张继科微博晒新机：\nC罗签名加持","date":"2016-09-05 14:54:27","auther_name":"Techweb","weburl":"http://iphone.myzaker.com/l.php?l=57cd13469490cb613100000b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd12f91bc8e07205000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd12f91bc8e07205000000_320.jpg","thumbnail_picsize":"500,718","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd13469490cb613100000b&m=1473060504","list_dtime":"2016-09-05 14:54:27"},{"pk":"57cd00501bc8e02f0c000032","title":"460元起！三星居然开始卖起腰带","date":"2016-09-05 14:25:42","auther_name":"TechWeb","weburl":"http://iphone.myzaker.com/l.php?l=57cd00501bc8e02f0c000032","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd0047a07aecc52301f98e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd0047a07aecc52301f98e_320.jpg","thumbnail_picsize":"500,319","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd00501bc8e02f0c000032&m=1473060504","list_dtime":"2016-09-05 14:25:42"},{"pk":"57cd14071bc8e08e06000016","title":"召回的三星Note 7要当翻新机卖","title_line_break":"召回的三星Note\n7要当翻新机卖","date":"2016-09-05 14:47:51","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd14071bc8e08e06000016","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca29ba7f52e91030000015_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca29ba7f52e91030000015_320.jpg","thumbnail_picsize":"600,338","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd14071bc8e08e06000016&m=1473060504","list_dtime":"2016-09-05 14:47:51"},{"pk":"57cd14081bc8e08e0600001b","title":"SSD容量10年后可达100TB","date":"2016-09-05 14:44:22","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd14081bc8e08e0600001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd10187f52e97431000088_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd10187f52e97431000088_320.jpg","thumbnail_picsize":"600,424","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd14081bc8e08e0600001b&m=1473060504","list_dtime":"2016-09-05 14:44:22"},{"pk":"57ccf65a9490cb4c7e000031","title":"马云给全球工商大佬展示哪五张照片","date":"2016-09-05 12:36:42","auther_name":"新华视界","weburl":"http://iphone.myzaker.com/l.php?l=57ccf65a9490cb4c7e000031","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc3111f5a2247e47000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc3111f5a2247e47000001_320.jpg","thumbnail_picsize":"640,426","media_count":"16","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccf65a9490cb4c7e000031&m=1473060504","list_dtime":"2016-09-05 12:36:42"},{"pk":"57cd1b029490cb4d7e00003b","title":"这所高校要\u201c刷脸签到\u201d：逃课党哭吧","title_line_break":"这所高校要\u201c刷脸签到\u201d：\n逃课党哭吧","date":"2016-09-05 15:13:20","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd1b029490cb4d7e00003b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd18617f52e97431000133_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd18617f52e97431000133_320.jpg","thumbnail_picsize":"564,310","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cd1b029490cb4d7e00003b&m=1473060504","list_dtime":"2016-09-05 15:13:20"},{"pk":"57ccf2401bc8e0b369000012","title":"Edge难救场，微软浏览器份额加速下滑","date":"2016-09-05 14:22:13","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccf2401bc8e0b369000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccee387f52e962310000d1_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccee387f52e962310000d1_320.jpg","thumbnail_picsize":"600,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccf2401bc8e0b369000012&m=1473060504","list_dtime":"2016-09-05 14:22:13"},{"pk":"57ccb7dd9490cb9151000008","title":"华为Mate 8大降价：Mate 9在路上？","title_line_break":"华为Mate 8大降价：\nMate 9在路上？","date":"2016-09-05 11:45:51","auther_name":"Techweb","weburl":"http://iphone.myzaker.com/l.php?l=57ccb7dd9490cb9151000008","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb49a1bc8e0504600000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb49a1bc8e0504600000d_320.jpg","thumbnail_picsize":"600,372","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccb7dd9490cb9151000008&m=1473060504","list_dtime":"2016-09-05 11:45:51"},{"pk":"57cceab59490cb057e000034","title":"苹果躺赢？三星Note 7这次麻烦大了","title_line_break":"苹果躺赢？三星Note\n7这次麻烦大了","date":"2016-09-05 11:47:08","auther_name":"爱范儿","weburl":"http://iphone.myzaker.com/l.php?l=57cceab59490cb057e000034","thumbnail_pic":"http://zkres.myzaker.com/201608/57c316801bc8e0bd72000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c316801bc8e0bd72000000_320.jpg","thumbnail_picsize":"1200,750","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cceab59490cb057e000034&m=1473060504","list_dtime":"2016-09-05 11:47:08"},{"pk":"57cce1571bc8e01461000002","title":"小米众筹新品再曝：羽绒服要来了","title_line_break":"小米众筹新品再曝：\n羽绒服要来了","date":"2016-09-05 11:11:27","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cce1571bc8e01461000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdd3c7f52e988640001b3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdd3c7f52e988640001b3_320.jpg","thumbnail_picsize":"594,459","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cce1571bc8e01461000002&m=1473060505","list_dtime":"2016-09-05 11:11:27"},{"pk":"57cce5929490cbd84400000f","title":"很快，那台经典的 iPhone 4 就要隐退了","date":"2016-09-05 11:42:15","auther_name":"鸵鸟电台","weburl":"http://iphone.myzaker.com/l.php?l=57cce5929490cbd84400000f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce9cef5a2248e64000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce9cef5a2248e64000000_320.jpg","thumbnail_picsize":"1200,874","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cce5929490cbd84400000f&m=1473060504","list_dtime":"2016-09-05 11:42:15"},{"pk":"57cce5929490cbd844000012","title":"国内外一视同仁 一加合并氢OS和氧OS","title_line_break":"国内外一视同仁\n一加合并氢OS和氧OS","date":"2016-09-05 11:32:47","auther_name":"cnBeta","weburl":"http://iphone.myzaker.com/l.php?l=57cce5929490cbd844000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce2627f52e988640001ef_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce2627f52e988640001ef_320.jpg","thumbnail_picsize":"600,337","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cce5929490cbd844000012&m=1473060504","list_dtime":"2016-09-05 11:32:47"},{"pk":"57ccd8ca1bc8e07f5a00000e","title":"1299元起：小米Max官方大降价","title_line_break":"1299元起：\n小米Max官方大降价","date":"2016-09-05 11:06:44","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccd8ca1bc8e07f5a00000e","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccd8ca1bc8e07f5a00000e&m=1473060505","list_dtime":"2016-09-05 11:06:44"},{"pk":"57ccd8ca1bc8e07f5a00000f","title":"说到iPhone爆料，怎能少了这个男人","date":"2016-09-05 11:09:40","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccd8ca1bc8e07f5a00000f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce00ea07aecc52301e568_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce00ea07aecc52301e568_320.jpg","thumbnail_picsize":"600,400","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccd8ca1bc8e07f5a00000f&m=1473060505","list_dtime":"2016-09-05 11:09:40"},{"pk":"57ccd65a9490cb6d7100000c","title":"LG新旗舰V20真机亮相：黑边感人","title_line_break":"LG新旗舰V20真机亮相：\n黑边感人","date":"2016-09-05 10:24:12","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57ccd65a9490cb6d7100000c","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccec71bc8e0a657000005_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccec71bc8e0a657000005_320.jpg","thumbnail_picsize":"640,386","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccd65a9490cb6d7100000c&m=1473060505","list_dtime":"2016-09-05 10:24:12"},{"pk":"57ccb9931bc8e00049000046","title":"行业标杆：三星Gear S3有啥不同？","title_line_break":"行业标杆：\n三星Gear S3有啥不同？","date":"2016-09-05 10:41:04","auther_name":"腾讯数码","weburl":"http://iphone.myzaker.com/l.php?l=57ccb9931bc8e00049000046","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb9911bc8e00049000040_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb9911bc8e00049000040_320.jpg","thumbnail_picsize":"640,426","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccb9931bc8e00049000046&m=1473060505","list_dtime":"2016-09-05 10:41:04"},{"pk":"57ccb9981bc8e0004900005d","title":"雷蛇发布全新\u201c机械薄膜\u201d键盘","date":"2016-09-05 10:11:56","auther_name":"腾讯数码","weburl":"http://iphone.myzaker.com/l.php?l=57ccb9981bc8e0004900005d","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb9981bc8e0004900005b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb9981bc8e0004900005b_320.jpg","thumbnail_picsize":"640,427","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccb9981bc8e0004900005d&m=1473060505","list_dtime":"2016-09-05 10:11:56"},{"pk":"57cc15811bc8e00a64000014","title":"又一款Win 10手机曝光：纤薄金属设计","title_line_break":"又一款Win 10手机曝光：\n纤薄金属设计","date":"2016-09-05 08:54:30","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cc15811bc8e00a64000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc11a37f52e9b8520002c5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc11a37f52e9b8520002c5_320.jpg","thumbnail_picsize":"600,436","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cc15811bc8e00a64000014&m=1473060505","list_dtime":"2016-09-05 08:54:30"},{"pk":"57ccc5859490cb147e00003b","title":"9月5日科技要闻：苹果不再支持iPhone 4","title_line_break":"9月5日科技要闻：\n苹果不再支持iPhone 4","date":"2016-09-05 09:08:55","auther_name":"爱范儿","weburl":"http://iphone.myzaker.com/l.php?l=57ccc5859490cb147e00003b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb7621bc8e07748000025_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb7621bc8e07748000025_320.jpg","thumbnail_picsize":"1830,1238","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccc5859490cb147e00003b&m=1473060505","list_dtime":"2016-09-05 09:08:55"},{"pk":"57cc27411bc8e0c071000003","title":"小米公关该找雷军谈谈了","date":"2016-09-05 07:47:50","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cc27411bc8e0c071000003","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc23187f52e94006000116_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc23187f52e94006000116_320.jpg","thumbnail_picsize":"600,476","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57cc27411bc8e0c071000003&m=1473060505","list_dtime":"2016-09-05 07:47:50"},{"pk":"57ccb9951bc8e0004900004b","title":"真正的远程无线充电技术 极限范围5m","title_line_break":"真正的远程无线充电技术\n极限范围5m","date":"2016-09-05 08:25:58","auther_name":"腾讯数码","weburl":"http://iphone.myzaker.com/l.php?l=57ccb9951bc8e0004900004b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb9941bc8e00049000048_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb9941bc8e00049000048_320.jpg","thumbnail_picsize":"640,427","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccb9951bc8e0004900004b&m=1473060505","list_dtime":"2016-09-05 08:25:58"},{"pk":"57ccacdd1bc8e0d83f000004","title":"iPhone7值得期待：一直被借鉴，还未被超越","title_line_break":"iPhone7值得期待：\n一直被借鉴，还未被超越","date":"2016-09-05 07:27:12","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccacdd1bc8e0d83f000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca89a7f52e9fe26000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca89a7f52e9fe26000003_320.jpg","thumbnail_picsize":"600,374","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccacdd1bc8e0d83f000004&m=1473060505","list_dtime":"2016-09-05 07:27:12"},{"pk":"57ccacdb1bc8e0d83f000001","title":"核多不一定管用：820与X25对比实测","title_line_break":"核多不一定管用：\n820与X25对比实测","date":"2016-09-05 07:32:37","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ccacdb1bc8e0d83f000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccacdd7f52e9fe26000069_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccacdd7f52e9fe26000069_320.jpg","thumbnail_picsize":"600,404","media_count":"15","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ccacdb1bc8e0d83f000001&m=1473060505","list_dtime":"2016-09-05 07:32:37"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","is_ad":"Y","focus_photo_size":{"width":"1242","height":"700"},"tpl_style":"2","articles":"57c92ac19490cbd71700005d,57c9234f9490cbee17000042,57cbacb11bc8e07a3f000034,57ccf4d19490cb9813000012,57cd1b029490cb4d7e000038,57c7f5749490cb7a2c000058","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cca8a19490cbc303000004,57ccd8039490cb227e000024,57cd040b9490cb155f00000e,57ccf4d19490cb9813000011,57cd040b9490cb155f00000b,57cbfcdc1bc8e07751000022","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cc386c1bc8e0cd7f000002,57cd13469490cb613100000b,57cd00501bc8e02f0c000032,57cd14071bc8e08e06000016,57cd14081bc8e08e0600001b,57ccf65a9490cb4c7e000031","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccf2401bc8e0b369000012,57cd1b029490cb4d7e00003b,57ccb7dd9490cb9151000008,57cceab59490cb057e000034,57cce1571bc8e01461000002,57cce5929490cbd84400000f","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccd8ca1bc8e07f5a00000f,57ccd8ca1bc8e07f5a00000e,57cce5929490cbd844000012,57ccd65a9490cb6d7100000c,57ccb9931bc8e00049000046,57ccb9981bc8e0004900005d","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccc5859490cb147e00003b,57cc15811bc8e00a64000014,57cc27411bc8e0c071000003,57ccb9951bc8e0004900004b,57ccacdd1bc8e0d83f000004,57ccacdb1bc8e0d83f000001","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}}],"article_block_colors":["#4fa7ab","#4fa7ab"],"only_text_page_bgcolors":["#4fa7ab","#4fa7ab"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/13.png?1413770585","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/13.png?1413770585","hidden_time":"24","need_userinfo":"NO","block_title":"科技频道","block_color":"#4fa7ab","desktop_color_number":"5","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_0b2dc7e97cc3795280b652a7a278839d","selected_index":"0","list":[{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=13&since_date=1472925254&nt=1&next_aticle_id=57ccacdb1bc8e0d83f000002&_appid=androidphone&opage=2&otimestamp=188
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=13&need_app_integration=0
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=13&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,5472a9b69490cb48180000f9,51a7103481853d8f4c000143&k=201609051530
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/13.png?1413770585
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/13.png?1413770585
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 科技频道
         * block_color : #4fa7ab
         * desktop_color_number : 5
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_0b2dc7e97cc3795280b652a7a278839d
         * selected_index : 0
         * list : [{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57c7f5749490cb7a2c000058
         * title : 遗憾！酷开829粉丝节电视总销量险超618
         * date : 2016-09-05 10:00:00
         * auther_name : 科技频道
         * page : 1
         * index : 6
         * weburl : http://iphone.myzaker.com/l.php?l=57c7f5749490cb7a2c000058
         * thumbnail_title : 遗憾！酷开829粉丝节电视总销量险超618
         * media_count : 1
         * hide_mask : Y
         * is_full : NO
         * content :
         * special_type : tag
         * special_info : {"icon_url":"http://zkres.myzaker.com/data/image/mark2/ad_2x.png?v=2015061216","tag_position":"1","show_jingcai":"Y","list_nodsp":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo_nocache.php?app_id=13&pk=57c7f5749490cb7a2c000058&ad=1
         * ga_info : {"category":"AD","action":"Article"}
         * is_ad : Y
         * list_dtime : 2016-09-05 10:00:00
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * is_ad : Y
             * focus_photo_size : {"width":"1242","height":"700"}
             * tpl_style : 2
             * articles : 57c92ac19490cbd71700005d,57c9234f9490cbee17000042,57cbacb11bc8e07a3f000034,57ccf4d19490cb9813000012,57cd1b029490cb4d7e000038,57c7f5749490cb7a2c000058
             * diy : {"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String is_ad;
                /**
                 * width : 1242
                 * height : 700
                 */

                private FocusPhotoSizeBean focus_photo_size;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * is_ad : Y
                 * stat_read_url : http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read
                 * ga_info : {"category":"AD","action":"Banner","send_after_showed":"Y"}
                 * open_type : web
                 * need_user_info : N
                 * open_confirm :
                 * ads_id : 5775c9899490cbef0300003b
                 * ads_title : 华为科技冠名160701-aPhone
                 * ad_pk : 5775c9899490cbef0300003b
                 * web_url : http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getIs_ad() {
                    return is_ad;
                }

                public void setIs_ad(String is_ad) {
                    this.is_ad = is_ad;
                }

                public FocusPhotoSizeBean getFocus_photo_size() {
                    return focus_photo_size;
                }

                public void setFocus_photo_size(FocusPhotoSizeBean focus_photo_size) {
                    this.focus_photo_size = focus_photo_size;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class FocusPhotoSizeBean {
                    private String width;
                    private String height;

                    public String getWidth() {
                        return width;
                    }

                    public void setWidth(String width) {
                        this.width = width;
                    }

                    public String getHeight() {
                        return height;
                    }

                    public void setHeight(String height) {
                        this.height = height;
                    }
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String is_ad;
                    private String stat_read_url;
                    /**
                     * category : AD
                     * action : Banner
                     * send_after_showed : Y
                     */

                    private GaInfoBean ga_info;
                    private String open_type;
                    private String need_user_info;
                    private String open_confirm;
                    private String ads_id;
                    private String ads_title;
                    private String ad_pk;
                    private String web_url;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getIs_ad() {
                        return is_ad;
                    }

                    public void setIs_ad(String is_ad) {
                        this.is_ad = is_ad;
                    }

                    public String getStat_read_url() {
                        return stat_read_url;
                    }

                    public void setStat_read_url(String stat_read_url) {
                        this.stat_read_url = stat_read_url;
                    }

                    public GaInfoBean getGa_info() {
                        return ga_info;
                    }

                    public void setGa_info(GaInfoBean ga_info) {
                        this.ga_info = ga_info;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }

                    public String getNeed_user_info() {
                        return need_user_info;
                    }

                    public void setNeed_user_info(String need_user_info) {
                        this.need_user_info = need_user_info;
                    }

                    public String getOpen_confirm() {
                        return open_confirm;
                    }

                    public void setOpen_confirm(String open_confirm) {
                        this.open_confirm = open_confirm;
                    }

                    public String getAds_id() {
                        return ads_id;
                    }

                    public void setAds_id(String ads_id) {
                        this.ads_id = ads_id;
                    }

                    public String getAds_title() {
                        return ads_title;
                    }

                    public void setAds_title(String ads_title) {
                        this.ads_title = ads_title;
                    }

                    public String getAd_pk() {
                        return ad_pk;
                    }

                    public void setAd_pk(String ad_pk) {
                        this.ad_pk = ad_pk;
                    }

                    public String getWeb_url() {
                        return web_url;
                    }

                    public void setWeb_url(String web_url) {
                        this.web_url = web_url;
                    }

                    public static class GaInfoBean {
                        private String category;
                        private String action;
                        private String send_after_showed;

                        public String getCategory() {
                            return category;
                        }

                        public void setCategory(String category) {
                            this.category = category;
                        }

                        public String getAction() {
                            return action;
                        }

                        public void setAction(String action) {
                            this.action = action;
                        }

                        public String getSend_after_showed() {
                            return send_after_showed;
                        }

                        public void setSend_after_showed(String send_after_showed) {
                            this.send_after_showed = send_after_showed;
                        }
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_13
             * title : 综合
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 13
                 * title : 科技频道
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13
                 * data_type : news
                 * skey : eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;
                    private String skey;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }

                    public String getSkey() {
                        return skey;
                    }

                    public void setSkey(String skey) {
                        this.skey = skey;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String thumbnail_title;
            private String media_count;
            private String hide_mask;
            private String is_full;
            private String content;
            private String special_type,thumbnail_pic;

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            /**
             * icon_url : http://zkres.myzaker.com/data/image/mark2/ad_2x.png?v=2015061216
             * tag_position : 1
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            /**
             * category : AD
             * action : Article
             */

            private GaInfoBean ga_info;
            private String is_ad;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_title() {
                return thumbnail_title;
            }

            public void setThumbnail_title(String thumbnail_title) {
                this.thumbnail_title = thumbnail_title;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getHide_mask() {
                return hide_mask;
            }

            public void setHide_mask(String hide_mask) {
                this.hide_mask = hide_mask;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getSpecial_type() {
                return special_type;
            }

            public void setSpecial_type(String special_type) {
                this.special_type = special_type;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public GaInfoBean getGa_info() {
                return ga_info;
            }

            public void setGa_info(GaInfoBean ga_info) {
                this.ga_info = ga_info;
            }

            public String getIs_ad() {
                return is_ad;
            }

            public void setIs_ad(String is_ad) {
                this.is_ad = is_ad;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String icon_url;
                private String tag_position;
                private String show_jingcai;
                private String list_nodsp;

                public String getIcon_url() {
                    return icon_url;
                }

                public void setIcon_url(String icon_url) {
                    this.icon_url = icon_url;
                }

                public String getTag_position() {
                    return tag_position;
                }

                public void setTag_position(String tag_position) {
                    this.tag_position = tag_position;
                }

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }
            }

            public static class GaInfoBean {
                private String category;
                private String action;

                public String getCategory() {
                    return category;
                }

                public void setCategory(String category) {
                    this.category = category;
                }

                public String getAction() {
                    return action;
                }

                public void setAction(String action) {
                    this.action = action;
                }
            }
        }
    }
}
