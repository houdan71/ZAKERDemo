package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class Bean_intent {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=5&since_date=1472863890&nt=1&next_aticle_id=57ccb98f9490cb057e000010&_appid=androidphone&opage=2&otimestamp=192&catalog_appid=13","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=5&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=5&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,51a7103481853d8f4c000143&k=201609051550"},"catalog":"","articles":[{"pk":"57c935dd9490cb201800004a","title":"亚马逊Kindle Oasis电子书阅读器","title_line_break":"亚马逊Kindle\nOasis电子书阅读器","date":"2016-09-05 10:00:00","auther_name":"互联网新闻","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c935dd9490cb201800004a","thumbnail_pic":"http://zkres3.myzaker.com/data/attachment/editor/2016/09/02/14728043986800.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/data/attachment/editor/2016/09/02/14728043986800.jpg","thumbnail_min_pic":"http://zkres.myzaker.com/201609/aHR0cDovL3prcmVzMy5teXpha2VyLmNvbS9kYXRhL2F0dGFjaG1lbnQvZWRpdG9yLzIwMTYvMDkvMDIvMTQ3MjgwNDM5ODY4MDAuanBn_640.jpg","thumbnail_picsize":"1242,700","thumbnail_title":"","media_count":"1","hide_mask":"Y","is_full":"NO","content":"","type":"web2","special_info":{"open_type":"web","need_user_info":"N","web_show_arg":{"toolbar_position":"top"},"web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c935dd9490cb201800004a&title=%E4%BA%9A%E9%A9%AC%E9%80%8AKindle+Oasis%E7%94%B5%E5%AD%90%E4%B9%A6%E9%98%85%E8%AF%BB%E5%99%A8&open_type=web&_appid=androidphone&need_userinfo=N&url=http%3A%2F%2Fe.cn.miaozhen.com%2Fr%2Fk%3D2027607%26p%3D71wmN%26dx%3D__IPDX__%26rt%3D2%26ns%3D__IP__%26ni%3D__IESID__%26v%3D__LOC__%26xa%3D__ADPLATFORM__%26ro%3Dsm%26vo%3D317c682b%26vr%3D2%26o%3Dhttp%253A%252F%252Fkindle.wx.eub-inc.com%252Fasp%252Fapp150901%252F%253Fs3%253D14","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=5&app_ids=5&pk=57c935dd9490cb201800004a&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c935dd9490cb201800004a","stat_read_url":"http://api.myzaker.com/zaker/ads_stat.php?pk=5&app_id=5&_appid=androidphone&ads_id=57c935dd9490cb201800004a&action=read","icon_url":"http://zkres.myzaker.com/data/image/mark/ad_2x.png","tag_position":"2","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo_nocache.php?app_id=5&pk=57c935dd9490cb201800004a&ad=1","ga_info":{"category":"AD","action":"Article"},"is_ad":"Y","list_dtime":"2016-09-05 10:00:00"},{"pk":"57ccb4349490cb517e000006","title":"创业者的10大谎言与吹牛皮","date":"2016-09-05 07:54:28","auther_name":"凤凰科技","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ccb4349490cb517e000006","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NiOTgwYzdmNTJlOTU4NDIwMDAxYTBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NiOTgwYzdmNTJlOTU4NDIwMDAxYTBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"580,330","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb4349490cb517e000006&m=1473062103","list_dtime":"2016-09-05 07:54:28"},{"pk":"57cc907b1bc8e02430000051","title":"\u201c滴优配\u201d足月：平民专车渐远","title_line_break":"\u201c滴优配\u201d足月：\n平民专车渐远","date":"2016-09-05 07:39:56","auther_name":"新浪科技","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57cc907b1bc8e02430000051","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYmIyY2EwN2FlY2M1MjMwMWNhMzJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYmIyY2EwN2FlY2M1MjMwMWNhMzJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"389,252","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cc907b1bc8e02430000051&m=1473062103","list_dtime":"2016-09-05 07:39:56"},{"pk":"57ccb2db1bc8e0a342000076","title":"新美大股权甩卖 阿里所持股份去留成谜","title_line_break":"新美大股权甩卖\n阿里所持股份去留成谜","date":"2016-09-05 07:45:44","auther_name":"腾讯科技","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ccb2db1bc8e0a342000076","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb2db7f52e9fe260000b8_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb2db7f52e9fe260000b8_320.jpg","thumbnail_picsize":"640,378","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb2db1bc8e0a342000076&m=1473062103","list_dtime":"2016-09-05 07:45:44"},{"pk":"57cd14119490cbf87d00003c","title":"马云\u201c复仇\u201d买下肯德基：这个鸡汤不好喝","title_line_break":"马云\u201c复仇\u201d买下肯德基：\n这个鸡汤不好喝","date":"2016-09-05 14:43:29","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd14119490cbf87d00003c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbe991bc8e0864c00000e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbe991bc8e0864c00000e_320.jpg","thumbnail_picsize":"600,422","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd14119490cbf87d00003c&m=1473061590","list_dtime":"2016-09-05 14:43:29"},{"pk":"57cd01511bc8e0170c000059","title":"电影还没上映先盗播，现在连盗版也做微商了","date":"2016-09-05 14:24:39","auther_name":"虎嗅网","weburl":"http://iphone.myzaker.com/l.php?l=57cd01511bc8e0170c000059","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd0146a07aecc52301f9fb_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd0146a07aecc52301f9fb_320.jpg","thumbnail_picsize":"800,450","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd01511bc8e0170c000059&m=1473061865","list_dtime":"2016-09-05 14:24:39"},{"pk":"57cd14fd9490cbe77d000039","title":"时下热捧的\u201cIP\u201d，其实是个伪概念","date":"2016-09-05 14:47:09","auther_name":"亿欧网","weburl":"http://iphone.myzaker.com/l.php?l=57cd14fd9490cbe77d000039","thumbnail_pic":"http://zkres.myzaker.com/201608/57a57b7a1bc8e00d6d000004_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57a57b7a1bc8e00d6d000004_320.jpg","thumbnail_picsize":"480,320","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd14fd9490cbe77d000039&m=1473061590","list_dtime":"2016-09-05 14:47:09"},{"pk":"57cd04089490cb155f000007","title":"iOS 9安装率达88% iOS 10是否能重复辉煌","date":"2016-09-05 14:23:38","auther_name":"天极网","weburl":"http://iphone.myzaker.com/l.php?l=57cd04089490cb155f000007","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccf4597f52e9c43b0001a3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccf4597f52e9c43b0001a3_320.jpg","thumbnail_picsize":"275,414","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd04089490cb155f000007&m=1473061865","list_dtime":"2016-09-05 14:23:38"},{"pk":"57cd09881bc8e0627d000050","title":"元老陆兆禧退休 阿里70后管理层崛起","title_line_break":"元老陆兆禧退休\n阿里70后管理层崛起","date":"2016-09-05 14:22:12","auther_name":"新浪科技","weburl":"http://iphone.myzaker.com/l.php?l=57cd09881bc8e0627d000050","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd098d7f52e9993100008a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd098d7f52e9993100008a_320.jpg","thumbnail_picsize":"550,322","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd09881bc8e0627d000050&m=1473061865","list_dtime":"2016-09-05 14:22:12"},{"pk":"57cd13e59490cb137e00003a","title":"网络暴民是怎样毁掉互联网以及你的生活的","date":"2016-09-05 14:42:45","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd13e59490cb137e00003a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccf2751bc8e0566a000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccf2751bc8e0566a000007_320.jpg","thumbnail_picsize":"814,1085","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd13e59490cb137e00003a&m=1473061590","list_dtime":"2016-09-05 14:42:45"},{"pk":"57ccf4cd9490cb9813000008","title":"Uber的商业模式根本就是一套谎言？","date":"2016-09-05 14:26:30","auther_name":"36氪","weburl":"http://iphone.myzaker.com/l.php?l=57ccf4cd9490cb9813000008","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=5&pk=57ccf4cd9490cb9813000008&url=http%3A%2F%2F36kr.com%2Fcoop%2Fzaker%2F5052289.html%3Fktm_source%3Dzaker","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccf4cd9490cb9813000008&m=1473061590","list_dtime":"2016-09-05 14:26:30"},{"pk":"57ccef5a1bc8e0ee6800000f","title":"新东方在线联合京东金融推出\u201c教育白条\u201d","date":"2016-09-05 14:27:01","auther_name":"亿邦动力","weburl":"http://iphone.myzaker.com/l.php?l=57ccef5a1bc8e0ee6800000f","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccef5a1bc8e0ee6800000f&m=1473061590","list_dtime":"2016-09-05 14:27:01"},{"pk":"57cd0c021bc8e0d67a000044","title":"多米音乐获准挂牌新三板 目标未来资本市场","title_line_break":"多米音乐获准挂牌新三板\n目标未来资本市场","date":"2016-09-05 13:45:15","auther_name":"亿邦动力","weburl":"http://iphone.myzaker.com/l.php?l=57cd0c021bc8e0d67a000044","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd0c037f52e9ef31000004_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd0c037f52e9ef31000004_320.jpg","thumbnail_picsize":"500,333","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd0c021bc8e0d67a000044&m=1473061865","list_dtime":"2016-09-05 13:45:15"},{"pk":"57cd09881bc8e0627d00004f","title":"互联网进入巨头战争时代 内容成为兵家必争之地","title_line_break":"互联网进入巨头战争时代\n内容成为兵家必争之地","date":"2016-09-05 14:21:36","auther_name":"新浪科技","weburl":"http://iphone.myzaker.com/l.php?l=57cd09881bc8e0627d00004f","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd09881bc8e0627d00004f&m=1473061865","list_dtime":"2016-09-05 14:21:36"},{"pk":"57ccdf3e1bc8e0b85e0000c2","title":"王自如：要从过气网红变成青年企业家","title_line_break":"王自如：\n要从过气网红变成青年企业家","date":"2016-09-05 11:23:04","auther_name":"新浪科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccdf3e1bc8e0b85e0000c2","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccdf3e1bc8e0b85e0000c2&m=1473061865","list_dtime":"2016-09-05 11:23:04"},{"pk":"57ccda201bc8e0220c00002d","title":"郑州女主播直播吃串 引20万网友围观","title_line_break":"郑州女主播直播吃串\n引20万网友围观","date":"2016-09-05 10:48:09","auther_name":"视觉中国","weburl":"http://iphone.myzaker.com/l.php?l=57ccda201bc8e0220c00002d","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd62ca07aecc52301d89c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd62ca07aecc52301d89c_320.jpg","thumbnail_picsize":"1200,799","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccda201bc8e0220c00002d&m=1473061865","list_dtime":"2016-09-05 10:48:09"},{"pk":"57ccce1c1bc8e03a53000002","title":"关店潮、频裁员，生鲜O2O盈利难举步维艰","date":"2016-09-05 11:25:34","auther_name":"新浪科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccce1c1bc8e03a53000002","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccce1c1bc8e03a53000002&m=1473061865","list_dtime":"2016-09-05 11:25:34"},{"pk":"57ccde941bc8e0e65d00005b","title":"比价格？苏宁易购：商超之战比的是商业模式","title_line_break":"比价格？苏宁易购：\n商超之战比的是商业模式","date":"2016-09-05 11:23:50","auther_name":"亿邦动力","weburl":"http://iphone.myzaker.com/l.php?l=57ccde941bc8e0e65d00005b","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccde941bc8e0e65d00005b&m=1473061865","list_dtime":"2016-09-05 11:23:50"},{"pk":"57cce13c1bc8e02360000000","title":"互联网广告新规正式实施：中小广告主视若无睹","title_line_break":"互联网广告新规正式实施：\n中小广告主视若无睹","date":"2016-09-05 11:22:22","auther_name":"亿邦动力","weburl":"http://iphone.myzaker.com/l.php?l=57cce13c1bc8e02360000000","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cce13c1bc8e02360000000&m=1473061865","list_dtime":"2016-09-05 11:22:22"},{"pk":"57ccd7a01bc8e0445b000000","title":"淘宝9月7日起将禁售上网资费卡等相关业务","date":"2016-09-05 10:36:58","auther_name":"腾讯科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccd7a01bc8e0445b000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd7a17f52e93c7f0000ab_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd7a17f52e93c7f0000ab_320.jpg","thumbnail_picsize":"400,281","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccd7a01bc8e0445b000000&m=1473061865","list_dtime":"2016-09-05 10:36:58"},{"pk":"57ccd6579490cb6d71000006","title":"App Store全新订阅服务启动 开发者收入增加","date":"2016-09-05 10:51:12","auther_name":"天极网","weburl":"http://iphone.myzaker.com/l.php?l=57ccd6579490cb6d71000006","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd2027f52e988640000ca_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd2027f52e988640000ca_320.jpg","thumbnail_picsize":"600,398","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccd6579490cb6d71000006&m=1473061865","list_dtime":"2016-09-05 10:51:12"},{"pk":"57ccdbcd1bc8e0195c00003d","title":"借壳上市前 顺丰先成立财务公司","title_line_break":"借壳上市前\n顺丰先成立财务公司","date":"2016-09-05 10:48:54","auther_name":"亿邦动力","weburl":"http://iphone.myzaker.com/l.php?l=57ccdbcd1bc8e0195c00003d","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccdbcd1bc8e0195c00003d&m=1473061865","list_dtime":"2016-09-05 10:48:54"},{"pk":"57ccc72b1bc8e0230c000017","title":"朋友圈里的这些谣言真的别再信了","date":"2016-09-05 09:21:21","auther_name":"央视新闻","weburl":"http://iphone.myzaker.com/l.php?l=57ccc72b1bc8e0230c000017","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc719a07aecc52301d0b8_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc719a07aecc52301d0b8_320.jpg","thumbnail_picsize":"348,220","media_count":"13","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccc72b1bc8e0230c000017&m=1473061865","list_dtime":"2016-09-05 09:21:21"},{"pk":"57cc4d369490cb182b000001","title":"腾讯网易后，游戏分发又一巨头将是万达？","date":"2016-09-05 07:46:25","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cc4d369490cb182b000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc386d7f52e91778000241_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc386d7f52e91778000241_320.jpg","thumbnail_picsize":"600,341","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cc4d369490cb182b000001&m=1473061865","list_dtime":"2016-09-05 07:46:25"},{"pk":"57ccc71a9490cba92000000c","title":"为什么创业公司容易在B轮死？","date":"2016-09-05 09:22:04","auther_name":"猎云网","weburl":"http://iphone.myzaker.com/l.php?l=57ccc71a9490cba92000000c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc58e1bc8e09851000012_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc58e1bc8e09851000012_320.jpg","thumbnail_picsize":"1024,614","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccc71a9490cba92000000c&m=1473061865","list_dtime":"2016-09-05 09:22:04"},{"pk":"57ccb41f9490cb2c7e00001b","title":"全球最具影响力的6位CEO 中国也有一位上榜","title_line_break":"全球最具影响力的6位CEO\n中国也有一位上榜","date":"2016-09-05 07:54:07","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccb41f9490cb2c7e00001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd998a07aecc52301db51_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd998a07aecc52301db51_320.jpg","thumbnail_picsize":"499,341","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb41f9490cb2c7e00001b&m=1473061865","list_dtime":"2016-09-05 07:54:07"},{"pk":"57ccb9cf9490cb2b7e00000f","title":"美团点评和百度糯米或难逃合并宿命","date":"2016-09-05 08:17:53","auther_name":"新浪科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccb9cf9490cb2b7e00000f","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb9cf9490cb2b7e00000f&m=1473061865","list_dtime":"2016-09-05 08:17:53"},{"pk":"57ccb1271bc8e02840000086","title":"马云买下KFC？夸张，投资额仅为5000万美元","date":"2016-09-05 07:49:46","auther_name":"腾讯科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccb1271bc8e02840000086","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb1287f52e9fe260000a2_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb1287f52e9fe260000a2_320.jpg","thumbnail_picsize":"624,439","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb1271bc8e02840000086&m=1473061865","list_dtime":"2016-09-05 07:49:46"},{"pk":"57ccb41f9490cb2c7e00001d","title":"高中生直播开学，直播边界在哪里？","date":"2016-09-05 07:54:07","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccb41f9490cb2c7e00001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca5d4a07aece76f000034_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca5d4a07aece76f000034_320.jpg","thumbnail_picsize":"450,299","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb41f9490cb2c7e00001d&m=1473061865","list_dtime":"2016-09-05 07:54:07"},{"pk":"57ccb41f9490cb2c7e00001c","title":"爱鲜蜂COO离职 人事动荡不止","title_line_break":"爱鲜蜂COO离职\n人事动荡不止","date":"2016-09-05 07:54:07","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccb41f9490cb2c7e00001c","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca5d5a07aecec6f000066_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca5d5a07aecec6f000066_320.jpg","thumbnail_picsize":"366,484","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb41f9490cb2c7e00001c&m=1473061865","list_dtime":"2016-09-05 07:54:07"},{"pk":"57cca4ed1bc8e05b3a00004b","title":"乐视如何\u201c捆绑\u201d员工、高管和股价？","date":"2016-09-05 07:32:59","auther_name":"腾讯科技","weburl":"http://iphone.myzaker.com/l.php?l=57cca4ed1bc8e05b3a00004b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca4ef7f52e97603000004_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca4ef7f52e97603000004_320.jpg","thumbnail_picsize":"640,427","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cca4ed1bc8e05b3a00004b&m=1473061865","list_dtime":"2016-09-05 07:32:59"},{"pk":"57cc6baf9490cbe245000000","title":"Oculus神秘办公室长啥样？标配裸露管道","date":"2016-09-05 07:42:28","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cc6baf9490cbe245000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc0d267f52e91778000009_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc0d267f52e91778000009_320.jpg","thumbnail_picsize":"600,398","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cc6baf9490cbe245000000&m=1473061865","list_dtime":"2016-09-05 07:42:28"},{"pk":"57cc76571bc8e07924000028","title":"滴滴打出租 司机一路抢红包","title_line_break":"滴滴打出租\n司机一路抢红包","date":"2016-09-05 07:45:45","auther_name":"新浪科技","weburl":"http://iphone.myzaker.com/l.php?l=57cc76571bc8e07924000028","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cc76571bc8e07924000028&m=1473061865","list_dtime":"2016-09-05 07:45:45"},{"pk":"57ccb7db9490cb9151000006","title":"年轻的科技圈布道者：野心还是使命？","title_line_break":"年轻的科技圈布道者：\n野心还是使命？","date":"2016-09-05 08:16:25","auther_name":"PingWest品玩","weburl":"http://iphone.myzaker.com/l.php?l=57ccb7db9490cb9151000006","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca8f01bc8e0e73b00004f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca8f01bc8e0e73b00004f_320.jpg","thumbnail_picsize":"625,411","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb7db9490cb9151000006&m=1473061865","list_dtime":"2016-09-05 08:16:25"},{"pk":"57cc7aeb9490cb1409000001","title":"Win10商店大清理：多款应用将被下架","title_line_break":"Win10商店大清理：\n多款应用将被下架","date":"2016-09-05 07:43:00","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cc7aeb9490cb1409000001","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cc7aeb9490cb1409000001&m=1473061865","list_dtime":"2016-09-05 07:43:00"},{"pk":"57ccb41f9490cb2c7e00001e","title":"懒癌有救 苹果Siri或支持第三方App付款","title_line_break":"懒癌有救\n苹果Siri或支持第三方App付款","date":"2016-09-05 07:54:07","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccb41f9490cb2c7e00001e","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb41f9490cb2c7e00001e&m=1473061865","list_dtime":"2016-09-05 07:54:07"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","is_ad":"Y","focus_photo_size":{"width":"1242","height":"700"},"tpl_style":"2","articles":"57c935dd9490cb201800004a,57ccb2db1bc8e0a342000076,57cd14119490cbf87d00003c,57cd01511bc8e0170c000059,57cd14fd9490cbe77d000039,57cd04089490cb155f000007","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cc907b1bc8e02430000051,57cd09881bc8e0627d000050,57cd13e59490cb137e00003a,57ccf4cd9490cb9813000008,57ccef5a1bc8e0ee6800000f,57cd0c021bc8e0d67a000044","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57ccb4349490cb517e000006,57cd09881bc8e0627d00004f,57ccdf3e1bc8e0b85e0000c2,57ccda201bc8e0220c00002d,57ccce1c1bc8e03a53000002,57ccde941bc8e0e65d00005b","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57ccd7a01bc8e0445b000000,57cce13c1bc8e02360000000,57ccd6579490cb6d71000006,57ccdbcd1bc8e0195c00003d,57ccc72b1bc8e0230c000017,57cc4d369490cb182b000001","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ccb41f9490cb2c7e00001b,57ccc71a9490cba92000000c,57ccb9cf9490cb2b7e00000f,57ccb1271bc8e02840000086,57ccb41f9490cb2c7e00001d,57ccb41f9490cb2c7e00001c","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cc6baf9490cbe245000000,57cca4ed1bc8e05b3a00004b,57cc76571bc8e07924000028,57ccb7db9490cb9151000006,57cc7aeb9490cb1409000001,57ccb41f9490cb2c7e00001e","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}}],"article_block_colors":["#757d8b","#757d8b"],"only_text_page_bgcolors":["#757d8b","#757d8b"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/5.png?t=1458290404","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/5.png?t=1458290404","hidden_time":"24","need_userinfo":"NO","block_title":"互联网新闻","block_color":"#757d8b","desktop_color_number":"5","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_2eb767f28def417abde411ca51cfe0ce","selected_index":"2","list":[{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]}}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=5&since_date=1472863890&nt=1&next_aticle_id=57ccb98f9490cb057e000010&_appid=androidphone&opage=2&otimestamp=192&catalog_appid=13","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=5&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=5&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,51a7103481853d8f4c000143&k=201609051550"}
     * catalog :
     * articles : [{"pk":"57c935dd9490cb201800004a","title":"亚马逊Kindle Oasis电子书阅读器","title_line_break":"亚马逊Kindle\nOasis电子书阅读器","date":"2016-09-05 10:00:00","auther_name":"互联网新闻","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c935dd9490cb201800004a","thumbnail_pic":"http://zkres3.myzaker.com/data/attachment/editor/2016/09/02/14728043986800.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/data/attachment/editor/2016/09/02/14728043986800.jpg","thumbnail_min_pic":"http://zkres.myzaker.com/201609/aHR0cDovL3prcmVzMy5teXpha2VyLmNvbS9kYXRhL2F0dGFjaG1lbnQvZWRpdG9yLzIwMTYvMDkvMDIvMTQ3MjgwNDM5ODY4MDAuanBn_640.jpg","thumbnail_picsize":"1242,700","thumbnail_title":"","media_count":"1","hide_mask":"Y","is_full":"NO","content":"","type":"web2","special_info":{"open_type":"web","need_user_info":"N","web_show_arg":{"toolbar_position":"top"},"web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c935dd9490cb201800004a&title=%E4%BA%9A%E9%A9%AC%E9%80%8AKindle+Oasis%E7%94%B5%E5%AD%90%E4%B9%A6%E9%98%85%E8%AF%BB%E5%99%A8&open_type=web&_appid=androidphone&need_userinfo=N&url=http%3A%2F%2Fe.cn.miaozhen.com%2Fr%2Fk%3D2027607%26p%3D71wmN%26dx%3D__IPDX__%26rt%3D2%26ns%3D__IP__%26ni%3D__IESID__%26v%3D__LOC__%26xa%3D__ADPLATFORM__%26ro%3Dsm%26vo%3D317c682b%26vr%3D2%26o%3Dhttp%253A%252F%252Fkindle.wx.eub-inc.com%252Fasp%252Fapp150901%252F%253Fs3%253D14","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=5&app_ids=5&pk=57c935dd9490cb201800004a&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c935dd9490cb201800004a","stat_read_url":"http://api.myzaker.com/zaker/ads_stat.php?pk=5&app_id=5&_appid=androidphone&ads_id=57c935dd9490cb201800004a&action=read","icon_url":"http://zkres.myzaker.com/data/image/mark/ad_2x.png","tag_position":"2","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo_nocache.php?app_id=5&pk=57c935dd9490cb201800004a&ad=1","ga_info":{"category":"AD","action":"Article"},"is_ad":"Y","list_dtime":"2016-09-05 10:00:00"},{"pk":"57ccb4349490cb517e000006","title":"创业者的10大谎言与吹牛皮","date":"2016-09-05 07:54:28","auther_name":"凤凰科技","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ccb4349490cb517e000006","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NiOTgwYzdmNTJlOTU4NDIwMDAxYTBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NiOTgwYzdmNTJlOTU4NDIwMDAxYTBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"580,330","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb4349490cb517e000006&m=1473062103","list_dtime":"2016-09-05 07:54:28"},{"pk":"57cc907b1bc8e02430000051","title":"\u201c滴优配\u201d足月：平民专车渐远","title_line_break":"\u201c滴优配\u201d足月：\n平民专车渐远","date":"2016-09-05 07:39:56","auther_name":"新浪科技","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57cc907b1bc8e02430000051","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYmIyY2EwN2FlY2M1MjMwMWNhMzJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjYmIyY2EwN2FlY2M1MjMwMWNhMzJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"389,252","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cc907b1bc8e02430000051&m=1473062103","list_dtime":"2016-09-05 07:39:56"},{"pk":"57ccb2db1bc8e0a342000076","title":"新美大股权甩卖 阿里所持股份去留成谜","title_line_break":"新美大股权甩卖\n阿里所持股份去留成谜","date":"2016-09-05 07:45:44","auther_name":"腾讯科技","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ccb2db1bc8e0a342000076","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb2db7f52e9fe260000b8_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb2db7f52e9fe260000b8_320.jpg","thumbnail_picsize":"640,378","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb2db1bc8e0a342000076&m=1473062103","list_dtime":"2016-09-05 07:45:44"},{"pk":"57cd14119490cbf87d00003c","title":"马云\u201c复仇\u201d买下肯德基：这个鸡汤不好喝","title_line_break":"马云\u201c复仇\u201d买下肯德基：\n这个鸡汤不好喝","date":"2016-09-05 14:43:29","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd14119490cbf87d00003c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbe991bc8e0864c00000e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbe991bc8e0864c00000e_320.jpg","thumbnail_picsize":"600,422","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd14119490cbf87d00003c&m=1473061590","list_dtime":"2016-09-05 14:43:29"},{"pk":"57cd01511bc8e0170c000059","title":"电影还没上映先盗播，现在连盗版也做微商了","date":"2016-09-05 14:24:39","auther_name":"虎嗅网","weburl":"http://iphone.myzaker.com/l.php?l=57cd01511bc8e0170c000059","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd0146a07aecc52301f9fb_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd0146a07aecc52301f9fb_320.jpg","thumbnail_picsize":"800,450","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd01511bc8e0170c000059&m=1473061865","list_dtime":"2016-09-05 14:24:39"},{"pk":"57cd14fd9490cbe77d000039","title":"时下热捧的\u201cIP\u201d，其实是个伪概念","date":"2016-09-05 14:47:09","auther_name":"亿欧网","weburl":"http://iphone.myzaker.com/l.php?l=57cd14fd9490cbe77d000039","thumbnail_pic":"http://zkres.myzaker.com/201608/57a57b7a1bc8e00d6d000004_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57a57b7a1bc8e00d6d000004_320.jpg","thumbnail_picsize":"480,320","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd14fd9490cbe77d000039&m=1473061590","list_dtime":"2016-09-05 14:47:09"},{"pk":"57cd04089490cb155f000007","title":"iOS 9安装率达88% iOS 10是否能重复辉煌","date":"2016-09-05 14:23:38","auther_name":"天极网","weburl":"http://iphone.myzaker.com/l.php?l=57cd04089490cb155f000007","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccf4597f52e9c43b0001a3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccf4597f52e9c43b0001a3_320.jpg","thumbnail_picsize":"275,414","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd04089490cb155f000007&m=1473061865","list_dtime":"2016-09-05 14:23:38"},{"pk":"57cd09881bc8e0627d000050","title":"元老陆兆禧退休 阿里70后管理层崛起","title_line_break":"元老陆兆禧退休\n阿里70后管理层崛起","date":"2016-09-05 14:22:12","auther_name":"新浪科技","weburl":"http://iphone.myzaker.com/l.php?l=57cd09881bc8e0627d000050","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd098d7f52e9993100008a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd098d7f52e9993100008a_320.jpg","thumbnail_picsize":"550,322","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd09881bc8e0627d000050&m=1473061865","list_dtime":"2016-09-05 14:22:12"},{"pk":"57cd13e59490cb137e00003a","title":"网络暴民是怎样毁掉互联网以及你的生活的","date":"2016-09-05 14:42:45","auther_name":"驱动之家","weburl":"http://iphone.myzaker.com/l.php?l=57cd13e59490cb137e00003a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccf2751bc8e0566a000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccf2751bc8e0566a000007_320.jpg","thumbnail_picsize":"814,1085","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd13e59490cb137e00003a&m=1473061590","list_dtime":"2016-09-05 14:42:45"},{"pk":"57ccf4cd9490cb9813000008","title":"Uber的商业模式根本就是一套谎言？","date":"2016-09-05 14:26:30","auther_name":"36氪","weburl":"http://iphone.myzaker.com/l.php?l=57ccf4cd9490cb9813000008","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=5&pk=57ccf4cd9490cb9813000008&url=http%3A%2F%2F36kr.com%2Fcoop%2Fzaker%2F5052289.html%3Fktm_source%3Dzaker","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccf4cd9490cb9813000008&m=1473061590","list_dtime":"2016-09-05 14:26:30"},{"pk":"57ccef5a1bc8e0ee6800000f","title":"新东方在线联合京东金融推出\u201c教育白条\u201d","date":"2016-09-05 14:27:01","auther_name":"亿邦动力","weburl":"http://iphone.myzaker.com/l.php?l=57ccef5a1bc8e0ee6800000f","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccef5a1bc8e0ee6800000f&m=1473061590","list_dtime":"2016-09-05 14:27:01"},{"pk":"57cd0c021bc8e0d67a000044","title":"多米音乐获准挂牌新三板 目标未来资本市场","title_line_break":"多米音乐获准挂牌新三板\n目标未来资本市场","date":"2016-09-05 13:45:15","auther_name":"亿邦动力","weburl":"http://iphone.myzaker.com/l.php?l=57cd0c021bc8e0d67a000044","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd0c037f52e9ef31000004_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd0c037f52e9ef31000004_320.jpg","thumbnail_picsize":"500,333","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd0c021bc8e0d67a000044&m=1473061865","list_dtime":"2016-09-05 13:45:15"},{"pk":"57cd09881bc8e0627d00004f","title":"互联网进入巨头战争时代 内容成为兵家必争之地","title_line_break":"互联网进入巨头战争时代\n内容成为兵家必争之地","date":"2016-09-05 14:21:36","auther_name":"新浪科技","weburl":"http://iphone.myzaker.com/l.php?l=57cd09881bc8e0627d00004f","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cd09881bc8e0627d00004f&m=1473061865","list_dtime":"2016-09-05 14:21:36"},{"pk":"57ccdf3e1bc8e0b85e0000c2","title":"王自如：要从过气网红变成青年企业家","title_line_break":"王自如：\n要从过气网红变成青年企业家","date":"2016-09-05 11:23:04","auther_name":"新浪科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccdf3e1bc8e0b85e0000c2","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccdf3e1bc8e0b85e0000c2&m=1473061865","list_dtime":"2016-09-05 11:23:04"},{"pk":"57ccda201bc8e0220c00002d","title":"郑州女主播直播吃串 引20万网友围观","title_line_break":"郑州女主播直播吃串\n引20万网友围观","date":"2016-09-05 10:48:09","auther_name":"视觉中国","weburl":"http://iphone.myzaker.com/l.php?l=57ccda201bc8e0220c00002d","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd62ca07aecc52301d89c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd62ca07aecc52301d89c_320.jpg","thumbnail_picsize":"1200,799","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccda201bc8e0220c00002d&m=1473061865","list_dtime":"2016-09-05 10:48:09"},{"pk":"57ccce1c1bc8e03a53000002","title":"关店潮、频裁员，生鲜O2O盈利难举步维艰","date":"2016-09-05 11:25:34","auther_name":"新浪科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccce1c1bc8e03a53000002","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccce1c1bc8e03a53000002&m=1473061865","list_dtime":"2016-09-05 11:25:34"},{"pk":"57ccde941bc8e0e65d00005b","title":"比价格？苏宁易购：商超之战比的是商业模式","title_line_break":"比价格？苏宁易购：\n商超之战比的是商业模式","date":"2016-09-05 11:23:50","auther_name":"亿邦动力","weburl":"http://iphone.myzaker.com/l.php?l=57ccde941bc8e0e65d00005b","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccde941bc8e0e65d00005b&m=1473061865","list_dtime":"2016-09-05 11:23:50"},{"pk":"57cce13c1bc8e02360000000","title":"互联网广告新规正式实施：中小广告主视若无睹","title_line_break":"互联网广告新规正式实施：\n中小广告主视若无睹","date":"2016-09-05 11:22:22","auther_name":"亿邦动力","weburl":"http://iphone.myzaker.com/l.php?l=57cce13c1bc8e02360000000","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cce13c1bc8e02360000000&m=1473061865","list_dtime":"2016-09-05 11:22:22"},{"pk":"57ccd7a01bc8e0445b000000","title":"淘宝9月7日起将禁售上网资费卡等相关业务","date":"2016-09-05 10:36:58","auther_name":"腾讯科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccd7a01bc8e0445b000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd7a17f52e93c7f0000ab_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd7a17f52e93c7f0000ab_320.jpg","thumbnail_picsize":"400,281","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccd7a01bc8e0445b000000&m=1473061865","list_dtime":"2016-09-05 10:36:58"},{"pk":"57ccd6579490cb6d71000006","title":"App Store全新订阅服务启动 开发者收入增加","date":"2016-09-05 10:51:12","auther_name":"天极网","weburl":"http://iphone.myzaker.com/l.php?l=57ccd6579490cb6d71000006","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd2027f52e988640000ca_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd2027f52e988640000ca_320.jpg","thumbnail_picsize":"600,398","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccd6579490cb6d71000006&m=1473061865","list_dtime":"2016-09-05 10:51:12"},{"pk":"57ccdbcd1bc8e0195c00003d","title":"借壳上市前 顺丰先成立财务公司","title_line_break":"借壳上市前\n顺丰先成立财务公司","date":"2016-09-05 10:48:54","auther_name":"亿邦动力","weburl":"http://iphone.myzaker.com/l.php?l=57ccdbcd1bc8e0195c00003d","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccdbcd1bc8e0195c00003d&m=1473061865","list_dtime":"2016-09-05 10:48:54"},{"pk":"57ccc72b1bc8e0230c000017","title":"朋友圈里的这些谣言真的别再信了","date":"2016-09-05 09:21:21","auther_name":"央视新闻","weburl":"http://iphone.myzaker.com/l.php?l=57ccc72b1bc8e0230c000017","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc719a07aecc52301d0b8_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc719a07aecc52301d0b8_320.jpg","thumbnail_picsize":"348,220","media_count":"13","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccc72b1bc8e0230c000017&m=1473061865","list_dtime":"2016-09-05 09:21:21"},{"pk":"57cc4d369490cb182b000001","title":"腾讯网易后，游戏分发又一巨头将是万达？","date":"2016-09-05 07:46:25","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cc4d369490cb182b000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc386d7f52e91778000241_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc386d7f52e91778000241_320.jpg","thumbnail_picsize":"600,341","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cc4d369490cb182b000001&m=1473061865","list_dtime":"2016-09-05 07:46:25"},{"pk":"57ccc71a9490cba92000000c","title":"为什么创业公司容易在B轮死？","date":"2016-09-05 09:22:04","auther_name":"猎云网","weburl":"http://iphone.myzaker.com/l.php?l=57ccc71a9490cba92000000c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc58e1bc8e09851000012_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc58e1bc8e09851000012_320.jpg","thumbnail_picsize":"1024,614","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccc71a9490cba92000000c&m=1473061865","list_dtime":"2016-09-05 09:22:04"},{"pk":"57ccb41f9490cb2c7e00001b","title":"全球最具影响力的6位CEO 中国也有一位上榜","title_line_break":"全球最具影响力的6位CEO\n中国也有一位上榜","date":"2016-09-05 07:54:07","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccb41f9490cb2c7e00001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd998a07aecc52301db51_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd998a07aecc52301db51_320.jpg","thumbnail_picsize":"499,341","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb41f9490cb2c7e00001b&m=1473061865","list_dtime":"2016-09-05 07:54:07"},{"pk":"57ccb9cf9490cb2b7e00000f","title":"美团点评和百度糯米或难逃合并宿命","date":"2016-09-05 08:17:53","auther_name":"新浪科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccb9cf9490cb2b7e00000f","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb9cf9490cb2b7e00000f&m=1473061865","list_dtime":"2016-09-05 08:17:53"},{"pk":"57ccb1271bc8e02840000086","title":"马云买下KFC？夸张，投资额仅为5000万美元","date":"2016-09-05 07:49:46","auther_name":"腾讯科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccb1271bc8e02840000086","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb1287f52e9fe260000a2_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb1287f52e9fe260000a2_320.jpg","thumbnail_picsize":"624,439","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb1271bc8e02840000086&m=1473061865","list_dtime":"2016-09-05 07:49:46"},{"pk":"57ccb41f9490cb2c7e00001d","title":"高中生直播开学，直播边界在哪里？","date":"2016-09-05 07:54:07","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccb41f9490cb2c7e00001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca5d4a07aece76f000034_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca5d4a07aece76f000034_320.jpg","thumbnail_picsize":"450,299","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb41f9490cb2c7e00001d&m=1473061865","list_dtime":"2016-09-05 07:54:07"},{"pk":"57ccb41f9490cb2c7e00001c","title":"爱鲜蜂COO离职 人事动荡不止","title_line_break":"爱鲜蜂COO离职\n人事动荡不止","date":"2016-09-05 07:54:07","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccb41f9490cb2c7e00001c","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca5d5a07aecec6f000066_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca5d5a07aecec6f000066_320.jpg","thumbnail_picsize":"366,484","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb41f9490cb2c7e00001c&m=1473061865","list_dtime":"2016-09-05 07:54:07"},{"pk":"57cca4ed1bc8e05b3a00004b","title":"乐视如何\u201c捆绑\u201d员工、高管和股价？","date":"2016-09-05 07:32:59","auther_name":"腾讯科技","weburl":"http://iphone.myzaker.com/l.php?l=57cca4ed1bc8e05b3a00004b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca4ef7f52e97603000004_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca4ef7f52e97603000004_320.jpg","thumbnail_picsize":"640,427","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cca4ed1bc8e05b3a00004b&m=1473061865","list_dtime":"2016-09-05 07:32:59"},{"pk":"57cc6baf9490cbe245000000","title":"Oculus神秘办公室长啥样？标配裸露管道","date":"2016-09-05 07:42:28","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cc6baf9490cbe245000000","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc0d267f52e91778000009_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc0d267f52e91778000009_320.jpg","thumbnail_picsize":"600,398","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cc6baf9490cbe245000000&m=1473061865","list_dtime":"2016-09-05 07:42:28"},{"pk":"57cc76571bc8e07924000028","title":"滴滴打出租 司机一路抢红包","title_line_break":"滴滴打出租\n司机一路抢红包","date":"2016-09-05 07:45:45","auther_name":"新浪科技","weburl":"http://iphone.myzaker.com/l.php?l=57cc76571bc8e07924000028","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cc76571bc8e07924000028&m=1473061865","list_dtime":"2016-09-05 07:45:45"},{"pk":"57ccb7db9490cb9151000006","title":"年轻的科技圈布道者：野心还是使命？","title_line_break":"年轻的科技圈布道者：\n野心还是使命？","date":"2016-09-05 08:16:25","auther_name":"PingWest品玩","weburl":"http://iphone.myzaker.com/l.php?l=57ccb7db9490cb9151000006","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca8f01bc8e0e73b00004f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca8f01bc8e0e73b00004f_320.jpg","thumbnail_picsize":"625,411","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb7db9490cb9151000006&m=1473061865","list_dtime":"2016-09-05 08:16:25"},{"pk":"57cc7aeb9490cb1409000001","title":"Win10商店大清理：多款应用将被下架","title_line_break":"Win10商店大清理：\n多款应用将被下架","date":"2016-09-05 07:43:00","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57cc7aeb9490cb1409000001","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57cc7aeb9490cb1409000001&m=1473061865","list_dtime":"2016-09-05 07:43:00"},{"pk":"57ccb41f9490cb2c7e00001e","title":"懒癌有救 苹果Siri或支持第三方App付款","title_line_break":"懒癌有救\n苹果Siri或支持第三方App付款","date":"2016-09-05 07:54:07","auther_name":"凤凰科技","weburl":"http://iphone.myzaker.com/l.php?l=57ccb41f9490cb2c7e00001e","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=5&pk=57ccb41f9490cb2c7e00001e&m=1473061865","list_dtime":"2016-09-05 07:54:07"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","is_ad":"Y","focus_photo_size":{"width":"1242","height":"700"},"tpl_style":"2","articles":"57c935dd9490cb201800004a,57ccb2db1bc8e0a342000076,57cd14119490cbf87d00003c,57cd01511bc8e0170c000059,57cd14fd9490cbe77d000039,57cd04089490cb155f000007","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57cc907b1bc8e02430000051,57cd09881bc8e0627d000050,57cd13e59490cb137e00003a,57ccf4cd9490cb9813000008,57ccef5a1bc8e0ee6800000f,57cd0c021bc8e0d67a000044","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57ccb4349490cb517e000006,57cd09881bc8e0627d00004f,57ccdf3e1bc8e0b85e0000c2,57ccda201bc8e0220c00002d,57ccce1c1bc8e03a53000002,57ccde941bc8e0e65d00005b","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57ccd7a01bc8e0445b000000,57cce13c1bc8e02360000000,57ccd6579490cb6d71000006,57ccdbcd1bc8e0195c00003d,57ccc72b1bc8e0230c000017,57cc4d369490cb182b000001","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"6","articles":"57ccb41f9490cb2c7e00001b,57ccc71a9490cba92000000c,57ccb9cf9490cb2b7e00000f,57ccb1271bc8e02840000086,57ccb41f9490cb2c7e00001d,57ccb41f9490cb2c7e00001c","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cc6baf9490cbe245000000,57cca4ed1bc8e05b3a00004b,57cc76571bc8e07924000028,57ccb7db9490cb9151000006,57cc7aeb9490cb1409000001,57ccb41f9490cb2c7e00001e","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}}],"article_block_colors":["#757d8b","#757d8b"],"only_text_page_bgcolors":["#757d8b","#757d8b"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/5.png?t=1458290404","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/5.png?t=1458290404","hidden_time":"24","need_userinfo":"NO","block_title":"互联网新闻","block_color":"#757d8b","desktop_color_number":"5","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_2eb767f28def417abde411ca51cfe0ce","selected_index":"2","list":[{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=5&since_date=1472863890&nt=1&next_aticle_id=57ccb98f9490cb057e000010&_appid=androidphone&opage=2&otimestamp=192&catalog_appid=13
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=5&need_app_integration=
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=5&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,51a7103481853d8f4c000143&k=201609051550
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/5.png?t=1458290404
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/5.png?t=1458290404
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 互联网新闻
         * block_color : #757d8b
         * desktop_color_number : 5
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_2eb767f28def417abde411ca51cfe0ce
         * selected_index : 2
         * list : [{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57c935dd9490cb201800004a
         * title : 亚马逊Kindle Oasis电子书阅读器
         * title_line_break : 亚马逊Kindle
         Oasis电子书阅读器
         * date : 2016-09-05 10:00:00
         * auther_name : 互联网新闻
         * page : 1
         * index : 1
         * weburl : http://iphone.myzaker.com/l.php?l=57c935dd9490cb201800004a
         * thumbnail_pic : http://zkres3.myzaker.com/data/attachment/editor/2016/09/02/14728043986800.jpg
         * thumbnail_mpic : http://zkres3.myzaker.com/data/attachment/editor/2016/09/02/14728043986800.jpg
         * thumbnail_min_pic : http://zkres.myzaker.com/201609/aHR0cDovL3prcmVzMy5teXpha2VyLmNvbS9kYXRhL2F0dGFjaG1lbnQvZWRpdG9yLzIwMTYvMDkvMDIvMTQ3MjgwNDM5ODY4MDAuanBn_640.jpg
         * thumbnail_picsize : 1242,700
         * thumbnail_title :
         * media_count : 1
         * hide_mask : Y
         * is_full : NO
         * content :
         * type : web2
         * special_info : {"open_type":"web","need_user_info":"N","web_show_arg":{"toolbar_position":"top"},"web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c935dd9490cb201800004a&title=%E4%BA%9A%E9%A9%AC%E9%80%8AKindle+Oasis%E7%94%B5%E5%AD%90%E4%B9%A6%E9%98%85%E8%AF%BB%E5%99%A8&open_type=web&_appid=androidphone&need_userinfo=N&url=http%3A%2F%2Fe.cn.miaozhen.com%2Fr%2Fk%3D2027607%26p%3D71wmN%26dx%3D__IPDX__%26rt%3D2%26ns%3D__IP__%26ni%3D__IESID__%26v%3D__LOC__%26xa%3D__ADPLATFORM__%26ro%3Dsm%26vo%3D317c682b%26vr%3D2%26o%3Dhttp%253A%252F%252Fkindle.wx.eub-inc.com%252Fasp%252Fapp150901%252F%253Fs3%253D14","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=5&app_ids=5&pk=57c935dd9490cb201800004a&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c935dd9490cb201800004a","stat_read_url":"http://api.myzaker.com/zaker/ads_stat.php?pk=5&app_id=5&_appid=androidphone&ads_id=57c935dd9490cb201800004a&action=read","icon_url":"http://zkres.myzaker.com/data/image/mark/ad_2x.png","tag_position":"2","show_jingcai":"Y","list_nodsp":"Y"}
         * special_type : tag
         * full_url : http://iphone.myzaker.com/zaker/article_mongo_nocache.php?app_id=5&pk=57c935dd9490cb201800004a&ad=1
         * ga_info : {"category":"AD","action":"Article"}
         * is_ad : Y
         * list_dtime : 2016-09-05 10:00:00
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * is_ad : Y
             * focus_photo_size : {"width":"1242","height":"700"}
             * tpl_style : 2
             * articles : 57c935dd9490cb201800004a,57ccb2db1bc8e0a342000076,57cd14119490cbf87d00003c,57cd01511bc8e0170c000059,57cd14fd9490cbe77d000039,57cd04089490cb155f000007
             * diy : {"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String is_ad;
                /**
                 * width : 1242
                 * height : 700
                 */

                private FocusPhotoSizeBean focus_photo_size;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * is_ad : Y
                 * stat_read_url : http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read
                 * ga_info : {"category":"AD","action":"Banner","send_after_showed":"Y"}
                 * open_type : web
                 * need_user_info : N
                 * open_confirm :
                 * ads_id : 5775c9899490cbef0300003b
                 * ads_title : 华为科技冠名160701-aPhone
                 * ad_pk : 5775c9899490cbef0300003b
                 * web_url : http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getIs_ad() {
                    return is_ad;
                }

                public void setIs_ad(String is_ad) {
                    this.is_ad = is_ad;
                }

                public FocusPhotoSizeBean getFocus_photo_size() {
                    return focus_photo_size;
                }

                public void setFocus_photo_size(FocusPhotoSizeBean focus_photo_size) {
                    this.focus_photo_size = focus_photo_size;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class FocusPhotoSizeBean {
                    private String width;
                    private String height;

                    public String getWidth() {
                        return width;
                    }

                    public void setWidth(String width) {
                        this.width = width;
                    }

                    public String getHeight() {
                        return height;
                    }

                    public void setHeight(String height) {
                        this.height = height;
                    }
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String is_ad;
                    private String stat_read_url;
                    /**
                     * category : AD
                     * action : Banner
                     * send_after_showed : Y
                     */

                    private GaInfoBean ga_info;
                    private String open_type;
                    private String need_user_info;
                    private String open_confirm;
                    private String ads_id;
                    private String ads_title;
                    private String ad_pk;
                    private String web_url;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getIs_ad() {
                        return is_ad;
                    }

                    public void setIs_ad(String is_ad) {
                        this.is_ad = is_ad;
                    }

                    public String getStat_read_url() {
                        return stat_read_url;
                    }

                    public void setStat_read_url(String stat_read_url) {
                        this.stat_read_url = stat_read_url;
                    }

                    public GaInfoBean getGa_info() {
                        return ga_info;
                    }

                    public void setGa_info(GaInfoBean ga_info) {
                        this.ga_info = ga_info;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }

                    public String getNeed_user_info() {
                        return need_user_info;
                    }

                    public void setNeed_user_info(String need_user_info) {
                        this.need_user_info = need_user_info;
                    }

                    public String getOpen_confirm() {
                        return open_confirm;
                    }

                    public void setOpen_confirm(String open_confirm) {
                        this.open_confirm = open_confirm;
                    }

                    public String getAds_id() {
                        return ads_id;
                    }

                    public void setAds_id(String ads_id) {
                        this.ads_id = ads_id;
                    }

                    public String getAds_title() {
                        return ads_title;
                    }

                    public void setAds_title(String ads_title) {
                        this.ads_title = ads_title;
                    }

                    public String getAd_pk() {
                        return ad_pk;
                    }

                    public void setAd_pk(String ad_pk) {
                        this.ad_pk = ad_pk;
                    }

                    public String getWeb_url() {
                        return web_url;
                    }

                    public void setWeb_url(String web_url) {
                        this.web_url = web_url;
                    }

                    public static class GaInfoBean {
                        private String category;
                        private String action;
                        private String send_after_showed;

                        public String getCategory() {
                            return category;
                        }

                        public void setCategory(String category) {
                            this.category = category;
                        }

                        public String getAction() {
                            return action;
                        }

                        public void setAction(String action) {
                            this.action = action;
                        }

                        public String getSend_after_showed() {
                            return send_after_showed;
                        }

                        public void setSend_after_showed(String send_after_showed) {
                            this.send_after_showed = send_after_showed;
                        }
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_13
             * title : 综合
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 13
                 * title : 科技频道
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13
                 * data_type : news
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String title_line_break;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_min_pic;
            private String thumbnail_picsize;
            private String thumbnail_title;
            private String media_count;
            private String hide_mask;
            private String is_full;
            private String content;
            private String type;
            /**
             * open_type : web
             * need_user_info : N
             * web_show_arg : {"toolbar_position":"top"}
             * web_url : http://iphone.myzaker.com/zaker/ad_article.php?_id=57c935dd9490cb201800004a&title=%E4%BA%9A%E9%A9%AC%E9%80%8AKindle+Oasis%E7%94%B5%E5%AD%90%E4%B9%A6%E9%98%85%E8%AF%BB%E5%99%A8&open_type=web&_appid=androidphone&need_userinfo=N&url=http%3A%2F%2Fe.cn.miaozhen.com%2Fr%2Fk%3D2027607%26p%3D71wmN%26dx%3D__IPDX__%26rt%3D2%26ns%3D__IP__%26ni%3D__IESID__%26v%3D__LOC__%26xa%3D__ADPLATFORM__%26ro%3Dsm%26vo%3D317c682b%26vr%3D2%26o%3Dhttp%253A%252F%252Fkindle.wx.eub-inc.com%252Fasp%252Fapp150901%252F%253Fs3%253D14
             * stat_click_url : http://stat.myzaker.com/stat.php?app_id=5&app_ids=5&pk=57c935dd9490cb201800004a&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c935dd9490cb201800004a
             * stat_read_url : http://api.myzaker.com/zaker/ads_stat.php?pk=5&app_id=5&_appid=androidphone&ads_id=57c935dd9490cb201800004a&action=read
             * icon_url : http://zkres.myzaker.com/data/image/mark/ad_2x.png
             * tag_position : 2
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String special_type;
            private String full_url;
            /**
             * category : AD
             * action : Article
             */

            private GaInfoBean ga_info;
            private String is_ad;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getTitle_line_break() {
                return title_line_break;
            }

            public void setTitle_line_break(String title_line_break) {
                this.title_line_break = title_line_break;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_min_pic() {
                return thumbnail_min_pic;
            }

            public void setThumbnail_min_pic(String thumbnail_min_pic) {
                this.thumbnail_min_pic = thumbnail_min_pic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getThumbnail_title() {
                return thumbnail_title;
            }

            public void setThumbnail_title(String thumbnail_title) {
                this.thumbnail_title = thumbnail_title;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getHide_mask() {
                return hide_mask;
            }

            public void setHide_mask(String hide_mask) {
                this.hide_mask = hide_mask;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getSpecial_type() {
                return special_type;
            }

            public void setSpecial_type(String special_type) {
                this.special_type = special_type;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public GaInfoBean getGa_info() {
                return ga_info;
            }

            public void setGa_info(GaInfoBean ga_info) {
                this.ga_info = ga_info;
            }

            public String getIs_ad() {
                return is_ad;
            }

            public void setIs_ad(String is_ad) {
                this.is_ad = is_ad;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String open_type;
                private String need_user_info;
                /**
                 * toolbar_position : top
                 */

                private WebShowArgBean web_show_arg;
                private String web_url;
                private String stat_click_url;
                private String stat_read_url;
                private String icon_url;
                private String tag_position;
                private String show_jingcai;
                private String list_nodsp;

                public String getOpen_type() {
                    return open_type;
                }

                public void setOpen_type(String open_type) {
                    this.open_type = open_type;
                }

                public String getNeed_user_info() {
                    return need_user_info;
                }

                public void setNeed_user_info(String need_user_info) {
                    this.need_user_info = need_user_info;
                }

                public WebShowArgBean getWeb_show_arg() {
                    return web_show_arg;
                }

                public void setWeb_show_arg(WebShowArgBean web_show_arg) {
                    this.web_show_arg = web_show_arg;
                }

                public String getWeb_url() {
                    return web_url;
                }

                public void setWeb_url(String web_url) {
                    this.web_url = web_url;
                }

                public String getStat_click_url() {
                    return stat_click_url;
                }

                public void setStat_click_url(String stat_click_url) {
                    this.stat_click_url = stat_click_url;
                }

                public String getStat_read_url() {
                    return stat_read_url;
                }

                public void setStat_read_url(String stat_read_url) {
                    this.stat_read_url = stat_read_url;
                }

                public String getIcon_url() {
                    return icon_url;
                }

                public void setIcon_url(String icon_url) {
                    this.icon_url = icon_url;
                }

                public String getTag_position() {
                    return tag_position;
                }

                public void setTag_position(String tag_position) {
                    this.tag_position = tag_position;
                }

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }

                public static class WebShowArgBean {
                    private String toolbar_position;

                    public String getToolbar_position() {
                        return toolbar_position;
                    }

                    public void setToolbar_position(String toolbar_position) {
                        this.toolbar_position = toolbar_position;
                    }
                }
            }

            public static class GaInfoBean {
                private String category;
                private String action;

                public String getCategory() {
                    return category;
                }

                public void setCategory(String category) {
                    this.category = category;
                }

                public String getAction() {
                    return action;
                }

                public void setAction(String action) {
                    this.action = action;
                }
            }
        }
    }
}
