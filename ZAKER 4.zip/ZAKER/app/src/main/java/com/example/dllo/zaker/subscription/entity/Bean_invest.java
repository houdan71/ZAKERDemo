package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/3.
 */
public class Bean_invest {


    /**
     * stat : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=11195&since_date=1472795406&nt=1&_appid=androidphone","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=11195&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=11195&ids=54dde63f9490cbbf07000101&k=201609031510"},"catalog":"","articles":[{"pk":"57c7c51b9490cbe42c000040","title":"你不得不知道的六个家庭理财常识","date":"2016-09-03 02:15:43","auther_name":"MBA智库","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c7c51b9490cbe42c000040","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2YTBiMjFiYzhlMDJiMjEwMDAwMDRfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2YTBiMjFiYzhlMDJiMjEwMDAwMDRfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,418","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c51b9490cbe42c000040&m=1472886430","list_dtime":"2016-09-03 02:15:43"},{"pk":"57c7bf949490cbc82c000026","title":"3100亿，重磅武器","date":"2016-09-03 03:41:40","auther_name":"黄生看金融","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c7bf949490cbc82c000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg4MTcwOF80MjEyOV9XNjQwSDM2MFM5MDQ3My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg4MTcwOF80MjEyOV9XNjQwSDM2MFM5MDQ3My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7bf949490cbc82c000026&m=1472886430","list_dtime":"2016-09-03 03:41:40"},{"pk":"57c5563d9490cb471300007a","title":"买房要盯牢了！房价暴涨可能是这三城市","date":"2016-09-03 02:46:55","auther_name":"嘉丰瑞德","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c5563d9490cb471300007a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1NTY0ZWEwN2FlY2Y3N2UwMzViMTBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1NTY0ZWEwN2FlY2Y3N2UwMzViMTBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"450,284","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c5563d9490cb471300007a&m=1472886430","list_dtime":"2016-09-03 02:46:55"},{"pk":"57ca709e9490cb493f00003c","title":"居民房贷激增后果多严重 你知道吗？","title_line_break":"居民房贷激增后果多严重\n你知道吗？","date":"2016-09-03 14:41:59","auther_name":"腾讯财经","weburl":"http://iphone.myzaker.com/l.php?l=57ca709e9490cb493f00003c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca3269a07aecc523006da6_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca3269a07aecc523006da6_320.jpg","thumbnail_picsize":"600,397","media_count":"13","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca709e9490cb493f00003c&m=1472886429","list_dtime":"2016-09-03 14:41:59"},{"pk":"57ca709e9490cb493f00003b","title":"八个地段的房子千万买不得！入手就贬值","date":"2016-09-03 14:41:34","auther_name":"南方网","weburl":"http://iphone.myzaker.com/l.php?l=57ca709e9490cb493f00003b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca34d1a07aecc523006f06_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca34d1a07aecc523006f06_320.jpg","thumbnail_picsize":"300,400","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca709e9490cb493f00003b&m=1472886429","list_dtime":"2016-09-03 14:41:34"},{"pk":"57ca709e9490cb493f00003a","title":"刘强东：想当\"人生赢家\"？先学会这个本事","title_line_break":"刘强东：\n想当\"人生赢家\"？先学会这个本事","date":"2016-09-03 14:41:34","auther_name":"央视财经","weburl":"http://iphone.myzaker.com/l.php?l=57ca709e9490cb493f00003a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca3477a07aecc523006eee_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca3477a07aecc523006eee_320.jpg","thumbnail_picsize":"640,480","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca709e9490cb493f00003a&m=1472886429","list_dtime":"2016-09-03 14:41:34"},{"pk":"57c26d461bc8e08d14000002","title":"哪是\u201c北上广深\u201d后的第五城？","date":"2016-09-03 13:47:32","auther_name":"小融读财","weburl":"http://iphone.myzaker.com/l.php?l=57c26d461bc8e08d14000002","thumbnail_pic":"http://zkres.myzaker.com/201608/57c26ed77f52e9c2050004d5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c26ed77f52e9c2050004d5_320.jpg","thumbnail_picsize":"565,327","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c26d461bc8e08d14000002&m=1472886429","list_dtime":"2016-09-03 13:47:32"},{"pk":"57c316d07f780be0670050d6","title":"留学生，毕业后你想过哪一种生活？","date":"2016-09-03 13:46:54","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57c316d07f780be0670050d6","thumbnail_pic":"http://zkres.myzaker.com/201608/57c316d37f52e95f6e00034a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c316d37f52e95f6e00034a_320.jpg","thumbnail_picsize":"640,367","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c316d07f780be0670050d6&m=1472886429","list_dtime":"2016-09-03 13:46:54"},{"pk":"57c44b8a7f780be067005781","title":"每一次楼市调控前，都有一次\u201c离婚\u201d高潮","date":"2016-09-03 13:46:06","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57c44b8a7f780be067005781","thumbnail_pic":"http://zkres.myzaker.com/201608/57c44b8b7f52e9a729000741_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c44b8b7f52e9a729000741_320.jpg","thumbnail_picsize":"640,828","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c44b8a7f780be067005781&m=1472886429","list_dtime":"2016-09-03 13:46:06"},{"pk":"57ca03597f780b141100037f","title":"这三个城市房价又要暴涨了","date":"2016-09-03 13:45:18","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57ca03597f780b141100037f","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca035c7f52e9d00700009a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca035c7f52e9d00700009a_320.jpg","thumbnail_picsize":"640,500","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca03597f780b141100037f&m=1472886429","list_dtime":"2016-09-03 13:45:18"},{"pk":"57ca39359490cb386a000017","title":"为什么这么多人叫你干一行爱一行？","date":"2016-09-03 13:44:12","auther_name":"MBA智库","weburl":"http://iphone.myzaker.com/l.php?l=57ca39359490cb386a000017","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca2ef01bc8e03743000014_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca2ef01bc8e03743000014_320.jpg","thumbnail_picsize":"730,476","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca39359490cb386a000017&m=1472886429","list_dtime":"2016-09-03 13:44:12"},{"pk":"57ca214a1bc8e0877b000014","title":"为什么买房的人都有选房困难症？","date":"2016-09-03 11:40:06","auther_name":"地产八卦女","weburl":"http://iphone.myzaker.com/l.php?l=57ca214a1bc8e0877b000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57c99e43a07aecc523004a9d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c99e43a07aecc523004a9d_320.jpg","thumbnail_picsize":"620,388","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca214a1bc8e0877b000014&m=1472886429","list_dtime":"2016-09-03 11:40:06"},{"pk":"57ca39359490cb386a000019","title":"从炒股热到炒房热的上演 揭示了什么？","title_line_break":"从炒股热到炒房热的上演\n揭示了什么？","date":"2016-09-03 11:39:17","auther_name":"金融界","weburl":"http://iphone.myzaker.com/l.php?l=57ca39359490cb386a000019","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca39359490cb386a000019&m=1472886429","list_dtime":"2016-09-03 11:39:17"},{"pk":"57c5a6a57f780be067005f40","title":"投资公司突然关门跑路，骗的都是老年人！","date":"2016-09-03 11:38:22","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57c5a6a57f780be067005f40","thumbnail_pic":"http://zkres.myzaker.com/201608/57c5a6a67f52e90e0e000182_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c5a6a67f52e90e0e000182_320.jpg","thumbnail_picsize":"1266,728","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c5a6a57f780be067005f40&m=1472886429","list_dtime":"2016-09-03 11:38:22"},{"pk":"57c6616e1bc8e02a720000d8","title":"选哪个：先有钱，先有好工作？","title_line_break":"选哪个：\n先有钱，先有好工作？","date":"2016-09-03 11:36:41","auther_name":"简七读财","weburl":"http://iphone.myzaker.com/l.php?l=57c6616e1bc8e02a720000d8","thumbnail_pic":"http://zkres.myzaker.com/201608/57c661717f52e9a01c0002e3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c661717f52e9a01c0002e3_320.jpg","thumbnail_picsize":"640,403","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c6616e1bc8e02a720000d8&m=1472886430","list_dtime":"2016-09-03 11:36:41"},{"pk":"57c908951bc8e0a111000018","title":"热议：月薪多少钱才叫幸福？","title_line_break":"热议：\n月薪多少钱才叫幸福？","date":"2016-09-03 11:32:16","auther_name":"好规划","weburl":"http://iphone.myzaker.com/l.php?l=57c908951bc8e0a111000018","thumbnail_pic":"http://zkres.myzaker.com/201605/5740a615a07aec9424034d81_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201605/5740a615a07aec9424034d81_320.jpg","thumbnail_picsize":"240,240","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c908951bc8e0a111000018&m=1472886430","list_dtime":"2016-09-03 11:32:16"},{"pk":"57c7c5e21bc8e03d4e00004d","title":"\u200b交了这么多年的生育险，到底怎么用？","date":"2016-09-03 11:31:36","auther_name":"优顾理财","weburl":"http://iphone.myzaker.com/l.php?l=57c7c5e21bc8e03d4e00004d","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c5e21bc8e03d4e00004d&m=1472886430","list_dtime":"2016-09-03 11:31:36"},{"pk":"57c8311a7f780bf00f000851","title":"送孩子去留学 《小别离》究竟值不值","title_line_break":"送孩子去留学\n《小别离》究竟值不值","date":"2016-09-03 11:30:52","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57c8311a7f780bf00f000851","thumbnail_pic":"http://zkres.myzaker.com/201609/57c831237f52e9ea7b00019c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c831237f52e9ea7b00019c_320.jpg","thumbnail_picsize":"640,380","media_count":"25","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c8311a7f780bf00f000851&m=1472886430","list_dtime":"2016-09-03 11:30:52"},{"pk":"57c8311d7f780bf00f000852","title":"半年卖出301亿，香港保险，凭什么成爆款","date":"2016-09-03 11:28:50","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57c8311d7f780bf00f000852","thumbnail_pic":"http://zkres.myzaker.com/201609/57c831287f52e96a7b0001b5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c831287f52e96a7b0001b5_320.jpg","thumbnail_picsize":"600,350","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c8311d7f780bf00f000852&m=1472886430","list_dtime":"2016-09-03 11:28:50"},{"pk":"57c831207f780bf00f000853","title":"关于公积金的秘密都在这里头","date":"2016-09-03 11:28:27","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57c831207f780bf00f000853","thumbnail_pic":"http://zkres.myzaker.com/201609/57c831247f52e91a7c00015d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c831247f52e91a7c00015d_320.jpg","thumbnail_picsize":"778,476","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c831207f780bf00f000853&m=1472886430","list_dtime":"2016-09-03 11:28:27"},{"pk":"57ca035c7f780b1411000380","title":"你的航班信息在裸奔！该怎么办？","date":"2016-09-03 11:27:10","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57ca035c7f780b1411000380","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca035f7f52e9dc05000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca035f7f52e9dc05000001_320.jpg","thumbnail_picsize":"266,239","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca035c7f780b1411000380&m=1472886430","list_dtime":"2016-09-03 11:27:10"},{"pk":"57c7c3e49490cb0b55000003","title":"回老家做什么最赚钱 10种职业大盘点","title_line_break":"回老家做什么最赚钱\n10种职业大盘点","date":"2016-09-03 04:00:04","auther_name":"金融界","weburl":"http://iphone.myzaker.com/l.php?l=57c7c3e49490cb0b55000003","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c3e49490cb0b55000003&m=1472886430","list_dtime":"2016-09-03 04:00:04"},{"pk":"57c7c07c9490cbca2c00003a","title":"永远是昨天的最便宜，房价神话怎么炼成？","date":"2016-09-03 03:45:32","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c7c07c9490cbca2c00003a","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c7c07c9490cbca2c00003a&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_99_1422906.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c07c9490cbca2c00003a&m=1472886430","list_dtime":"2016-09-03 03:45:32"},{"pk":"57c7c07c9490cbca2c00003e","title":"科学家奉献一生，不如戏子作秀一场？！","date":"2016-09-03 03:45:32","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c7c07c9490cbca2c00003e","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c7c07c9490cbca2c00003e&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_99_1422872.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c07c9490cbca2c00003e&m=1472886430","list_dtime":"2016-09-03 03:45:32"},{"pk":"57c7c07c9490cbca2c00003f","title":"富人不再囤房了，未来10年钱往哪投？","date":"2016-09-03 03:45:32","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c7c07c9490cbca2c00003f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c784fc1bc8e0822400001b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c784fc1bc8e0822400001b_320.jpg","thumbnail_picsize":"329,293","media_count":"6","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c7c07c9490cbca2c00003f&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_101_1422867.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c07c9490cbca2c00003f&m=1472886430","list_dtime":"2016-09-03 03:45:32"},{"pk":"57c554b49490cb8613000068","title":"今年那么多人创业，原来是因为这些福利","date":"2016-09-03 02:40:11","auther_name":"央视财经","weburl":"http://iphone.myzaker.com/l.php?l=57c554b49490cb8613000068","thumbnail_pic":"http://zkres.myzaker.com/201608/57c4c757a07aecf77e030d8a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c4c757a07aecf77e030d8a_320.jpg","thumbnail_picsize":"220,220","media_count":"20","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c554b49490cb8613000068&m=1472886430","list_dtime":"2016-09-03 02:40:11"},{"pk":"57c7c5b69490cbf12c00003f","title":"国内居民投资黄金的渠道有哪些？","date":"2016-09-03 02:07:50","auther_name":"环球老虎财经","weburl":"http://iphone.myzaker.com/l.php?l=57c7c5b69490cbf12c00003f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c790761bc8e0c82a00000e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c790761bc8e0c82a00000e_320.jpg","thumbnail_picsize":"865,1023","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c5b69490cbf12c00003f&m=1472886430","list_dtime":"2016-09-03 02:07:50"},{"pk":"57c95fa39490cb0c18000065","title":"你认为钱是靠挣回来的？还是靠存来的？","date":"2016-09-02 19:16:51","auther_name":"理财换大房","weburl":"http://iphone.myzaker.com/l.php?l=57c95fa39490cb0c18000065","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"204","title":"理财换大房","stitle":"","pic":"http://zkres.myzaker.com/data/image/dis_icon/special/zkdis_icon_0092.png","large_pic":"http://zkres.myzaker.com/data/image/dis_icon/special/zkdis_icon_0092.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=204","block_color":"","subscribe_count":"176689","post_count":"4964","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=11195&app_ids=11195&pk=57c95fa39490cb0c18000065&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c95fa39490cb0c18000065","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c95fa39490cb0c18000065&m=1472886430","list_dtime":"2016-09-02 19:16:51"},{"pk":"57c8f4949490cbe35a000011","title":"屌丝厨师卖包子起家，竟身家3亿，上《时代》封面","date":"2016-09-02 16:21:00","auther_name":"商界","weburl":"http://iphone.myzaker.com/l.php?l=57c8f4949490cbe35a000011","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8ec391bc8e0d27d000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8ec391bc8e0d27d000000_320.jpg","thumbnail_picsize":"470,294","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c8f4949490cbe35a000011&m=1472806018","list_dtime":"2016-09-02 16:21:00"},{"pk":"57c8e55e9490cb8b0f000018","title":"一位浙江老板对比了中美制造业的真实成本，有点可怕","date":"2016-09-02 16:21:00","auther_name":"商界","weburl":"http://iphone.myzaker.com/l.php?l=57c8e55e9490cb8b0f000018","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8e2d31bc8e0947800001e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8e2d31bc8e0947800001e_320.jpg","thumbnail_picsize":"345,463","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c8e55e9490cb8b0f000018&m=1472806018","list_dtime":"2016-09-02 16:21:00"},{"pk":"57c9130e9490cba76c000004","title":"偷偷超了华为和小米，他才是真正的人生大赢家！","date":"2016-09-02 16:21:00","auther_name":"商界","weburl":"http://iphone.myzaker.com/l.php?l=57c9130e9490cba76c000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8dd601bc8e00f7500000a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8dd601bc8e00f7500000a_320.jpg","thumbnail_picsize":"450,250","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c9130e9490cba76c000004&m=1472806018","list_dtime":"2016-09-02 16:21:00"},{"pk":"57c913999490cbf81700004b","title":"惊!这个骗局99%的人都会上当!","date":"2016-09-02 13:52:25","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c913999490cbf81700004b","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c913999490cbf81700004b&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_99_1422962.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c913999490cbf81700004b&m=1472797317","list_dtime":"2016-09-02 13:52:25"},{"pk":"57c913999490cbf81700004c","title":"喝酸奶能长寿？全世界被他骗了100年","date":"2016-09-02 13:52:25","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c913999490cbf81700004c","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8e42f1bc8e0d679000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8e42f1bc8e0d679000000_320.jpg","thumbnail_picsize":"362,220","media_count":"11","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c913999490cbf81700004c&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_105_1422955.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c913999490cbf81700004c&m=1472797317","list_dtime":"2016-09-02 13:52:25"},{"pk":"57c913999490cbf81700004d","title":"马云的妻子，背景也相当惊人！","date":"2016-09-02 13:52:25","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c913999490cbf81700004d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8dbb21bc8e0db75000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8dbb21bc8e0db75000000_320.jpg","thumbnail_picsize":"500,333","media_count":"11","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c913999490cbf81700004d&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_99_1422953.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c913999490cbf81700004d&m=1472797317","list_dtime":"2016-09-02 13:52:25"},{"pk":"57c913999490cbf81700004a","title":"揭五险一金的真相！不知道的白干30年！","date":"2016-09-02 13:52:25","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c913999490cbf81700004a","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9363ca07aecc523001197_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9363ca07aecc523001197_320.jpg","thumbnail_picsize":"294,195","media_count":"1","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c913999490cbf81700004a&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_99_1422963.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c913999490cbf81700004a&m=1472806018","list_dtime":"2016-09-02 13:52:25"},{"pk":"57c9130e9490cba76c000006","title":"学历重要但也不太重要，他只是敲门砖","date":"2016-09-02 13:50:06","auther_name":"她理财","weburl":"http://iphone.myzaker.com/l.php?l=57c9130e9490cba76c000006","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c9130e9490cba76c000006&m=1472797075","list_dtime":"2016-09-02 13:50:06"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c7bf949490cbc82c000026,57ca709e9490cb493f00003c,57ca709e9490cb493f00003b,57ca709e9490cb493f00003a,57c26d461bc8e08d14000002,57c316d07f780be0670050d6","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c5563d9490cb471300007a,57c44b8a7f780be067005781,57ca03597f780b141100037f,57ca39359490cb386a000017,57ca214a1bc8e0877b000014,57ca39359490cb386a000019","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c7c51b9490cbe42c000040,57c5a6a57f780be067005f40,57c6616e1bc8e02a720000d8,57c908951bc8e0a111000018,57c7c5e21bc8e03d4e00004d,57c8311a7f780bf00f000851","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c831207f780bf00f000853,57c8311d7f780bf00f000852,57ca035c7f780b1411000380,57c7c3e49490cb0b55000003,57c7c07c9490cbca2c00003a,57c7c07c9490cbca2c00003e","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c554b49490cb8613000068,57c7c07c9490cbca2c00003f,57c7c5b69490cbf12c00003f,57c95fa39490cb0c18000065,57c8f4949490cbe35a000011,57c8e55e9490cb8b0f000018","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c913999490cbf81700004c,57c913999490cbf81700004b,57c9130e9490cba76c000004,57c913999490cbf81700004d,57c913999490cbf81700004a,57c9130e9490cba76c000006","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}}],"article_block_colors":["#23283e","#23283e"],"only_text_page_bgcolors":["#23283e","#23283e"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11195.png?1395915550","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11195.png?1395915550","hidden_time":"24","need_userinfo":"NO","block_title":"投资理财","block_color":"#23283e","desktop_color_number":"0","use_original_icon":"N"}}
     */

    private String stat;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=11195&since_date=1472795406&nt=1&_appid=androidphone","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=11195&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=11195&ids=54dde63f9490cbbf07000101&k=201609031510"}
     * catalog :
     * articles : [{"pk":"57c7c51b9490cbe42c000040","title":"你不得不知道的六个家庭理财常识","date":"2016-09-03 02:15:43","auther_name":"MBA智库","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c7c51b9490cbe42c000040","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2YTBiMjFiYzhlMDJiMjEwMDAwMDRfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2YTBiMjFiYzhlMDJiMjEwMDAwMDRfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,418","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c51b9490cbe42c000040&m=1472886430","list_dtime":"2016-09-03 02:15:43"},{"pk":"57c7bf949490cbc82c000026","title":"3100亿，重磅武器","date":"2016-09-03 03:41:40","auther_name":"黄生看金融","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c7bf949490cbc82c000026","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg4MTcwOF80MjEyOV9XNjQwSDM2MFM5MDQ3My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg4MTcwOF80MjEyOV9XNjQwSDM2MFM5MDQ3My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7bf949490cbc82c000026&m=1472886430","list_dtime":"2016-09-03 03:41:40"},{"pk":"57c5563d9490cb471300007a","title":"买房要盯牢了！房价暴涨可能是这三城市","date":"2016-09-03 02:46:55","auther_name":"嘉丰瑞德","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c5563d9490cb471300007a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1NTY0ZWEwN2FlY2Y3N2UwMzViMTBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1NTY0ZWEwN2FlY2Y3N2UwMzViMTBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"450,284","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c5563d9490cb471300007a&m=1472886430","list_dtime":"2016-09-03 02:46:55"},{"pk":"57ca709e9490cb493f00003c","title":"居民房贷激增后果多严重 你知道吗？","title_line_break":"居民房贷激增后果多严重\n你知道吗？","date":"2016-09-03 14:41:59","auther_name":"腾讯财经","weburl":"http://iphone.myzaker.com/l.php?l=57ca709e9490cb493f00003c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca3269a07aecc523006da6_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca3269a07aecc523006da6_320.jpg","thumbnail_picsize":"600,397","media_count":"13","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca709e9490cb493f00003c&m=1472886429","list_dtime":"2016-09-03 14:41:59"},{"pk":"57ca709e9490cb493f00003b","title":"八个地段的房子千万买不得！入手就贬值","date":"2016-09-03 14:41:34","auther_name":"南方网","weburl":"http://iphone.myzaker.com/l.php?l=57ca709e9490cb493f00003b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca34d1a07aecc523006f06_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca34d1a07aecc523006f06_320.jpg","thumbnail_picsize":"300,400","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca709e9490cb493f00003b&m=1472886429","list_dtime":"2016-09-03 14:41:34"},{"pk":"57ca709e9490cb493f00003a","title":"刘强东：想当\"人生赢家\"？先学会这个本事","title_line_break":"刘强东：\n想当\"人生赢家\"？先学会这个本事","date":"2016-09-03 14:41:34","auther_name":"央视财经","weburl":"http://iphone.myzaker.com/l.php?l=57ca709e9490cb493f00003a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca3477a07aecc523006eee_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca3477a07aecc523006eee_320.jpg","thumbnail_picsize":"640,480","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca709e9490cb493f00003a&m=1472886429","list_dtime":"2016-09-03 14:41:34"},{"pk":"57c26d461bc8e08d14000002","title":"哪是\u201c北上广深\u201d后的第五城？","date":"2016-09-03 13:47:32","auther_name":"小融读财","weburl":"http://iphone.myzaker.com/l.php?l=57c26d461bc8e08d14000002","thumbnail_pic":"http://zkres.myzaker.com/201608/57c26ed77f52e9c2050004d5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c26ed77f52e9c2050004d5_320.jpg","thumbnail_picsize":"565,327","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c26d461bc8e08d14000002&m=1472886429","list_dtime":"2016-09-03 13:47:32"},{"pk":"57c316d07f780be0670050d6","title":"留学生，毕业后你想过哪一种生活？","date":"2016-09-03 13:46:54","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57c316d07f780be0670050d6","thumbnail_pic":"http://zkres.myzaker.com/201608/57c316d37f52e95f6e00034a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c316d37f52e95f6e00034a_320.jpg","thumbnail_picsize":"640,367","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c316d07f780be0670050d6&m=1472886429","list_dtime":"2016-09-03 13:46:54"},{"pk":"57c44b8a7f780be067005781","title":"每一次楼市调控前，都有一次\u201c离婚\u201d高潮","date":"2016-09-03 13:46:06","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57c44b8a7f780be067005781","thumbnail_pic":"http://zkres.myzaker.com/201608/57c44b8b7f52e9a729000741_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c44b8b7f52e9a729000741_320.jpg","thumbnail_picsize":"640,828","media_count":"9","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c44b8a7f780be067005781&m=1472886429","list_dtime":"2016-09-03 13:46:06"},{"pk":"57ca03597f780b141100037f","title":"这三个城市房价又要暴涨了","date":"2016-09-03 13:45:18","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57ca03597f780b141100037f","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca035c7f52e9d00700009a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca035c7f52e9d00700009a_320.jpg","thumbnail_picsize":"640,500","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca03597f780b141100037f&m=1472886429","list_dtime":"2016-09-03 13:45:18"},{"pk":"57ca39359490cb386a000017","title":"为什么这么多人叫你干一行爱一行？","date":"2016-09-03 13:44:12","auther_name":"MBA智库","weburl":"http://iphone.myzaker.com/l.php?l=57ca39359490cb386a000017","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca2ef01bc8e03743000014_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca2ef01bc8e03743000014_320.jpg","thumbnail_picsize":"730,476","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca39359490cb386a000017&m=1472886429","list_dtime":"2016-09-03 13:44:12"},{"pk":"57ca214a1bc8e0877b000014","title":"为什么买房的人都有选房困难症？","date":"2016-09-03 11:40:06","auther_name":"地产八卦女","weburl":"http://iphone.myzaker.com/l.php?l=57ca214a1bc8e0877b000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57c99e43a07aecc523004a9d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c99e43a07aecc523004a9d_320.jpg","thumbnail_picsize":"620,388","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca214a1bc8e0877b000014&m=1472886429","list_dtime":"2016-09-03 11:40:06"},{"pk":"57ca39359490cb386a000019","title":"从炒股热到炒房热的上演 揭示了什么？","title_line_break":"从炒股热到炒房热的上演\n揭示了什么？","date":"2016-09-03 11:39:17","auther_name":"金融界","weburl":"http://iphone.myzaker.com/l.php?l=57ca39359490cb386a000019","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca39359490cb386a000019&m=1472886429","list_dtime":"2016-09-03 11:39:17"},{"pk":"57c5a6a57f780be067005f40","title":"投资公司突然关门跑路，骗的都是老年人！","date":"2016-09-03 11:38:22","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57c5a6a57f780be067005f40","thumbnail_pic":"http://zkres.myzaker.com/201608/57c5a6a67f52e90e0e000182_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c5a6a67f52e90e0e000182_320.jpg","thumbnail_picsize":"1266,728","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c5a6a57f780be067005f40&m=1472886429","list_dtime":"2016-09-03 11:38:22"},{"pk":"57c6616e1bc8e02a720000d8","title":"选哪个：先有钱，先有好工作？","title_line_break":"选哪个：\n先有钱，先有好工作？","date":"2016-09-03 11:36:41","auther_name":"简七读财","weburl":"http://iphone.myzaker.com/l.php?l=57c6616e1bc8e02a720000d8","thumbnail_pic":"http://zkres.myzaker.com/201608/57c661717f52e9a01c0002e3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c661717f52e9a01c0002e3_320.jpg","thumbnail_picsize":"640,403","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c6616e1bc8e02a720000d8&m=1472886430","list_dtime":"2016-09-03 11:36:41"},{"pk":"57c908951bc8e0a111000018","title":"热议：月薪多少钱才叫幸福？","title_line_break":"热议：\n月薪多少钱才叫幸福？","date":"2016-09-03 11:32:16","auther_name":"好规划","weburl":"http://iphone.myzaker.com/l.php?l=57c908951bc8e0a111000018","thumbnail_pic":"http://zkres.myzaker.com/201605/5740a615a07aec9424034d81_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201605/5740a615a07aec9424034d81_320.jpg","thumbnail_picsize":"240,240","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c908951bc8e0a111000018&m=1472886430","list_dtime":"2016-09-03 11:32:16"},{"pk":"57c7c5e21bc8e03d4e00004d","title":"\u200b交了这么多年的生育险，到底怎么用？","date":"2016-09-03 11:31:36","auther_name":"优顾理财","weburl":"http://iphone.myzaker.com/l.php?l=57c7c5e21bc8e03d4e00004d","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c5e21bc8e03d4e00004d&m=1472886430","list_dtime":"2016-09-03 11:31:36"},{"pk":"57c8311a7f780bf00f000851","title":"送孩子去留学 《小别离》究竟值不值","title_line_break":"送孩子去留学\n《小别离》究竟值不值","date":"2016-09-03 11:30:52","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57c8311a7f780bf00f000851","thumbnail_pic":"http://zkres.myzaker.com/201609/57c831237f52e9ea7b00019c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c831237f52e9ea7b00019c_320.jpg","thumbnail_picsize":"640,380","media_count":"25","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c8311a7f780bf00f000851&m=1472886430","list_dtime":"2016-09-03 11:30:52"},{"pk":"57c8311d7f780bf00f000852","title":"半年卖出301亿，香港保险，凭什么成爆款","date":"2016-09-03 11:28:50","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57c8311d7f780bf00f000852","thumbnail_pic":"http://zkres.myzaker.com/201609/57c831287f52e96a7b0001b5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c831287f52e96a7b0001b5_320.jpg","thumbnail_picsize":"600,350","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c8311d7f780bf00f000852&m=1472886430","list_dtime":"2016-09-03 11:28:50"},{"pk":"57c831207f780bf00f000853","title":"关于公积金的秘密都在这里头","date":"2016-09-03 11:28:27","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57c831207f780bf00f000853","thumbnail_pic":"http://zkres.myzaker.com/201609/57c831247f52e91a7c00015d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c831247f52e91a7c00015d_320.jpg","thumbnail_picsize":"778,476","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c831207f780bf00f000853&m=1472886430","list_dtime":"2016-09-03 11:28:27"},{"pk":"57ca035c7f780b1411000380","title":"你的航班信息在裸奔！该怎么办？","date":"2016-09-03 11:27:10","auther_name":"好有财","weburl":"http://iphone.myzaker.com/l.php?l=57ca035c7f780b1411000380","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca035f7f52e9dc05000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca035f7f52e9dc05000001_320.jpg","thumbnail_picsize":"266,239","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57ca035c7f780b1411000380&m=1472886430","list_dtime":"2016-09-03 11:27:10"},{"pk":"57c7c3e49490cb0b55000003","title":"回老家做什么最赚钱 10种职业大盘点","title_line_break":"回老家做什么最赚钱\n10种职业大盘点","date":"2016-09-03 04:00:04","auther_name":"金融界","weburl":"http://iphone.myzaker.com/l.php?l=57c7c3e49490cb0b55000003","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c3e49490cb0b55000003&m=1472886430","list_dtime":"2016-09-03 04:00:04"},{"pk":"57c7c07c9490cbca2c00003a","title":"永远是昨天的最便宜，房价神话怎么炼成？","date":"2016-09-03 03:45:32","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c7c07c9490cbca2c00003a","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c7c07c9490cbca2c00003a&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_99_1422906.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c07c9490cbca2c00003a&m=1472886430","list_dtime":"2016-09-03 03:45:32"},{"pk":"57c7c07c9490cbca2c00003e","title":"科学家奉献一生，不如戏子作秀一场？！","date":"2016-09-03 03:45:32","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c7c07c9490cbca2c00003e","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c7c07c9490cbca2c00003e&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_99_1422872.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c07c9490cbca2c00003e&m=1472886430","list_dtime":"2016-09-03 03:45:32"},{"pk":"57c7c07c9490cbca2c00003f","title":"富人不再囤房了，未来10年钱往哪投？","date":"2016-09-03 03:45:32","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c7c07c9490cbca2c00003f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c784fc1bc8e0822400001b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c784fc1bc8e0822400001b_320.jpg","thumbnail_picsize":"329,293","media_count":"6","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c7c07c9490cbca2c00003f&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_101_1422867.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c07c9490cbca2c00003f&m=1472886430","list_dtime":"2016-09-03 03:45:32"},{"pk":"57c554b49490cb8613000068","title":"今年那么多人创业，原来是因为这些福利","date":"2016-09-03 02:40:11","auther_name":"央视财经","weburl":"http://iphone.myzaker.com/l.php?l=57c554b49490cb8613000068","thumbnail_pic":"http://zkres.myzaker.com/201608/57c4c757a07aecf77e030d8a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c4c757a07aecf77e030d8a_320.jpg","thumbnail_picsize":"220,220","media_count":"20","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c554b49490cb8613000068&m=1472886430","list_dtime":"2016-09-03 02:40:11"},{"pk":"57c7c5b69490cbf12c00003f","title":"国内居民投资黄金的渠道有哪些？","date":"2016-09-03 02:07:50","auther_name":"环球老虎财经","weburl":"http://iphone.myzaker.com/l.php?l=57c7c5b69490cbf12c00003f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c790761bc8e0c82a00000e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c790761bc8e0c82a00000e_320.jpg","thumbnail_picsize":"865,1023","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c5b69490cbf12c00003f&m=1472886430","list_dtime":"2016-09-03 02:07:50"},{"pk":"57c95fa39490cb0c18000065","title":"你认为钱是靠挣回来的？还是靠存来的？","date":"2016-09-02 19:16:51","auther_name":"理财换大房","weburl":"http://iphone.myzaker.com/l.php?l=57c95fa39490cb0c18000065","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"204","title":"理财换大房","stitle":"","pic":"http://zkres.myzaker.com/data/image/dis_icon/special/zkdis_icon_0092.png","large_pic":"http://zkres.myzaker.com/data/image/dis_icon/special/zkdis_icon_0092.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=204","block_color":"","subscribe_count":"176689","post_count":"4964","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=11195&app_ids=11195&pk=57c95fa39490cb0c18000065&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c95fa39490cb0c18000065","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c95fa39490cb0c18000065&m=1472886430","list_dtime":"2016-09-02 19:16:51"},{"pk":"57c8f4949490cbe35a000011","title":"屌丝厨师卖包子起家，竟身家3亿，上《时代》封面","date":"2016-09-02 16:21:00","auther_name":"商界","weburl":"http://iphone.myzaker.com/l.php?l=57c8f4949490cbe35a000011","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8ec391bc8e0d27d000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8ec391bc8e0d27d000000_320.jpg","thumbnail_picsize":"470,294","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c8f4949490cbe35a000011&m=1472806018","list_dtime":"2016-09-02 16:21:00"},{"pk":"57c8e55e9490cb8b0f000018","title":"一位浙江老板对比了中美制造业的真实成本，有点可怕","date":"2016-09-02 16:21:00","auther_name":"商界","weburl":"http://iphone.myzaker.com/l.php?l=57c8e55e9490cb8b0f000018","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8e2d31bc8e0947800001e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8e2d31bc8e0947800001e_320.jpg","thumbnail_picsize":"345,463","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c8e55e9490cb8b0f000018&m=1472806018","list_dtime":"2016-09-02 16:21:00"},{"pk":"57c9130e9490cba76c000004","title":"偷偷超了华为和小米，他才是真正的人生大赢家！","date":"2016-09-02 16:21:00","auther_name":"商界","weburl":"http://iphone.myzaker.com/l.php?l=57c9130e9490cba76c000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8dd601bc8e00f7500000a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8dd601bc8e00f7500000a_320.jpg","thumbnail_picsize":"450,250","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c9130e9490cba76c000004&m=1472806018","list_dtime":"2016-09-02 16:21:00"},{"pk":"57c913999490cbf81700004b","title":"惊!这个骗局99%的人都会上当!","date":"2016-09-02 13:52:25","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c913999490cbf81700004b","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c913999490cbf81700004b&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_99_1422962.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c913999490cbf81700004b&m=1472797317","list_dtime":"2016-09-02 13:52:25"},{"pk":"57c913999490cbf81700004c","title":"喝酸奶能长寿？全世界被他骗了100年","date":"2016-09-02 13:52:25","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c913999490cbf81700004c","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8e42f1bc8e0d679000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8e42f1bc8e0d679000000_320.jpg","thumbnail_picsize":"362,220","media_count":"11","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c913999490cbf81700004c&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_105_1422955.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c913999490cbf81700004c&m=1472797317","list_dtime":"2016-09-02 13:52:25"},{"pk":"57c913999490cbf81700004d","title":"马云的妻子，背景也相当惊人！","date":"2016-09-02 13:52:25","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c913999490cbf81700004d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8dbb21bc8e0db75000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8dbb21bc8e0db75000000_320.jpg","thumbnail_picsize":"500,333","media_count":"11","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c913999490cbf81700004d&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_99_1422953.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c913999490cbf81700004d&m=1472797317","list_dtime":"2016-09-02 13:52:25"},{"pk":"57c913999490cbf81700004a","title":"揭五险一金的真相！不知道的白干30年！","date":"2016-09-02 13:52:25","auther_name":"21财经搜索","weburl":"http://iphone.myzaker.com/l.php?l=57c913999490cbf81700004a","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9363ca07aecc523001197_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9363ca07aecc523001197_320.jpg","thumbnail_picsize":"294,195","media_count":"1","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=11195&pk=57c913999490cbf81700004a&url=http%3A%2F%2Fm.21so.com%2Frss_zaker_0_99_1422963.html","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c913999490cbf81700004a&m=1472806018","list_dtime":"2016-09-02 13:52:25"},{"pk":"57c9130e9490cba76c000006","title":"学历重要但也不太重要，他只是敲门砖","date":"2016-09-02 13:50:06","auther_name":"她理财","weburl":"http://iphone.myzaker.com/l.php?l=57c9130e9490cba76c000006","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c9130e9490cba76c000006&m=1472797075","list_dtime":"2016-09-02 13:50:06"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c7bf949490cbc82c000026,57ca709e9490cb493f00003c,57ca709e9490cb493f00003b,57ca709e9490cb493f00003a,57c26d461bc8e08d14000002,57c316d07f780be0670050d6","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c5563d9490cb471300007a,57c44b8a7f780be067005781,57ca03597f780b141100037f,57ca39359490cb386a000017,57ca214a1bc8e0877b000014,57ca39359490cb386a000019","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c7c51b9490cbe42c000040,57c5a6a57f780be067005f40,57c6616e1bc8e02a720000d8,57c908951bc8e0a111000018,57c7c5e21bc8e03d4e00004d,57c8311a7f780bf00f000851","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c831207f780bf00f000853,57c8311d7f780bf00f000852,57ca035c7f780b1411000380,57c7c3e49490cb0b55000003,57c7c07c9490cbca2c00003a,57c7c07c9490cbca2c00003e","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57c554b49490cb8613000068,57c7c07c9490cbca2c00003f,57c7c5b69490cbf12c00003f,57c95fa39490cb0c18000065,57c8f4949490cbe35a000011,57c8e55e9490cb8b0f000018","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c913999490cbf81700004c,57c913999490cbf81700004b,57c9130e9490cba76c000004,57c913999490cbf81700004d,57c913999490cbf81700004a,57c9130e9490cba76c000006","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}}],"article_block_colors":["#23283e","#23283e"],"only_text_page_bgcolors":["#23283e","#23283e"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11195.png?1395915550","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11195.png?1395915550","hidden_time":"24","need_userinfo":"NO","block_title":"投资理财","block_color":"#23283e","desktop_color_number":"0","use_original_icon":"N"}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=11195&since_date=1472795406&nt=1&_appid=androidphone
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=11195&need_app_integration=0
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=11195&ids=54dde63f9490cbbf07000101&k=201609031510
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/11195.png?1395915550
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/11195.png?1395915550
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 投资理财
         * block_color : #23283e
         * desktop_color_number : 0
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57c7c51b9490cbe42c000040
         * title : 你不得不知道的六个家庭理财常识
         * date : 2016-09-03 02:15:43
         * auther_name : MBA智库
         * page : 3
         * index : 1
         * weburl : http://iphone.myzaker.com/l.php?l=57c7c51b9490cbe42c000040
         * thumbnail_pic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2YTBiMjFiYzhlMDJiMjEwMDAwMDRfNjQwLmpwZw==_1242.jpg
         * thumbnail_mpic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2YTBiMjFiYzhlMDJiMjEwMDAwMDRfNjQwLmpwZw==_1242.jpg
         * thumbnail_picsize : 640,418
         * media_count : 0
         * is_full : NO
         * content :
         * special_info : {"show_jingcai":"Y","list_nodsp":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11195&pk=57c7c51b9490cbe42c000040&m=1472886430
         * list_dtime : 2016-09-03 02:15:43
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 1
             * articles : 57c7bf949490cbc82c000026,57ca709e9490cb493f00003c,57ca709e9490cb493f00003b,57ca709e9490cb493f00003a,57c26d461bc8e08d14000002,57c316d07f780be0670050d6
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES"}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/11195.png?1418971077
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String is_full;
            private String content;
            /**
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String show_jingcai;
                private String list_nodsp;

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }
            }
        }
    }
}
