package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/3.
 */
public class Bean_luxuty {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=1067&since_date=1472601400&nt=1&next_aticle_id=57c8f3839490cb3f18000023&_appid=androidphone&opage=2&otimestamp=174","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=1067&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=1067&ids=5642f2aa9490cbb13200000e,51a7109f81853dc24d00014d&k=201609031420"},"catalog":"","articles":[{"pk":"57c613f69490cbe24a000008","title":"徐子淇追星行头50W都拦不住！","date":"2016-09-03 05:55:00","auther_name":"YOKA服饰美容","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c613f69490cbe24a000008","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMDQxMl82NjYyMF9XNjQwSDM2MFM2NDk2My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMDQxMl82NjYyMF9XNjQwSDM2MFM2NDk2My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c613f69490cbe24a000008&m=1472883906","list_dtime":"2016-09-03 05:55:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c941239490cb2318000060","title":"活跃在 Instagram 上的特色喝咖啡体验","date":"2016-09-03 12:07:58","auther_name":"果库","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c941239490cb2318000060","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c93c491bc8e0ab38000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c93c491bc8e0ab38000000_320.jpg","thumbnail_picsize":"900,499","media_count":"84","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c941239490cb2318000060&m=1472883906","list_dtime":"2016-09-03 12:07:58"},{"pk":"57c4d1861bc8e0776f000006","title":"好想活成她！名媛奥利维亚的童话生活","date":"2016-09-03 06:00:00","auther_name":"GQ男士网","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c4d1861bc8e0776f000006","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MDQ3MF8xNjY4OF9XNjQwSDM2MFM0MTY1OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MDQ3MF8xNjY4OF9XNjQwSDM2MFM0MTY1OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"20","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c4d1861bc8e0776f000006&m=1472883906","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c6dc7a7f780bf00f000191","title":"小白鞋只算基础单品，今年麂皮鞋是主角","date":"2016-09-03 06:00:00","auther_name":"TOPMEN","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c6dc7a7f780bf00f000191","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MDM5M181NzU5NF9XNjQwSDM2MFM0NTc5Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MDM5M181NzU5NF9XNjQwSDM2MFM0NTc5Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"52","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c6dc7a7f780bf00f000191&m=1472883906","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c9b5a77f780b1411000196","title":"从柯震东的西装看穿明星借衣服的门道","date":"2016-09-03 12:05:47","auther_name":"商务范","weburl":"http://iphone.myzaker.com/l.php?l=57c9b5a77f780b1411000196","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9b5a87f52e95c530001ae_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9b5a87f52e95c530001ae_320.jpg","thumbnail_picsize":"435,539","media_count":"34","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c9b5a77f780b1411000196&m=1472883810","list_dtime":"2016-09-03 12:05:47"},{"pk":"57bc71b47f780be06700289a","title":"还说男人不性感？这些发型性感你一脸","date":"2016-09-03 06:00:00","auther_name":"TOPMEN","weburl":"http://iphone.myzaker.com/l.php?l=57bc71b47f780be06700289a","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57bc3c807f52e9920800010b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bc3c807f52e9920800010b_320.jpg","thumbnail_picsize":"500,465","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57bc71b47f780be06700289a&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c7a6989490cbdf2c00004d","title":"没想到印度超模王妃还是个颜值担当！","date":"2016-09-03 06:00:00","auther_name":"YOKA时尚网","weburl":"http://iphone.myzaker.com/l.php?l=57c7a6989490cbdf2c00004d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a6a37f52e94d570000ea_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a6a37f52e94d570000ea_320.jpg","thumbnail_picsize":"600,700","media_count":"34","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7a6989490cbdf2c00004d&m=1472883810","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57bf5e2d7f780be067003dd3","title":"为什么我喜欢在不同的酒店捡肥皂?","date":"2016-09-03 06:00:00","auther_name":"屌私型格","weburl":"http://iphone.myzaker.com/l.php?l=57bf5e2d7f780be067003dd3","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57bf5e2e7f52e97b6d00000e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bf5e2e7f52e97b6d00000e_320.jpg","thumbnail_picsize":"400,223","media_count":"24","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57bf5e2d7f780be067003dd3&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c7c3ef9490cb1865000010","title":"朱丹也爱上了CELINE的阔腿裤，美","date":"2016-09-03 06:00:00","auther_name":"凤凰时尚识装","weburl":"http://iphone.myzaker.com/l.php?l=57c7c3ef9490cb1865000010","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c69fe71bc8e0e91f000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c69fe71bc8e0e91f000000_320.jpg","thumbnail_picsize":"600,899","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7c3ef9490cb1865000010&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c93e491bc8e0083800001c","title":"奥巴马在卸任前找了份兼职，新工作是编辑","date":"2016-09-03 12:10:18","auther_name":"GQ男士网","weburl":"http://iphone.myzaker.com/l.php?l=57c93e491bc8e0083800001c","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c93d451bc8e0a838000045_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c93d451bc8e0a838000045_320.jpg","thumbnail_picsize":"1280,1919","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c93e491bc8e0083800001c&m=1472883809","list_dtime":"2016-09-03 12:10:18"},{"pk":"57ca4dad9490cbf33e00001f","title":"Hot Toys：把手办做成奢侈品 ","title_line_break":"Hot Toys：\n把手办做成奢侈品 ","date":"2016-09-03 12:11:54","auther_name":"芭莎男士","weburl":"http://iphone.myzaker.com/l.php?l=57ca4dad9490cbf33e00001f","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca4dbba07aecc5230083c6_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca4dbba07aecc5230083c6_320.jpg","thumbnail_picsize":"640,427","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57ca4dad9490cbf33e00001f&m=1472883809","list_dtime":"2016-09-03 12:11:54"},{"pk":"57c7c4259490cba62c000048","title":"12款手袋 买不起开开眼界也是极好的","title_line_break":"12款手袋\n买不起开开眼界也是极好的","date":"2016-09-03 06:00:00","auther_name":"凤凰时尚识装","weburl":"http://iphone.myzaker.com/l.php?l=57c7c4259490cba62c000048","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57b527241bc8e0e46d00002e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b527241bc8e0e46d00002e_320.jpg","thumbnail_picsize":"600,600","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7c4259490cba62c000048&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57ca12b29490cbcb3e00001c","title":"2017年最值得期待的年历\u201c抢钱\u201d预告","date":"2016-09-03 12:07:21","auther_name":"海报时尚网","weburl":"http://iphone.myzaker.com/l.php?l=57ca12b29490cbcb3e00001c","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c970c61bc8e0915800001c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c970c61bc8e0915800001c_320.jpg","thumbnail_picsize":"600,579","media_count":"53","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57ca12b29490cbcb3e00001c&m=1472883810","list_dtime":"2016-09-03 12:07:21"},{"pk":"57c7a7999490cbb52c000035","title":"素雅高贵，赵薇把珠宝戴出低调美","date":"2016-09-03 06:00:00","auther_name":"YOKA时尚网","weburl":"http://iphone.myzaker.com/l.php?l=57c7a7999490cbb52c000035","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a7a57f52e9986a000067_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a7a57f52e9986a000067_320.jpg","thumbnail_picsize":"600,600","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7a7999490cbb52c000035&m=1472883810","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c582a57f780be067005daf","title":"发型：脸型作参考，发型零烦恼","title_line_break":"发型：\n脸型作参考，发型零烦恼","date":"2016-09-03 03:00:00","auther_name":"TOPMEN","weburl":"http://iphone.myzaker.com/l.php?l=57c582a57f780be067005daf","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMDk1M18xNDg5X1c2NDBIMzYwUzM3NzA3LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMDk1M18xNDg5X1c2NDBIMzYwUzM3NzA3LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c582a57f780be067005daf&m=1472883811","list_dtime":"2016-09-03 03:00:00"},{"pk":"57c944869490cb3718000075","title":"有一种撩人，叫抽着烟并帅你一脸的型男","date":"2016-09-03 06:00:00","auther_name":"潮库","weburl":"http://iphone.myzaker.com/l.php?l=57c944869490cb3718000075","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c897c47f52e9bd5c000064_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c897c47f52e9bd5c000064_320.jpg","thumbnail_picsize":"1280,854","media_count":"46","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c944869490cb3718000075&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c7a86f9490cbd52c000031","title":"全世界最精彩的婚礼在哪里，当然在王室","date":"2016-09-03 06:00:00","auther_name":"YOKA服饰美容","weburl":"http://iphone.myzaker.com/l.php?l=57c7a86f9490cbd52c000031","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c78dd21bc8e0252900000c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c78dd21bc8e0252900000c_320.jpg","thumbnail_picsize":"640,886","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7a86f9490cbd52c000031&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c7a2e39490cbde2c00003d","title":"才不好好穿西装，把西装穿出运动风","date":"2016-09-03 06:00:00","auther_name":"芭莎男士","weburl":"http://iphone.myzaker.com/l.php?l=57c7a2e39490cbde2c00003d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a2f27f52e94d5700006a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a2f27f52e94d5700006a_320.jpg","thumbnail_picsize":"1013,762","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7a2e39490cbde2c00003d&m=1472883810","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c7a86e9490cbd52c000030","title":"王室一家不愧是英\u201c格\u201d兰的最好演绎者","date":"2016-09-03 06:00:00","auther_name":"凤凰时尚识装","weburl":"http://iphone.myzaker.com/l.php?l=57c7a86e9490cbd52c000030","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a20e1bc8e01b3400000c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a20e1bc8e01b3400000c_320.jpg","thumbnail_picsize":"480,719","media_count":"27","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7a86e9490cbd52c000030&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c46c9d7f780be06700589d","title":"为什么全世界还尊称他为「流行之王」?","date":"2016-09-03 06:00:00","auther_name":"屌私型格","weburl":"http://iphone.myzaker.com/l.php?l=57c46c9d7f780be06700589d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c46c9e7f52e9131d00015a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c46c9e7f52e9131d00015a_320.jpg","thumbnail_picsize":"640,356","media_count":"29","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=1067&pk=57c46c9d7f780be06700589d&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c46c9d7f780be06700589d%26app_id%3D1067%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c46c9d7f780be06700589d&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c3d1399490cb2f73000078","title":"辣法，米白色的，传说，仅此一辆！","date":"2016-09-03 06:00:00","auther_name":"跑车网","weburl":"http://iphone.myzaker.com/l.php?l=57c3d1399490cb2f73000078","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57bf24f17f52e9c83b000518_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bf24f17f52e9c83b000518_320.jpg","thumbnail_picsize":"600,416","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c3d1399490cb2f73000078&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c6a9201bc8e0d122000038","title":"单色调之美　三款纯黑色腕表推荐","title_line_break":"单色调之美\n三款纯黑色腕表推荐","date":"2016-09-03 06:00:00","auther_name":"腕表之家","weburl":"http://iphone.myzaker.com/l.php?l=57c6a9201bc8e0d122000038","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6a91f1bc8e0d122000035_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6a91f1bc8e0d122000035_320.jpg","thumbnail_picsize":"700,450","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c6a9201bc8e0d122000038&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c5117a1bc8e04b1a00001f","title":"即使穿上定制西装，也不保证让你好看","date":"2016-09-03 06:00:00","auther_name":"Enjoy雅趣","weburl":"http://iphone.myzaker.com/l.php?l=57c5117a1bc8e04b1a00001f","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c50c021bc8e06816000084_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c50c021bc8e06816000084_320.jpg","thumbnail_picsize":"600,400","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c5117a1bc8e04b1a00001f&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c406ff1bc8e0936e000037","title":"赛道上的灵魂 几款腕表给你速度与激情","title_line_break":"赛道上的灵魂\n几款腕表给你速度与激情","date":"2016-09-03 06:00:00","auther_name":"腕表之家","weburl":"http://iphone.myzaker.com/l.php?l=57c406ff1bc8e0936e000037","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c406fe1bc8e0936e000034_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c406fe1bc8e0936e000034_320.jpg","thumbnail_picsize":"700,450","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c406ff1bc8e0936e000037&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c7ff149490cb7b2c000083","title":"抓住夏天的尾巴，来杯冰咖啡","date":"2016-09-03 06:00:00","auther_name":"ELLEMEN睿士","weburl":"http://iphone.myzaker.com/l.php?l=57c7ff149490cb7b2c000083","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6eff81bc8e00056000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6eff81bc8e00056000001_320.jpg","thumbnail_picsize":"893,521","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7ff149490cb7b2c000083&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c4d1811bc8e0776f000001","title":"还没吃过鸡尾酒冰棒?","date":"2016-09-03 06:00:00","auther_name":"GQ男士网","weburl":"http://iphone.myzaker.com/l.php?l=57c4d1811bc8e0776f000001","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c4cbfa1bc8e0bf69000121_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c4cbfa1bc8e0bf69000121_320.jpg","thumbnail_picsize":"425,500","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c4d1811bc8e0776f000001&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57bd529c9490cb9b51000014","title":"他是水原希子现男友、日剧当红小生","date":"2016-09-02 17:13:22","auther_name":"YOHO潮流志","weburl":"http://iphone.myzaker.com/l.php?l=57bd529c9490cb9b51000014","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57bc336c7f52e9ae08000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bc336c7f52e9ae08000000_320.jpg","thumbnail_picsize":"640,425","media_count":"40","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57bd529c9490cb9b51000014&m=1472807766","list_dtime":"2016-09-02 17:13:22"},{"pk":"57c941239490cb2318000061","title":"初秋将至，该为你的衣橱添几件针织衫了","date":"2016-09-02 17:09:28","auther_name":"果库","weburl":"http://iphone.myzaker.com/l.php?l=57c941239490cb2318000061","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c911b91bc8e04e16000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c911b91bc8e04e16000011_320.jpg","thumbnail_picsize":"900,499","media_count":"96","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c941239490cb2318000061&m=1472807415","list_dtime":"2016-09-02 17:09:28"},{"pk":"57bfb2dd9490cb5d6000005c","title":"大牌经典手袋 在这一季都变得年轻时髦","title_line_break":"大牌经典手袋\n在这一季都变得年轻时髦","date":"2016-09-02 17:13:01","auther_name":"VOGUE中国","weburl":"http://iphone.myzaker.com/l.php?l=57bfb2dd9490cb5d6000005c","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwNDY5N18zMzM2NV9XNjQwSDM2MFM0MDgwMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwNDY5N18zMzM2NV9XNjQwSDM2MFM0MDgwMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"55","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57bfb2dd9490cb5d6000005c&m=1472807831","list_dtime":"2016-09-02 17:13:01","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c7cbcf9490cbf12c000042","title":"余文乐屹立潮流界不倒的6大原因","date":"2016-09-02 18:12:32","auther_name":"YOKA男士网","weburl":"http://iphone.myzaker.com/l.php?l=57c7cbcf9490cbf12c000042","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7cbe5a07aecf77e046eb7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7cbe5a07aecf77e046eb7_320.jpg","thumbnail_picsize":"640,480","media_count":"24","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7cbcf9490cbf12c000042&m=1472811340","list_dtime":"2016-09-02 18:12:32"},{"pk":"57c93cba9490cbfe17000069","title":"年薪百万的本科生是怎样生活的？","date":"2016-09-02 16:48:43","auther_name":"于小戈","weburl":"http://iphone.myzaker.com/l.php?l=57c93cba9490cbfe17000069","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c666417f52e9225e00017c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c666417f52e9225e00017c_320.jpg","thumbnail_picsize":"640,460","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c93cba9490cbfe17000069&m=1472806252","list_dtime":"2016-09-02 16:48:43"},{"pk":"57c931757f780bf00f000e83","title":"能阻止这品牌成为日本Supreme的只有时间","date":"2016-09-02 17:11:15","auther_name":"Steppy潮流周志","weburl":"http://iphone.myzaker.com/l.php?l=57c931757f780bf00f000e83","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M5MmU0MzdmNTJlOWU4MWYwMDAwYjRfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M5MmU0MzdmNTJlOWU4MWYwMDAwYjRfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"21","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=1067&pk=57c931757f780bf00f000e83&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c931757f780bf00f000e83%26app_id%3D1067%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c931757f780bf00f000e83&m=1472883811","list_dtime":"2016-09-02 17:11:15"},{"pk":"57c93e461bc8e0083800001a","title":"重获新生的双排扣西服外套","date":"2016-09-02 17:12:30","auther_name":"GQ男士网","weburl":"http://iphone.myzaker.com/l.php?l=57c93e461bc8e0083800001a","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c93d431bc8e0a838000037_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c93d431bc8e0a838000037_320.jpg","thumbnail_picsize":"790,790","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c93e461bc8e0083800001a&m=1472807752","list_dtime":"2016-09-02 17:12:30"},{"pk":"57c941849490cbd91700007d","title":"马克·吕布，你在乱世中定格了优雅","date":"2016-09-02 17:23:00","auther_name":"好奇心日报","weburl":"http://iphone.myzaker.com/l.php?l=57c941849490cbd91700007d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8ddca1bc8e0f076000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8ddca1bc8e0f076000000_320.jpg","thumbnail_picsize":"640,380","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c941849490cbd91700007d&m=1472808359","list_dtime":"2016-09-02 17:23:00"},{"pk":"57c941849490cbd91700007c","title":"日本淡路岛的旅游营销，是看谁哭得美","date":"2016-09-02 17:09:02","auther_name":"好奇心日报","weburl":"http://iphone.myzaker.com/l.php?l=57c941849490cbd91700007c","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c92ade1bc8e09929000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c92ade1bc8e09929000007_320.jpg","thumbnail_picsize":"640,380","media_count":"2","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=1067&pk=57c941849490cbd91700007c&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c941849490cbd91700007c%26app_id%3D1067%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c941849490cbd91700007c&m=1472883811","list_dtime":"2016-09-02 17:09:02"},{"pk":"57c7fe571bc8e0e573000006","title":"顶级入门款 宁要凤尾不要鸡头的几款腕表","title_line_break":"顶级入门款\n宁要凤尾不要鸡头的几款腕表","date":"2016-09-02 10:28:40","auther_name":"腕表之家","weburl":"http://iphone.myzaker.com/l.php?l=57c7fe571bc8e0e573000006","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7f9df1bc8e07e72000037_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7f9df1bc8e07e72000037_320.jpg","thumbnail_picsize":"700,450","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7fe571bc8e0e573000006&m=1472793598","list_dtime":"2016-09-02 10:28:40"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c613f69490cbe24a000008,57c9b5a77f780b1411000196,57bc71b47f780be06700289a,57c7a6989490cbdf2c00004d,57bf5e2d7f780be067003dd3,57c7c3ef9490cb1865000010","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c6dc7a7f780bf00f000191,57c93e491bc8e0083800001c,57ca4dad9490cbf33e00001f,57c7c4259490cba62c000048,57ca12b29490cbcb3e00001c,57c7a7999490cbb52c000035","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c941239490cb2318000060,57c4d1861bc8e0776f000006,57c582a57f780be067005daf,57c944869490cb3718000075,57c7a86f9490cbd52c000031,57c7a2e39490cbde2c00003d","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c46c9d7f780be06700589d,57c7a86e9490cbd52c000030,57c3d1399490cb2f73000078,57c6a9201bc8e0d122000038,57c5117a1bc8e04b1a00001f,57c406ff1bc8e0936e000037","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c4d1811bc8e0776f000001,57c7ff149490cb7b2c000083,57bd529c9490cb9b51000014,57c941239490cb2318000061,57bfb2dd9490cb5d6000005c,57c7cbcf9490cbf12c000042","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c931757f780bf00f000e83,57c93cba9490cbfe17000069,57c93e461bc8e0083800001a,57c941849490cbd91700007d,57c941849490cbd91700007c,57c7fe571bc8e0e573000006","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#262626","#262626"],"only_text_page_bgcolors":["#262626","#262626"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/1067.png?t=1460715585","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/1067.png?t=1460715585","hidden_time":"24","need_userinfo":"NO","block_title":"奢侈品频道","block_color":"#262626","desktop_color_number":"12","use_original_icon":"N"}}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=1067&since_date=1472601400&nt=1&next_aticle_id=57c8f3839490cb3f18000023&_appid=androidphone&opage=2&otimestamp=174","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=1067&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=1067&ids=5642f2aa9490cbb13200000e,51a7109f81853dc24d00014d&k=201609031420"}
     * catalog :
     * articles : [{"pk":"57c613f69490cbe24a000008","title":"徐子淇追星行头50W都拦不住！","date":"2016-09-03 05:55:00","auther_name":"YOKA服饰美容","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c613f69490cbe24a000008","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMDQxMl82NjYyMF9XNjQwSDM2MFM2NDk2My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMDQxMl82NjYyMF9XNjQwSDM2MFM2NDk2My5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c613f69490cbe24a000008&m=1472883906","list_dtime":"2016-09-03 05:55:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c941239490cb2318000060","title":"活跃在 Instagram 上的特色喝咖啡体验","date":"2016-09-03 12:07:58","auther_name":"果库","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c941239490cb2318000060","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c93c491bc8e0ab38000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c93c491bc8e0ab38000000_320.jpg","thumbnail_picsize":"900,499","media_count":"84","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c941239490cb2318000060&m=1472883906","list_dtime":"2016-09-03 12:07:58"},{"pk":"57c4d1861bc8e0776f000006","title":"好想活成她！名媛奥利维亚的童话生活","date":"2016-09-03 06:00:00","auther_name":"GQ男士网","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c4d1861bc8e0776f000006","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MDQ3MF8xNjY4OF9XNjQwSDM2MFM0MTY1OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MDQ3MF8xNjY4OF9XNjQwSDM2MFM0MTY1OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"20","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c4d1861bc8e0776f000006&m=1472883906","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c6dc7a7f780bf00f000191","title":"小白鞋只算基础单品，今年麂皮鞋是主角","date":"2016-09-03 06:00:00","auther_name":"TOPMEN","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c6dc7a7f780bf00f000191","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MDM5M181NzU5NF9XNjQwSDM2MFM0NTc5Ni5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MDM5M181NzU5NF9XNjQwSDM2MFM0NTc5Ni5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"52","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c6dc7a7f780bf00f000191&m=1472883906","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c9b5a77f780b1411000196","title":"从柯震东的西装看穿明星借衣服的门道","date":"2016-09-03 12:05:47","auther_name":"商务范","weburl":"http://iphone.myzaker.com/l.php?l=57c9b5a77f780b1411000196","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9b5a87f52e95c530001ae_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9b5a87f52e95c530001ae_320.jpg","thumbnail_picsize":"435,539","media_count":"34","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c9b5a77f780b1411000196&m=1472883810","list_dtime":"2016-09-03 12:05:47"},{"pk":"57bc71b47f780be06700289a","title":"还说男人不性感？这些发型性感你一脸","date":"2016-09-03 06:00:00","auther_name":"TOPMEN","weburl":"http://iphone.myzaker.com/l.php?l=57bc71b47f780be06700289a","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57bc3c807f52e9920800010b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bc3c807f52e9920800010b_320.jpg","thumbnail_picsize":"500,465","media_count":"26","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57bc71b47f780be06700289a&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c7a6989490cbdf2c00004d","title":"没想到印度超模王妃还是个颜值担当！","date":"2016-09-03 06:00:00","auther_name":"YOKA时尚网","weburl":"http://iphone.myzaker.com/l.php?l=57c7a6989490cbdf2c00004d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a6a37f52e94d570000ea_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a6a37f52e94d570000ea_320.jpg","thumbnail_picsize":"600,700","media_count":"34","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7a6989490cbdf2c00004d&m=1472883810","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57bf5e2d7f780be067003dd3","title":"为什么我喜欢在不同的酒店捡肥皂?","date":"2016-09-03 06:00:00","auther_name":"屌私型格","weburl":"http://iphone.myzaker.com/l.php?l=57bf5e2d7f780be067003dd3","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57bf5e2e7f52e97b6d00000e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bf5e2e7f52e97b6d00000e_320.jpg","thumbnail_picsize":"400,223","media_count":"24","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57bf5e2d7f780be067003dd3&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c7c3ef9490cb1865000010","title":"朱丹也爱上了CELINE的阔腿裤，美","date":"2016-09-03 06:00:00","auther_name":"凤凰时尚识装","weburl":"http://iphone.myzaker.com/l.php?l=57c7c3ef9490cb1865000010","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c69fe71bc8e0e91f000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c69fe71bc8e0e91f000000_320.jpg","thumbnail_picsize":"600,899","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7c3ef9490cb1865000010&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c93e491bc8e0083800001c","title":"奥巴马在卸任前找了份兼职，新工作是编辑","date":"2016-09-03 12:10:18","auther_name":"GQ男士网","weburl":"http://iphone.myzaker.com/l.php?l=57c93e491bc8e0083800001c","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c93d451bc8e0a838000045_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c93d451bc8e0a838000045_320.jpg","thumbnail_picsize":"1280,1919","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c93e491bc8e0083800001c&m=1472883809","list_dtime":"2016-09-03 12:10:18"},{"pk":"57ca4dad9490cbf33e00001f","title":"Hot Toys：把手办做成奢侈品 ","title_line_break":"Hot Toys：\n把手办做成奢侈品 ","date":"2016-09-03 12:11:54","auther_name":"芭莎男士","weburl":"http://iphone.myzaker.com/l.php?l=57ca4dad9490cbf33e00001f","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca4dbba07aecc5230083c6_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca4dbba07aecc5230083c6_320.jpg","thumbnail_picsize":"640,427","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57ca4dad9490cbf33e00001f&m=1472883809","list_dtime":"2016-09-03 12:11:54"},{"pk":"57c7c4259490cba62c000048","title":"12款手袋 买不起开开眼界也是极好的","title_line_break":"12款手袋\n买不起开开眼界也是极好的","date":"2016-09-03 06:00:00","auther_name":"凤凰时尚识装","weburl":"http://iphone.myzaker.com/l.php?l=57c7c4259490cba62c000048","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57b527241bc8e0e46d00002e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57b527241bc8e0e46d00002e_320.jpg","thumbnail_picsize":"600,600","media_count":"12","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7c4259490cba62c000048&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57ca12b29490cbcb3e00001c","title":"2017年最值得期待的年历\u201c抢钱\u201d预告","date":"2016-09-03 12:07:21","auther_name":"海报时尚网","weburl":"http://iphone.myzaker.com/l.php?l=57ca12b29490cbcb3e00001c","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c970c61bc8e0915800001c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c970c61bc8e0915800001c_320.jpg","thumbnail_picsize":"600,579","media_count":"53","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57ca12b29490cbcb3e00001c&m=1472883810","list_dtime":"2016-09-03 12:07:21"},{"pk":"57c7a7999490cbb52c000035","title":"素雅高贵，赵薇把珠宝戴出低调美","date":"2016-09-03 06:00:00","auther_name":"YOKA时尚网","weburl":"http://iphone.myzaker.com/l.php?l=57c7a7999490cbb52c000035","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a7a57f52e9986a000067_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a7a57f52e9986a000067_320.jpg","thumbnail_picsize":"600,600","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7a7999490cbb52c000035&m=1472883810","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c582a57f780be067005daf","title":"发型：脸型作参考，发型零烦恼","title_line_break":"发型：\n脸型作参考，发型零烦恼","date":"2016-09-03 03:00:00","auther_name":"TOPMEN","weburl":"http://iphone.myzaker.com/l.php?l=57c582a57f780be067005daf","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMDk1M18xNDg5X1c2NDBIMzYwUzM3NzA3LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMDk1M18xNDg5X1c2NDBIMzYwUzM3NzA3LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"11","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c582a57f780be067005daf&m=1472883811","list_dtime":"2016-09-03 03:00:00"},{"pk":"57c944869490cb3718000075","title":"有一种撩人，叫抽着烟并帅你一脸的型男","date":"2016-09-03 06:00:00","auther_name":"潮库","weburl":"http://iphone.myzaker.com/l.php?l=57c944869490cb3718000075","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c897c47f52e9bd5c000064_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c897c47f52e9bd5c000064_320.jpg","thumbnail_picsize":"1280,854","media_count":"46","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c944869490cb3718000075&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c7a86f9490cbd52c000031","title":"全世界最精彩的婚礼在哪里，当然在王室","date":"2016-09-03 06:00:00","auther_name":"YOKA服饰美容","weburl":"http://iphone.myzaker.com/l.php?l=57c7a86f9490cbd52c000031","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c78dd21bc8e0252900000c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c78dd21bc8e0252900000c_320.jpg","thumbnail_picsize":"640,886","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7a86f9490cbd52c000031&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c7a2e39490cbde2c00003d","title":"才不好好穿西装，把西装穿出运动风","date":"2016-09-03 06:00:00","auther_name":"芭莎男士","weburl":"http://iphone.myzaker.com/l.php?l=57c7a2e39490cbde2c00003d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a2f27f52e94d5700006a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a2f27f52e94d5700006a_320.jpg","thumbnail_picsize":"1013,762","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7a2e39490cbde2c00003d&m=1472883810","list_dtime":"2016-09-03 06:00:00","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c7a86e9490cbd52c000030","title":"王室一家不愧是英\u201c格\u201d兰的最好演绎者","date":"2016-09-03 06:00:00","auther_name":"凤凰时尚识装","weburl":"http://iphone.myzaker.com/l.php?l=57c7a86e9490cbd52c000030","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7a20e1bc8e01b3400000c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7a20e1bc8e01b3400000c_320.jpg","thumbnail_picsize":"480,719","media_count":"27","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7a86e9490cbd52c000030&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c46c9d7f780be06700589d","title":"为什么全世界还尊称他为「流行之王」?","date":"2016-09-03 06:00:00","auther_name":"屌私型格","weburl":"http://iphone.myzaker.com/l.php?l=57c46c9d7f780be06700589d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c46c9e7f52e9131d00015a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c46c9e7f52e9131d00015a_320.jpg","thumbnail_picsize":"640,356","media_count":"29","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=1067&pk=57c46c9d7f780be06700589d&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c46c9d7f780be06700589d%26app_id%3D1067%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c46c9d7f780be06700589d&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c3d1399490cb2f73000078","title":"辣法，米白色的，传说，仅此一辆！","date":"2016-09-03 06:00:00","auther_name":"跑车网","weburl":"http://iphone.myzaker.com/l.php?l=57c3d1399490cb2f73000078","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57bf24f17f52e9c83b000518_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bf24f17f52e9c83b000518_320.jpg","thumbnail_picsize":"600,416","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c3d1399490cb2f73000078&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c6a9201bc8e0d122000038","title":"单色调之美　三款纯黑色腕表推荐","title_line_break":"单色调之美\n三款纯黑色腕表推荐","date":"2016-09-03 06:00:00","auther_name":"腕表之家","weburl":"http://iphone.myzaker.com/l.php?l=57c6a9201bc8e0d122000038","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6a91f1bc8e0d122000035_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6a91f1bc8e0d122000035_320.jpg","thumbnail_picsize":"700,450","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c6a9201bc8e0d122000038&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c5117a1bc8e04b1a00001f","title":"即使穿上定制西装，也不保证让你好看","date":"2016-09-03 06:00:00","auther_name":"Enjoy雅趣","weburl":"http://iphone.myzaker.com/l.php?l=57c5117a1bc8e04b1a00001f","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c50c021bc8e06816000084_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c50c021bc8e06816000084_320.jpg","thumbnail_picsize":"600,400","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c5117a1bc8e04b1a00001f&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c406ff1bc8e0936e000037","title":"赛道上的灵魂 几款腕表给你速度与激情","title_line_break":"赛道上的灵魂\n几款腕表给你速度与激情","date":"2016-09-03 06:00:00","auther_name":"腕表之家","weburl":"http://iphone.myzaker.com/l.php?l=57c406ff1bc8e0936e000037","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c406fe1bc8e0936e000034_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c406fe1bc8e0936e000034_320.jpg","thumbnail_picsize":"700,450","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c406ff1bc8e0936e000037&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c7ff149490cb7b2c000083","title":"抓住夏天的尾巴，来杯冰咖啡","date":"2016-09-03 06:00:00","auther_name":"ELLEMEN睿士","weburl":"http://iphone.myzaker.com/l.php?l=57c7ff149490cb7b2c000083","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6eff81bc8e00056000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6eff81bc8e00056000001_320.jpg","thumbnail_picsize":"893,521","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7ff149490cb7b2c000083&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57c4d1811bc8e0776f000001","title":"还没吃过鸡尾酒冰棒?","date":"2016-09-03 06:00:00","auther_name":"GQ男士网","weburl":"http://iphone.myzaker.com/l.php?l=57c4d1811bc8e0776f000001","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c4cbfa1bc8e0bf69000121_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c4cbfa1bc8e0bf69000121_320.jpg","thumbnail_picsize":"425,500","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c4d1811bc8e0776f000001&m=1472883810","list_dtime":"2016-09-03 06:00:00"},{"pk":"57bd529c9490cb9b51000014","title":"他是水原希子现男友、日剧当红小生","date":"2016-09-02 17:13:22","auther_name":"YOHO潮流志","weburl":"http://iphone.myzaker.com/l.php?l=57bd529c9490cb9b51000014","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57bc336c7f52e9ae08000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57bc336c7f52e9ae08000000_320.jpg","thumbnail_picsize":"640,425","media_count":"40","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57bd529c9490cb9b51000014&m=1472807766","list_dtime":"2016-09-02 17:13:22"},{"pk":"57c941239490cb2318000061","title":"初秋将至，该为你的衣橱添几件针织衫了","date":"2016-09-02 17:09:28","auther_name":"果库","weburl":"http://iphone.myzaker.com/l.php?l=57c941239490cb2318000061","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c911b91bc8e04e16000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c911b91bc8e04e16000011_320.jpg","thumbnail_picsize":"900,499","media_count":"96","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c941239490cb2318000061&m=1472807415","list_dtime":"2016-09-02 17:09:28"},{"pk":"57bfb2dd9490cb5d6000005c","title":"大牌经典手袋 在这一季都变得年轻时髦","title_line_break":"大牌经典手袋\n在这一季都变得年轻时髦","date":"2016-09-02 17:13:01","auther_name":"VOGUE中国","weburl":"http://iphone.myzaker.com/l.php?l=57bfb2dd9490cb5d6000005c","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwNDY5N18zMzM2NV9XNjQwSDM2MFM0MDgwMS5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MjYvdXBfMTQ3MjIwNDY5N18zMzM2NV9XNjQwSDM2MFM0MDgwMS5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"55","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57bfb2dd9490cb5d6000005c&m=1472807831","list_dtime":"2016-09-02 17:13:01","tpl_info":{"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}},{"pk":"57c7cbcf9490cbf12c000042","title":"余文乐屹立潮流界不倒的6大原因","date":"2016-09-02 18:12:32","auther_name":"YOKA男士网","weburl":"http://iphone.myzaker.com/l.php?l=57c7cbcf9490cbf12c000042","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7cbe5a07aecf77e046eb7_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7cbe5a07aecf77e046eb7_320.jpg","thumbnail_picsize":"640,480","media_count":"24","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7cbcf9490cbf12c000042&m=1472811340","list_dtime":"2016-09-02 18:12:32"},{"pk":"57c93cba9490cbfe17000069","title":"年薪百万的本科生是怎样生活的？","date":"2016-09-02 16:48:43","auther_name":"于小戈","weburl":"http://iphone.myzaker.com/l.php?l=57c93cba9490cbfe17000069","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201608/57c666417f52e9225e00017c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c666417f52e9225e00017c_320.jpg","thumbnail_picsize":"640,460","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c93cba9490cbfe17000069&m=1472806252","list_dtime":"2016-09-02 16:48:43"},{"pk":"57c931757f780bf00f000e83","title":"能阻止这品牌成为日本Supreme的只有时间","date":"2016-09-02 17:11:15","auther_name":"Steppy潮流周志","weburl":"http://iphone.myzaker.com/l.php?l=57c931757f780bf00f000e83","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M5MmU0MzdmNTJlOWU4MWYwMDAwYjRfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M5MmU0MzdmNTJlOWU4MWYwMDAwYjRfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"21","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=1067&pk=57c931757f780bf00f000e83&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c931757f780bf00f000e83%26app_id%3D1067%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c931757f780bf00f000e83&m=1472883811","list_dtime":"2016-09-02 17:11:15"},{"pk":"57c93e461bc8e0083800001a","title":"重获新生的双排扣西服外套","date":"2016-09-02 17:12:30","auther_name":"GQ男士网","weburl":"http://iphone.myzaker.com/l.php?l=57c93e461bc8e0083800001a","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c93d431bc8e0a838000037_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c93d431bc8e0a838000037_320.jpg","thumbnail_picsize":"790,790","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c93e461bc8e0083800001a&m=1472807752","list_dtime":"2016-09-02 17:12:30"},{"pk":"57c941849490cbd91700007d","title":"马克·吕布，你在乱世中定格了优雅","date":"2016-09-02 17:23:00","auther_name":"好奇心日报","weburl":"http://iphone.myzaker.com/l.php?l=57c941849490cbd91700007d","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8ddca1bc8e0f076000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8ddca1bc8e0f076000000_320.jpg","thumbnail_picsize":"640,380","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c941849490cbd91700007d&m=1472808359","list_dtime":"2016-09-02 17:23:00"},{"pk":"57c941849490cbd91700007c","title":"日本淡路岛的旅游营销，是看谁哭得美","date":"2016-09-02 17:09:02","auther_name":"好奇心日报","weburl":"http://iphone.myzaker.com/l.php?l=57c941849490cbd91700007c","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c92ade1bc8e09929000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c92ade1bc8e09929000007_320.jpg","thumbnail_picsize":"640,380","media_count":"2","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=1067&pk=57c941849490cbd91700007c&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c941849490cbd91700007c%26app_id%3D1067%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c941849490cbd91700007c&m=1472883811","list_dtime":"2016-09-02 17:09:02"},{"pk":"57c7fe571bc8e0e573000006","title":"顶级入门款 宁要凤尾不要鸡头的几款腕表","title_line_break":"顶级入门款\n宁要凤尾不要鸡头的几款腕表","date":"2016-09-02 10:28:40","auther_name":"腕表之家","weburl":"http://iphone.myzaker.com/l.php?l=57c7fe571bc8e0e573000006","tpl_group":"titleCenter","tpl_style":"1","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7f9df1bc8e07e72000037_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7f9df1bc8e07e72000037_320.jpg","thumbnail_picsize":"700,450","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c7fe571bc8e0e573000006&m=1472793598","list_dtime":"2016-09-02 10:28:40"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c613f69490cbe24a000008,57c9b5a77f780b1411000196,57bc71b47f780be06700289a,57c7a6989490cbdf2c00004d,57bf5e2d7f780be067003dd3,57c7c3ef9490cb1865000010","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c6dc7a7f780bf00f000191,57c93e491bc8e0083800001c,57ca4dad9490cbf33e00001f,57c7c4259490cba62c000048,57ca12b29490cbcb3e00001c,57c7a7999490cbb52c000035","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c941239490cb2318000060,57c4d1861bc8e0776f000006,57c582a57f780be067005daf,57c944869490cb3718000075,57c7a86f9490cbd52c000031,57c7a2e39490cbde2c00003d","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c46c9d7f780be06700589d,57c7a86e9490cbd52c000030,57c3d1399490cb2f73000078,57c6a9201bc8e0d122000038,57c5117a1bc8e04b1a00001f,57c406ff1bc8e0936e000037","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57c4d1811bc8e0776f000001,57c7ff149490cb7b2c000083,57bd529c9490cb9b51000014,57c941239490cb2318000061,57bfb2dd9490cb5d6000005c,57c7cbcf9490cbf12c000042","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c931757f780bf00f000e83,57c93cba9490cbfe17000069,57c93e461bc8e0083800001a,57c941849490cbd91700007d,57c941849490cbd91700007c,57c7fe571bc8e0e573000006","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}}],"article_block_colors":["#262626","#262626"],"only_text_page_bgcolors":["#262626","#262626"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/1067.png?t=1460715585","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/1067.png?t=1460715585","hidden_time":"24","need_userinfo":"NO","block_title":"奢侈品频道","block_color":"#262626","desktop_color_number":"12","use_original_icon":"N"}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=1067&since_date=1472601400&nt=1&next_aticle_id=57c8f3839490cb3f18000023&_appid=androidphone&opage=2&otimestamp=174
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=1067&need_app_integration=0
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=1067&ids=5642f2aa9490cbb13200000e,51a7109f81853dc24d00014d&k=201609031420
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/1067.png?t=1460715585
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/1067.png?t=1460715585
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 奢侈品频道
         * block_color : #262626
         * desktop_color_number : 12
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57c613f69490cbe24a000008
         * title : 徐子淇追星行头50W都拦不住！
         * date : 2016-09-03 05:55:00
         * auther_name : YOKA服饰美容
         * page : 1
         * index : 1
         * weburl : http://iphone.myzaker.com/l.php?l=57c613f69490cbe24a000008
         * tpl_group : titleCenter
         * tpl_style : 1
         * thumbnail_pic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMDQxMl82NjYyMF9XNjQwSDM2MFM2NDk2My5qcGc=_1242.jpg
         * thumbnail_mpic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDIvdXBfMTQ3MjgxMDQxMl82NjYyMF9XNjQwSDM2MFM2NDk2My5qcGc=_1242.jpg
         * thumbnail_picsize : 640,360
         * media_count : 14
         * is_full : NO
         * content :
         * special_info : {"show_jingcai":"Y","list_nodsp":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=1067&pk=57c613f69490cbe24a000008&m=1472883906
         * list_dtime : 2016-09-03 05:55:00
         * tpl_info : {"url":"http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403","name":"tpl_02","update":"201606281403"}
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 1
             * articles : 57c613f69490cbe24a000008,57c9b5a77f780b1411000196,57bc71b47f780be06700289a,57c7a6989490cbdf2c00004d,57bf5e2d7f780be067003dd3,57c7c3ef9490cb1865000010
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":""}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/1067.png?t=1460715585
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * open_type :
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String tpl_group;
            private String tpl_style;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String is_full;
            private String content;
            /**
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;
            /**
             * url : http://zkres.myzaker.com/static/tpl/tpl_02.zip?t=201606281403
             * name : tpl_02
             * update : 201606281403
             */

            private TplInfoBean tpl_info;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getTpl_group() {
                return tpl_group;
            }

            public void setTpl_group(String tpl_group) {
                this.tpl_group = tpl_group;
            }

            public String getTpl_style() {
                return tpl_style;
            }

            public void setTpl_style(String tpl_style) {
                this.tpl_style = tpl_style;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public TplInfoBean getTpl_info() {
                return tpl_info;
            }

            public void setTpl_info(TplInfoBean tpl_info) {
                this.tpl_info = tpl_info;
            }

            public static class SpecialInfoBean {
                private String show_jingcai;
                private String list_nodsp;

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }
            }

            public static class TplInfoBean {
                private String url;
                private String name;
                private String update;

                public String getUrl() {
                    return url;
                }

                public void setUrl(String url) {
                    this.url = url;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public String getUpdate() {
                    return update;
                }

                public void setUpdate(String update) {
                    this.update = update;
                }
            }
        }
    }
}
