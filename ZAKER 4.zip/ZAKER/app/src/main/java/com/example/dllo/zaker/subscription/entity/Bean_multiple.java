package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class Bean_multiple {

    /**
     * stat : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=11610&since_date=1472969539&nt=1&_appid=androidphone&catalog_appid=8","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=11610&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=11610&ids=51a7106381853df24c000138&k=201609051430"},"catalog":"","articles":[{"pk":"57cd11089490cb3a7e000044","title":"激动！法国新星：淘汰纳达尔难以置信","title_line_break":"激动！法国新星：\n淘汰纳达尔难以置信","date":"2016-09-05 14:27:55","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd11089490cb3a7e000044","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd110ca07aecc523020007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd110ca07aecc523020007_320.jpg","thumbnail_picsize":"550,379","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd11089490cb3a7e000044&m=1473057048","list_dtime":"2016-09-05 14:27:55"},{"pk":"57cd0e3d9490cb007e00002a","title":"小德完胜英国新星 进八强将战特松加","title_line_break":"小德完胜英国新星\n进八强将战特松加","date":"2016-09-05 14:17:54","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0e3d9490cb007e00002a","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd0c981bc8e0aa7d000077_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd0c981bc8e0aa7d000077_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd0e3d9490cb007e00002a&m=1473056345","list_dtime":"2016-09-05 14:17:54"},{"pk":"57cd0cbd9490cb177e000030","title":"纳达尔输在哪？ACE太少制胜分稍逊","date":"2016-09-05 14:13:28","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0cbd9490cb177e000030","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc8e31bc8e03d5100002d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc8e31bc8e03d5100002d_320.jpg","thumbnail_picsize":"640,427","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd0cbd9490cb177e000030&m=1473056079","list_dtime":"2016-09-05 14:13:28"},{"pk":"57cd0a679490cb6358000022","title":"12年最差成绩单 纳达尔未来在哪？","title_line_break":"12年最差成绩单\n纳达尔未来在哪？","date":"2016-09-05 14:02:15","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0a679490cb6358000022","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc8e21bc8e03d5100002b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc8e21bc8e03d5100002b_320.jpg","thumbnail_picsize":"640,427","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd0a679490cb6358000022&m=1473055284","list_dtime":"2016-09-05 14:02:15"},{"pk":"57cd09629490cb2c7e000048","title":"从大山走到领奖台！蔡泽林银牌沉甸甸","date":"2016-09-05 14:00:36","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd09629490cb2c7e000048","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc8de1bc8e03d51000027_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc8de1bc8e03d51000027_320.jpg","thumbnail_picsize":"400,600","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd09629490cb2c7e000048&m=1473055309","list_dtime":"2016-09-05 14:00:36"},{"pk":"57ccdfcf1bc8e02d0c00001f","title":"论做瑜伽，人类在动物面前真是战五渣","date":"2016-09-05 13:55:23","auther_name":"央广新闻综合","weburl":"http://iphone.myzaker.com/l.php?l=57ccdfcf1bc8e02d0c00001f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvY21zL2FydGljbGVfaW1nLzEyMjYyL3VwXzEyMjYyXzE0NzMwNDQzNzk0ODUuanBn_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvY21zL2FydGljbGVfaW1nLzEyMjYyL3VwXzEyMjYyXzE0NzMwNDQzNzk0ODUuanBn_1242.jpg","thumbnail_picsize":"575,362","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccdfcf1bc8e02d0c00001f&m=1473054927","list_dtime":"2016-09-05 13:55:23"},{"pk":"57cd06389490cb424b000010","title":"等候主人的幽灵自行车：提醒开车人","title_line_break":"等候主人的幽灵自行车：\n提醒开车人","date":"2016-09-05 13:54:35","auther_name":"DUNKHOME","weburl":"http://iphone.myzaker.com/l.php?l=57cd06389490cb424b000010","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd71f1bc8e01859000060_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd71f1bc8e01859000060_320.jpg","thumbnail_picsize":"635,357","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd06389490cb424b000010&m=1473054878","list_dtime":"2016-09-05 13:54:35"},{"pk":"57cd06389490cb424b00000f","title":"改革VS激情：应禁止比赛用功率计？","title_line_break":"改革VS激情：\n应禁止比赛用功率计？","date":"2016-09-05 13:52:01","auther_name":"DUNKHOME","weburl":"http://iphone.myzaker.com/l.php?l=57cd06389490cb424b00000f","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccf9061bc8e0466f00002f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccf9061bc8e0466f00002f_320.jpg","thumbnail_picsize":"840,555","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd06389490cb424b00000f&m=1473054795","list_dtime":"2016-09-05 13:52:01"},{"pk":"57cce2ca9490cb0b7e000029","title":"6红球世锦赛强手如林 中国3球手出战","title_line_break":"6红球世锦赛强手如林\n中国3球手出战","date":"2016-09-05 11:08:54","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce2ca9490cb0b7e000029","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce2cba07aecc52301e869_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce2cba07aecc52301e869_320.jpg","thumbnail_picsize":"550,367","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cce2ca9490cb0b7e000029&m=1473045203","list_dtime":"2016-09-05 11:08:54"},{"pk":"57ccc5291bc8e0474f0000e7","title":"95后冠军又添一员 曾因负女棋手受质疑","title_line_break":"95后冠军又添一员\n曾因负女棋手受质疑","date":"2016-09-05 10:44:29","auther_name":"信息时报","weburl":"http://iphone.myzaker.com/l.php?l=57ccc5291bc8e0474f0000e7","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbfcd1bc8e0d44d00000f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbfcd1bc8e0d44d00000f_320.jpg","thumbnail_picsize":"550,415","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccc5291bc8e0474f0000e7&m=1473043811","list_dtime":"2016-09-05 10:44:29"},{"pk":"57ccbc361bc8e0d14900003c","title":"17岁棋手取代柯洁 成中国最年轻九段","title_line_break":"17岁棋手取代柯洁\n成中国最年轻九段","date":"2016-09-05 10:38:32","auther_name":"信息时报","weburl":"http://iphone.myzaker.com/l.php?l=57ccbc361bc8e0d14900003c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbc361bc8e0d14900003b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbc361bc8e0d14900003b_320.jpg","thumbnail_picsize":"550,366","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccbc361bc8e0d14900003c&m=1473043113","list_dtime":"2016-09-05 10:38:32"},{"pk":"57ccc5271bc8e0474f0000e5","title":"张帅成中国一姐仍不满足：挺让人失望","title_line_break":"张帅成中国一姐仍不满足：\n挺让人失望","date":"2016-09-05 10:35:49","auther_name":"南方都市报","weburl":"http://iphone.myzaker.com/l.php?l=57ccc5271bc8e0474f0000e5","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbfca1bc8e0d44d00000b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbfca1bc8e0d44d00000b_320.jpg","thumbnail_picsize":"350,500","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccc5271bc8e0474f0000e5&m=1473043596","list_dtime":"2016-09-05 10:35:49"},{"pk":"57ccc5281bc8e0474f0000e6","title":"张帅本季大满贯7胜4负 排名稳定前60","title_line_break":"张帅本季大满贯7胜4负\n排名稳定前60","date":"2016-09-05 10:35:36","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccc5281bc8e0474f0000e6","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbfcb1bc8e0d44d00000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbfcb1bc8e0d44d00000d_320.jpg","thumbnail_picsize":"400,266","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccc5281bc8e0474f0000e6&m=1473042938","list_dtime":"2016-09-05 10:35:36"},{"pk":"57cccdd31bc8e0ff56000008","title":"孟菲尔斯挺进8强 或首次入围总决赛","title_line_break":"孟菲尔斯挺进8强\n或首次入围总决赛","date":"2016-09-05 10:32:21","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cccdd31bc8e0ff56000008","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccdd31bc8e0ff56000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccdd31bc8e0ff56000007_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cccdd31bc8e0ff56000008&m=1473042743","list_dtime":"2016-09-05 10:32:21"},{"pk":"57ccbc341bc8e0d149000038","title":"纳达尔决胜盘抢七惜败 爆冷不敌新星","title_line_break":"纳达尔决胜盘抢七惜败\n爆冷不敌新星","date":"2016-09-05 10:30:49","auther_name":"新华网","weburl":"http://iphone.myzaker.com/l.php?l=57ccbc341bc8e0d149000038","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbc341bc8e0d149000037_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbc341bc8e0d149000037_320.jpg","thumbnail_picsize":"550,346","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccbc341bc8e0d149000038&m=1473043025","list_dtime":"2016-09-05 10:30:49"},{"pk":"57ccd6711bc8e0475b000003","title":"女排全锦赛上海夺冠 北京胜天津摘铜","title_line_break":"女排全锦赛上海夺冠\n北京胜天津摘铜","date":"2016-09-05 10:24:54","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd6711bc8e0475b000003","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd6701bc8e0475b000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd6701bc8e0475b000002_320.jpg","thumbnail_picsize":"550,298","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccd6711bc8e0475b000003&m=1473042296","list_dtime":"2016-09-05 10:24:54"},{"pk":"57ccd6701bc8e0475b000001","title":"美网科贝尔完胜科娃 时隔5年重返8强","title_line_break":"美网科贝尔完胜科娃\n时隔5年重返8强","date":"2016-09-05 10:22:38","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd6701bc8e0475b000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd66f1bc8e0475b000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd66f1bc8e0475b000000_320.jpg","thumbnail_picsize":"500,330","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccd6701bc8e0475b000001&m=1473042160","list_dtime":"2016-09-05 10:22:38"},{"pk":"57cccdd01bc8e0ff56000002","title":"沃兹仅7误完胜凯斯 重返美网八强","title_line_break":"沃兹仅7误完胜凯斯\n重返美网八强","date":"2016-09-05 10:20:30","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cccdd01bc8e0ff56000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccdd01bc8e0ff56000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccdd01bc8e0ff56000001_320.jpg","thumbnail_picsize":"500,300","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cccdd01bc8e0ff56000002&m=1473042032","list_dtime":"2016-09-05 10:20:30"},{"pk":"57ccb33a1bc8e09c41000075","title":"特松加苦战4盘胜本土选手 静候小德","title_line_break":"特松加苦战4盘胜本土选手\n静候小德","date":"2016-09-05 08:09:35","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccb33a1bc8e09c41000075","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccadec1bc8e0c64100000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccadec1bc8e0c64100000d_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb33a1bc8e09c41000075&m=1473034198","list_dtime":"2016-09-05 08:09:35"},{"pk":"57ccb3391bc8e09c41000074","title":"郑赛赛/徐一璠不敌辛吉斯 无缘八强","title_line_break":"郑赛赛/徐一璠不敌辛吉斯\n无缘八强","date":"2016-09-05 08:08:46","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccb3391bc8e09c41000074","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb3381bc8e09c41000073_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb3381bc8e09c41000073_320.jpg","thumbnail_picsize":"550,369","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb3391bc8e09c41000074&m=1473034150","list_dtime":"2016-09-05 08:08:46"},{"pk":"57ccb7659490cb357e000025","title":"如何激活赞助\u2014\u2014那些顶级成功小贴士","date":"2016-09-05 08:08:05","auther_name":"禹唐体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccb7659490cb357e000025","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca90237f52e98d63000232_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca90237f52e98d63000232_320.jpg","thumbnail_picsize":"579,378","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb7659490cb357e000025&m=1473034059","list_dtime":"2016-09-05 08:08:05"},{"pk":"57ccb33d1bc8e09c41000078","title":"17岁天才棋手夺冠 被说大器晚成","title_line_break":"17岁天才棋手夺冠\n被说大器晚成","date":"2016-09-05 08:07:35","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccb33d1bc8e09c41000078","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccaded1bc8e0c64100000f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccaded1bc8e0c64100000f_320.jpg","thumbnail_picsize":"550,400","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb33d1bc8e09c41000078&m=1473034078","list_dtime":"2016-09-05 08:07:35"},{"pk":"57ccb4b49490cbf87d000018","title":"帆船赛与VR的不解之缘","date":"2016-09-05 07:56:44","auther_name":"体育大生意","weburl":"http://iphone.myzaker.com/l.php?l=57ccb4b49490cbf87d000018","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb9abd7f52e9127a00011d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb9abd7f52e9127a00011d_320.jpg","thumbnail_picsize":"835,540","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb4b49490cbf87d000018&m=1473033428","list_dtime":"2016-09-05 07:56:44"},{"pk":"57ccb3381bc8e09c41000072","title":"世界排第51位成中国第一！张帅：惭愧","title_line_break":"世界排第51位成中国第一！张帅：\n惭愧","date":"2016-09-05 07:55:54","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccb3381bc8e09c41000072","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb3361bc8e09c41000071_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb3361bc8e09c41000071_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb3381bc8e09c41000072&m=1473033377","list_dtime":"2016-09-05 07:55:54"},{"pk":"57ccb3899490cb137e000013","title":"环不列颠赛：丹尼斯带领BMC车队出战","title_line_break":"环不列颠赛：\n丹尼斯带领BMC车队出战","date":"2016-09-05 07:54:13","auther_name":"DUNKHOME","weburl":"http://iphone.myzaker.com/l.php?l=57ccb3899490cb137e000013","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc2e0e1bc8e04a74000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc2e0e1bc8e04a74000000_320.jpg","thumbnail_picsize":"670,444","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb3899490cb137e000013&m=1473033276","list_dtime":"2016-09-05 07:54:13"},{"pk":"57ccaa651bc8e09a3e00002b","title":"加提蓬率北京女排夺季军 曾发火","title_line_break":"加提蓬率北京女排夺季军\n曾发火","date":"2016-09-05 07:36:36","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccaa651bc8e09a3e00002b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccaa621bc8e09a3e00002a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccaa621bc8e09a3e00002a_320.jpg","thumbnail_picsize":"413,356","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccaa651bc8e09a3e00002b&m=1473032224","list_dtime":"2016-09-05 07:36:36"},{"pk":"57ccaa621bc8e09a3e000029","title":"张帅笑称使洪荒之力 证明自己可立足","title_line_break":"张帅笑称使洪荒之力\n证明自己可立足","date":"2016-09-05 07:35:10","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccaa621bc8e09a3e000029","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccaa621bc8e09a3e000028_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccaa621bc8e09a3e000028_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccaa621bc8e09a3e000029&m=1473032133","list_dtime":"2016-09-05 07:35:10"},{"pk":"57cca19e1bc8e0c538000050","title":"张晓雅姚笛领女排名单 龚翔宇或增补","title_line_break":"张晓雅姚笛领女排名单\n龚翔宇或增补","date":"2016-09-05 07:34:26","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cca19e1bc8e0c538000050","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca19d1bc8e0c53800004f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca19d1bc8e0c53800004f_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cca19e1bc8e0c538000050&m=1473032093","list_dtime":"2016-09-05 07:34:26"},{"pk":"57cc24ea9490cbe335000065","title":"签下新约！巴顿将在2017赛季暂别赛场","date":"2016-09-04 21:43:06","auther_name":"赛道时光","weburl":"http://iphone.myzaker.com/l.php?l=57cc24ea9490cbe335000065","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc176d1bc8e0956300000a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc176d1bc8e0956300000a_320.jpg","thumbnail_picsize":"660,440","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cc24ea9490cbe335000065&m=1473032368","list_dtime":"2016-09-04 21:43:06"},{"pk":"57cc0ae41bc8e05559000001","title":"结束征战！羽球奥运冠军田卿宣布退役","date":"2016-09-04 21:04:34","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cc0ae41bc8e05559000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc0ae31bc8e05559000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc0ae31bc8e05559000000_320.jpg","thumbnail_picsize":"640,480","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cc0ae41bc8e05559000001&m=1472994302","list_dtime":"2016-09-04 21:04:34"},{"pk":"57cbe30b9490cbcf35000044","title":"WEC：保时捷919两连胜 阿斯顿取首胜","title_line_break":"WEC：\n保时捷919两连胜 阿斯顿取首胜","date":"2016-09-04 18:00:34","auther_name":"赛道时光","weburl":"http://iphone.myzaker.com/l.php?l=57cbe30b9490cbcf35000044","thumbnail_pic":"http://zkres.myzaker.com/201609/57cba4931bc8e03b1f000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cba4931bc8e03b1f000002_320.jpg","thumbnail_picsize":"615,400","media_count":"3","is_full":"NO","content":"","special_type":"tag","special_info":{"icon_url":"http://zkres.myzaker.com/data/image/mark2/battlefield_report_2x.png?v=2015061216","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cbe30b9490cbcf35000044&m=1472983126","list_dtime":"2016-09-04 18:00:34"},{"pk":"57cbe1229490cb7c35000056","title":"日本否认申奥行贿 辩驳苍白无力？","title_line_break":"日本否认申奥行贿\n辩驳苍白无力？","date":"2016-09-04 16:48:45","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cbe1229490cb7c35000056","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbe12ea07aecc52301537d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbe12ea07aecc52301537d_320.jpg","thumbnail_picsize":"550,390","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cbe1229490cb7c35000056&m=1472979350","list_dtime":"2016-09-04 16:48:45"},{"pk":"57cbddeb9490cb963500004e","title":"李雪芮手术成功 职业生涯不会受影响","title_line_break":"李雪芮手术成功\n职业生涯不会受影响","date":"2016-09-04 16:46:57","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cbddeb9490cb963500004e","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb83201bc8e0ca08000012_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb83201bc8e0ca08000012_320.jpg","thumbnail_picsize":"540,652","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cbddeb9490cb963500004e&m=1472978681","list_dtime":"2016-09-04 16:46:57"},{"pk":"57cbda889490cbc535000054","title":"传统射箭精英赛开赛 22国选手参赛","title_line_break":"传统射箭精英赛开赛\n22国选手参赛","date":"2016-09-04 16:24:31","auther_name":"中新网","weburl":"http://iphone.myzaker.com/l.php?l=57cbda889490cbc535000054","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbda99a07aecc523014661_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbda99a07aecc523014661_320.jpg","thumbnail_picsize":"540,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cbda889490cbc535000054&m=1472977586","list_dtime":"2016-09-04 16:24:31"},{"pk":"57cbd6169490cb8f3500003f","title":"小威：307胜不是终点 盼赢更多比赛","title_line_break":"小威：\n307胜不是终点 盼赢更多比赛","date":"2016-09-04 16:06:46","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cbd6169490cb8f3500003f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbd5201bc8e00c3a00000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbd5201bc8e00c3a00000d_320.jpg","thumbnail_picsize":"900,600","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cbd6169490cb8f3500003f&m=1472976463","list_dtime":"2016-09-04 16:06:46"},{"pk":"57cbb1381bc8e0a42600001b","title":"残奥村马桶依然堵 队员自备泡面榨菜","title_line_break":"残奥村马桶依然堵\n队员自备泡面榨菜","date":"2016-09-04 14:12:19","auther_name":"新华社","weburl":"http://iphone.myzaker.com/l.php?l=57cbb1381bc8e0a42600001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbac4e1bc8e0e921000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbac4e1bc8e0e921000000_320.jpg","thumbnail_picsize":"640,516","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cbb1381bc8e0a42600001b&m=1472969403","list_dtime":"2016-09-04 14:12:19"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57cd0e3d9490cb007e00002a,57cd11089490cb3a7e000044,57cd0cbd9490cb177e000030,57cd0a679490cb6358000022,57cd09629490cb2c7e000048,57ccdfcf1bc8e02d0c00001f","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cd06389490cb424b00000f,57cd06389490cb424b000010,57cce2ca9490cb0b7e000029,57ccc5291bc8e0474f0000e7,57ccbc361bc8e0d14900003c,57ccc5271bc8e0474f0000e5","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57cccdd31bc8e0ff56000008,57ccc5281bc8e0474f0000e6,57ccbc341bc8e0d149000038,57ccd6711bc8e0475b000003,57ccd6701bc8e0475b000001,57cccdd01bc8e0ff56000002","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57ccb3391bc8e09c41000074,57ccb33a1bc8e09c41000075,57ccb7659490cb357e000025,57ccb33d1bc8e09c41000078,57ccb4b49490cbf87d000018,57ccb3381bc8e09c41000072","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57ccaa651bc8e09a3e00002b,57ccb3899490cb137e000013,57ccaa621bc8e09a3e000029,57cca19e1bc8e0c538000050,57cc24ea9490cbe335000065,57cc0ae41bc8e05559000001","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cbe1229490cb7c35000056,57cbe30b9490cbcf35000044,57cbddeb9490cb963500004e,57cbda889490cbc535000054,57cbd6169490cb8f3500003f,57cbb1381bc8e0a42600001b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}}],"article_block_colors":["#72a5e4","#72a5e4"],"only_text_page_bgcolors":["#72a5e4","#72a5e4"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11610.png?1415670949","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11610.png?1415670949","hidden_time":"24","need_userinfo":"NO","block_title":"综合体育","block_color":"#72a5e4","desktop_color_number":"14","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_f20c0127e47553cccf73a1c3b008c861","selected_index":"3","list":[{"pk":"zk_app_column_8","title":"头条","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12083","title":"足球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12083_zk_app_column_block_8","title":"足球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12083&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12084","title":"篮球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12084_zk_app_column_block_8","title":"篮球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12084&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_11610","title":"综合","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11610_zk_app_column_block_8","title":"综合体育","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11610&catalog_appid=8","data_type":"news"}}]}}
     */

    private String stat;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=11610&since_date=1472969539&nt=1&_appid=androidphone&catalog_appid=8","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=11610&need_app_integration=","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=11610&ids=51a7106381853df24c000138&k=201609051430"}
     * catalog :
     * articles : [{"pk":"57cd11089490cb3a7e000044","title":"激动！法国新星：淘汰纳达尔难以置信","title_line_break":"激动！法国新星：\n淘汰纳达尔难以置信","date":"2016-09-05 14:27:55","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd11089490cb3a7e000044","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd110ca07aecc523020007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd110ca07aecc523020007_320.jpg","thumbnail_picsize":"550,379","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd11089490cb3a7e000044&m=1473057048","list_dtime":"2016-09-05 14:27:55"},{"pk":"57cd0e3d9490cb007e00002a","title":"小德完胜英国新星 进八强将战特松加","title_line_break":"小德完胜英国新星\n进八强将战特松加","date":"2016-09-05 14:17:54","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0e3d9490cb007e00002a","thumbnail_pic":"http://zkres.myzaker.com/201609/57cd0c981bc8e0aa7d000077_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cd0c981bc8e0aa7d000077_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd0e3d9490cb007e00002a&m=1473056345","list_dtime":"2016-09-05 14:17:54"},{"pk":"57cd0cbd9490cb177e000030","title":"纳达尔输在哪？ACE太少制胜分稍逊","date":"2016-09-05 14:13:28","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0cbd9490cb177e000030","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc8e31bc8e03d5100002d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc8e31bc8e03d5100002d_320.jpg","thumbnail_picsize":"640,427","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd0cbd9490cb177e000030&m=1473056079","list_dtime":"2016-09-05 14:13:28"},{"pk":"57cd0a679490cb6358000022","title":"12年最差成绩单 纳达尔未来在哪？","title_line_break":"12年最差成绩单\n纳达尔未来在哪？","date":"2016-09-05 14:02:15","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd0a679490cb6358000022","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc8e21bc8e03d5100002b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc8e21bc8e03d5100002b_320.jpg","thumbnail_picsize":"640,427","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd0a679490cb6358000022&m=1473055284","list_dtime":"2016-09-05 14:02:15"},{"pk":"57cd09629490cb2c7e000048","title":"从大山走到领奖台！蔡泽林银牌沉甸甸","date":"2016-09-05 14:00:36","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd09629490cb2c7e000048","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc8de1bc8e03d51000027_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc8de1bc8e03d51000027_320.jpg","thumbnail_picsize":"400,600","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd09629490cb2c7e000048&m=1473055309","list_dtime":"2016-09-05 14:00:36"},{"pk":"57ccdfcf1bc8e02d0c00001f","title":"论做瑜伽，人类在动物面前真是战五渣","date":"2016-09-05 13:55:23","auther_name":"央广新闻综合","weburl":"http://iphone.myzaker.com/l.php?l=57ccdfcf1bc8e02d0c00001f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvY21zL2FydGljbGVfaW1nLzEyMjYyL3VwXzEyMjYyXzE0NzMwNDQzNzk0ODUuanBn_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvY21zL2FydGljbGVfaW1nLzEyMjYyL3VwXzEyMjYyXzE0NzMwNDQzNzk0ODUuanBn_1242.jpg","thumbnail_picsize":"575,362","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccdfcf1bc8e02d0c00001f&m=1473054927","list_dtime":"2016-09-05 13:55:23"},{"pk":"57cd06389490cb424b000010","title":"等候主人的幽灵自行车：提醒开车人","title_line_break":"等候主人的幽灵自行车：\n提醒开车人","date":"2016-09-05 13:54:35","auther_name":"DUNKHOME","weburl":"http://iphone.myzaker.com/l.php?l=57cd06389490cb424b000010","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd71f1bc8e01859000060_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd71f1bc8e01859000060_320.jpg","thumbnail_picsize":"635,357","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd06389490cb424b000010&m=1473054878","list_dtime":"2016-09-05 13:54:35"},{"pk":"57cd06389490cb424b00000f","title":"改革VS激情：应禁止比赛用功率计？","title_line_break":"改革VS激情：\n应禁止比赛用功率计？","date":"2016-09-05 13:52:01","auther_name":"DUNKHOME","weburl":"http://iphone.myzaker.com/l.php?l=57cd06389490cb424b00000f","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccf9061bc8e0466f00002f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccf9061bc8e0466f00002f_320.jpg","thumbnail_picsize":"840,555","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd06389490cb424b00000f&m=1473054795","list_dtime":"2016-09-05 13:52:01"},{"pk":"57cce2ca9490cb0b7e000029","title":"6红球世锦赛强手如林 中国3球手出战","title_line_break":"6红球世锦赛强手如林\n中国3球手出战","date":"2016-09-05 11:08:54","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce2ca9490cb0b7e000029","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce2cba07aecc52301e869_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce2cba07aecc52301e869_320.jpg","thumbnail_picsize":"550,367","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cce2ca9490cb0b7e000029&m=1473045203","list_dtime":"2016-09-05 11:08:54"},{"pk":"57ccc5291bc8e0474f0000e7","title":"95后冠军又添一员 曾因负女棋手受质疑","title_line_break":"95后冠军又添一员\n曾因负女棋手受质疑","date":"2016-09-05 10:44:29","auther_name":"信息时报","weburl":"http://iphone.myzaker.com/l.php?l=57ccc5291bc8e0474f0000e7","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbfcd1bc8e0d44d00000f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbfcd1bc8e0d44d00000f_320.jpg","thumbnail_picsize":"550,415","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccc5291bc8e0474f0000e7&m=1473043811","list_dtime":"2016-09-05 10:44:29"},{"pk":"57ccbc361bc8e0d14900003c","title":"17岁棋手取代柯洁 成中国最年轻九段","title_line_break":"17岁棋手取代柯洁\n成中国最年轻九段","date":"2016-09-05 10:38:32","auther_name":"信息时报","weburl":"http://iphone.myzaker.com/l.php?l=57ccbc361bc8e0d14900003c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbc361bc8e0d14900003b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbc361bc8e0d14900003b_320.jpg","thumbnail_picsize":"550,366","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccbc361bc8e0d14900003c&m=1473043113","list_dtime":"2016-09-05 10:38:32"},{"pk":"57ccc5271bc8e0474f0000e5","title":"张帅成中国一姐仍不满足：挺让人失望","title_line_break":"张帅成中国一姐仍不满足：\n挺让人失望","date":"2016-09-05 10:35:49","auther_name":"南方都市报","weburl":"http://iphone.myzaker.com/l.php?l=57ccc5271bc8e0474f0000e5","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbfca1bc8e0d44d00000b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbfca1bc8e0d44d00000b_320.jpg","thumbnail_picsize":"350,500","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccc5271bc8e0474f0000e5&m=1473043596","list_dtime":"2016-09-05 10:35:49"},{"pk":"57ccc5281bc8e0474f0000e6","title":"张帅本季大满贯7胜4负 排名稳定前60","title_line_break":"张帅本季大满贯7胜4负\n排名稳定前60","date":"2016-09-05 10:35:36","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccc5281bc8e0474f0000e6","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbfcb1bc8e0d44d00000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbfcb1bc8e0d44d00000d_320.jpg","thumbnail_picsize":"400,266","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccc5281bc8e0474f0000e6&m=1473042938","list_dtime":"2016-09-05 10:35:36"},{"pk":"57cccdd31bc8e0ff56000008","title":"孟菲尔斯挺进8强 或首次入围总决赛","title_line_break":"孟菲尔斯挺进8强\n或首次入围总决赛","date":"2016-09-05 10:32:21","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cccdd31bc8e0ff56000008","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccdd31bc8e0ff56000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccdd31bc8e0ff56000007_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cccdd31bc8e0ff56000008&m=1473042743","list_dtime":"2016-09-05 10:32:21"},{"pk":"57ccbc341bc8e0d149000038","title":"纳达尔决胜盘抢七惜败 爆冷不敌新星","title_line_break":"纳达尔决胜盘抢七惜败\n爆冷不敌新星","date":"2016-09-05 10:30:49","auther_name":"新华网","weburl":"http://iphone.myzaker.com/l.php?l=57ccbc341bc8e0d149000038","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccbc341bc8e0d149000037_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccbc341bc8e0d149000037_320.jpg","thumbnail_picsize":"550,346","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccbc341bc8e0d149000038&m=1473043025","list_dtime":"2016-09-05 10:30:49"},{"pk":"57ccd6711bc8e0475b000003","title":"女排全锦赛上海夺冠 北京胜天津摘铜","title_line_break":"女排全锦赛上海夺冠\n北京胜天津摘铜","date":"2016-09-05 10:24:54","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd6711bc8e0475b000003","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd6701bc8e0475b000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd6701bc8e0475b000002_320.jpg","thumbnail_picsize":"550,298","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccd6711bc8e0475b000003&m=1473042296","list_dtime":"2016-09-05 10:24:54"},{"pk":"57ccd6701bc8e0475b000001","title":"美网科贝尔完胜科娃 时隔5年重返8强","title_line_break":"美网科贝尔完胜科娃\n时隔5年重返8强","date":"2016-09-05 10:22:38","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd6701bc8e0475b000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd66f1bc8e0475b000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd66f1bc8e0475b000000_320.jpg","thumbnail_picsize":"500,330","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccd6701bc8e0475b000001&m=1473042160","list_dtime":"2016-09-05 10:22:38"},{"pk":"57cccdd01bc8e0ff56000002","title":"沃兹仅7误完胜凯斯 重返美网八强","title_line_break":"沃兹仅7误完胜凯斯\n重返美网八强","date":"2016-09-05 10:20:30","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cccdd01bc8e0ff56000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccdd01bc8e0ff56000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccdd01bc8e0ff56000001_320.jpg","thumbnail_picsize":"500,300","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cccdd01bc8e0ff56000002&m=1473042032","list_dtime":"2016-09-05 10:20:30"},{"pk":"57ccb33a1bc8e09c41000075","title":"特松加苦战4盘胜本土选手 静候小德","title_line_break":"特松加苦战4盘胜本土选手\n静候小德","date":"2016-09-05 08:09:35","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccb33a1bc8e09c41000075","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccadec1bc8e0c64100000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccadec1bc8e0c64100000d_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb33a1bc8e09c41000075&m=1473034198","list_dtime":"2016-09-05 08:09:35"},{"pk":"57ccb3391bc8e09c41000074","title":"郑赛赛/徐一璠不敌辛吉斯 无缘八强","title_line_break":"郑赛赛/徐一璠不敌辛吉斯\n无缘八强","date":"2016-09-05 08:08:46","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccb3391bc8e09c41000074","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb3381bc8e09c41000073_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb3381bc8e09c41000073_320.jpg","thumbnail_picsize":"550,369","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb3391bc8e09c41000074&m=1473034150","list_dtime":"2016-09-05 08:08:46"},{"pk":"57ccb7659490cb357e000025","title":"如何激活赞助\u2014\u2014那些顶级成功小贴士","date":"2016-09-05 08:08:05","auther_name":"禹唐体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccb7659490cb357e000025","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca90237f52e98d63000232_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca90237f52e98d63000232_320.jpg","thumbnail_picsize":"579,378","media_count":"14","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb7659490cb357e000025&m=1473034059","list_dtime":"2016-09-05 08:08:05"},{"pk":"57ccb33d1bc8e09c41000078","title":"17岁天才棋手夺冠 被说大器晚成","title_line_break":"17岁天才棋手夺冠\n被说大器晚成","date":"2016-09-05 08:07:35","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccb33d1bc8e09c41000078","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccaded1bc8e0c64100000f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccaded1bc8e0c64100000f_320.jpg","thumbnail_picsize":"550,400","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb33d1bc8e09c41000078&m=1473034078","list_dtime":"2016-09-05 08:07:35"},{"pk":"57ccb4b49490cbf87d000018","title":"帆船赛与VR的不解之缘","date":"2016-09-05 07:56:44","auther_name":"体育大生意","weburl":"http://iphone.myzaker.com/l.php?l=57ccb4b49490cbf87d000018","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb9abd7f52e9127a00011d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb9abd7f52e9127a00011d_320.jpg","thumbnail_picsize":"835,540","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb4b49490cbf87d000018&m=1473033428","list_dtime":"2016-09-05 07:56:44"},{"pk":"57ccb3381bc8e09c41000072","title":"世界排第51位成中国第一！张帅：惭愧","title_line_break":"世界排第51位成中国第一！张帅：\n惭愧","date":"2016-09-05 07:55:54","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccb3381bc8e09c41000072","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccb3361bc8e09c41000071_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccb3361bc8e09c41000071_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb3381bc8e09c41000072&m=1473033377","list_dtime":"2016-09-05 07:55:54"},{"pk":"57ccb3899490cb137e000013","title":"环不列颠赛：丹尼斯带领BMC车队出战","title_line_break":"环不列颠赛：\n丹尼斯带领BMC车队出战","date":"2016-09-05 07:54:13","auther_name":"DUNKHOME","weburl":"http://iphone.myzaker.com/l.php?l=57ccb3899490cb137e000013","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc2e0e1bc8e04a74000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc2e0e1bc8e04a74000000_320.jpg","thumbnail_picsize":"670,444","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccb3899490cb137e000013&m=1473033276","list_dtime":"2016-09-05 07:54:13"},{"pk":"57ccaa651bc8e09a3e00002b","title":"加提蓬率北京女排夺季军 曾发火","title_line_break":"加提蓬率北京女排夺季军\n曾发火","date":"2016-09-05 07:36:36","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccaa651bc8e09a3e00002b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccaa621bc8e09a3e00002a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccaa621bc8e09a3e00002a_320.jpg","thumbnail_picsize":"413,356","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccaa651bc8e09a3e00002b&m=1473032224","list_dtime":"2016-09-05 07:36:36"},{"pk":"57ccaa621bc8e09a3e000029","title":"张帅笑称使洪荒之力 证明自己可立足","title_line_break":"张帅笑称使洪荒之力\n证明自己可立足","date":"2016-09-05 07:35:10","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccaa621bc8e09a3e000029","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccaa621bc8e09a3e000028_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccaa621bc8e09a3e000028_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57ccaa621bc8e09a3e000029&m=1473032133","list_dtime":"2016-09-05 07:35:10"},{"pk":"57cca19e1bc8e0c538000050","title":"张晓雅姚笛领女排名单 龚翔宇或增补","title_line_break":"张晓雅姚笛领女排名单\n龚翔宇或增补","date":"2016-09-05 07:34:26","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cca19e1bc8e0c538000050","thumbnail_pic":"http://zkres.myzaker.com/201609/57cca19d1bc8e0c53800004f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cca19d1bc8e0c53800004f_320.jpg","thumbnail_picsize":"500,350","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cca19e1bc8e0c538000050&m=1473032093","list_dtime":"2016-09-05 07:34:26"},{"pk":"57cc24ea9490cbe335000065","title":"签下新约！巴顿将在2017赛季暂别赛场","date":"2016-09-04 21:43:06","auther_name":"赛道时光","weburl":"http://iphone.myzaker.com/l.php?l=57cc24ea9490cbe335000065","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc176d1bc8e0956300000a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc176d1bc8e0956300000a_320.jpg","thumbnail_picsize":"660,440","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cc24ea9490cbe335000065&m=1473032368","list_dtime":"2016-09-04 21:43:06"},{"pk":"57cc0ae41bc8e05559000001","title":"结束征战！羽球奥运冠军田卿宣布退役","date":"2016-09-04 21:04:34","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cc0ae41bc8e05559000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57cc0ae31bc8e05559000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cc0ae31bc8e05559000000_320.jpg","thumbnail_picsize":"640,480","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cc0ae41bc8e05559000001&m=1472994302","list_dtime":"2016-09-04 21:04:34"},{"pk":"57cbe30b9490cbcf35000044","title":"WEC：保时捷919两连胜 阿斯顿取首胜","title_line_break":"WEC：\n保时捷919两连胜 阿斯顿取首胜","date":"2016-09-04 18:00:34","auther_name":"赛道时光","weburl":"http://iphone.myzaker.com/l.php?l=57cbe30b9490cbcf35000044","thumbnail_pic":"http://zkres.myzaker.com/201609/57cba4931bc8e03b1f000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cba4931bc8e03b1f000002_320.jpg","thumbnail_picsize":"615,400","media_count":"3","is_full":"NO","content":"","special_type":"tag","special_info":{"icon_url":"http://zkres.myzaker.com/data/image/mark2/battlefield_report_2x.png?v=2015061216","show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cbe30b9490cbcf35000044&m=1472983126","list_dtime":"2016-09-04 18:00:34"},{"pk":"57cbe1229490cb7c35000056","title":"日本否认申奥行贿 辩驳苍白无力？","title_line_break":"日本否认申奥行贿\n辩驳苍白无力？","date":"2016-09-04 16:48:45","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cbe1229490cb7c35000056","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbe12ea07aecc52301537d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbe12ea07aecc52301537d_320.jpg","thumbnail_picsize":"550,390","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cbe1229490cb7c35000056&m=1472979350","list_dtime":"2016-09-04 16:48:45"},{"pk":"57cbddeb9490cb963500004e","title":"李雪芮手术成功 职业生涯不会受影响","title_line_break":"李雪芮手术成功\n职业生涯不会受影响","date":"2016-09-04 16:46:57","auther_name":"央广网-体育","weburl":"http://iphone.myzaker.com/l.php?l=57cbddeb9490cb963500004e","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb83201bc8e0ca08000012_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb83201bc8e0ca08000012_320.jpg","thumbnail_picsize":"540,652","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cbddeb9490cb963500004e&m=1472978681","list_dtime":"2016-09-04 16:46:57"},{"pk":"57cbda889490cbc535000054","title":"传统射箭精英赛开赛 22国选手参赛","title_line_break":"传统射箭精英赛开赛\n22国选手参赛","date":"2016-09-04 16:24:31","auther_name":"中新网","weburl":"http://iphone.myzaker.com/l.php?l=57cbda889490cbc535000054","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbda99a07aecc523014661_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbda99a07aecc523014661_320.jpg","thumbnail_picsize":"540,360","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cbda889490cbc535000054&m=1472977586","list_dtime":"2016-09-04 16:24:31"},{"pk":"57cbd6169490cb8f3500003f","title":"小威：307胜不是终点 盼赢更多比赛","title_line_break":"小威：\n307胜不是终点 盼赢更多比赛","date":"2016-09-04 16:06:46","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cbd6169490cb8f3500003f","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbd5201bc8e00c3a00000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbd5201bc8e00c3a00000d_320.jpg","thumbnail_picsize":"900,600","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cbd6169490cb8f3500003f&m=1472976463","list_dtime":"2016-09-04 16:06:46"},{"pk":"57cbb1381bc8e0a42600001b","title":"残奥村马桶依然堵 队员自备泡面榨菜","title_line_break":"残奥村马桶依然堵\n队员自备泡面榨菜","date":"2016-09-04 14:12:19","auther_name":"新华社","weburl":"http://iphone.myzaker.com/l.php?l=57cbb1381bc8e0a42600001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbac4e1bc8e0e921000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbac4e1bc8e0e921000000_320.jpg","thumbnail_picsize":"640,516","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cbb1381bc8e0a42600001b&m=1472969403","list_dtime":"2016-09-04 14:12:19"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57cd0e3d9490cb007e00002a,57cd11089490cb3a7e000044,57cd0cbd9490cb177e000030,57cd0a679490cb6358000022,57cd09629490cb2c7e000048,57ccdfcf1bc8e02d0c00001f","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cd06389490cb424b00000f,57cd06389490cb424b000010,57cce2ca9490cb0b7e000029,57ccc5291bc8e0474f0000e7,57ccbc361bc8e0d14900003c,57ccc5271bc8e0474f0000e5","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57cccdd31bc8e0ff56000008,57ccc5281bc8e0474f0000e6,57ccbc341bc8e0d149000038,57ccd6711bc8e0475b000003,57ccd6701bc8e0475b000001,57cccdd01bc8e0ff56000002","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57ccb3391bc8e09c41000074,57ccb33a1bc8e09c41000075,57ccb7659490cb357e000025,57ccb33d1bc8e09c41000078,57ccb4b49490cbf87d000018,57ccb3381bc8e09c41000072","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"4","articles":"57ccaa651bc8e09a3e00002b,57ccb3899490cb137e000013,57ccaa621bc8e09a3e000029,57cca19e1bc8e0c538000050,57cc24ea9490cbe335000065,57cc0ae41bc8e05559000001","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"3","articles":"57cbe1229490cb7c35000056,57cbe30b9490cbcf35000044,57cbddeb9490cb963500004e,57cbda889490cbc535000054,57cbd6169490cb8f3500003f,57cbb1381bc8e0a42600001b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}}],"article_block_colors":["#72a5e4","#72a5e4"],"only_text_page_bgcolors":["#72a5e4","#72a5e4"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11610.png?1415670949","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/11610.png?1415670949","hidden_time":"24","need_userinfo":"NO","block_title":"综合体育","block_color":"#72a5e4","desktop_color_number":"14","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_f20c0127e47553cccf73a1c3b008c861","selected_index":"3","list":[{"pk":"zk_app_column_8","title":"头条","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12083","title":"足球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12083_zk_app_column_block_8","title":"足球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12083&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12084","title":"篮球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12084_zk_app_column_block_8","title":"篮球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12084&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_11610","title":"综合","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11610_zk_app_column_block_8","title":"综合体育","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11610&catalog_appid=8","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=11610&since_date=1472969539&nt=1&_appid=androidphone&catalog_appid=8
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=11610&need_app_integration=
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=11610&ids=51a7106381853df24c000138&k=201609051430
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/11610.png?1415670949
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/11610.png?1415670949
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 综合体育
         * block_color : #72a5e4
         * desktop_color_number : 14
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_f20c0127e47553cccf73a1c3b008c861
         * selected_index : 3
         * list : [{"pk":"zk_app_column_8","title":"头条","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12083","title":"足球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12083_zk_app_column_block_8","title":"足球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12083&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12084","title":"篮球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12084_zk_app_column_block_8","title":"篮球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12084&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_11610","title":"综合","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11610_zk_app_column_block_8","title":"综合体育","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11610&catalog_appid=8","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57cd11089490cb3a7e000044
         * title : 激动！法国新星：淘汰纳达尔难以置信
         * title_line_break : 激动！法国新星：
         淘汰纳达尔难以置信
         * date : 2016-09-05 14:27:55
         * auther_name : 网易体育
         * weburl : http://iphone.myzaker.com/l.php?l=57cd11089490cb3a7e000044
         * thumbnail_pic : http://zkres.myzaker.com/201609/57cd110ca07aecc523020007_640.jpg
         * thumbnail_mpic : http://zkres.myzaker.com/201609/57cd110ca07aecc523020007_320.jpg
         * thumbnail_picsize : 550,379
         * media_count : 1
         * is_full : NO
         * content :
         * special_info : {"show_jingcai":"Y"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=11610&pk=57cd11089490cb3a7e000044&m=1473057048
         * list_dtime : 2016-09-05 14:27:55
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 5
             * articles : 57cd0e3d9490cb007e00002a,57cd11089490cb3a7e000044,57cd0cbd9490cb177e000030,57cd0a679490cb6358000022,57cd09629490cb2c7e000048,57ccdfcf1bc8e02d0c00001f
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * open_type :
                 * bgimage_icon_style : 0
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;
                    private String bgimage_icon_style;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }

                    public String getBgimage_icon_style() {
                        return bgimage_icon_style;
                    }

                    public void setBgimage_icon_style(String bgimage_icon_style) {
                        this.bgimage_icon_style = bgimage_icon_style;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_8
             * title : 头条
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 8
                 * title : 体育新闻
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8
                 * data_type : news
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String title_line_break;
            private String date;
            private String auther_name;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String is_full;
            private String content;
            /**
             * show_jingcai : Y
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getTitle_line_break() {
                return title_line_break;
            }

            public void setTitle_line_break(String title_line_break) {
                this.title_line_break = title_line_break;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String show_jingcai;

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }
            }
        }
    }
}
