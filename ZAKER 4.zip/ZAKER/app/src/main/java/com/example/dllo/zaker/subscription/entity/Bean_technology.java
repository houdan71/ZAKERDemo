package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/3.
 */
public class Bean_technology {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=13&since_date=1472771674&nt=1&next_aticle_id=57c80c4c1bc8e0357f000001&_appid=androidphone&opage=2&otimestamp=143","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=13&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=13&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,5472a9b69490cb48180000f9,51a7103481853d8f4c000143&k=201609031150"},"catalog":"","articles":[{"pk":"57c92b629490cb1f18000045","title":"你最想用哪款手机刷iOS？","date":"2016-09-02 15:33:54","auther_name":"数码脑残粉","page":"2","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57c92b629490cb1f18000045","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"156","title":"数码脑残粉","stitle":"数码科技达人聚集地","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=156","block_color":"","subscribe_count":"293428","post_count":"16599","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=13&app_ids=13&pk=57c92b629490cb1f18000045&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c92b629490cb1f18000045","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c92b629490cb1f18000045&m=1472874305","list_dtime":"2016-09-02 15:33:54"},{"pk":"57ca2a581bc8e08a40000007","title":"索尼Xperia XZ体验 又一部\u201c快时尚\u201d手机","date":"2016-09-03 10:37:48","auther_name":"腾讯数码","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57ca2a581bc8e08a40000007","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca29f11bc8e01d41000023_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca29f11bc8e01d41000023_320.jpg","thumbnail_picsize":"554,416","media_count":"8","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c76d419490cbb42c000016","block_title":"ZAKER带你直击IFA","title":"ZAKER带你直击IFA","block_in_title":"索尼Xperia XZ体验 又一部\u201c快时尚\u201d手机","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=13&topic_id=57c76d419490cbb42c000016&updated=1472872091"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca2a581bc8e08a40000007&m=1472874305","list_dtime":"2016-09-03 10:37:48"},{"pk":"57c9a1681bc8e0a47a000002","title":"惠普推出的新电脑怎么这么像音响！","date":"2016-09-03 08:30:14","auther_name":"腾讯数码","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c9a1681bc8e0a47a000002","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M5YTE2ODFiYzhlMGE0N2EwMDAwMDBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M5YTE2ODFiYzhlMGE0N2EwMDAwMDBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"554,371","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9a1681bc8e0a47a000002&m=1472874305","list_dtime":"2016-09-03 08:30:14"},{"pk":"57c8ad199490cb4e77000006","title":"HDMI接口为何很重要？","date":"2016-09-03 02:12:51","auther_name":"中关村在线","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c8ad199490cb4e77000006","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MjgyN180NTIwN19XNjQwSDM2MFM0NTU0OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MjgyN180NTIwN19XNjQwSDM2MFM0NTU0OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c8ad199490cb4e77000006&m=1472874305","list_dtime":"2016-09-03 02:12:51"},{"pk":"57ca1bda9490cbec3e00001e","title":"大疆首款小飞机曝光！这可真是一场好戏啊","date":"2016-09-03 08:41:00","auther_name":"爱范儿","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ca1bda9490cbec3e00001e","thumbnail_pic":"http://zkres.myzaker.com/201609/57c989fa1bc8e0fc69000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c989fa1bc8e0fc69000001_320.jpg","thumbnail_picsize":"1200,750","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca1bda9490cbec3e00001e&m=1472874305","list_dtime":"2016-09-03 08:41:00"},{"pk":"57c996321bc8e04e7100001b","title":"疑似锤子T3清晰亮屏谍照曝光：流光魅影","title_line_break":"疑似锤子T3清晰亮屏谍照曝光：\n流光魅影","date":"2016-09-03 10:33:18","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c996321bc8e04e7100001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c992637f52e9f26900006a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c992637f52e9f26900006a_320.jpg","thumbnail_picsize":"600,391","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c996321bc8e04e7100001b&m=1472874182","list_dtime":"2016-09-03 10:33:18"},{"pk":"57ca3c3b9490cbed3e000033","title":"这可能是Note 7\u201c炸机\u201d的元凶 ","date":"2016-09-03 10:57:15","auther_name":"腾讯科技","weburl":"http://iphone.myzaker.com/l.php?l=57ca3c3b9490cbed3e000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca3c3ea07aecc5230072e1_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca3c3ea07aecc5230072e1_320.jpg","thumbnail_picsize":"520,347","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca3c3b9490cbed3e000033&m=1472874182","list_dtime":"2016-09-03 10:57:15"},{"pk":"57c9919f9490cb5b6b000012","title":"iPhone 7亮光黑惊艳：工艺复杂或成新风向","title_line_break":"iPhone 7亮光黑惊艳：\n工艺复杂或成新风向","date":"2016-09-03 08:23:49","auther_name":"科客网","weburl":"http://iphone.myzaker.com/l.php?l=57c9919f9490cb5b6b000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57c98f5b1bc8e0526e000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c98f5b1bc8e0526e000011_320.jpg","thumbnail_picsize":"550,412","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9919f9490cb5b6b000012&m=1472874183","list_dtime":"2016-09-03 08:23:49"},{"pk":"57c98e091bc8e0076e00000a","title":"联想K6/K6 Power/K6 Note新机三连发","date":"2016-09-03 10:33:38","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c98e091bc8e0076e00000a","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c98e091bc8e0076e00000a&m=1472874182","list_dtime":"2016-09-03 10:33:38"},{"pk":"57ca1d839490cb103f000025","title":"董明珠谈小米：它还敢估值四百五十亿美金吗","title_line_break":"董明珠谈小米：\n它还敢估值四百五十亿美金吗","date":"2016-09-03 09:14:28","auther_name":"虎嗅网","weburl":"http://iphone.myzaker.com/l.php?l=57ca1d839490cb103f000025","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca1d839490cb103f000025&m=1472874182","list_dtime":"2016-09-03 09:14:28"},{"pk":"57c99e9e1bc8e08678000001","title":"iPhone7的A10处理器找三星还是英特尔代工？","date":"2016-09-03 10:32:55","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c99e9e1bc8e08678000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57c99ea07f52e9df1c0001e3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c99ea07f52e9df1c0001e3_320.jpg","thumbnail_picsize":"600,337","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c99e9e1bc8e08678000001&m=1472874182","list_dtime":"2016-09-03 10:32:55"},{"pk":"57ca0a941bc8e03b2c000060","title":"联想Vibe P2正式发布：这个充电宝有点贵","title_line_break":"联想Vibe P2正式发布：\n这个充电宝有点贵","date":"2016-09-03 08:17:35","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca0a941bc8e03b2c000060","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca065e7f52e95860000156_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca065e7f52e95860000156_320.jpg","thumbnail_picsize":"600,483","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca0a941bc8e03b2c000060&m=1472874183","list_dtime":"2016-09-03 08:17:35"},{"pk":"57c9625b1bc8e03c4e000009","title":"还敢用伪基站？以后抓到罚到你想死","date":"2016-09-03 09:31:12","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c9625b1bc8e03c4e000009","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9625e7f52e9a434000248_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9625e7f52e9a434000248_320.jpg","thumbnail_picsize":"520,388","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9625b1bc8e03c4e000009&m=1472874182","list_dtime":"2016-09-03 09:31:12"},{"pk":"57ca01f71bc8e02a29000003","title":"双面女主播：表面宣传禁毒，私下贩毒","title_line_break":"双面女主播：\n表面宣传禁毒，私下贩毒","date":"2016-09-03 08:08:58","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca01f71bc8e02a29000003","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9fda67f52e958600000da_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9fda67f52e958600000da_320.jpg","thumbnail_picsize":"600,450","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca01f71bc8e02a29000003&m=1472874183","list_dtime":"2016-09-03 08:08:58"},{"pk":"57ca1f949490cb463f000046","title":"引得苹果孤注一掷的双摄像头有何魔力","date":"2016-09-03 09:13:49","auther_name":"腾讯科技","weburl":"http://iphone.myzaker.com/l.php?l=57ca1f949490cb463f000046","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca08c87f52e9d96b000066_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca08c87f52e9d96b000066_320.jpg","thumbnail_picsize":"640,387","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca1f949490cb463f000046&m=1472874182","list_dtime":"2016-09-03 09:13:49"},{"pk":"57ca1c631bc8e0cd35000027","title":"索尼展示Xperia家庭机器人，摸头泡咖啡","date":"2016-09-03 10:36:38","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca1c631bc8e0cd35000027","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca1c677f52e90e3800000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1c677f52e90e3800000d_320.jpg","thumbnail_picsize":"600,397","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca1c631bc8e0cd35000027&m=1472874182","list_dtime":"2016-09-03 10:36:38"},{"pk":"57c95ef41bc8e00e4f000001","title":"让机器人\u201c活\u201d起来：可以！这很迪士尼！","title_line_break":"让机器人\u201c活\u201d起来：\n可以！这很迪士尼！","date":"2016-09-03 08:56:37","auther_name":"雷锋网","weburl":"http://iphone.myzaker.com/l.php?l=57c95ef41bc8e00e4f000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57c95e991bc8e01b4f000005_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c95e991bc8e01b4f000005_320.jpg","thumbnail_picsize":"675,753","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c95ef41bc8e00e4f000001&m=1472874182","list_dtime":"2016-09-03 08:56:37"},{"pk":"57ca1bda9490cbec3e00001f","title":"索尼要用它们告诉你音乐的真谛","date":"2016-09-03 09:12:58","auther_name":"爱范儿","weburl":"http://iphone.myzaker.com/l.php?l=57ca1bda9490cbec3e00001f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c96a6d1bc8e07255000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c96a6d1bc8e07255000000_320.jpg","thumbnail_picsize":"1200,750","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca1bda9490cbec3e00001f&m=1472874182","list_dtime":"2016-09-03 09:12:58"},{"pk":"57c985041bc8e00c69000001","title":"暴风影音去广告功能被判违法：赔腾讯50万","title_line_break":"暴风影音去广告功能被判违法：\n赔腾讯50万","date":"2016-09-03 08:19:23","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c985041bc8e00c69000001","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c985041bc8e00c69000001&m=1472874183","list_dtime":"2016-09-03 08:19:23"},{"pk":"57c9bf509490cb5460000006","title":"12英寸MacBook接口不够？看看这款配件吧","date":"2016-09-03 08:18:21","auther_name":"威锋网","weburl":"http://iphone.myzaker.com/l.php?l=57c9bf509490cb5460000006","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9a5041bc8e06d7e000004_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9a5041bc8e06d7e000004_320.jpg","thumbnail_picsize":"506,374","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9bf509490cb5460000006&m=1472874183","list_dtime":"2016-09-03 08:18:21"},{"pk":"57c997c41bc8e0a674000002","title":"微软Hololens 全息眼镜开箱图赏","title_line_break":"微软Hololens\n全息眼镜开箱图赏","date":"2016-09-03 08:31:16","auther_name":"雷锋网","weburl":"http://iphone.myzaker.com/l.php?l=57c997c41bc8e0a674000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57c997a51bc8e08e7200001a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c997a51bc8e08e7200001a_320.jpg","thumbnail_picsize":"880,568","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c997c41bc8e0a674000002&m=1472874182","list_dtime":"2016-09-03 08:31:16"},{"pk":"57ca29f69490cb9d1c00000c","title":"用事实说话 盘点京东十大热销机械键盘","title_line_break":"用事实说话\n盘点京东十大热销机械键盘","date":"2016-09-03 09:40:06","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57ca29f69490cb9d1c00000c","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9fbc71bc8e06027000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9fbc71bc8e06027000003_320.jpg","thumbnail_picsize":"640,477","media_count":"37","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca29f69490cb9d1c00000c&m=1472874182","list_dtime":"2016-09-03 09:40:06"},{"pk":"57ca0a931bc8e03b2c00005e","title":"LG V20三配色齐曝，命名让人纠结不已","title_line_break":"LG\nV20三配色齐曝，命名让人纠结不已","date":"2016-09-03 08:08:09","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca0a931bc8e03b2c00005e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca0a947f52e9d96b000070_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca0a947f52e9d96b000070_320.jpg","thumbnail_picsize":"600,396","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca0a931bc8e03b2c00005e&m=1472874183","list_dtime":"2016-09-03 08:08:09"},{"pk":"57c9fc429490cbb02c000005","title":"科技乱谈琴：新学期要换新手机 iPhone7","title_line_break":"科技乱谈琴：\n新学期要换新手机 iPhone7","date":"2016-09-03 08:16:17","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57c9fc429490cbb02c000005","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9f7c51bc8e0dc24000050_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9f7c51bc8e0dc24000050_320.jpg","thumbnail_picsize":"640,428","media_count":"20","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9fc429490cbb02c000005&m=1472874183","list_dtime":"2016-09-03 08:16:17"},{"pk":"57ca01f71bc8e02a29000001","title":"三星Note7全球召回，运营商销售急刹","date":"2016-09-03 08:09:55","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca01f71bc8e02a29000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca01fa7f52e95860000109_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca01fa7f52e95860000109_320.jpg","thumbnail_picsize":"600,351","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca01f71bc8e02a29000001&m=1472874183","list_dtime":"2016-09-03 08:09:55"},{"pk":"57ca212e9490cbd13e000025","title":"骨感现实，Google 暂停模块化手机项目","title_line_break":"骨感现实，Google\n暂停模块化手机项目","date":"2016-09-03 09:10:35","auther_name":"爱范儿","weburl":"http://iphone.myzaker.com/l.php?l=57ca212e9490cbd13e000025","thumbnail_pic":"http://zkres.myzaker.com/201609/57c95a8a1bc8e0334b000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c95a8a1bc8e0334b000000_320.jpg","thumbnail_picsize":"1200,750","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca212e9490cbd13e000025&m=1472874182","list_dtime":"2016-09-03 09:10:35"},{"pk":"57ca1bda9490cbec3e00001d","title":"这款黑客游戏成了\u201c赛博朋克\u201d风格","date":"2016-09-03 09:11:14","auther_name":"爱范儿","weburl":"http://iphone.myzaker.com/l.php?l=57ca1bda9490cbec3e00001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9aa3b1bc8e0d702000009_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9aa3b1bc8e0d702000009_320.jpg","thumbnail_picsize":"1024,619","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca1bda9490cbec3e00001d&m=1472874182","list_dtime":"2016-09-03 09:11:14"},{"pk":"57c996311bc8e04e71000018","title":"乔布斯旧衣拍卖：价格考验果粉信仰","title_line_break":"乔布斯旧衣拍卖：\n价格考验果粉信仰","date":"2016-09-03 08:25:19","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c996311bc8e04e71000018","thumbnail_pic":"http://zkres.myzaker.com/201609/57c996327f52e9df1c000040_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c996327f52e9df1c000040_320.jpg","thumbnail_picsize":"600,394","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c996311bc8e04e71000018&m=1472874182","list_dtime":"2016-09-03 08:25:19"},{"pk":"57c99e9f1bc8e08678000004","title":"诺基亚发布2016上半年恶意软件调查报告","date":"2016-09-03 08:26:41","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c99e9f1bc8e08678000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57c99ea37f52e9f2690002ad_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c99ea37f52e9f2690002ad_320.jpg","thumbnail_picsize":"600,439","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c99e9f1bc8e08678000004&m=1472874182","list_dtime":"2016-09-03 08:26:41"},{"pk":"57ca13631bc8e09a3200000e","title":"Gear S3智能手表秋季开卖，售价399欧元","title_line_break":"Gear\nS3智能手表秋季开卖，售价399欧元","date":"2016-09-03 08:28:32","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca13631bc8e09a3200000e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca0f0f7f52e9074c00000c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca0f0f7f52e9074c00000c_320.jpg","thumbnail_picsize":"491,453","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca13631bc8e09a3200000e&m=1472874182","list_dtime":"2016-09-03 08:28:32"},{"pk":"57c9ed059490cb1859000002","title":"都怪iPhone 7?报告称DRAM价格将持续攀升","title_line_break":"都怪iPhone\n7?报告称DRAM价格将持续攀升","date":"2016-09-03 08:24:15","auther_name":"威锋网","weburl":"http://iphone.myzaker.com/l.php?l=57c9ed059490cb1859000002","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9ed059490cb1859000002&m=1472874183","list_dtime":"2016-09-03 08:24:15"},{"pk":"57c945719490cbb16f000007","title":"苹果发布会后它就上线了 让你家更安全","title_line_break":"苹果发布会后它就上线了\n让你家更安全","date":"2016-09-03 05:39:15","auther_name":"威锋网","weburl":"http://iphone.myzaker.com/l.php?l=57c945719490cbb16f000007","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9363e1bc8e08633000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9363e1bc8e08633000002_320.jpg","thumbnail_picsize":"620,413","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c945719490cbb16f000007&m=1472874183","list_dtime":"2016-09-03 05:39:15"},{"pk":"57c93ac79490cbce17000050","title":"性能大对比 骁龙821比骁龙820强多少","title_line_break":"性能大对比\n骁龙821比骁龙820强多少","date":"2016-09-03 05:42:22","auther_name":"手机中国","weburl":"http://iphone.myzaker.com/l.php?l=57c93ac79490cbce17000050","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8a83d1bc8e0c757000036_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8a83d1bc8e0c757000036_320.jpg","thumbnail_picsize":"600,338","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c93ac79490cbce17000050&m=1472874183","list_dtime":"2016-09-03 05:42:22"},{"pk":"57c945719490cbb16f00000f","title":"索尼音频之战","date":"2016-09-03 05:39:38","auther_name":"爱活网","weburl":"http://iphone.myzaker.com/l.php?l=57c945719490cbb16f00000f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9375b1bc8e00534000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9375b1bc8e00534000000_320.jpg","thumbnail_picsize":"660,371","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c945719490cbb16f00000f&m=1472874183","list_dtime":"2016-09-03 05:39:38"},{"pk":"57c82e711bc8e00115000004","title":"Win10版《纸牌》有多火？全球都在玩","date":"2016-09-03 01:41:03","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c82e711bc8e00115000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57c829ee7f52e96a7b0000cf_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c829ee7f52e96a7b0000cf_320.jpg","thumbnail_picsize":"600,331","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c82e711bc8e00115000004&m=1472874183","list_dtime":"2016-09-03 01:41:03"},{"pk":"57c6f4b61bc8e06759000005","title":"奥巴马体验VR走红，又被网友玩坏了","date":"2016-09-03 00:49:06","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c6f4b61bc8e06759000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3MjgzNTAzMV8xMzc0M19XNjAwSDM5OVM0NzY5My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3MjgzNTAzMV8xMzc0M19XNjAwSDM5OVM0NzY5My5qcGc=_1242.jpg","thumbnail_picsize":"600,399","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c6f4b61bc8e06759000005&m=1472874183","list_dtime":"2016-09-03 00:49:06"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca1bda9490cbec3e00001e,57c996321bc8e04e7100001b,57ca3c3b9490cbed3e000033,57c9919f9490cb5b6b000012,57c98e091bc8e0076e00000a,57ca2a581bc8e08a40000007","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c8ad199490cb4e77000006,57c92b629490cb1f18000045,57ca1d839490cb103f000025,57c99e9e1bc8e08678000001,57ca0a941bc8e03b2c000060,57c9625b1bc8e03c4e000009","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c9a1681bc8e0a47a000002,57ca01f71bc8e02a29000003,57ca1f949490cb463f000046,57ca1c631bc8e0cd35000027,57c95ef41bc8e00e4f000001,57ca1bda9490cbec3e00001f","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c9bf509490cb5460000006,57c985041bc8e00c69000001,57c997c41bc8e0a674000002,57ca29f69490cb9d1c00000c,57ca0a931bc8e03b2c00005e,57c9fc429490cbb02c000005","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca212e9490cbd13e000025,57ca01f71bc8e02a29000001,57ca1bda9490cbec3e00001d,57c996311bc8e04e71000018,57c99e9f1bc8e08678000004,57ca13631bc8e09a3200000e","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c945719490cbb16f000007,57c9ed059490cb1859000002,57c93ac79490cbce17000050,57c945719490cbb16f00000f,57c82e711bc8e00115000004,57c6f4b61bc8e06759000005","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}}],"article_block_colors":["#4fa7ab","#4fa7ab"],"only_text_page_bgcolors":["#4fa7ab","#4fa7ab"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/13.png?1413770585","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/13.png?1413770585","hidden_time":"24","need_userinfo":"NO","block_title":"科技频道","block_color":"#4fa7ab","desktop_color_number":"5","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_9343dec7e5e5c8843b2e73a0e132db1f","selected_index":"0","list":[{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]}}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=13&since_date=1472771674&nt=1&next_aticle_id=57c80c4c1bc8e0357f000001&_appid=androidphone&opage=2&otimestamp=143","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=13&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=13&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,5472a9b69490cb48180000f9,51a7103481853d8f4c000143&k=201609031150"}
     * catalog :
     * articles : [{"pk":"57c92b629490cb1f18000045","title":"你最想用哪款手机刷iOS？","date":"2016-09-02 15:33:54","auther_name":"数码脑残粉","page":"2","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57c92b629490cb1f18000045","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"156","title":"数码脑残粉","stitle":"数码科技达人聚集地","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=156","block_color":"","subscribe_count":"293428","post_count":"16599","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=13&app_ids=13&pk=57c92b629490cb1f18000045&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c92b629490cb1f18000045","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c92b629490cb1f18000045&m=1472874305","list_dtime":"2016-09-02 15:33:54"},{"pk":"57ca2a581bc8e08a40000007","title":"索尼Xperia XZ体验 又一部\u201c快时尚\u201d手机","date":"2016-09-03 10:37:48","auther_name":"腾讯数码","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57ca2a581bc8e08a40000007","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca29f11bc8e01d41000023_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca29f11bc8e01d41000023_320.jpg","thumbnail_picsize":"554,416","media_count":"8","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c76d419490cbb42c000016","block_title":"ZAKER带你直击IFA","title":"ZAKER带你直击IFA","block_in_title":"索尼Xperia XZ体验 又一部\u201c快时尚\u201d手机","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=13&topic_id=57c76d419490cbb42c000016&updated=1472872091"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca2a581bc8e08a40000007&m=1472874305","list_dtime":"2016-09-03 10:37:48"},{"pk":"57c9a1681bc8e0a47a000002","title":"惠普推出的新电脑怎么这么像音响！","date":"2016-09-03 08:30:14","auther_name":"腾讯数码","page":"3","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c9a1681bc8e0a47a000002","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M5YTE2ODFiYzhlMGE0N2EwMDAwMDBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M5YTE2ODFiYzhlMGE0N2EwMDAwMDBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"554,371","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9a1681bc8e0a47a000002&m=1472874305","list_dtime":"2016-09-03 08:30:14"},{"pk":"57c8ad199490cb4e77000006","title":"HDMI接口为何很重要？","date":"2016-09-03 02:12:51","auther_name":"中关村在线","page":"2","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c8ad199490cb4e77000006","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MjgyN180NTIwN19XNjQwSDM2MFM0NTU0OC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3Mjg2MjgyN180NTIwN19XNjQwSDM2MFM0NTU0OC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c8ad199490cb4e77000006&m=1472874305","list_dtime":"2016-09-03 02:12:51"},{"pk":"57ca1bda9490cbec3e00001e","title":"大疆首款小飞机曝光！这可真是一场好戏啊","date":"2016-09-03 08:41:00","auther_name":"爱范儿","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57ca1bda9490cbec3e00001e","thumbnail_pic":"http://zkres.myzaker.com/201609/57c989fa1bc8e0fc69000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c989fa1bc8e0fc69000001_320.jpg","thumbnail_picsize":"1200,750","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca1bda9490cbec3e00001e&m=1472874305","list_dtime":"2016-09-03 08:41:00"},{"pk":"57c996321bc8e04e7100001b","title":"疑似锤子T3清晰亮屏谍照曝光：流光魅影","title_line_break":"疑似锤子T3清晰亮屏谍照曝光：\n流光魅影","date":"2016-09-03 10:33:18","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c996321bc8e04e7100001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57c992637f52e9f26900006a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c992637f52e9f26900006a_320.jpg","thumbnail_picsize":"600,391","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c996321bc8e04e7100001b&m=1472874182","list_dtime":"2016-09-03 10:33:18"},{"pk":"57ca3c3b9490cbed3e000033","title":"这可能是Note 7\u201c炸机\u201d的元凶 ","date":"2016-09-03 10:57:15","auther_name":"腾讯科技","weburl":"http://iphone.myzaker.com/l.php?l=57ca3c3b9490cbed3e000033","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca3c3ea07aecc5230072e1_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca3c3ea07aecc5230072e1_320.jpg","thumbnail_picsize":"520,347","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca3c3b9490cbed3e000033&m=1472874182","list_dtime":"2016-09-03 10:57:15"},{"pk":"57c9919f9490cb5b6b000012","title":"iPhone 7亮光黑惊艳：工艺复杂或成新风向","title_line_break":"iPhone 7亮光黑惊艳：\n工艺复杂或成新风向","date":"2016-09-03 08:23:49","auther_name":"科客网","weburl":"http://iphone.myzaker.com/l.php?l=57c9919f9490cb5b6b000012","thumbnail_pic":"http://zkres.myzaker.com/201609/57c98f5b1bc8e0526e000011_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c98f5b1bc8e0526e000011_320.jpg","thumbnail_picsize":"550,412","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9919f9490cb5b6b000012&m=1472874183","list_dtime":"2016-09-03 08:23:49"},{"pk":"57c98e091bc8e0076e00000a","title":"联想K6/K6 Power/K6 Note新机三连发","date":"2016-09-03 10:33:38","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c98e091bc8e0076e00000a","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c98e091bc8e0076e00000a&m=1472874182","list_dtime":"2016-09-03 10:33:38"},{"pk":"57ca1d839490cb103f000025","title":"董明珠谈小米：它还敢估值四百五十亿美金吗","title_line_break":"董明珠谈小米：\n它还敢估值四百五十亿美金吗","date":"2016-09-03 09:14:28","auther_name":"虎嗅网","weburl":"http://iphone.myzaker.com/l.php?l=57ca1d839490cb103f000025","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca1d839490cb103f000025&m=1472874182","list_dtime":"2016-09-03 09:14:28"},{"pk":"57c99e9e1bc8e08678000001","title":"iPhone7的A10处理器找三星还是英特尔代工？","date":"2016-09-03 10:32:55","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c99e9e1bc8e08678000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57c99ea07f52e9df1c0001e3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c99ea07f52e9df1c0001e3_320.jpg","thumbnail_picsize":"600,337","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c99e9e1bc8e08678000001&m=1472874182","list_dtime":"2016-09-03 10:32:55"},{"pk":"57ca0a941bc8e03b2c000060","title":"联想Vibe P2正式发布：这个充电宝有点贵","title_line_break":"联想Vibe P2正式发布：\n这个充电宝有点贵","date":"2016-09-03 08:17:35","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca0a941bc8e03b2c000060","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca065e7f52e95860000156_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca065e7f52e95860000156_320.jpg","thumbnail_picsize":"600,483","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca0a941bc8e03b2c000060&m=1472874183","list_dtime":"2016-09-03 08:17:35"},{"pk":"57c9625b1bc8e03c4e000009","title":"还敢用伪基站？以后抓到罚到你想死","date":"2016-09-03 09:31:12","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c9625b1bc8e03c4e000009","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9625e7f52e9a434000248_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9625e7f52e9a434000248_320.jpg","thumbnail_picsize":"520,388","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9625b1bc8e03c4e000009&m=1472874182","list_dtime":"2016-09-03 09:31:12"},{"pk":"57ca01f71bc8e02a29000003","title":"双面女主播：表面宣传禁毒，私下贩毒","title_line_break":"双面女主播：\n表面宣传禁毒，私下贩毒","date":"2016-09-03 08:08:58","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca01f71bc8e02a29000003","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9fda67f52e958600000da_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9fda67f52e958600000da_320.jpg","thumbnail_picsize":"600,450","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca01f71bc8e02a29000003&m=1472874183","list_dtime":"2016-09-03 08:08:58"},{"pk":"57ca1f949490cb463f000046","title":"引得苹果孤注一掷的双摄像头有何魔力","date":"2016-09-03 09:13:49","auther_name":"腾讯科技","weburl":"http://iphone.myzaker.com/l.php?l=57ca1f949490cb463f000046","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca08c87f52e9d96b000066_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca08c87f52e9d96b000066_320.jpg","thumbnail_picsize":"640,387","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca1f949490cb463f000046&m=1472874182","list_dtime":"2016-09-03 09:13:49"},{"pk":"57ca1c631bc8e0cd35000027","title":"索尼展示Xperia家庭机器人，摸头泡咖啡","date":"2016-09-03 10:36:38","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca1c631bc8e0cd35000027","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca1c677f52e90e3800000d_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca1c677f52e90e3800000d_320.jpg","thumbnail_picsize":"600,397","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca1c631bc8e0cd35000027&m=1472874182","list_dtime":"2016-09-03 10:36:38"},{"pk":"57c95ef41bc8e00e4f000001","title":"让机器人\u201c活\u201d起来：可以！这很迪士尼！","title_line_break":"让机器人\u201c活\u201d起来：\n可以！这很迪士尼！","date":"2016-09-03 08:56:37","auther_name":"雷锋网","weburl":"http://iphone.myzaker.com/l.php?l=57c95ef41bc8e00e4f000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57c95e991bc8e01b4f000005_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c95e991bc8e01b4f000005_320.jpg","thumbnail_picsize":"675,753","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c95ef41bc8e00e4f000001&m=1472874182","list_dtime":"2016-09-03 08:56:37"},{"pk":"57ca1bda9490cbec3e00001f","title":"索尼要用它们告诉你音乐的真谛","date":"2016-09-03 09:12:58","auther_name":"爱范儿","weburl":"http://iphone.myzaker.com/l.php?l=57ca1bda9490cbec3e00001f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c96a6d1bc8e07255000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c96a6d1bc8e07255000000_320.jpg","thumbnail_picsize":"1200,750","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca1bda9490cbec3e00001f&m=1472874182","list_dtime":"2016-09-03 09:12:58"},{"pk":"57c985041bc8e00c69000001","title":"暴风影音去广告功能被判违法：赔腾讯50万","title_line_break":"暴风影音去广告功能被判违法：\n赔腾讯50万","date":"2016-09-03 08:19:23","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c985041bc8e00c69000001","media_count":"0","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c985041bc8e00c69000001&m=1472874183","list_dtime":"2016-09-03 08:19:23"},{"pk":"57c9bf509490cb5460000006","title":"12英寸MacBook接口不够？看看这款配件吧","date":"2016-09-03 08:18:21","auther_name":"威锋网","weburl":"http://iphone.myzaker.com/l.php?l=57c9bf509490cb5460000006","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9a5041bc8e06d7e000004_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9a5041bc8e06d7e000004_320.jpg","thumbnail_picsize":"506,374","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9bf509490cb5460000006&m=1472874183","list_dtime":"2016-09-03 08:18:21"},{"pk":"57c997c41bc8e0a674000002","title":"微软Hololens 全息眼镜开箱图赏","title_line_break":"微软Hololens\n全息眼镜开箱图赏","date":"2016-09-03 08:31:16","auther_name":"雷锋网","weburl":"http://iphone.myzaker.com/l.php?l=57c997c41bc8e0a674000002","thumbnail_pic":"http://zkres.myzaker.com/201609/57c997a51bc8e08e7200001a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c997a51bc8e08e7200001a_320.jpg","thumbnail_picsize":"880,568","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c997c41bc8e0a674000002&m=1472874182","list_dtime":"2016-09-03 08:31:16"},{"pk":"57ca29f69490cb9d1c00000c","title":"用事实说话 盘点京东十大热销机械键盘","title_line_break":"用事实说话\n盘点京东十大热销机械键盘","date":"2016-09-03 09:40:06","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57ca29f69490cb9d1c00000c","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9fbc71bc8e06027000003_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9fbc71bc8e06027000003_320.jpg","thumbnail_picsize":"640,477","media_count":"37","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca29f69490cb9d1c00000c&m=1472874182","list_dtime":"2016-09-03 09:40:06"},{"pk":"57ca0a931bc8e03b2c00005e","title":"LG V20三配色齐曝，命名让人纠结不已","title_line_break":"LG\nV20三配色齐曝，命名让人纠结不已","date":"2016-09-03 08:08:09","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca0a931bc8e03b2c00005e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca0a947f52e9d96b000070_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca0a947f52e9d96b000070_320.jpg","thumbnail_picsize":"600,396","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca0a931bc8e03b2c00005e&m=1472874183","list_dtime":"2016-09-03 08:08:09"},{"pk":"57c9fc429490cbb02c000005","title":"科技乱谈琴：新学期要换新手机 iPhone7","title_line_break":"科技乱谈琴：\n新学期要换新手机 iPhone7","date":"2016-09-03 08:16:17","auther_name":"中关村在线","weburl":"http://iphone.myzaker.com/l.php?l=57c9fc429490cbb02c000005","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9f7c51bc8e0dc24000050_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9f7c51bc8e0dc24000050_320.jpg","thumbnail_picsize":"640,428","media_count":"20","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9fc429490cbb02c000005&m=1472874183","list_dtime":"2016-09-03 08:16:17"},{"pk":"57ca01f71bc8e02a29000001","title":"三星Note7全球召回，运营商销售急刹","date":"2016-09-03 08:09:55","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca01f71bc8e02a29000001","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca01fa7f52e95860000109_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca01fa7f52e95860000109_320.jpg","thumbnail_picsize":"600,351","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca01f71bc8e02a29000001&m=1472874183","list_dtime":"2016-09-03 08:09:55"},{"pk":"57ca212e9490cbd13e000025","title":"骨感现实，Google 暂停模块化手机项目","title_line_break":"骨感现实，Google\n暂停模块化手机项目","date":"2016-09-03 09:10:35","auther_name":"爱范儿","weburl":"http://iphone.myzaker.com/l.php?l=57ca212e9490cbd13e000025","thumbnail_pic":"http://zkres.myzaker.com/201609/57c95a8a1bc8e0334b000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c95a8a1bc8e0334b000000_320.jpg","thumbnail_picsize":"1200,750","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca212e9490cbd13e000025&m=1472874182","list_dtime":"2016-09-03 09:10:35"},{"pk":"57ca1bda9490cbec3e00001d","title":"这款黑客游戏成了\u201c赛博朋克\u201d风格","date":"2016-09-03 09:11:14","auther_name":"爱范儿","weburl":"http://iphone.myzaker.com/l.php?l=57ca1bda9490cbec3e00001d","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9aa3b1bc8e0d702000009_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9aa3b1bc8e0d702000009_320.jpg","thumbnail_picsize":"1024,619","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca1bda9490cbec3e00001d&m=1472874182","list_dtime":"2016-09-03 09:11:14"},{"pk":"57c996311bc8e04e71000018","title":"乔布斯旧衣拍卖：价格考验果粉信仰","title_line_break":"乔布斯旧衣拍卖：\n价格考验果粉信仰","date":"2016-09-03 08:25:19","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c996311bc8e04e71000018","thumbnail_pic":"http://zkres.myzaker.com/201609/57c996327f52e9df1c000040_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c996327f52e9df1c000040_320.jpg","thumbnail_picsize":"600,394","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c996311bc8e04e71000018&m=1472874182","list_dtime":"2016-09-03 08:25:19"},{"pk":"57c99e9f1bc8e08678000004","title":"诺基亚发布2016上半年恶意软件调查报告","date":"2016-09-03 08:26:41","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c99e9f1bc8e08678000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57c99ea37f52e9f2690002ad_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c99ea37f52e9f2690002ad_320.jpg","thumbnail_picsize":"600,439","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c99e9f1bc8e08678000004&m=1472874182","list_dtime":"2016-09-03 08:26:41"},{"pk":"57ca13631bc8e09a3200000e","title":"Gear S3智能手表秋季开卖，售价399欧元","title_line_break":"Gear\nS3智能手表秋季开卖，售价399欧元","date":"2016-09-03 08:28:32","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57ca13631bc8e09a3200000e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ca0f0f7f52e9074c00000c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ca0f0f7f52e9074c00000c_320.jpg","thumbnail_picsize":"491,453","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57ca13631bc8e09a3200000e&m=1472874182","list_dtime":"2016-09-03 08:28:32"},{"pk":"57c9ed059490cb1859000002","title":"都怪iPhone 7?报告称DRAM价格将持续攀升","title_line_break":"都怪iPhone\n7?报告称DRAM价格将持续攀升","date":"2016-09-03 08:24:15","auther_name":"威锋网","weburl":"http://iphone.myzaker.com/l.php?l=57c9ed059490cb1859000002","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c9ed059490cb1859000002&m=1472874183","list_dtime":"2016-09-03 08:24:15"},{"pk":"57c945719490cbb16f000007","title":"苹果发布会后它就上线了 让你家更安全","title_line_break":"苹果发布会后它就上线了\n让你家更安全","date":"2016-09-03 05:39:15","auther_name":"威锋网","weburl":"http://iphone.myzaker.com/l.php?l=57c945719490cbb16f000007","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9363e1bc8e08633000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9363e1bc8e08633000002_320.jpg","thumbnail_picsize":"620,413","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c945719490cbb16f000007&m=1472874183","list_dtime":"2016-09-03 05:39:15"},{"pk":"57c93ac79490cbce17000050","title":"性能大对比 骁龙821比骁龙820强多少","title_line_break":"性能大对比\n骁龙821比骁龙820强多少","date":"2016-09-03 05:42:22","auther_name":"手机中国","weburl":"http://iphone.myzaker.com/l.php?l=57c93ac79490cbce17000050","thumbnail_pic":"http://zkres.myzaker.com/201609/57c8a83d1bc8e0c757000036_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c8a83d1bc8e0c757000036_320.jpg","thumbnail_picsize":"600,338","media_count":"4","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c93ac79490cbce17000050&m=1472874183","list_dtime":"2016-09-03 05:42:22"},{"pk":"57c945719490cbb16f00000f","title":"索尼音频之战","date":"2016-09-03 05:39:38","auther_name":"爱活网","weburl":"http://iphone.myzaker.com/l.php?l=57c945719490cbb16f00000f","thumbnail_pic":"http://zkres.myzaker.com/201609/57c9375b1bc8e00534000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c9375b1bc8e00534000000_320.jpg","thumbnail_picsize":"660,371","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c945719490cbb16f00000f&m=1472874183","list_dtime":"2016-09-03 05:39:38"},{"pk":"57c82e711bc8e00115000004","title":"Win10版《纸牌》有多火？全球都在玩","date":"2016-09-03 01:41:03","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c82e711bc8e00115000004","thumbnail_pic":"http://zkres.myzaker.com/201609/57c829ee7f52e96a7b0000cf_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c829ee7f52e96a7b0000cf_320.jpg","thumbnail_picsize":"600,331","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c82e711bc8e00115000004&m=1472874183","list_dtime":"2016-09-03 01:41:03"},{"pk":"57c6f4b61bc8e06759000005","title":"奥巴马体验VR走红，又被网友玩坏了","date":"2016-09-03 00:49:06","auther_name":"IT之家","weburl":"http://iphone.myzaker.com/l.php?l=57c6f4b61bc8e06759000005","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3MjgzNTAzMV8xMzc0M19XNjAwSDM5OVM0NzY5My5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDMvdXBfMTQ3MjgzNTAzMV8xMzc0M19XNjAwSDM5OVM0NzY5My5qcGc=_1242.jpg","thumbnail_picsize":"600,399","media_count":"10","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c6f4b61bc8e06759000005&m=1472874183","list_dtime":"2016-09-03 00:49:06"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca1bda9490cbec3e00001e,57c996321bc8e04e7100001b,57ca3c3b9490cbed3e000033,57c9919f9490cb5b6b000012,57c98e091bc8e0076e00000a,57ca2a581bc8e08a40000007","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c8ad199490cb4e77000006,57c92b629490cb1f18000045,57ca1d839490cb103f000025,57c99e9e1bc8e08678000001,57ca0a941bc8e03b2c000060,57c9625b1bc8e03c4e000009","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c9a1681bc8e0a47a000002,57ca01f71bc8e02a29000003,57ca1f949490cb463f000046,57ca1c631bc8e0cd35000027,57c95ef41bc8e00e4f000001,57ca1bda9490cbec3e00001f","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c9bf509490cb5460000006,57c985041bc8e00c69000001,57c997c41bc8e0a674000002,57ca29f69490cb9d1c00000c,57ca0a931bc8e03b2c00005e,57c9fc429490cbb02c000005","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ca212e9490cbd13e000025,57ca01f71bc8e02a29000001,57ca1bda9490cbec3e00001d,57c996311bc8e04e71000018,57c99e9f1bc8e08678000004,57ca13631bc8e09a3200000e","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c945719490cbb16f000007,57c9ed059490cb1859000002,57c93ac79490cbce17000050,57c945719490cbb16f00000f,57c82e711bc8e00115000004,57c6f4b61bc8e06759000005","diy":{"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}}],"article_block_colors":["#4fa7ab","#4fa7ab"],"only_text_page_bgcolors":["#4fa7ab","#4fa7ab"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/13.png?1413770585","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/13.png?1413770585","hidden_time":"24","need_userinfo":"NO","block_title":"科技频道","block_color":"#4fa7ab","desktop_color_number":"5","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_9343dec7e5e5c8843b2e73a0e132db1f","selected_index":"0","list":[{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=13&since_date=1472771674&nt=1&next_aticle_id=57c80c4c1bc8e0357f000001&_appid=androidphone&opage=2&otimestamp=143
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=13&need_app_integration=0
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=13&ids=5642f2aa9490cbb13200000e,54b09f669490cb527e0000ee,5472a9b69490cb48180000f9,51a7103481853d8f4c000143&k=201609031150
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/13.png?1413770585
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/13.png?1413770585
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 科技频道
         * block_color : #4fa7ab
         * desktop_color_number : 5
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_9343dec7e5e5c8843b2e73a0e132db1f
         * selected_index : 0
         * list : [{"pk":"zk_app_column_13","title":"综合","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_11542","title":"数码","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11542_zk_app_column_block_13","title":"数码测评","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11542&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_5","title":"互联网","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"5_zk_app_column_block_13","title":"互联网新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=5&catalog_appid=13","data_type":"news"}},{"pk":"zk_app_column_1039","title":"科学","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"1039_zk_app_column_block_13","title":"科学频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=1039&catalog_appid=13","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57c92b629490cb1f18000045
         * title : 你最想用哪款手机刷iOS？
         * date : 2016-09-02 15:33:54
         * auther_name : 数码脑残粉
         * page : 2
         * index : 2
         * weburl : http://iphone.myzaker.com/l.php?l=57c92b629490cb1f18000045
         * media_count : 0
         * is_full : NO
         * content :
         * type : other
         * special_info : {"open_type":"discussion","discussion":{"pk":"156","title":"数码脑残粉","stitle":"数码科技达人聚集地","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=156","block_color":"","subscribe_count":"293428","post_count":"16599","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=13&app_ids=13&pk=57c92b629490cb1f18000045&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c92b629490cb1f18000045","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"}
         * special_type : tag
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=13&pk=57c92b629490cb1f18000045&m=1472874305
         * list_dtime : 2016-09-02 15:33:54
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 2
             * articles : 57ca1bda9490cbec3e00001e,57c996321bc8e04e7100001b,57ca3c3b9490cbed3e000033,57c9919f9490cb5b6b000012,57c98e091bc8e0076e00000a,57ca2a581bc8e08a40000007
             * diy : {"bgimage_url":"http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","is_ad":"Y","stat_read_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read","ga_info":{"category":"AD","action":"Banner","send_after_showed":"Y"},"open_type":"web","need_user_info":"N","open_confirm":"","ads_id":"5775c9899490cbef0300003b","ads_title":"华为科技冠名160701-aPhone","ad_pk":"5775c9899490cbef0300003b","web_url":"http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y"}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres.myzaker.com/201609/aHR0cDovL3VwbG9hZC5teXpha2VyLmNvbS9kYXRhL2Fkcy8yMDE2LTA5LTAzLzE0NzI4NzEwNTgyMjM0LnBuZw==_2048.jpg
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * is_ad : Y
                 * stat_read_url : http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&action=read
                 * ga_info : {"category":"AD","action":"Banner","send_after_showed":"Y"}
                 * open_type : web
                 * need_user_info : N
                 * open_confirm :
                 * ads_id : 5775c9899490cbef0300003b
                 * ads_title : 华为科技冠名160701-aPhone
                 * ad_pk : 5775c9899490cbef0300003b
                 * web_url : http://iphone.myzaker.com/zaker/ads_stat.php?pk=13&app_id=13&_appid=androidphone&ads_id=5775c9899490cbef0300003b&url=http%3A%2F%2Fclickc.admaster.com.cn%2Fc%2Fa70421%2Cb1175906%2Cc1665%2Ci0%2Cm101%2Ch&action=click&need_user_info=Y
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String is_ad;
                    private String stat_read_url;
                    /**
                     * category : AD
                     * action : Banner
                     * send_after_showed : Y
                     */

                    private GaInfoBean ga_info;
                    private String open_type;
                    private String need_user_info;
                    private String open_confirm;
                    private String ads_id;
                    private String ads_title;
                    private String ad_pk;
                    private String web_url;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getIs_ad() {
                        return is_ad;
                    }

                    public void setIs_ad(String is_ad) {
                        this.is_ad = is_ad;
                    }

                    public String getStat_read_url() {
                        return stat_read_url;
                    }

                    public void setStat_read_url(String stat_read_url) {
                        this.stat_read_url = stat_read_url;
                    }

                    public GaInfoBean getGa_info() {
                        return ga_info;
                    }

                    public void setGa_info(GaInfoBean ga_info) {
                        this.ga_info = ga_info;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }

                    public String getNeed_user_info() {
                        return need_user_info;
                    }

                    public void setNeed_user_info(String need_user_info) {
                        this.need_user_info = need_user_info;
                    }

                    public String getOpen_confirm() {
                        return open_confirm;
                    }

                    public void setOpen_confirm(String open_confirm) {
                        this.open_confirm = open_confirm;
                    }

                    public String getAds_id() {
                        return ads_id;
                    }

                    public void setAds_id(String ads_id) {
                        this.ads_id = ads_id;
                    }

                    public String getAds_title() {
                        return ads_title;
                    }

                    public void setAds_title(String ads_title) {
                        this.ads_title = ads_title;
                    }

                    public String getAd_pk() {
                        return ad_pk;
                    }

                    public void setAd_pk(String ad_pk) {
                        this.ad_pk = ad_pk;
                    }

                    public String getWeb_url() {
                        return web_url;
                    }

                    public void setWeb_url(String web_url) {
                        this.web_url = web_url;
                    }

                    public static class GaInfoBean {
                        private String category;
                        private String action;
                        private String send_after_showed;

                        public String getCategory() {
                            return category;
                        }

                        public void setCategory(String category) {
                            this.category = category;
                        }

                        public String getAction() {
                            return action;
                        }

                        public void setAction(String action) {
                            this.action = action;
                        }

                        public String getSend_after_showed() {
                            return send_after_showed;
                        }

                        public void setSend_after_showed(String send_after_showed) {
                            this.send_after_showed = send_after_showed;
                        }
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_13
             * title : 综合
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"13","title":"科技频道","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 13
                 * title : 科技频道
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=13&catalog_appid=13
                 * data_type : news
                 * skey : eyJkYXRlIjoiMjAxNi0wOS0wMyIsInQiOiJhbSJ9
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;
                    private String skey;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }

                    public String getSkey() {
                        return skey;
                    }

                    public void setSkey(String skey) {
                        this.skey = skey;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String media_count;
            private String is_full;
            private String content;
            private String type;
            /**
             * open_type : discussion
             * discussion : {"pk":"156","title":"数码脑残粉","stitle":"数码科技达人聚集地","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=156","block_color":"","subscribe_count":"293428","post_count":"16599","need_user_info":"Y"}
             * stat_click_url : http://stat.myzaker.com/stat.php?app_id=13&app_ids=13&pk=57c92b629490cb1f18000045&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57c92b629490cb1f18000045
             * icon_url : http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String special_type;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getSpecial_type() {
                return special_type;
            }

            public void setSpecial_type(String special_type) {
                this.special_type = special_type;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String open_type;
                /**
                 * pk : 156
                 * title : 数码脑残粉
                 * stitle : 数码科技达人聚集地
                 * pic : http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png
                 * large_pic : http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f8d9490cb187b0000f9.png
                 * api_url : http://dis.myzaker.com/api/get_post.php?discussion_id=156
                 * block_color :
                 * subscribe_count : 293428
                 * post_count : 16599
                 * need_user_info : Y
                 */

                private DiscussionBean discussion;
                private String stat_click_url;
                private String icon_url;
                private String show_jingcai;
                private String list_nodsp;

                public String getOpen_type() {
                    return open_type;
                }

                public void setOpen_type(String open_type) {
                    this.open_type = open_type;
                }

                public DiscussionBean getDiscussion() {
                    return discussion;
                }

                public void setDiscussion(DiscussionBean discussion) {
                    this.discussion = discussion;
                }

                public String getStat_click_url() {
                    return stat_click_url;
                }

                public void setStat_click_url(String stat_click_url) {
                    this.stat_click_url = stat_click_url;
                }

                public String getIcon_url() {
                    return icon_url;
                }

                public void setIcon_url(String icon_url) {
                    this.icon_url = icon_url;
                }

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }

                public static class DiscussionBean {
                    private String pk;
                    private String title;
                    private String stitle;
                    private String pic;
                    private String large_pic;
                    private String api_url;
                    private String block_color;
                    private String subscribe_count;
                    private String post_count;
                    private String need_user_info;

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getStitle() {
                        return stitle;
                    }

                    public void setStitle(String stitle) {
                        this.stitle = stitle;
                    }

                    public String getPic() {
                        return pic;
                    }

                    public void setPic(String pic) {
                        this.pic = pic;
                    }

                    public String getLarge_pic() {
                        return large_pic;
                    }

                    public void setLarge_pic(String large_pic) {
                        this.large_pic = large_pic;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getBlock_color() {
                        return block_color;
                    }

                    public void setBlock_color(String block_color) {
                        this.block_color = block_color;
                    }

                    public String getSubscribe_count() {
                        return subscribe_count;
                    }

                    public void setSubscribe_count(String subscribe_count) {
                        this.subscribe_count = subscribe_count;
                    }

                    public String getPost_count() {
                        return post_count;
                    }

                    public void setPost_count(String post_count) {
                        this.post_count = post_count;
                    }

                    public String getNeed_user_info() {
                        return need_user_info;
                    }

                    public void setNeed_user_info(String need_user_info) {
                        this.need_user_info = need_user_info;
                    }
                }
            }
        }
    }
}
