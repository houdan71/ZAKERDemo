package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/5.
 */
public class Bean_top {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","catalog_url":"http://iphone.myzaker.com/zaker/blog2news_catalog.php?catalog_appid=8&back=&act=list","catalog_title":"子栏目","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=8&since_date=1473038393&nt=1&next_aticle_id=57cce5979490cbd844000020&_appid=androidphone&opage=2&otimestamp=170","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=8&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=8&ids=5642f2aa9490cbb13200000e,51a7106381853df24c000138&k=201609051400"},"articles":[{"pk":"57be9f559490cb1c56000073","title":"阅赛程数据榜单，看今日精彩赛事","date":"2016-09-05 11:57:34","auther_name":"体育疯","page":"2","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57be9f559490cb1c56000073","media_count":"0","is_full":"NO","content":"","type":"web2","special_info":{"open_type":"web","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57be9f559490cb1c56000073&title=%E9%98%85%E8%B5%9B%E7%A8%8B%E6%95%B0%E6%8D%AE%E6%A6%9C%E5%8D%95%EF%BC%8C%E7%9C%8B%E4%BB%8A%E6%97%A5%E7%B2%BE%E5%BD%A9%E8%B5%9B%E4%BA%8B&open_type=web&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fwww.tiyufeng.com%2Fhz%2Fzaker%2FmatchList.jsp%3Ftarget%3Dweb3","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=8&app_ids=8&pk=57be9f559490cb1c56000073&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57be9f559490cb1c56000073","icon_url":"http://zkres.myzaker.com/data/image/mark2/forecast_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57be9f559490cb1c56000073&m=1473055504","list_dtime":"2016-09-05 11:57:34"},{"pk":"579f1e469490cb0f470000af","title":"国足战伊朗，中锋该用张玉宁吗？","date":"2016-09-05 10:10:47","auther_name":"ZAKER话题","page":"3","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=579f1e469490cb0f470000af","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"88","title":"足球","stitle":"球迷集聚地，为你的主队助威！","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f369490cbff7a00013c.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f369490cbff7a00013c.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=88","block_color":"","subscribe_count":"190663","post_count":"5689","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=8&app_ids=8&pk=579f1e469490cb0f470000af&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D579f1e469490cb0f470000af","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=579f1e469490cb0f470000af&m=1473055504","list_dtime":"2016-09-05 10:10:47"},{"pk":"57c94cc59490cbe21700004b","title":"一见\u201c误终生\u201d，始终追随詹姆斯的嘉宜","date":"2016-09-05 10:30:32","auther_name":"ZAKER体育","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c94cc59490cbe21700004b","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c94cc59490cbe21700004b&title=%E4%B8%80%E8%A7%81%E2%80%9C%E8%AF%AF%E7%BB%88%E7%94%9F%E2%80%9D%EF%BC%8C%E5%A7%8B%E7%BB%88%E8%BF%BD%E9%9A%8F%E8%A9%B9%E5%A7%86%E6%96%AF%E7%9A%84%E5%98%89%E5%AE%9C&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_car.php%3Fpk%3D57c939df9490cb3018000050%26target%3Dweb3%26article_pk%3D57c94cc59490cbe21700004b","icon_url":"http://zkres.myzaker.com/data/image/mark2/zhuanlan_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57c94cc59490cbe21700004b&m=1473055504","list_dtime":"2016-09-05 10:30:32"},{"pk":"57cb99989490cbc035000028","title":"阿杜与火辣妹纸压马路 有说有笑","title_line_break":"阿杜与火辣妹纸压马路\n有说有笑","date":"2016-09-05 06:48:40","auther_name":"OnFire","page":"2","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57cb99989490cbc035000028","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb86fb1bc8e0ea0a000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb86fb1bc8e0ea0a000002_320.jpg","thumbnail_picsize":"600,561","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cb99989490cbc035000028&m=1473055504","list_dtime":"2016-09-05 06:48:40"},{"pk":"57cb96b49490cb7f35000014","title":"祝福！纳什晒新婚照 娇妻乃沙排女神","title_line_break":"祝福！纳什晒新婚照\n娇妻乃沙排女神","date":"2016-09-05 06:56:20","auther_name":"网易体育","page":"4","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57cb96b49490cb7f35000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbc7faa07aecc523013443_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbc7faa07aecc523013443_320.jpg","thumbnail_picsize":"480,430","media_count":"25","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cb96b49490cb7f35000014&m=1473055504","list_dtime":"2016-09-05 06:56:20"},{"pk":"57cbcc569490cb9b35000038","title":"爆红！日本撑杆跳美女颜值逆天","date":"2016-09-05 06:52:55","auther_name":"3G门户·体育","page":"6","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57cbcc569490cb9b35000038","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbcc84a07aecc523013888_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbcc84a07aecc523013888_320.jpg","thumbnail_picsize":"480,266","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cbcc569490cb9b35000038&m=1473055504","list_dtime":"2016-09-05 06:52:55"},{"pk":"57cbd9b59490cb7e35000031","title":"人美心善！女神刘湘参加公益活动","date":"2016-09-05 06:57:27","auther_name":"网易体育","page":"5","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57cbd9b59490cb7e35000031","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbda08a07aecc5230145d4_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbda08a07aecc5230145d4_320.jpg","thumbnail_picsize":"800,600","media_count":"13","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cbd9b59490cb7e35000031&m=1473055504","list_dtime":"2016-09-05 06:57:27"},{"pk":"57cbe5349490cb4763000046","title":"曝科勒约会骑士汤普森 疑公开恋情","title_line_break":"曝科勒约会骑士汤普森\n疑公开恋情","date":"2016-09-05 06:57:30","auther_name":"网易体育","page":"3","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57cbe5349490cb4763000046","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbe57fa07aecc523016166_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbe57fa07aecc523016166_320.jpg","thumbnail_picsize":"1024,909","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cbe5349490cb4763000046&m=1473055504","list_dtime":"2016-09-05 06:57:30"},{"pk":"57ccd1f89490cbf17d000017","title":"国足不需要虽败犹荣 世预赛只看分数","title_line_break":"国足不需要虽败犹荣\n世预赛只看分数","date":"2016-09-05 10:01:28","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd1f89490cbf17d000017","thumbnail_pic":"http://zkres.myzaker.com/201609/57c832e4a07aecf77e04a0f5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c832e4a07aecf77e04a0f5_320.jpg","thumbnail_picsize":"600,400","media_count":"1","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c933969490cb3018000049","block_title":"体坛星期事第五十八期","title":"体坛星期事第五十八期","block_in_title":"国足不需要虽败犹荣 世预赛只看分数","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=8&topic_id=57c933969490cb3018000049&updated=1473047369"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccd1f89490cbf17d000017&m=1473055504","list_dtime":"2016-09-05 10:01:28"},{"pk":"57cceb8d9490cb0f7e000043","title":"米兰中国老板承诺 冬季将砸1亿买人","title_line_break":"米兰中国老板承诺\n冬季将砸1亿买人","date":"2016-09-05 11:50:37","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57cceb8d9490cb0f7e000043","thumbnail_pic":"http://zkres.myzaker.com/201609/57cceb61a07aecc52301ef1b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cceb61a07aecc52301ef1b_320.jpg","thumbnail_picsize":"480,270","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cceb8d9490cb0f7e000043&m=1473055504","list_dtime":"2016-09-05 11:50:37"},{"pk":"57ccea9e9490cbf27d00002e","title":"4人超400场从未替补 詹皇为何缺席？","title_line_break":"4人超400场从未替补\n詹皇为何缺席？","date":"2016-09-05 11:46:38","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccea9e9490cbf27d00002e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTdkYjFiYzhlMGNjNjQwMDAwNGJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTdkYjFiYzhlMGNjNjQwMDAwNGJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"446,313","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccea9e9490cbf27d00002e&m=1473055504","list_dtime":"2016-09-05 11:46:38"},{"pk":"57ccea9e9490cbf27d000030","title":"库里谈薪水低：当时那是一种恩赐","title_line_break":"库里谈薪水低：\n当时那是一种恩赐","date":"2016-09-05 11:46:38","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccea9e9490cbf27d000030","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce7cc1bc8e0cc64000026_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce7cc1bc8e0cc64000026_320.jpg","thumbnail_picsize":"480,269","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccea9e9490cbf27d000030&m=1473055504","list_dtime":"2016-09-05 11:46:38"},{"pk":"57cce45f9490cb147e000052","title":"十动然拒！周琦新赛季只能在CBA练级","date":"2016-09-05 11:27:58","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57cce45f9490cb147e000052","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTE4OTFiYzhlMDM4NWUwMDAwMzBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTE4OTFiYzhlMDM4NWUwMDAwMzBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"450,300","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cce45f9490cb147e000052&m=1473055504","list_dtime":"2016-09-05 11:27:58"},{"pk":"57cce7071bc8e0cd64000001","title":"新季最佳主帅预测：波波第3 科尔落选","title_line_break":"新季最佳主帅预测：\n波波第3 科尔落选","date":"2016-09-05 13:54:23","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce7071bc8e0cd64000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTQ0MjFiYzhlMDA1NWYwMDAwMGVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTQ0MjFiYzhlMDA1NWYwMDAwMGVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,425","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cce7071bc8e0cd64000001&m=1473055504","list_dtime":"2016-09-05 13:54:23"},{"pk":"57cd08619490cb377e00006e","title":"国足需重整锋线 郜林强对抗性该领衔","title_line_break":"国足需重整锋线\n郜林强对抗性该领衔","date":"2016-09-05 13:53:50","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57cd08619490cb377e00006e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccea081bc8e02c67000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccea081bc8e02c67000007_320.jpg","thumbnail_picsize":"600,400","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cd08619490cb377e00006e&m=1473055504","list_dtime":"2016-09-05 13:53:50"},{"pk":"57cd07869490cb3a7e00003e","title":"前裁判爆料 阿Kun停赛背后有黑手？","title_line_break":"前裁判爆料\n阿Kun停赛背后有黑手？","date":"2016-09-05 13:51:58","auther_name":"PPTV第1体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd07869490cb3a7e00003e","thumbnail_pic":"http://zkres.myzaker.com/201608/57c50fad7f52e90e45000591_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c50fad7f52e90e45000591_320.jpg","thumbnail_picsize":"320,179","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cd07869490cb3a7e00003e&m=1473055504","list_dtime":"2016-09-05 13:51:58"},{"pk":"57ccef7f1bc8e0576a000006","title":"宫帅：体测只为督促 不会长期存在","title_line_break":"宫帅：\n体测只为督促 不会长期存在","date":"2016-09-05 13:45:31","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccef7f1bc8e0576a000006","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccef7f1bc8e0576a000006&m=1473055504","list_dtime":"2016-09-05 13:45:31"},{"pk":"57cd05cd9490cb3b7e000028","title":"曝曼联欲引格子 穆帅钦定其接班鲁尼","title_line_break":"曝曼联欲引格子\n穆帅钦定其接班鲁尼","date":"2016-09-05 13:42:37","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd05cd9490cb3b7e000028","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccee771bc8e01067000015_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccee771bc8e01067000015_320.jpg","thumbnail_picsize":"960,607","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cd05cd9490cb3b7e000028&m=1473055504","list_dtime":"2016-09-05 13:42:37"},{"pk":"57ccda6a1bc8e02a0c00002d","title":"库里突袭广州校园球场 被对手狂\u201c嘘\u201d","title_line_break":"库里突袭广州校园球场\n被对手狂\u201c嘘\u201d","date":"2016-09-05 10:50:33","auther_name":"触电","weburl":"http://iphone.myzaker.com/l.php?l=57ccda6a1bc8e02a0c00002d","thumbnail_pic":"http://zkres1.myzaker.com/201609/57ccd8b1a07aecc52301daf3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd9b6a07aecc52301dba6_320.jpg","thumbnail_picsize":"640,576","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccda6a1bc8e02a0c00002d&m=1473055285","list_dtime":"2016-09-05 10:50:33"},{"pk":"57ccd25f9490cbe17d000021","title":"高洪波将变阵出击伊朗：张琳芃踢中卫","title_line_break":"高洪波将变阵出击伊朗：\n张琳芃踢中卫","date":"2016-09-05 10:30:27","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd25f9490cbe17d000021","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd275f5a2246262000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd275f5a2246262000001_320.jpg","thumbnail_picsize":"1024,681","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccd25f9490cbe17d000021&m=1473055285","list_dtime":"2016-09-05 10:30:27"},{"pk":"57ccdbbf9490cbf77d000026","title":"分裂！贝尔高年薪引队内两大佬不满","date":"2016-09-05 10:43:11","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdbbf9490cbf77d000026","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccb66a07aecc52301d2c9_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdb87a07aecc52301dce8_320.jpg","thumbnail_picsize":"550,313","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccdbbf9490cbf77d000026&m=1473055285","list_dtime":"2016-09-05 10:43:11"},{"pk":"57cccaeb9490cb047e000020","title":"麻烦多于胜利？罗斯丑闻或令纽约后悔","date":"2016-09-05 09:31:23","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cccaeb9490cb047e000020","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccaeea07aecc52301d231_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccaeea07aecc52301d231_320.jpg","thumbnail_picsize":"534,401","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cccaeb9490cb047e000020&m=1473055286","list_dtime":"2016-09-05 09:31:23"},{"pk":"57ccd79c9490cb357e00002b","title":"抠门！曼联禁止大腕与对手换球衣","date":"2016-09-05 10:25:32","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd79c9490cb357e00002b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd78aa07aecc52301d983_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd78aa07aecc52301d983_320.jpg","thumbnail_picsize":"536,400","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccd79c9490cb357e00002b&m=1473055285","list_dtime":"2016-09-05 10:25:32"},{"pk":"57cce3f39490cb147e000050","title":"马努常与马刺队友聚餐 跟大加聊新季","title_line_break":"马努常与马刺队友聚餐\n跟大加聊新季","date":"2016-09-05 11:18:11","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce3f39490cb147e000050","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce3dea07aecc52301e913_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce3dea07aecc52301e913_320.jpg","thumbnail_picsize":"529,402","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cce3f39490cb147e000050&m=1473055285","list_dtime":"2016-09-05 11:18:11"},{"pk":"57ccda2c9490cb0d7e000026","title":"火箭关注周琦已多年 今年放弃因两点","title_line_break":"火箭关注周琦已多年\n今年放弃因两点","date":"2016-09-05 10:36:28","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccda2c9490cb0d7e000026","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccda0ba07aecc52301dbe6_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccda0ba07aecc52301dbe6_320.jpg","thumbnail_picsize":"550,415","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccda2c9490cb0d7e000026&m=1473055285","list_dtime":"2016-09-05 10:36:28"},{"pk":"57ccd8839490cbd77d00001c","title":"妈妈，别问我为什么跪着看手机！","date":"2016-09-05 10:29:23","auther_name":"壹球ONEBALL","weburl":"http://iphone.myzaker.com/l.php?l=57ccd8839490cbd77d00001c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZDg1Y2EwN2FlY2M1MjMwMWRhYTRfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZDg1Y2EwN2FlY2M1MjMwMWRhYTRfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,300","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccd8839490cbd77d00001c&m=1473055285","list_dtime":"2016-09-05 10:29:23"},{"pk":"57ccc8399490cb0a7e00000a","title":"皇马门神伤势加重 缺席4战无缘PK潜艇","title_line_break":"皇马门神伤势加重\n缺席4战无缘PK潜艇","date":"2016-09-05 09:19:53","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccc8399490cb0a7e00000a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc7f5a07aecc52301d0f1_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc7f5a07aecc52301d0f1_320.jpg","thumbnail_picsize":"549,348","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccc8399490cb0a7e00000a&m=1473055286","list_dtime":"2016-09-05 09:19:53"},{"pk":"57ccdced9490cb187e000030","title":"国足欲变四后卫 任航还能继续首发？","title_line_break":"国足欲变四后卫\n任航还能继续首发？","date":"2016-09-05 10:48:52","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57ccdced9490cb187e000030","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTkxZGEwN2FlY2M1MjMwMWVlNjVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTkxZGEwN2FlY2M1MjMwMWVlNjVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccdced9490cb187e000030&m=1473055285","list_dtime":"2016-09-05 10:48:52"},{"pk":"57cccc8c9490cb3c7e000015","title":"诺伊尔不忘前锋梦 转身过人美如画","title_line_break":"诺伊尔不忘前锋梦\n转身过人美如画","date":"2016-09-05 10:15:46","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cccc8c9490cb3c7e000015","thumbnail_pic":"http://zkres.myzaker.com/201609/57c835b71bc8e0bf1a000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccc8da07aecc52301d327_320.jpg","thumbnail_picsize":"450,253","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cccc8c9490cb3c7e000015&m=1473055285","list_dtime":"2016-09-05 10:15:46"},{"pk":"57ccdeb09490cbf87d00002c","title":"大器晚成！洛瑞明夏有望拿1.5亿","date":"2016-09-05 10:55:44","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdeb09490cbf87d00002c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdea0a07aecc52301e2a5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdea0a07aecc52301e2a5_320.jpg","thumbnail_picsize":"600,446","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccdeb09490cbf87d00002c&m=1473055285","list_dtime":"2016-09-05 10:55:44"},{"pk":"57cce0219490cb117e00003e","title":"上海男篮大外援抵沪 季前赛将战火箭","title_line_break":"上海男篮大外援抵沪\n季前赛将战火箭","date":"2016-09-05 11:01:53","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce0219490cb117e00003e","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce013a07aecc52301e569_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce013a07aecc52301e569_320.jpg","thumbnail_picsize":"541,304","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cce0219490cb117e00003e&m=1473055285","list_dtime":"2016-09-05 11:01:53"},{"pk":"57ccda609490cbe47d00001b","title":"克洛普：梅西在西甲散步也进5球","title_line_break":"克洛普：\n梅西在西甲散步也进5球","date":"2016-09-05 10:37:20","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccda609490cbe47d00001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cad54e1bc8e0272b000024_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccda64f5a2248c62000003_320.jpg","thumbnail_picsize":"450,313","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccda609490cbe47d00001b&m=1473055285","list_dtime":"2016-09-05 10:37:20"},{"pk":"57ccebfe9490cbd77d000026","title":"做备胎！曝切尔西签回昔日弃将内幕","date":"2016-09-05 11:52:30","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccebfe9490cbd77d000026","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccebc5a07aecc52301ef41_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccebc5a07aecc52301ef41_320.jpg","thumbnail_picsize":"480,314","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccebfe9490cbd77d000026&m=1473055285","list_dtime":"2016-09-05 11:52:30"},{"pk":"57ccdced9490cb187e000031","title":"英格兰像保级队 三狮到底谁不争气？","title_line_break":"英格兰像保级队\n三狮到底谁不争气？","date":"2016-09-05 10:52:21","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57ccdced9490cb187e000031","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd0781bc8e0c05500002e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd0781bc8e0c05500002e_320.jpg","thumbnail_picsize":"450,273","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccdced9490cb187e000031&m=1473055285","list_dtime":"2016-09-05 10:52:21"},{"pk":"57cccb979490cb247e000032","title":"曝贝尔谈妥续约 如愿获C罗级别待遇","title_line_break":"曝贝尔谈妥续约\n如愿获C罗级别待遇","date":"2016-09-05 10:15:46","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cccb979490cb247e000032","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccb66a07aecc52301d2c9_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccb66a07aecc52301d2c9_320.jpg","thumbnail_picsize":"550,313","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cccb979490cb247e000032&m=1473055285","list_dtime":"2016-09-05 10:15:46"},{"pk":"57cce57c9490cb0e7e000043","title":"曾文鼎与女友结婚 结束16年爱情长跑","title_line_break":"曾文鼎与女友结婚\n结束16年爱情长跑","date":"2016-09-05 11:24:44","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce57c9490cb0e7e000043","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce588a07aecc52301eb74_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce588a07aecc52301eb74_320.jpg","thumbnail_picsize":"550,412","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cce57c9490cb0e7e000043&m=1473055285","list_dtime":"2016-09-05 11:24:44"}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cceb8d9490cb0f7e000043,57ccd1f89490cbf17d000017,57ccea9e9490cbf27d00002e,57ccea9e9490cbf27d000030,57cce45f9490cb147e000052,57c94cc59490cbe21700004b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cd08619490cb377e00006e,57be9f559490cb1c56000073,57cce7071bc8e0cd64000001,57cd07869490cb3a7e00003e,57ccef7f1bc8e0576a000006,57cb99989490cbc035000028","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccda6a1bc8e02a0c00002d,57cd05cd9490cb3b7e000028,57ccd25f9490cbe17d000021,57ccdbbf9490cbf77d000026,579f1e469490cb0f470000af,57cbe5349490cb4763000046","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccd79c9490cb357e00002b,57cccaeb9490cb047e000020,57cce3f39490cb147e000050,57ccda2c9490cb0d7e000026,57ccd8839490cbd77d00001c,57cb96b49490cb7f35000014","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccdced9490cb187e000030,57ccc8399490cb0a7e00000a,57cccc8c9490cb3c7e000015,57ccdeb09490cbf87d00002c,57cce0219490cb117e00003e,57cbd9b59490cb7e35000031","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccebfe9490cbd77d000026,57ccda609490cbe47d00001b,57ccdced9490cb187e000031,57cccb979490cb247e000032,57cce57c9490cb0e7e000043,57cbcc569490cb9b35000038","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}}],"article_block_colors":["#5bd39f","#5bd39f"],"only_text_page_bgcolors":["#5bd39f","#5bd39f"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/8.png?t=1471575641","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/8.png?t=1471575641","hidden_time":"24","need_userinfo":"NO","block_title":"体育频道","block_color":"#5bd39f","desktop_color_number":"14","use_original_icon":"N"},"column_info":{"pk":"zk_app_column_info_pk_8f877381c422698ecd6a9aa028177af7","selected_index":"0","list":[{"pk":"zk_app_column_8","title":"头条","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_12083","title":"足球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12083_zk_app_column_block_8","title":"足球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12083&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12084","title":"篮球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12084_zk_app_column_block_8","title":"篮球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12084&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_11610","title":"综合","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11610_zk_app_column_block_8","title":"综合体育","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11610&catalog_appid=8","data_type":"news"}}]}}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","catalog_url":"http://iphone.myzaker.com/zaker/blog2news_catalog.php?catalog_appid=8&back=&act=list","catalog_title":"子栏目","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=8&since_date=1473038393&nt=1&next_aticle_id=57cce5979490cbd844000020&_appid=androidphone&opage=2&otimestamp=170","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=8&need_app_integration=0","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=8&ids=5642f2aa9490cbb13200000e,51a7106381853df24c000138&k=201609051400"}
     * articles : [{"pk":"57be9f559490cb1c56000073","title":"阅赛程数据榜单，看今日精彩赛事","date":"2016-09-05 11:57:34","auther_name":"体育疯","page":"2","index":"2","weburl":"http://iphone.myzaker.com/l.php?l=57be9f559490cb1c56000073","media_count":"0","is_full":"NO","content":"","type":"web2","special_info":{"open_type":"web","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57be9f559490cb1c56000073&title=%E9%98%85%E8%B5%9B%E7%A8%8B%E6%95%B0%E6%8D%AE%E6%A6%9C%E5%8D%95%EF%BC%8C%E7%9C%8B%E4%BB%8A%E6%97%A5%E7%B2%BE%E5%BD%A9%E8%B5%9B%E4%BA%8B&open_type=web&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fwww.tiyufeng.com%2Fhz%2Fzaker%2FmatchList.jsp%3Ftarget%3Dweb3","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=8&app_ids=8&pk=57be9f559490cb1c56000073&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57be9f559490cb1c56000073","icon_url":"http://zkres.myzaker.com/data/image/mark2/forecast_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57be9f559490cb1c56000073&m=1473055504","list_dtime":"2016-09-05 11:57:34"},{"pk":"579f1e469490cb0f470000af","title":"国足战伊朗，中锋该用张玉宁吗？","date":"2016-09-05 10:10:47","auther_name":"ZAKER话题","page":"3","index":"5","weburl":"http://iphone.myzaker.com/l.php?l=579f1e469490cb0f470000af","media_count":"0","is_full":"NO","content":"","type":"other","special_info":{"open_type":"discussion","discussion":{"pk":"88","title":"足球","stitle":"球迷集聚地，为你的主队助威！","pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f369490cbff7a00013c.png","large_pic":"http://disres.myzaker.com/img_upload/discussion/disicon/2016/03/07/56dd3f369490cbff7a00013c.png","api_url":"http://dis.myzaker.com/api/get_post.php?discussion_id=88","block_color":"","subscribe_count":"190663","post_count":"5689","need_user_info":"Y"},"stat_click_url":"http://stat.myzaker.com/stat.php?app_id=8&app_ids=8&pk=579f1e469490cb0f470000af&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D579f1e469490cb0f470000af","icon_url":"http://zkres.myzaker.com/data/image/mark2/huati_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=579f1e469490cb0f470000af&m=1473055504","list_dtime":"2016-09-05 10:10:47"},{"pk":"57c94cc59490cbe21700004b","title":"一见\u201c误终生\u201d，始终追随詹姆斯的嘉宜","date":"2016-09-05 10:30:32","auther_name":"ZAKER体育","page":"1","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57c94cc59490cbe21700004b","media_count":"0","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57c94cc59490cbe21700004b&title=%E4%B8%80%E8%A7%81%E2%80%9C%E8%AF%AF%E7%BB%88%E7%94%9F%E2%80%9D%EF%BC%8C%E5%A7%8B%E7%BB%88%E8%BF%BD%E9%9A%8F%E8%A9%B9%E5%A7%86%E6%96%AF%E7%9A%84%E5%98%89%E5%AE%9C&open_type=web3&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_car.php%3Fpk%3D57c939df9490cb3018000050%26target%3Dweb3%26article_pk%3D57c94cc59490cbe21700004b","icon_url":"http://zkres.myzaker.com/data/image/mark2/zhuanlan_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"special_type":"tag","full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57c94cc59490cbe21700004b&m=1473055504","list_dtime":"2016-09-05 10:30:32"},{"pk":"57cb99989490cbc035000028","title":"阿杜与火辣妹纸压马路 有说有笑","title_line_break":"阿杜与火辣妹纸压马路\n有说有笑","date":"2016-09-05 06:48:40","auther_name":"OnFire","page":"2","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57cb99989490cbc035000028","thumbnail_pic":"http://zkres.myzaker.com/201609/57cb86fb1bc8e0ea0a000002_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cb86fb1bc8e0ea0a000002_320.jpg","thumbnail_picsize":"600,561","media_count":"8","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cb99989490cbc035000028&m=1473055504","list_dtime":"2016-09-05 06:48:40"},{"pk":"57cb96b49490cb7f35000014","title":"祝福！纳什晒新婚照 娇妻乃沙排女神","title_line_break":"祝福！纳什晒新婚照\n娇妻乃沙排女神","date":"2016-09-05 06:56:20","auther_name":"网易体育","page":"4","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57cb96b49490cb7f35000014","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbc7faa07aecc523013443_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbc7faa07aecc523013443_320.jpg","thumbnail_picsize":"480,430","media_count":"25","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cb96b49490cb7f35000014&m=1473055504","list_dtime":"2016-09-05 06:56:20"},{"pk":"57cbcc569490cb9b35000038","title":"爆红！日本撑杆跳美女颜值逆天","date":"2016-09-05 06:52:55","auther_name":"3G门户·体育","page":"6","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57cbcc569490cb9b35000038","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbcc84a07aecc523013888_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbcc84a07aecc523013888_320.jpg","thumbnail_picsize":"480,266","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cbcc569490cb9b35000038&m=1473055504","list_dtime":"2016-09-05 06:52:55"},{"pk":"57cbd9b59490cb7e35000031","title":"人美心善！女神刘湘参加公益活动","date":"2016-09-05 06:57:27","auther_name":"网易体育","page":"5","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57cbd9b59490cb7e35000031","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbda08a07aecc5230145d4_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbda08a07aecc5230145d4_320.jpg","thumbnail_picsize":"800,600","media_count":"13","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cbd9b59490cb7e35000031&m=1473055504","list_dtime":"2016-09-05 06:57:27"},{"pk":"57cbe5349490cb4763000046","title":"曝科勒约会骑士汤普森 疑公开恋情","title_line_break":"曝科勒约会骑士汤普森\n疑公开恋情","date":"2016-09-05 06:57:30","auther_name":"网易体育","page":"3","index":"6","weburl":"http://iphone.myzaker.com/l.php?l=57cbe5349490cb4763000046","thumbnail_pic":"http://zkres.myzaker.com/201609/57cbe57fa07aecc523016166_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cbe57fa07aecc523016166_320.jpg","thumbnail_picsize":"1024,909","media_count":"7","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cbe5349490cb4763000046&m=1473055504","list_dtime":"2016-09-05 06:57:30"},{"pk":"57ccd1f89490cbf17d000017","title":"国足不需要虽败犹荣 世预赛只看分数","title_line_break":"国足不需要虽败犹荣\n世预赛只看分数","date":"2016-09-05 10:01:28","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd1f89490cbf17d000017","thumbnail_pic":"http://zkres.myzaker.com/201609/57c832e4a07aecf77e04a0f5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c832e4a07aecf77e04a0f5_320.jpg","thumbnail_picsize":"600,400","media_count":"1","is_full":"NO","content":"","special_type":"topic","special_info":{"icon_type":"1","block_info":{"pk":"57c933969490cb3018000049","block_title":"体坛星期事第五十八期","title":"体坛星期事第五十八期","block_in_title":"国足不需要虽败犹荣 世预赛只看分数","type":"user","need_userinfo":"NO","skey":"","api_url":"http://iphone.myzaker.com/zaker/topic.php?app_id=8&topic_id=57c933969490cb3018000049&updated=1473047369"},"icon_url":"http://zkres.myzaker.com/data/image/mark2/topic_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccd1f89490cbf17d000017&m=1473055504","list_dtime":"2016-09-05 10:01:28"},{"pk":"57cceb8d9490cb0f7e000043","title":"米兰中国老板承诺 冬季将砸1亿买人","title_line_break":"米兰中国老板承诺\n冬季将砸1亿买人","date":"2016-09-05 11:50:37","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57cceb8d9490cb0f7e000043","thumbnail_pic":"http://zkres.myzaker.com/201609/57cceb61a07aecc52301ef1b_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cceb61a07aecc52301ef1b_320.jpg","thumbnail_picsize":"480,270","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cceb8d9490cb0f7e000043&m=1473055504","list_dtime":"2016-09-05 11:50:37"},{"pk":"57ccea9e9490cbf27d00002e","title":"4人超400场从未替补 詹皇为何缺席？","title_line_break":"4人超400场从未替补\n詹皇为何缺席？","date":"2016-09-05 11:46:38","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccea9e9490cbf27d00002e","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTdkYjFiYzhlMGNjNjQwMDAwNGJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTdkYjFiYzhlMGNjNjQwMDAwNGJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"446,313","media_count":"6","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccea9e9490cbf27d00002e&m=1473055504","list_dtime":"2016-09-05 11:46:38"},{"pk":"57ccea9e9490cbf27d000030","title":"库里谈薪水低：当时那是一种恩赐","title_line_break":"库里谈薪水低：\n当时那是一种恩赐","date":"2016-09-05 11:46:38","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccea9e9490cbf27d000030","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce7cc1bc8e0cc64000026_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce7cc1bc8e0cc64000026_320.jpg","thumbnail_picsize":"480,269","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccea9e9490cbf27d000030&m=1473055504","list_dtime":"2016-09-05 11:46:38"},{"pk":"57cce45f9490cb147e000052","title":"十动然拒！周琦新赛季只能在CBA练级","date":"2016-09-05 11:27:58","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57cce45f9490cb147e000052","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTE4OTFiYzhlMDM4NWUwMDAwMzBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTE4OTFiYzhlMDM4NWUwMDAwMzBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"450,300","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cce45f9490cb147e000052&m=1473055504","list_dtime":"2016-09-05 11:27:58"},{"pk":"57cce7071bc8e0cd64000001","title":"新季最佳主帅预测：波波第3 科尔落选","title_line_break":"新季最佳主帅预测：\n波波第3 科尔落选","date":"2016-09-05 13:54:23","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce7071bc8e0cd64000001","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTQ0MjFiYzhlMDA1NWYwMDAwMGVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTQ0MjFiYzhlMDA1NWYwMDAwMGVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,425","media_count":"5","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cce7071bc8e0cd64000001&m=1473055504","list_dtime":"2016-09-05 13:54:23"},{"pk":"57cd08619490cb377e00006e","title":"国足需重整锋线 郜林强对抗性该领衔","title_line_break":"国足需重整锋线\n郜林强对抗性该领衔","date":"2016-09-05 13:53:50","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57cd08619490cb377e00006e","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccea081bc8e02c67000007_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccea081bc8e02c67000007_320.jpg","thumbnail_picsize":"600,400","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cd08619490cb377e00006e&m=1473055504","list_dtime":"2016-09-05 13:53:50"},{"pk":"57cd07869490cb3a7e00003e","title":"前裁判爆料 阿Kun停赛背后有黑手？","title_line_break":"前裁判爆料\n阿Kun停赛背后有黑手？","date":"2016-09-05 13:51:58","auther_name":"PPTV第1体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd07869490cb3a7e00003e","thumbnail_pic":"http://zkres.myzaker.com/201608/57c50fad7f52e90e45000591_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c50fad7f52e90e45000591_320.jpg","thumbnail_picsize":"320,179","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cd07869490cb3a7e00003e&m=1473055504","list_dtime":"2016-09-05 13:51:58"},{"pk":"57ccef7f1bc8e0576a000006","title":"宫帅：体测只为督促 不会长期存在","title_line_break":"宫帅：\n体测只为督促 不会长期存在","date":"2016-09-05 13:45:31","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccef7f1bc8e0576a000006","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccef7f1bc8e0576a000006&m=1473055504","list_dtime":"2016-09-05 13:45:31"},{"pk":"57cd05cd9490cb3b7e000028","title":"曝曼联欲引格子 穆帅钦定其接班鲁尼","title_line_break":"曝曼联欲引格子\n穆帅钦定其接班鲁尼","date":"2016-09-05 13:42:37","auther_name":"凤凰体育","weburl":"http://iphone.myzaker.com/l.php?l=57cd05cd9490cb3b7e000028","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccee771bc8e01067000015_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccee771bc8e01067000015_320.jpg","thumbnail_picsize":"960,607","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cd05cd9490cb3b7e000028&m=1473055504","list_dtime":"2016-09-05 13:42:37"},{"pk":"57ccda6a1bc8e02a0c00002d","title":"库里突袭广州校园球场 被对手狂\u201c嘘\u201d","title_line_break":"库里突袭广州校园球场\n被对手狂\u201c嘘\u201d","date":"2016-09-05 10:50:33","auther_name":"触电","weburl":"http://iphone.myzaker.com/l.php?l=57ccda6a1bc8e02a0c00002d","thumbnail_pic":"http://zkres1.myzaker.com/201609/57ccd8b1a07aecc52301daf3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd9b6a07aecc52301dba6_320.jpg","thumbnail_picsize":"640,576","media_count":"17","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccda6a1bc8e02a0c00002d&m=1473055285","list_dtime":"2016-09-05 10:50:33"},{"pk":"57ccd25f9490cbe17d000021","title":"高洪波将变阵出击伊朗：张琳芃踢中卫","title_line_break":"高洪波将变阵出击伊朗：\n张琳芃踢中卫","date":"2016-09-05 10:30:27","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd25f9490cbe17d000021","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd275f5a2246262000001_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd275f5a2246262000001_320.jpg","thumbnail_picsize":"1024,681","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccd25f9490cbe17d000021&m=1473055285","list_dtime":"2016-09-05 10:30:27"},{"pk":"57ccdbbf9490cbf77d000026","title":"分裂！贝尔高年薪引队内两大佬不满","date":"2016-09-05 10:43:11","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdbbf9490cbf77d000026","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccb66a07aecc52301d2c9_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdb87a07aecc52301dce8_320.jpg","thumbnail_picsize":"550,313","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccdbbf9490cbf77d000026&m=1473055285","list_dtime":"2016-09-05 10:43:11"},{"pk":"57cccaeb9490cb047e000020","title":"麻烦多于胜利？罗斯丑闻或令纽约后悔","date":"2016-09-05 09:31:23","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cccaeb9490cb047e000020","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccaeea07aecc52301d231_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccaeea07aecc52301d231_320.jpg","thumbnail_picsize":"534,401","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cccaeb9490cb047e000020&m=1473055286","list_dtime":"2016-09-05 09:31:23"},{"pk":"57ccd79c9490cb357e00002b","title":"抠门！曼联禁止大腕与对手换球衣","date":"2016-09-05 10:25:32","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccd79c9490cb357e00002b","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd78aa07aecc52301d983_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd78aa07aecc52301d983_320.jpg","thumbnail_picsize":"536,400","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccd79c9490cb357e00002b&m=1473055285","list_dtime":"2016-09-05 10:25:32"},{"pk":"57cce3f39490cb147e000050","title":"马努常与马刺队友聚餐 跟大加聊新季","title_line_break":"马努常与马刺队友聚餐\n跟大加聊新季","date":"2016-09-05 11:18:11","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce3f39490cb147e000050","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce3dea07aecc52301e913_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce3dea07aecc52301e913_320.jpg","thumbnail_picsize":"529,402","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cce3f39490cb147e000050&m=1473055285","list_dtime":"2016-09-05 11:18:11"},{"pk":"57ccda2c9490cb0d7e000026","title":"火箭关注周琦已多年 今年放弃因两点","title_line_break":"火箭关注周琦已多年\n今年放弃因两点","date":"2016-09-05 10:36:28","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccda2c9490cb0d7e000026","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccda0ba07aecc52301dbe6_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccda0ba07aecc52301dbe6_320.jpg","thumbnail_picsize":"550,415","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccda2c9490cb0d7e000026&m=1473055285","list_dtime":"2016-09-05 10:36:28"},{"pk":"57ccd8839490cbd77d00001c","title":"妈妈，别问我为什么跪着看手机！","date":"2016-09-05 10:29:23","auther_name":"壹球ONEBALL","weburl":"http://iphone.myzaker.com/l.php?l=57ccd8839490cbd77d00001c","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZDg1Y2EwN2FlY2M1MjMwMWRhYTRfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZDg1Y2EwN2FlY2M1MjMwMWRhYTRfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,300","media_count":"18","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccd8839490cbd77d00001c&m=1473055285","list_dtime":"2016-09-05 10:29:23"},{"pk":"57ccc8399490cb0a7e00000a","title":"皇马门神伤势加重 缺席4战无缘PK潜艇","title_line_break":"皇马门神伤势加重\n缺席4战无缘PK潜艇","date":"2016-09-05 09:19:53","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccc8399490cb0a7e00000a","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccc7f5a07aecc52301d0f1_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccc7f5a07aecc52301d0f1_320.jpg","thumbnail_picsize":"549,348","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccc8399490cb0a7e00000a&m=1473055286","list_dtime":"2016-09-05 09:19:53"},{"pk":"57ccdced9490cb187e000030","title":"国足欲变四后卫 任航还能继续首发？","title_line_break":"国足欲变四后卫\n任航还能继续首发？","date":"2016-09-05 10:48:52","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57ccdced9490cb187e000030","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTkxZGEwN2FlY2M1MjMwMWVlNjVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2NjZTkxZGEwN2FlY2M1MjMwMWVlNjVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccdced9490cb187e000030&m=1473055285","list_dtime":"2016-09-05 10:48:52"},{"pk":"57cccc8c9490cb3c7e000015","title":"诺伊尔不忘前锋梦 转身过人美如画","title_line_break":"诺伊尔不忘前锋梦\n转身过人美如画","date":"2016-09-05 10:15:46","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cccc8c9490cb3c7e000015","thumbnail_pic":"http://zkres.myzaker.com/201609/57c835b71bc8e0bf1a000000_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccc8da07aecc52301d327_320.jpg","thumbnail_picsize":"450,253","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cccc8c9490cb3c7e000015&m=1473055285","list_dtime":"2016-09-05 10:15:46"},{"pk":"57ccdeb09490cbf87d00002c","title":"大器晚成！洛瑞明夏有望拿1.5亿","date":"2016-09-05 10:55:44","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccdeb09490cbf87d00002c","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccdea0a07aecc52301e2a5_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccdea0a07aecc52301e2a5_320.jpg","thumbnail_picsize":"600,446","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccdeb09490cbf87d00002c&m=1473055285","list_dtime":"2016-09-05 10:55:44"},{"pk":"57cce0219490cb117e00003e","title":"上海男篮大外援抵沪 季前赛将战火箭","title_line_break":"上海男篮大外援抵沪\n季前赛将战火箭","date":"2016-09-05 11:01:53","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce0219490cb117e00003e","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce013a07aecc52301e569_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce013a07aecc52301e569_320.jpg","thumbnail_picsize":"541,304","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cce0219490cb117e00003e&m=1473055285","list_dtime":"2016-09-05 11:01:53"},{"pk":"57ccda609490cbe47d00001b","title":"克洛普：梅西在西甲散步也进5球","title_line_break":"克洛普：\n梅西在西甲散步也进5球","date":"2016-09-05 10:37:20","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccda609490cbe47d00001b","thumbnail_pic":"http://zkres.myzaker.com/201609/57cad54e1bc8e0272b000024_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccda64f5a2248c62000003_320.jpg","thumbnail_picsize":"450,313","media_count":"2","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccda609490cbe47d00001b&m=1473055285","list_dtime":"2016-09-05 10:37:20"},{"pk":"57ccebfe9490cbd77d000026","title":"做备胎！曝切尔西签回昔日弃将内幕","date":"2016-09-05 11:52:30","auther_name":"3G门户·体育","weburl":"http://iphone.myzaker.com/l.php?l=57ccebfe9490cbd77d000026","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccebc5a07aecc52301ef41_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccebc5a07aecc52301ef41_320.jpg","thumbnail_picsize":"480,314","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccebfe9490cbd77d000026&m=1473055285","list_dtime":"2016-09-05 11:52:30"},{"pk":"57ccdced9490cb187e000031","title":"英格兰像保级队 三狮到底谁不争气？","title_line_break":"英格兰像保级队\n三狮到底谁不争气？","date":"2016-09-05 10:52:21","auther_name":"体育疯","weburl":"http://iphone.myzaker.com/l.php?l=57ccdced9490cb187e000031","thumbnail_pic":"http://zkres.myzaker.com/201609/57ccd0781bc8e0c05500002e_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57ccd0781bc8e0c05500002e_320.jpg","thumbnail_picsize":"450,273","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57ccdced9490cb187e000031&m=1473055285","list_dtime":"2016-09-05 10:52:21"},{"pk":"57cccb979490cb247e000032","title":"曝贝尔谈妥续约 如愿获C罗级别待遇","title_line_break":"曝贝尔谈妥续约\n如愿获C罗级别待遇","date":"2016-09-05 10:15:46","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cccb979490cb247e000032","thumbnail_pic":"http://zkres.myzaker.com/201609/57cccb66a07aecc52301d2c9_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cccb66a07aecc52301d2c9_320.jpg","thumbnail_picsize":"550,313","media_count":"1","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cccb979490cb247e000032&m=1473055285","list_dtime":"2016-09-05 10:15:46"},{"pk":"57cce57c9490cb0e7e000043","title":"曾文鼎与女友结婚 结束16年爱情长跑","title_line_break":"曾文鼎与女友结婚\n结束16年爱情长跑","date":"2016-09-05 11:24:44","auther_name":"网易体育","weburl":"http://iphone.myzaker.com/l.php?l=57cce57c9490cb0e7e000043","thumbnail_pic":"http://zkres.myzaker.com/201609/57cce588a07aecc52301eb74_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57cce588a07aecc52301eb74_320.jpg","thumbnail_picsize":"550,412","media_count":"3","is_full":"NO","content":"","special_info":{"show_jingcai":"Y"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57cce57c9490cb0e7e000043&m=1473055285","list_dtime":"2016-09-05 11:24:44"}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cceb8d9490cb0f7e000043,57ccd1f89490cbf17d000017,57ccea9e9490cbf27d00002e,57ccea9e9490cbf27d000030,57cce45f9490cb147e000052,57c94cc59490cbe21700004b","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57cd08619490cb377e00006e,57be9f559490cb1c56000073,57cce7071bc8e0cd64000001,57cd07869490cb3a7e00003e,57ccef7f1bc8e0576a000006,57cb99989490cbc035000028","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccda6a1bc8e02a0c00002d,57cd05cd9490cb3b7e000028,57ccd25f9490cbe17d000021,57ccdbbf9490cbf77d000026,579f1e469490cb0f470000af,57cbe5349490cb4763000046","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccd79c9490cb357e00002b,57cccaeb9490cb047e000020,57cce3f39490cb147e000050,57ccda2c9490cb0d7e000026,57ccd8839490cbd77d00001c,57cb96b49490cb7f35000014","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccdced9490cb187e000030,57ccc8399490cb0a7e00000a,57cccc8c9490cb3c7e000015,57ccdeb09490cbf87d00002c,57cce0219490cb117e00003e,57cbd9b59490cb7e35000031","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57ccebfe9490cbd77d000026,57ccda609490cbe47d00001b,57ccdced9490cb187e000031,57cccb979490cb247e000032,57cce57c9490cb0e7e000043,57cbcc569490cb9b35000038","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}}],"article_block_colors":["#5bd39f","#5bd39f"],"only_text_page_bgcolors":["#5bd39f","#5bd39f"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/8.png?t=1471575641","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/8.png?t=1471575641","hidden_time":"24","need_userinfo":"NO","block_title":"体育频道","block_color":"#5bd39f","desktop_color_number":"14","use_original_icon":"N"}
     * column_info : {"pk":"zk_app_column_info_pk_8f877381c422698ecd6a9aa028177af7","selected_index":"0","list":[{"pk":"zk_app_column_8","title":"头条","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_12083","title":"足球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12083_zk_app_column_block_8","title":"足球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12083&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12084","title":"篮球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12084_zk_app_column_block_8","title":"篮球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12084&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_11610","title":"综合","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11610_zk_app_column_block_8","title":"综合体育","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11610&catalog_appid=8","data_type":"news"}}]}
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * catalog_url : http://iphone.myzaker.com/zaker/blog2news_catalog.php?catalog_appid=8&back=&act=list
         * catalog_title : 子栏目
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=8&since_date=1473038393&nt=1&next_aticle_id=57cce5979490cbd844000020&_appid=androidphone&opage=2&otimestamp=170
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=8&need_app_integration=0
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=8&ids=5642f2aa9490cbb13200000e,51a7106381853df24c000138&k=201609051400
         */

        private InfoBean info;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/8.png?t=1471575641
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/8.png?t=1471575641
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 体育频道
         * block_color : #5bd39f
         * desktop_color_number : 14
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        /**
         * pk : zk_app_column_info_pk_8f877381c422698ecd6a9aa028177af7
         * selected_index : 0
         * list : [{"pk":"zk_app_column_8","title":"头条","type":"in_block","block_info":{"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}},{"pk":"zk_app_column_12083","title":"足球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12083_zk_app_column_block_8","title":"足球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12083&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_12084","title":"篮球","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"12084_zk_app_column_block_8","title":"篮球","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=12084&catalog_appid=8","data_type":"news"}},{"pk":"zk_app_column_11610","title":"综合","type":"in_block","block_info":{"can_addtodesk":"N","need_userinfo":"NO","pk":"11610_zk_app_column_block_8","title":"综合体育","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=11610&catalog_appid=8","data_type":"news"}}]
         */

        private ColumnInfoBean column_info;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57be9f559490cb1c56000073
         * title : 阅赛程数据榜单，看今日精彩赛事
         * date : 2016-09-05 11:57:34
         * auther_name : 体育疯
         * page : 2
         * index : 2
         * weburl : http://iphone.myzaker.com/l.php?l=57be9f559490cb1c56000073
         * media_count : 0
         * is_full : NO
         * content :
         * type : web2
         * special_info : {"open_type":"web","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/ad_article.php?_id=57be9f559490cb1c56000073&title=%E9%98%85%E8%B5%9B%E7%A8%8B%E6%95%B0%E6%8D%AE%E6%A6%9C%E5%8D%95%EF%BC%8C%E7%9C%8B%E4%BB%8A%E6%97%A5%E7%B2%BE%E5%BD%A9%E8%B5%9B%E4%BA%8B&open_type=web&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fwww.tiyufeng.com%2Fhz%2Fzaker%2FmatchList.jsp%3Ftarget%3Dweb3","stat_click_url":"http://stat.myzaker.com/stat.php?app_id=8&app_ids=8&pk=57be9f559490cb1c56000073&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57be9f559490cb1c56000073","icon_url":"http://zkres.myzaker.com/data/image/mark2/forecast_2x.png?v=2015061216","show_jingcai":"Y","list_nodsp":"Y"}
         * special_type : tag
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=8&pk=57be9f559490cb1c56000073&m=1473055504
         * list_dtime : 2016-09-05 11:57:34
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public ColumnInfoBean getColumn_info() {
            return column_info;
        }

        public void setColumn_info(ColumnInfoBean column_info) {
            this.column_info = column_info;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String catalog_url;
            private String catalog_title;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getCatalog_url() {
                return catalog_url;
            }

            public void setCatalog_url(String catalog_url) {
                this.catalog_url = catalog_url;
            }

            public String getCatalog_title() {
                return catalog_title;
            }

            public void setCatalog_title(String catalog_title) {
                this.catalog_title = catalog_title;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 2
             * articles : 57cceb8d9490cb0f7e000043,57ccd1f89490cbf17d000017,57ccea9e9490cbf27d00002e,57ccea9e9490cbf27d000030,57cce45f9490cb147e000052,57c94cc59490cbe21700004b
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641","bgimage_frame":"0,0,320,60","title_h":"60","hide_title":"YES","open_type":"","bgimage_icon_style":"0"}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/8.png?t=1471575641
                 * bgimage_frame : 0,0,320,60
                 * title_h : 60
                 * hide_title : YES
                 * open_type :
                 * bgimage_icon_style : 0
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;
                    private String bgimage_icon_style;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }

                    public String getBgimage_icon_style() {
                        return bgimage_icon_style;
                    }

                    public void setBgimage_icon_style(String bgimage_icon_style) {
                        this.bgimage_icon_style = bgimage_icon_style;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ColumnInfoBean {
            private String pk;
            private String selected_index;
            /**
             * pk : zk_app_column_8
             * title : 头条
             * type : in_block
             * block_info : {"can_addtodesk":"Y","need_userinfo":"NO","pk":"8","title":"体育新闻","api_url":"http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8","data_type":"news","skey":"eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9"}
             */

            private List<ListBean> list;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getSelected_index() {
                return selected_index;
            }

            public void setSelected_index(String selected_index) {
                this.selected_index = selected_index;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String pk;
                private String title;
                private String type;
                /**
                 * can_addtodesk : Y
                 * need_userinfo : NO
                 * pk : 8
                 * title : 体育新闻
                 * api_url : http://iphone.myzaker.com/zaker/blog.php?app_id=8&catalog_appid=8
                 * data_type : news
                 * skey : eyJkYXRlIjoiMjAxNi0wOS0wNSIsInQiOiJhbSJ9
                 */

                private BlockInfoBean block_info;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public BlockInfoBean getBlock_info() {
                    return block_info;
                }

                public void setBlock_info(BlockInfoBean block_info) {
                    this.block_info = block_info;
                }

                public static class BlockInfoBean {
                    private String can_addtodesk;
                    private String need_userinfo;
                    private String pk;
                    private String title;
                    private String api_url;
                    private String data_type;
                    private String skey;

                    public String getCan_addtodesk() {
                        return can_addtodesk;
                    }

                    public void setCan_addtodesk(String can_addtodesk) {
                        this.can_addtodesk = can_addtodesk;
                    }

                    public String getNeed_userinfo() {
                        return need_userinfo;
                    }

                    public void setNeed_userinfo(String need_userinfo) {
                        this.need_userinfo = need_userinfo;
                    }

                    public String getPk() {
                        return pk;
                    }

                    public void setPk(String pk) {
                        this.pk = pk;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getApi_url() {
                        return api_url;
                    }

                    public void setApi_url(String api_url) {
                        this.api_url = api_url;
                    }

                    public String getData_type() {
                        return data_type;
                    }

                    public void setData_type(String data_type) {
                        this.data_type = data_type;
                    }

                    public String getSkey() {
                        return skey;
                    }

                    public void setSkey(String skey) {
                        this.skey = skey;
                    }
                }
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String media_count;
            private String is_full;
            private String content;
            private String type,thumbnail_pic;

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            /**
             * open_type : web
             * need_user_info : Y
             * web_url : http://iphone.myzaker.com/zaker/ad_article.php?_id=57be9f559490cb1c56000073&title=%E9%98%85%E8%B5%9B%E7%A8%8B%E6%95%B0%E6%8D%AE%E6%A6%9C%E5%8D%95%EF%BC%8C%E7%9C%8B%E4%BB%8A%E6%97%A5%E7%B2%BE%E5%BD%A9%E8%B5%9B%E4%BA%8B&open_type=web&_appid=androidphone&need_userinfo=Y&url=http%3A%2F%2Fwww.tiyufeng.com%2Fhz%2Fzaker%2FmatchList.jsp%3Ftarget%3Dweb3
             * stat_click_url : http://stat.myzaker.com/stat.php?app_id=8&app_ids=8&pk=57be9f559490cb1c56000073&readlast=5&title=&url=http%3A%2F%2Fiphone.myzaker.com%2Fl.php%3Fl%3D57be9f559490cb1c56000073
             * icon_url : http://zkres.myzaker.com/data/image/mark2/forecast_2x.png?v=2015061216
             * show_jingcai : Y
             * list_nodsp : Y
             */

            private SpecialInfoBean special_info;
            private String special_type;
            private String full_url;
            private String list_dtime;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getSpecial_type() {
                return special_type;
            }

            public void setSpecial_type(String special_type) {
                this.special_type = special_type;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public static class SpecialInfoBean {
                private String open_type;
                private String need_user_info;
                private String web_url;
                private String stat_click_url;
                private String icon_url;
                private String show_jingcai;
                private String list_nodsp;

                public String getOpen_type() {
                    return open_type;
                }

                public void setOpen_type(String open_type) {
                    this.open_type = open_type;
                }

                public String getNeed_user_info() {
                    return need_user_info;
                }

                public void setNeed_user_info(String need_user_info) {
                    this.need_user_info = need_user_info;
                }

                public String getWeb_url() {
                    return web_url;
                }

                public void setWeb_url(String web_url) {
                    this.web_url = web_url;
                }

                public String getStat_click_url() {
                    return stat_click_url;
                }

                public void setStat_click_url(String stat_click_url) {
                    this.stat_click_url = stat_click_url;
                }

                public String getIcon_url() {
                    return icon_url;
                }

                public void setIcon_url(String icon_url) {
                    this.icon_url = icon_url;
                }

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }
            }
        }
    }
}
