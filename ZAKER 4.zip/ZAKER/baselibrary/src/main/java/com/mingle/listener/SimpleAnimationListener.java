package com.mingle.listener;

import com.nineoldandroids.animation.Animator;

/**
 * Created by zzz40500 on 15/8/26.
 */
public class SimpleAnimationListener implements Animator.AnimatorListener {




    @Override
    public void onAnimationStart(Animator animation) {


    }


    @Override
    public void onAnimationEnd(Animator animation) {


    }


    @Override
    public void onAnimationCancel(Animator animation) {


    }


    @Override
    public void onAnimationRepeat(Animator animation) {


    }
}