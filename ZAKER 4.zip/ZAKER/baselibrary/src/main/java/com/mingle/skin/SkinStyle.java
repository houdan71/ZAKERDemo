package com.mingle.skin;

/**
 * Created by zzz40500 on 15/8/27.
 */
public enum SkinStyle {

    Dark,
    Light//默认Light
}
