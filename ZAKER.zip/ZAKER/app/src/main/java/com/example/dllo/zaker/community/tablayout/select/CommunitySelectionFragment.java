package com.example.dllo.zaker.community.tablayout.select;

import android.view.View;

import com.example.dllo.zaker.R;
import com.example.dllo.zaker.base.BaseFragment;

/**
 * Created by dllo on 16/8/30.
 */
public class CommunitySelectionFragment extends BaseFragment {
    @Override
    protected int initLayout() {
        return R.layout.fragment_community_selection;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
