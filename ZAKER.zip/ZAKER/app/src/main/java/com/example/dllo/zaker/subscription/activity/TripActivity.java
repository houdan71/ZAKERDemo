package com.example.dllo.zaker.subscription.activity;

import com.example.dllo.zaker.R;
import com.example.dllo.zaker.base.BaseActivity;

/**
 * Created by dllo on 16/8/31.
 */
public class TripActivity extends BaseActivity {
    @Override
    protected int getLayout() {
        return R.layout.activity_trip;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
