package com.example.dllo.zaker.subscription.entity;

import java.util.List;

/**
 * Created by dllo on 16/9/1.
 */
public class Bean_choice {

    /**
     * stat : 1
     * newrule : 1
     * msg : ok
     * data : {"refresh_interval":"300","share":[{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}],"info":{"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=10386&since_date=1472199356&nt=1&next_aticle_id=57c4e4d29490cbad13000022&_appid=androidphone&opage=2&otimestamp=186&top_tab_id=10386","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=10386&need_app_integration=1","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=10386&ids=5642f2aa9490cbb13200000e,54f40b639490cb12100000da&k=201609011630"},"catalog":"","articles":[{"pk":"57c639539490cbc24a00002d","title":"吃牛排，千万别点八分熟！","date":"","auther_name":"豆果美食","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c639539490cbc24a00002d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"18","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c639539490cbc24a00002d&m=1472696728","list_dtime":""},{"pk":"57c644f29490cbcb4a000024","title":"让吃货看电影，全程都是咽口水的声音","date":"","auther_name":"微在","weburl":"http://iphone.myzaker.com/l.php?l=57c644f29490cbcb4a000024","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6178d1bc8e05d41000025_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6178d1bc8e05d41000025_320.jpg","thumbnail_picsize":"600,353","media_count":"24","thumbnail_medias":[{"type":"image","id":"57c6178d1bc8e05d41000025","url":"http://zkres.myzaker.com/201608/57c6178d1bc8e05d41000025_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c6178d1bc8e05d41000025_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c6178d1bc8e05d41000025_120.jpg","raw_url":"http://static.wezeit.com/wp-content/uploads/Editor/2016-08-22/1471833353519563.jpg","w":"600","h":"353"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c644f29490cbcb4a000024&m=1472714707","list_dtime":""},{"pk":"57c795e39490cbad2c00003b","title":"这些美食背后，有一段感人至深的故事","date":"","auther_name":"天天美食","weburl":"http://iphone.myzaker.com/l.php?l=57c795e39490cbad2c00003b","thumbnail_pic":"http://zkres.myzaker.com/201608/57c65de57f52e927670000c1_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c65de57f52e927670000c1_320.jpg","thumbnail_picsize":"690,450","media_count":"10","thumbnail_medias":[{"type":"image","id":"57c65de57f52e927670000c1","url":"http://zkres.myzaker.com/201608/57c65de57f52e927670000c1_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c65de57f52e927670000c1_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c65de57f52e927670000c1_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_jpg/juibT3Wqklvj1kjOLylvia1pHhico4kpmJr0hT8xyz4BupnAbzGAyiciceQTb2hDsndK1IPTLSa7TQ2QtCYHum0UicgA/0?wx_fmt=jpeg","w":"690","h":"450"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c795e39490cbad2c00003b&m=1472714582","list_dtime":""},{"pk":"57c7d24c1bc8e07a61000044","title":"那些你不知道的秋季美食\u201c黑名单\u201d","date":"","auther_name":"大苏网","weburl":"http://iphone.myzaker.com/l.php?l=57c7d24c1bc8e07a61000044","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7d213a07aecf77e04738f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7d213a07aecf77e04738f_320.jpg","thumbnail_picsize":"578,386","media_count":"1","thumbnail_medias":[{"type":"image","id":"57c7d213a07aecf77e04738f","url":"http://zkres.myzaker.com/201609/57c7d213a07aecf77e04738f_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c7d213a07aecf77e04738f_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c7d213a07aecf77e04738f_120.jpg","raw_url":"http://365jia.cn/uploads/news/folder_1662966/images/84652f66a50b43ec2fe0d1246ea20000.jpeg","w":"578","h":"386"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c7d24c1bc8e07a61000044&m=1472714639","list_dtime":""},{"pk":"57c65d211bc8e0500c000033","title":"舌尖上的农村美食，童年的记忆！","date":"","auther_name":"天下英雄城","weburl":"http://iphone.myzaker.com/l.php?l=57c65d211bc8e0500c000033","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NWQwYmEwN2FlY2Y3N2UwM2NkN2VfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NWQwYmEwN2FlY2Y3N2UwM2NkN2VfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"450,297","media_count":"24","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NWQwYmEwN2FlY2Y3N2UwM2NkN2VfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NWQwYmEwN2FlY2Y3N2UwM2NkN2VfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NWQwYmEwN2FlY2Y3N2UwM2NkN2VfNjQwLmpwZw==_1242.jpg","w":"450","h":"297"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c65d211bc8e0500c000033&m=1472695996","list_dtime":""},{"pk":"57c790269490cb922c000019","title":"2分钟学会的高逼格，所有人对你刮目相看！","date":"","auther_name":"美食工坊","weburl":"http://iphone.myzaker.com/l.php?l=57c790269490cb922c000019","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2ZDY2MjdmNTJlOWM0MWYwMDAyY2FfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2ZDY2MjdmNTJlOWM0MWYwMDAyY2FfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"625,457","media_count":"8","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2ZDY2MjdmNTJlOWM0MWYwMDAyY2FfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2ZDY2MjdmNTJlOWM0MWYwMDAyY2FfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2ZDY2MjdmNTJlOWM0MWYwMDAyY2FfNjQwLmpwZw==_1242.jpg","w":"625","h":"457"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c790269490cb922c000019&m=1472697014","list_dtime":""},{"pk":"57c78f5c9490cb882c000015","title":"以贴秋膘的名义，放肆吃牛肉！","date":"","auther_name":"美食天下","weburl":"http://iphone.myzaker.com/l.php?l=57c78f5c9490cb882c000015","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6e9c67f52e9246d0001a0_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6e9c67f52e9246d0001a0_320.jpg","thumbnail_picsize":"500,333","media_count":"20","thumbnail_medias":[{"type":"image","id":"57c6e9c67f52e9246d00019b","url":"http://zkres.myzaker.com/201608/57c6e9c67f52e9246d00019b_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c6e9c67f52e9246d00019b_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c6e9c67f52e9246d00019b_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_jpg/6CMMolTgtUMbQ7SW66m7Hf3wT6JpiakZwBDeq0kfae5BItKm1yztfFXXiczoby0HUdmdNw7eicqS8WicTqqRJdgqmw/0?wx_fmt=jpeg","w":"500","h":"500"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c78f5c9490cb882c000015&m=1472696999","list_dtime":""},{"pk":"57c78f3f9490cbc52c00001a","title":"超省时美颜减脂餐，助你轻松吃出好身材！","date":"","auther_name":"豆果美食","weburl":"http://iphone.myzaker.com/l.php?l=57c78f3f9490cbc52c00001a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDZhNTdmNTJlOTBkNjEwMDAwOGZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDZhNTdmNTJlOTBkNjEwMDAwOGZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"22","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDZhNTdmNTJlOTBkNjEwMDAwOGZfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDZhNTdmNTJlOTBkNjEwMDAwOGZfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDZhNTdmNTJlOTBkNjEwMDAwOGZfNjQwLmpwZw==_1242.jpg","w":"640","h":"427"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c78f3f9490cbc52c00001a&m=1472718721","list_dtime":""},{"pk":"57c78fc09490cb741e000007","title":"锅贴，是不是饺子？","date":"","auther_name":"贝太厨房","weburl":"http://iphone.myzaker.com/l.php?l=57c78fc09490cb741e000007","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjM4OF84NDM3NV9XNjQwSDM2MFM0ODIyNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjM4OF84NDM3NV9XNjQwSDM2MFM0ODIyNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"8","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjM4OF84NDM3NV9XNjQwSDM2MFM0ODIyNC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjM4OF84NDM3NV9XNjQwSDM2MFM0ODIyNC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjM4OF84NDM3NV9XNjQwSDM2MFM0ODIyNC5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c78fc09490cb741e000007&m=1472696418","list_dtime":""},{"pk":"57c6391f9490cbe34a000025","title":"家里大米长虫了，还能不能继续吃","date":"","auther_name":"每日菜谱","weburl":"http://iphone.myzaker.com/l.php?l=57c6391f9490cbe34a000025","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGY5ZTdmNTJlOTE2MGIwMDAyMTJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGY5ZTdmNTJlOTE2MGIwMDAyMTJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"630,416","media_count":"13","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGY5ZTdmNTJlOTE2MGIwMDAyMTJfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGY5ZTdmNTJlOTE2MGIwMDAyMTJfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGY5ZTdmNTJlOTE2MGIwMDAyMTJfNjQwLmpwZw==_1242.jpg","w":"630","h":"416"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c6391f9490cbe34a000025&m=1472693963","list_dtime":""},{"pk":"57c78ab61bc8e0786100003a","title":"家里的制冰盒，竟然还有这么多用途","date":"","auther_name":"江南都市报","weburl":"http://iphone.myzaker.com/l.php?l=57c78ab61bc8e0786100003a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ODYxZDdmNTJlOTQxNjUwMDAxMzdfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ODYxZDdmNTJlOTQxNjUwMDAxMzdfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,457","media_count":"11","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ODYxZDdmNTJlOTQxNjUwMDAxMzdfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ODYxZDdmNTJlOTQxNjUwMDAxMzdfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ODYxZDdmNTJlOTQxNjUwMDAxMzdfNjQwLmpwZw==_1242.jpg","w":"640","h":"457"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c78ab61bc8e0786100003a&m=1472696014","list_dtime":""},{"pk":"57c78f3f9490cbc52c000019","title":"为了尝各国飞机餐，他4年环绕地球17圈","date":"","auther_name":"豆果美食","weburl":"http://iphone.myzaker.com/l.php?l=57c78f3f9490cbc52c000019","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDY5ZjdmNTJlOTU2MzIwMDA0NzVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDY5ZjdmNTJlOTU2MzIwMDA0NzVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"550,366","media_count":"22","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDY5ZjdmNTJlOTU2MzIwMDA0NzVfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDY5ZjdmNTJlOTU2MzIwMDA0NzVfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDY5ZjdmNTJlOTU2MzIwMDA0NzVfNjQwLmpwZw==_1242.jpg","w":"550","h":"366"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c78f3f9490cbc52c000019&m=1472696984","list_dtime":""},{"pk":"57c6765e9490cb024b000040","title":"为什么意大利人不屑于吃哈根达斯？","date":"","auther_name":"穷游网","weburl":"http://iphone.myzaker.com/l.php?l=57c6765e9490cb024b000040","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NmExMDdmNTJlOTIyNWUwMDAyMWFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NmExMDdmNTJlOTIyNWUwMDAyMWFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"18","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NmExMDdmNTJlOTIyNWUwMDAyMWFfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NmExMDdmNTJlOTIyNWUwMDAyMWFfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NmExMDdmNTJlOTIyNWUwMDAyMWFfNjQwLmpwZw==_1242.jpg","w":"640","h":"427"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c6765e9490cb024b000040&m=1472718640","list_dtime":""},{"pk":"57c7893a1bc8e06a6100001f","title":"5种口感脆嫩的美味豆角，一定要学会","date":"","auther_name":"高质量生活知识","weburl":"http://iphone.myzaker.com/l.php?l=57c7893a1bc8e06a6100001f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3ODg2OWEwN2FlY2Y3N2UwNDNjMDZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3ODg2OWEwN2FlY2Y3N2UwNDNjMDZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,404","media_count":"6","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3ODg2OWEwN2FlY2Y3N2UwNDNjMDZfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3ODg2OWEwN2FlY2Y3N2UwNDNjMDZfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3ODg2OWEwN2FlY2Y3N2UwNDNjMDZfNjQwLmpwZw==_1242.jpg","w":"640","h":"404"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c7893a1bc8e06a6100001f&m=1472695761","list_dtime":""},{"pk":"57c39c0d9490cb257300003b","title":"香港有哪些不能错过的美食！","date":"","auther_name":"十六番","weburl":"http://iphone.myzaker.com/l.php?l=57c39c0d9490cb257300003b","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JlZDk3MzdmNTJlOTFiMzcwMDAwMjdfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JlZDk3MzdmNTJlOTFiMzcwMDAwMjdfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,400","media_count":"70","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JlZDk3MzdmNTJlOTFiMzcwMDAwMjdfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JlZDk3MzdmNTJlOTFiMzcwMDAwMjdfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JlZDk3MzdmNTJlOTFiMzcwMDAwMjdfNjQwLmpwZw==_1242.jpg","w":"600","h":"400"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c39c0d9490cb257300003b&m=1472623736","list_dtime":""},{"pk":"57c639af9490cbfd4a000016","title":"勾魂小炒店几十年的拿手菜，都在这里了","date":"","auther_name":"美食天下","weburl":"http://iphone.myzaker.com/l.php?l=57c639af9490cbfd4a000016","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1YTI1ZDdmNTJlOTBlMGUwMDAwYTNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1YTI1ZDdmNTJlOTBlMGUwMDAwYTNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,334","media_count":"23","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1YTI1ZDdmNTJlOTBlMGUwMDAwYTNfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1YTI1ZDdmNTJlOTBlMGUwMDAwYTNfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1YTI1ZDdmNTJlOTBlMGUwMDAwYTNfNjQwLmpwZw==_1242.jpg","w":"500","h":"334"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c639af9490cbfd4a000016&m=1472610928","list_dtime":""},{"pk":"57c63a189490cbe04a000036","title":"韭菜别只会包饺子，还可以更美味！","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a000036","thumbnail_pic":"http://zkres.myzaker.com/201608/57c50e597f52e96963000330_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c50e597f52e96963000330_320.jpg","thumbnail_picsize":"450,399","media_count":"8","thumbnail_medias":[{"type":"image","id":"57c50e597f52e96963000330","url":"http://zkres.myzaker.com/201608/57c50e597f52e96963000330_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c50e597f52e96963000330_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c50e597f52e96963000330_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/QqzITlgJUtw4o4kSyHN1KYziaQ9gVYjbHoeeDJPT1QHuE1bJeEORDSiclH9oYL08E73ibDHOlz9Y08qLALhC7iaefw/640?","w":"450","h":"399"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a000036&m=1472610589","list_dtime":""},{"pk":"57c6761a9490cb044b000037","title":"意大利面的懒人做法，单纯好吃不做作！","date":"","auther_name":"美食杰","weburl":"http://iphone.myzaker.com/l.php?l=57c6761a9490cb044b000037","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NzYyMGEwN2FlY2Y3N2UwM2RjMjJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NzYyMGEwN2FlY2Y3N2UwM2RjMjJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,357","media_count":"11","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NzYyMGEwN2FlY2Y3N2UwM2RjMjJfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NzYyMGEwN2FlY2Y3N2UwM2RjMjJfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NzYyMGEwN2FlY2Y3N2UwM2RjMjJfNjQwLmpwZw==_1242.jpg","w":"640","h":"357"}],"app_ids":"10386","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10386&pk=57c6761a9490cb044b000037&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c6761a9490cb044b000037%26app_id%3D10386%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c6761a9490cb044b000037&m=1472718745","list_dtime":""},{"pk":"57c639539490cbc24a00002b","title":"国内最受争议的蔬菜，被岛国人民玩脱了\u2026","date":"","auther_name":"豆果美食","weburl":"http://iphone.myzaker.com/l.php?l=57c639539490cbc24a00002b","thumbnail_pic":"http://zkres.myzaker.com/201608/57c5cd827f52e9275e0002a3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c5cd827f52e9275e0002a3_320.jpg","thumbnail_picsize":"640,480","media_count":"28","thumbnail_medias":[{"type":"image","id":"57c5cd827f52e9275e0002a3","url":"http://zkres.myzaker.com/201608/57c5cd827f52e9275e0002a3_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c5cd827f52e9275e0002a3_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c5cd827f52e9275e0002a3_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_jpg/44pws9Yz5pVQtNC7BpqtibXuaL2dcicLEK2NU9PIAgvaZl38ibuZkiagCFafFWz8vpbtZBLxr0aq9HBLic1DWOTgb6Q/0?wx_fmt=jpeg","w":"640","h":"480"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c639539490cbc24a00002b&m=1472610548","list_dtime":""},{"pk":"57c676969490cbcc4a00003a","title":"7道水煮菜，给你香麻的川味体验！","date":"","auther_name":"美食工场","weburl":"http://iphone.myzaker.com/l.php?l=57c676969490cbcc4a00003a","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6769da07aecf77e03dc4a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6769da07aecf77e03dc4a_320.jpg","thumbnail_picsize":"640,577","media_count":"7","thumbnail_medias":[{"type":"image","id":"57c6769da07aecf77e03dc4a","url":"http://zkres.myzaker.com/201608/57c6769da07aecf77e03dc4a_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c6769da07aecf77e03dc4a_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c6769da07aecf77e03dc4a_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/j9FBeXAB9nWFruj63OVJ0OI71jygPnXFCicibnCYWun50jLiczJkFUTxlAXia8yk0n0OpQkdia7riaRhw2GMqicYGX3tA/640?wx_fmt=jpeg","w":"640","h":"577"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c676969490cbcc4a00003a&m=1472627840","list_dtime":""},{"pk":"57c63a189490cbe04a000034","title":"炒青菜还能有什么花样？多花1分钟","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a000034","thumbnail_pic":"http://zkres.myzaker.com/201608/57c50e547f52e96963000323_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c50e547f52e96963000323_320.jpg","thumbnail_picsize":"545,505","media_count":"13","thumbnail_medias":[{"type":"image","id":"57c50e547f52e96963000323","url":"http://zkres.myzaker.com/201608/57c50e547f52e96963000323_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c50e547f52e96963000323_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c50e547f52e96963000323_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/E1QqbPzMaLska60YmsQ1RFKeCIvb76M6INg4uF4BIJDqyrXDlu6oJNw1gaicSRbsEWRDicNhZWbbC5Ysgp5IkIsw/640?wx_fmt=png","w":"545","h":"505"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a000034&m=1472610709","list_dtime":""},{"pk":"57c63a189490cbe04a000039","title":"这些水果晚上不要吃，再喜欢也要戒","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a000039","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwMy81NmUwZDNlYzdmNTJlOTU2NWEwMDA0MDJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwMy81NmUwZDNlYzdmNTJlOTU2NWEwMDA0MDJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"13","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwMy81NmUwZDNlYzdmNTJlOTU2NWEwMDA0MDJfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwMy81NmUwZDNlYzdmNTJlOTU2NWEwMDA0MDJfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwMy81NmUwZDNlYzdmNTJlOTU2NWEwMDA0MDJfNjQwLmpwZw==_1242.jpg","w":"640","h":"427"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a000039&m=1472609467","list_dtime":""},{"pk":"57c4e54e9490cb9713000043","title":"饺子馅加一物，就变成了日式！","date":"","auther_name":"美食工坊","weburl":"http://iphone.myzaker.com/l.php?l=57c4e54e9490cb9713000043","thumbnail_pic":"http://zkres.myzaker.com/201608/57c2f24f7f52e9cf31000202_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c2f24f7f52e9cf31000202_320.jpg","thumbnail_picsize":"1200,890","media_count":"12","thumbnail_medias":[{"type":"image","id":"57c2f24f7f52e9cf31000201","url":"http://zkres.myzaker.com/201608/57c2f24f7f52e9cf31000201_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c2f24f7f52e9cf31000201_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c2f24f7f52e9cf31000201_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_jpg/RgAhJKheXgEsxeAT75nSKnUhpz8wLjHWj2vpRa4sq9uuG7NfxMS2juibm9qic5kxGqZmy518WCSdmp9OOqU27kVg/0?wx_fmt=jpeg","w":"1200","h":"1798"}],"app_ids":"10386","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10386&pk=57c4e54e9490cb9713000043&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c4e54e9490cb9713000043%26app_id%3D10386%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c4e54e9490cb9713000043&m=1472610421","list_dtime":""},{"pk":"57c63a189490cbe04a00003a","title":"这么多好吃的家常菜，一周的菜单都不用愁了","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a00003a","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmYxZDdmNTJlOWMyMDUwMDA1MjVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmYxZDdmNTJlOWMyMDUwMDA1MjVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"400,257","media_count":"10","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmYxZDdmNTJlOWMyMDUwMDA1MjVfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmYxZDdmNTJlOWMyMDUwMDA1MjVfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmYxZDdmNTJlOWMyMDUwMDA1MjVfNjQwLmpwZw==_1242.jpg","w":"400","h":"257"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a00003a&m=1472610009","list_dtime":""},{"pk":"57c639af9490cbfd4a000017","title":"好想养一只刺猬啊！吃货属性萌翻天！","date":"","auther_name":"美食天下","weburl":"http://iphone.myzaker.com/l.php?l=57c639af9490cbfd4a000017","thumbnail_pic":"http://zkres.myzaker.com/201608/57c5a2617f52e9100e000081_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c5a2617f52e9100e000081_320.jpg","thumbnail_picsize":"241,225","media_count":"27","thumbnail_medias":[{"type":"image","id":"57c5a2617f52e9100e000081","url":"http://zkres.myzaker.com/201608/57c5a2617f52e9100e000081_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c5a2617f52e9100e000081_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c5a2617f52e9100e000081_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_gif/icdHpHMYRdfqhMpj0uicvvicSGJ7fyler5eSudL3LDQpo1OiaN5jTsaMFAicKruuCnKGvHUo4WWraJMiaTqThTUickzUA/0?wx_fmt=gif","w":"241","h":"225","gif_url":"http://zkres.myzaker.com/201608/57c5a2617f52e9100e000081_raw.gif"}],"app_ids":"10386","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10386&pk=57c639af9490cbfd4a000017&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c639af9490cbfd4a000017%26app_id%3D10386%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c639af9490cbfd4a000017&m=1472610861","list_dtime":""},{"pk":"57c63a189490cbe04a000037","title":"50种排骨美味做法，够吃一年了！","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a000037","thumbnail_pic":"http://zkres.myzaker.com/201606/57630d73a07aec5e7003b0fd_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201606/57630d73a07aec5e7003b0fd_320.jpg","thumbnail_picsize":"426,315","media_count":"50","thumbnail_medias":[{"type":"image","id":"57630d73a07aec5e7003b0fd","url":"http://zkres.myzaker.com/201606/57630d73a07aec5e7003b0fd_640.jpg","m_url":"http://zkres.myzaker.com/201606/57630d73a07aec5e7003b0fd_320.jpg","min_url":"http://zkres.myzaker.com/201606/57630d73a07aec5e7003b0fd_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/E1QqbPzMaLuZsqicxQEsp5hE6FlcQGJOaWibAicgYKYU6w1tnNRDzsohk4wibPvWgyncpyWMzIIPAIIe0rNnRZ0gkQ/640?wx_fmt=jpeg","w":"426","h":"315"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a000037&m=1472610774","list_dtime":""},{"pk":"57c639539490cbc24a00002c","title":"35道微波炉美食，让你告别刷锅和油烟！","date":"","auther_name":"豆果美食","weburl":"http://iphone.myzaker.com/l.php?l=57c639539490cbc24a00002c","thumbnail_pic":"http://zkres.myzaker.com/201608/57c567c17f52e9374200052c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c567c17f52e9374200052c_320.jpg","thumbnail_picsize":"640,469","media_count":"17","thumbnail_medias":[{"type":"image","id":"57c567c17f52e9374200052c","url":"http://zkres.myzaker.com/201608/57c567c17f52e9374200052c_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c567c17f52e9374200052c_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c567c17f52e9374200052c_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_jpg/44pws9Yz5pXWd3qZ7Jyea66rZjdgaPRrmmMBreaKqSb7nYzicgbQ0Z840wdTUaEzXRWJM9I3IEfsYLZdILbsyMA/0?wx_fmt=jpeg","w":"640","h":"469"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c639539490cbc24a00002c&m=1472610321","list_dtime":""},{"pk":"57c63a189490cbe04a000038","title":"这样做烙饼香到骨头里！来，咬一口...","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a000038","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNi81NzVmNmI5NDc3YTMyNDQ3NWYwMDAwMTFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNi81NzVmNmI5NDc3YTMyNDQ3NWYwMDAwMTFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"465,391","media_count":"6","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNi81NzVmNmI5NDc3YTMyNDQ3NWYwMDAwMTFfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNi81NzVmNmI5NDc3YTMyNDQ3NWYwMDAwMTFfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNi81NzVmNmI5NDc3YTMyNDQ3NWYwMDAwMTFfNjQwLmpwZw==_1242.jpg","w":"465","h":"391"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a000038&m=1472609752","list_dtime":""},{"pk":"57c63a549490cb064b00001e","title":"细数105个城市的招牌菜，你的家乡上榜了吗？","date":"","auther_name":"天天美食","weburl":"http://iphone.myzaker.com/l.php?l=57c63a549490cb064b00001e","thumbnail_pic":"http://zkres.myzaker.com/201510/561792687f52e96953000156_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201510/561792687f52e96953000156_320.jpg","thumbnail_picsize":"580,463","media_count":"24","thumbnail_medias":[{"type":"image","id":"561792687f52e96953000156","url":"http://zkres.myzaker.com/201510/561792687f52e96953000156_640.jpg","m_url":"http://zkres.myzaker.com/201510/561792687f52e96953000156_320.jpg","min_url":"http://zkres.myzaker.com/201510/561792687f52e96953000156_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/AMCUFlyHOI9USBZVcrSoqV7GGmicYMjWG5VDrSP0IpWeX0tDr7XmKwe3k1NtGWicrUwbqj3jibW2fqSmLzaNKj2yw/0?wx_fmt=jpeg","w":"580","h":"463"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a549490cb064b00001e&m=1472609527","list_dtime":""},{"pk":"57c63a189490cbe04a000035","title":"五花肉销魂吃法，饿么饿么饿么？","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a000035","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGU1YjdmNTJlOTBlNDUwMDA0OWVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGU1YjdmNTJlOTBlNDUwMDA0OWVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"638,310","media_count":"8","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGU1YjdmNTJlOTBlNDUwMDA0OWVfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGU1YjdmNTJlOTBlNDUwMDA0OWVfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGU1YjdmNTJlOTBlNDUwMDA0OWVfNjQwLmpwZw==_1242.jpg","w":"638","h":"310"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a000035&m=1472609364","list_dtime":""},{"pk":"57c639539490cbc24a00002a","title":"童年时期的小零食，都吃过说明你老了\u2026","date":"","auther_name":"豆果美食","weburl":"http://iphone.myzaker.com/l.php?l=57c639539490cbc24a00002a","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwOTI1MF80MDM3X1c2NDBIMzYwUzYyMDM5LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwOTI1MF80MDM3X1c2NDBIMzYwUzYyMDM5LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwOTI1MF80MDM3X1c2NDBIMzYwUzYyMDM5LmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwOTI1MF80MDM3X1c2NDBIMzYwUzYyMDM5LmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwOTI1MF80MDM3X1c2NDBIMzYwUzYyMDM5LmpwZw==_1242.jpg","w":"640","h":"360"}],"app_ids":"10386","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10386&pk=57c639539490cbc24a00002a&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c639539490cbc24a00002a%26app_id%3D10386%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c639539490cbc24a00002a&m=1472609138","list_dtime":""},{"pk":"57c63a549490cb064b00001d","title":"好吃的鸡块做法精选，赶快来试试吧","date":"","auther_name":"天天美食","weburl":"http://iphone.myzaker.com/l.php?l=57c63a549490cb064b00001d","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNC81NzAxY2E5MWEwN2FlYzQ3NzcwNDc3NzBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNC81NzAxY2E5MWEwN2FlYzQ3NzcwNDc3NzBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"490,338","media_count":"8","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNC81NzAxY2E5MWEwN2FlYzQ3NzcwNDc3NzBfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNC81NzAxY2E5MWEwN2FlYzQ3NzcwNDc3NzBfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNC81NzAxY2E5MWEwN2FlYzQ3NzcwNDc3NzBfNjQwLmpwZw==_1242.jpg","w":"490","h":"338"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a549490cb064b00001d&m=1472609299","list_dtime":""},{"pk":"57c4e54e9490cb9713000041","title":"水果和生鲜这样来保鲜，冰箱都省了","date":"","auther_name":"美食工坊","weburl":"http://iphone.myzaker.com/l.php?l=57c4e54e9490cb9713000041","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MxNmU3YzdmNTJlOWVlNzUwMDA2MjFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MxNmU3YzdmNTJlOWVlNzUwMDA2MjFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"9","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MxNmU3YzdmNTJlOWVlNzUwMDA2MjFfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MxNmU3YzdmNTJlOWVlNzUwMDA2MjFfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MxNmU3YzdmNTJlOWVlNzUwMDA2MjFfNjQwLmpwZw==_1242.jpg","w":"640","h":"427"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c4e54e9490cb9713000041&m=1472550914","list_dtime":""},{"pk":"57c4e4b09490cb9113000023","title":"鸡蛋煎馄饨，这么新鲜的吃法还是头一次见","date":"","auther_name":"美食杰","weburl":"http://iphone.myzaker.com/l.php?l=57c4e4b09490cb9113000023","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ODczYzFiYzhlMDM0NDcwMDAwMDhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ODczYzFiYzhlMDM0NDcwMDAwMDhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,450","media_count":"10","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ODczYzFiYzhlMDM0NDcwMDAwMDhfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ODczYzFiYzhlMDM0NDcwMDAwMDhfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ODczYzFiYzhlMDM0NDcwMDAwMDhfNjQwLmpwZw==_1242.jpg","w":"600","h":"450"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c4e4b09490cb9113000023&m=1472541310","list_dtime":""},{"pk":"57c4ec931bc8e08132000036","title":"百吃不厌豆腐的万能吃法，大师级的水准","date":"","auther_name":" 高质量生活知识","weburl":"http://iphone.myzaker.com/l.php?l=57c4ec931bc8e08132000036","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ZWMxNmEwN2FlY2Y3N2UwMzFjYmNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ZWMxNmEwN2FlY2Y3N2UwMzFjYmNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,454","media_count":"6","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ZWMxNmEwN2FlY2Y3N2UwMzFjYmNfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ZWMxNmEwN2FlY2Y3N2UwMzFjYmNfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ZWMxNmEwN2FlY2Y3N2UwMzFjYmNfNjQwLmpwZw==_1242.jpg","w":"640","h":"454"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c4ec931bc8e08132000036&m=1472552333","list_dtime":""},{"pk":"57c4e5759490cb5213000015","title":"世界上最臭的食物排行，你敢挑战看看吗？","date":"","auther_name":"天天美食","weburl":"http://iphone.myzaker.com/l.php?l=57c4e5759490cb5213000015","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmVlYzdmNTJlOTVjM2EwMDAwZWNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmVlYzdmNTJlOTVjM2EwMDAwZWNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"542,397","media_count":"11","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmVlYzdmNTJlOTVjM2EwMDAwZWNfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmVlYzdmNTJlOTVjM2EwMDAwZWNfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmVlYzdmNTJlOTVjM2EwMDAwZWNfNjQwLmpwZw==_1242.jpg","w":"542","h":"397"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c4e5759490cb5213000015&m=1472540751","list_dtime":""}],"ipadconfig":{"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c639539490cbc24a00002d,57c644f29490cbcb4a000024,57c795e39490cbad2c00003b,57c7d24c1bc8e07a61000044,57c65d211bc8e0500c000033,57c790269490cb922c000019","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c78f5c9490cb882c000015,57c78f3f9490cbc52c00001a,57c78fc09490cb741e000007,57c6391f9490cbe34a000025,57c78ab61bc8e0786100003a,57c78f3f9490cbc52c000019","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c6765e9490cb024b000040,57c7893a1bc8e06a6100001f,57c39c0d9490cb257300003b,57c639af9490cbfd4a000016,57c63a189490cbe04a000036,57c6761a9490cb044b000037","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c639539490cbc24a00002b,57c676969490cbcc4a00003a,57c63a189490cbe04a000034,57c63a189490cbe04a000039,57c4e54e9490cb9713000043,57c63a189490cbe04a00003a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c639af9490cbfd4a000017,57c63a189490cbe04a000037,57c639539490cbc24a00002c,57c63a189490cbe04a000038,57c63a549490cb064b00001e,57c63a189490cbe04a000035","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c639539490cbc24a00002a,57c63a549490cb064b00001d,57c4e54e9490cb9713000041,57c4e4b09490cb9113000023,57c4ec931bc8e08132000036,57c4e5759490cb5213000015","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}}],"article_block_colors":["#fc9a64","#fc9a64"],"only_text_page_bgcolors":["#fc9a64","#fc9a64"]},"block_info":{"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/10386.png?t=1458288274","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/10386.png?t=1458288274","hidden_time":"24","need_userinfo":"NO","block_title":"美食频道","block_color":"#fc9a64","desktop_color_number":"8","use_original_icon":"N"},"top_tab_info_url":"http://iphone.myzaker.com/zaker/top_tab_info.php?app_id=10386&full_arg=_appid,_v,_version,_lbs_city","show_type":"top_tab"}
     */

    private String stat;
    private String newrule;
    private String msg;
    /**
     * refresh_interval : 300
     * share : [{"title":"转发至新浪微博","block_pk":"100000","share_url":"http://wbapi.myzaker.com/weibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"100003","title":"转发至腾讯微博","share_url":"http://wbapi.myzaker.com/qqweibo/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"10312","title":"转发至人人网","share_url":"http://wbapi.myzaker.com/renren/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"},{"block_pk":"100004","title":"转发至搜狐微博","share_url":"http://wbapi.myzaker.com/sohu/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400005","title":"转发至QQ空间","share_url":"http://wbapi.myzaker.com/qqzone/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y"},{"block_pk":"400006","title":"转发至Pocket","share_url":"http://wbapi.myzaker.com/pocket/api_post.php?act=post_article","action_type":"sendForward","require_pk":"Y","require_title":"Y","require_web_url":"Y","no_photo":"Y"}]
     * info : {"comment_list_url":"http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments","comment_url":"http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments","comment_reply_url":"http://c.myzaker.com/weibo/api_post_article.php?act=reply","comment_count_url":"http://c.myzaker.com/weibo/api_comment_count.php?act=get_count","comment_hot_url":"http://c.myzaker.com/weibo/api_comment_article_hot.php","like_count_url":"http://iphone.myzaker.com/zaker/like.php","like_save_url":"http://iphone.myzaker.com/zaker/like.php?act=add","like_remove_url":"http://iphone.myzaker.com/zaker/like.php?act=remove","readstat":"http://stat.myzaker.com/stat.php","next_url":"http://iphone.myzaker.com/zaker/blog2news.php?app_id=10386&since_date=1472199356&nt=1&next_aticle_id=57c4e4d29490cbad13000022&_appid=androidphone&opage=2&otimestamp=186&top_tab_id=10386","localremove_url":"http://api.myzaker.com/zaker/fav_act.php?act=delete2","localsave_url":"http://api.myzaker.com/zaker/fav_act.php?act=add","ad_url":"http://ggs.myzaker.com/zk_block_ad.php?app_id=10386&need_app_integration=1","tuijian_list_url":"http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=10386&ids=5642f2aa9490cbb13200000e,54f40b639490cb12100000da&k=201609011630"}
     * catalog :
     * articles : [{"pk":"57c639539490cbc24a00002d","title":"吃牛排，千万别点八分熟！","date":"","auther_name":"豆果美食","page":"1","index":"1","weburl":"http://iphone.myzaker.com/l.php?l=57c639539490cbc24a00002d","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"18","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","list_nodsp":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c639539490cbc24a00002d&m=1472696728","list_dtime":""},{"pk":"57c644f29490cbcb4a000024","title":"让吃货看电影，全程都是咽口水的声音","date":"","auther_name":"微在","weburl":"http://iphone.myzaker.com/l.php?l=57c644f29490cbcb4a000024","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6178d1bc8e05d41000025_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6178d1bc8e05d41000025_320.jpg","thumbnail_picsize":"600,353","media_count":"24","thumbnail_medias":[{"type":"image","id":"57c6178d1bc8e05d41000025","url":"http://zkres.myzaker.com/201608/57c6178d1bc8e05d41000025_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c6178d1bc8e05d41000025_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c6178d1bc8e05d41000025_120.jpg","raw_url":"http://static.wezeit.com/wp-content/uploads/Editor/2016-08-22/1471833353519563.jpg","w":"600","h":"353"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c644f29490cbcb4a000024&m=1472714707","list_dtime":""},{"pk":"57c795e39490cbad2c00003b","title":"这些美食背后，有一段感人至深的故事","date":"","auther_name":"天天美食","weburl":"http://iphone.myzaker.com/l.php?l=57c795e39490cbad2c00003b","thumbnail_pic":"http://zkres.myzaker.com/201608/57c65de57f52e927670000c1_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c65de57f52e927670000c1_320.jpg","thumbnail_picsize":"690,450","media_count":"10","thumbnail_medias":[{"type":"image","id":"57c65de57f52e927670000c1","url":"http://zkres.myzaker.com/201608/57c65de57f52e927670000c1_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c65de57f52e927670000c1_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c65de57f52e927670000c1_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_jpg/juibT3Wqklvj1kjOLylvia1pHhico4kpmJr0hT8xyz4BupnAbzGAyiciceQTb2hDsndK1IPTLSa7TQ2QtCYHum0UicgA/0?wx_fmt=jpeg","w":"690","h":"450"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c795e39490cbad2c00003b&m=1472714582","list_dtime":""},{"pk":"57c7d24c1bc8e07a61000044","title":"那些你不知道的秋季美食\u201c黑名单\u201d","date":"","auther_name":"大苏网","weburl":"http://iphone.myzaker.com/l.php?l=57c7d24c1bc8e07a61000044","thumbnail_pic":"http://zkres.myzaker.com/201609/57c7d213a07aecf77e04738f_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201609/57c7d213a07aecf77e04738f_320.jpg","thumbnail_picsize":"578,386","media_count":"1","thumbnail_medias":[{"type":"image","id":"57c7d213a07aecf77e04738f","url":"http://zkres.myzaker.com/201609/57c7d213a07aecf77e04738f_640.jpg","m_url":"http://zkres.myzaker.com/201609/57c7d213a07aecf77e04738f_320.jpg","min_url":"http://zkres.myzaker.com/201609/57c7d213a07aecf77e04738f_120.jpg","raw_url":"http://365jia.cn/uploads/news/folder_1662966/images/84652f66a50b43ec2fe0d1246ea20000.jpeg","w":"578","h":"386"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c7d24c1bc8e07a61000044&m=1472714639","list_dtime":""},{"pk":"57c65d211bc8e0500c000033","title":"舌尖上的农村美食，童年的记忆！","date":"","auther_name":"天下英雄城","weburl":"http://iphone.myzaker.com/l.php?l=57c65d211bc8e0500c000033","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NWQwYmEwN2FlY2Y3N2UwM2NkN2VfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NWQwYmEwN2FlY2Y3N2UwM2NkN2VfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"450,297","media_count":"24","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NWQwYmEwN2FlY2Y3N2UwM2NkN2VfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NWQwYmEwN2FlY2Y3N2UwM2NkN2VfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NWQwYmEwN2FlY2Y3N2UwM2NkN2VfNjQwLmpwZw==_1242.jpg","w":"450","h":"297"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c65d211bc8e0500c000033&m=1472695996","list_dtime":""},{"pk":"57c790269490cb922c000019","title":"2分钟学会的高逼格，所有人对你刮目相看！","date":"","auther_name":"美食工坊","weburl":"http://iphone.myzaker.com/l.php?l=57c790269490cb922c000019","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2ZDY2MjdmNTJlOWM0MWYwMDAyY2FfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2ZDY2MjdmNTJlOWM0MWYwMDAyY2FfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"625,457","media_count":"8","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2ZDY2MjdmNTJlOWM0MWYwMDAyY2FfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2ZDY2MjdmNTJlOWM0MWYwMDAyY2FfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2ZDY2MjdmNTJlOWM0MWYwMDAyY2FfNjQwLmpwZw==_1242.jpg","w":"625","h":"457"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c790269490cb922c000019&m=1472697014","list_dtime":""},{"pk":"57c78f5c9490cb882c000015","title":"以贴秋膘的名义，放肆吃牛肉！","date":"","auther_name":"美食天下","weburl":"http://iphone.myzaker.com/l.php?l=57c78f5c9490cb882c000015","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6e9c67f52e9246d0001a0_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6e9c67f52e9246d0001a0_320.jpg","thumbnail_picsize":"500,333","media_count":"20","thumbnail_medias":[{"type":"image","id":"57c6e9c67f52e9246d00019b","url":"http://zkres.myzaker.com/201608/57c6e9c67f52e9246d00019b_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c6e9c67f52e9246d00019b_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c6e9c67f52e9246d00019b_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_jpg/6CMMolTgtUMbQ7SW66m7Hf3wT6JpiakZwBDeq0kfae5BItKm1yztfFXXiczoby0HUdmdNw7eicqS8WicTqqRJdgqmw/0?wx_fmt=jpeg","w":"500","h":"500"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c78f5c9490cb882c000015&m=1472696999","list_dtime":""},{"pk":"57c78f3f9490cbc52c00001a","title":"超省时美颜减脂餐，助你轻松吃出好身材！","date":"","auther_name":"豆果美食","weburl":"http://iphone.myzaker.com/l.php?l=57c78f3f9490cbc52c00001a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDZhNTdmNTJlOTBkNjEwMDAwOGZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDZhNTdmNTJlOTBkNjEwMDAwOGZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"22","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDZhNTdmNTJlOTBkNjEwMDAwOGZfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDZhNTdmNTJlOTBkNjEwMDAwOGZfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDZhNTdmNTJlOTBkNjEwMDAwOGZfNjQwLmpwZw==_1242.jpg","w":"640","h":"427"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c78f3f9490cbc52c00001a&m=1472718721","list_dtime":""},{"pk":"57c78fc09490cb741e000007","title":"锅贴，是不是饺子？","date":"","auther_name":"贝太厨房","weburl":"http://iphone.myzaker.com/l.php?l=57c78fc09490cb741e000007","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjM4OF84NDM3NV9XNjQwSDM2MFM0ODIyNC5qcGc=_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjM4OF84NDM3NV9XNjQwSDM2MFM0ODIyNC5qcGc=_1242.jpg","thumbnail_picsize":"640,360","media_count":"8","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjM4OF84NDM3NV9XNjQwSDM2MFM0ODIyNC5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjM4OF84NDM3NV9XNjQwSDM2MFM0ODIyNC5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5NjM4OF84NDM3NV9XNjQwSDM2MFM0ODIyNC5qcGc=_1242.jpg","w":"640","h":"360"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c78fc09490cb741e000007&m=1472696418","list_dtime":""},{"pk":"57c6391f9490cbe34a000025","title":"家里大米长虫了，还能不能继续吃","date":"","auther_name":"每日菜谱","weburl":"http://iphone.myzaker.com/l.php?l=57c6391f9490cbe34a000025","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGY5ZTdmNTJlOTE2MGIwMDAyMTJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGY5ZTdmNTJlOTE2MGIwMDAyMTJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"630,416","media_count":"13","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGY5ZTdmNTJlOTE2MGIwMDAyMTJfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGY5ZTdmNTJlOTE2MGIwMDAyMTJfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGY5ZTdmNTJlOTE2MGIwMDAyMTJfNjQwLmpwZw==_1242.jpg","w":"630","h":"416"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c6391f9490cbe34a000025&m=1472693963","list_dtime":""},{"pk":"57c78ab61bc8e0786100003a","title":"家里的制冰盒，竟然还有这么多用途","date":"","auther_name":"江南都市报","weburl":"http://iphone.myzaker.com/l.php?l=57c78ab61bc8e0786100003a","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ODYxZDdmNTJlOTQxNjUwMDAxMzdfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ODYxZDdmNTJlOTQxNjUwMDAxMzdfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,457","media_count":"11","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ODYxZDdmNTJlOTQxNjUwMDAxMzdfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ODYxZDdmNTJlOTQxNjUwMDAxMzdfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1ODYxZDdmNTJlOTQxNjUwMDAxMzdfNjQwLmpwZw==_1242.jpg","w":"640","h":"457"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c78ab61bc8e0786100003a&m=1472696014","list_dtime":""},{"pk":"57c78f3f9490cbc52c000019","title":"为了尝各国飞机餐，他4年环绕地球17圈","date":"","auther_name":"豆果美食","weburl":"http://iphone.myzaker.com/l.php?l=57c78f3f9490cbc52c000019","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDY5ZjdmNTJlOTU2MzIwMDA0NzVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDY5ZjdmNTJlOTU2MzIwMDA0NzVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"550,366","media_count":"22","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDY5ZjdmNTJlOTU2MzIwMDA0NzVfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDY5ZjdmNTJlOTU2MzIwMDA0NzVfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3MDY5ZjdmNTJlOTU2MzIwMDA0NzVfNjQwLmpwZw==_1242.jpg","w":"550","h":"366"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c78f3f9490cbc52c000019&m=1472696984","list_dtime":""},{"pk":"57c6765e9490cb024b000040","title":"为什么意大利人不屑于吃哈根达斯？","date":"","auther_name":"穷游网","weburl":"http://iphone.myzaker.com/l.php?l=57c6765e9490cb024b000040","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NmExMDdmNTJlOTIyNWUwMDAyMWFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NmExMDdmNTJlOTIyNWUwMDAyMWFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"18","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NmExMDdmNTJlOTIyNWUwMDAyMWFfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NmExMDdmNTJlOTIyNWUwMDAyMWFfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NmExMDdmNTJlOTIyNWUwMDAyMWFfNjQwLmpwZw==_1242.jpg","w":"640","h":"427"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c6765e9490cb024b000040&m=1472718640","list_dtime":""},{"pk":"57c7893a1bc8e06a6100001f","title":"5种口感脆嫩的美味豆角，一定要学会","date":"","auther_name":"高质量生活知识","weburl":"http://iphone.myzaker.com/l.php?l=57c7893a1bc8e06a6100001f","thumbnail_pic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3ODg2OWEwN2FlY2Y3N2UwNDNjMDZfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3ODg2OWEwN2FlY2Y3N2UwNDNjMDZfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,404","media_count":"6","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3ODg2OWEwN2FlY2Y3N2UwNDNjMDZfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3ODg2OWEwN2FlY2Y3N2UwNDNjMDZfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOS81N2M3ODg2OWEwN2FlY2Y3N2UwNDNjMDZfNjQwLmpwZw==_1242.jpg","w":"640","h":"404"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c7893a1bc8e06a6100001f&m=1472695761","list_dtime":""},{"pk":"57c39c0d9490cb257300003b","title":"香港有哪些不能错过的美食！","date":"","auther_name":"十六番","weburl":"http://iphone.myzaker.com/l.php?l=57c39c0d9490cb257300003b","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JlZDk3MzdmNTJlOTFiMzcwMDAwMjdfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JlZDk3MzdmNTJlOTFiMzcwMDAwMjdfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,400","media_count":"70","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JlZDk3MzdmNTJlOTFiMzcwMDAwMjdfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JlZDk3MzdmNTJlOTFiMzcwMDAwMjdfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2JlZDk3MzdmNTJlOTFiMzcwMDAwMjdfNjQwLmpwZw==_1242.jpg","w":"600","h":"400"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c39c0d9490cb257300003b&m=1472623736","list_dtime":""},{"pk":"57c639af9490cbfd4a000016","title":"勾魂小炒店几十年的拿手菜，都在这里了","date":"","auther_name":"美食天下","weburl":"http://iphone.myzaker.com/l.php?l=57c639af9490cbfd4a000016","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1YTI1ZDdmNTJlOTBlMGUwMDAwYTNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1YTI1ZDdmNTJlOTBlMGUwMDAwYTNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"500,334","media_count":"23","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1YTI1ZDdmNTJlOTBlMGUwMDAwYTNfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1YTI1ZDdmNTJlOTBlMGUwMDAwYTNfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1YTI1ZDdmNTJlOTBlMGUwMDAwYTNfNjQwLmpwZw==_1242.jpg","w":"500","h":"334"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c639af9490cbfd4a000016&m=1472610928","list_dtime":""},{"pk":"57c63a189490cbe04a000036","title":"韭菜别只会包饺子，还可以更美味！","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a000036","thumbnail_pic":"http://zkres.myzaker.com/201608/57c50e597f52e96963000330_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c50e597f52e96963000330_320.jpg","thumbnail_picsize":"450,399","media_count":"8","thumbnail_medias":[{"type":"image","id":"57c50e597f52e96963000330","url":"http://zkres.myzaker.com/201608/57c50e597f52e96963000330_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c50e597f52e96963000330_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c50e597f52e96963000330_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/QqzITlgJUtw4o4kSyHN1KYziaQ9gVYjbHoeeDJPT1QHuE1bJeEORDSiclH9oYL08E73ibDHOlz9Y08qLALhC7iaefw/640?","w":"450","h":"399"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a000036&m=1472610589","list_dtime":""},{"pk":"57c6761a9490cb044b000037","title":"意大利面的懒人做法，单纯好吃不做作！","date":"","auther_name":"美食杰","weburl":"http://iphone.myzaker.com/l.php?l=57c6761a9490cb044b000037","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NzYyMGEwN2FlY2Y3N2UwM2RjMjJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NzYyMGEwN2FlY2Y3N2UwM2RjMjJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,357","media_count":"11","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NzYyMGEwN2FlY2Y3N2UwM2RjMjJfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NzYyMGEwN2FlY2Y3N2UwM2RjMjJfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M2NzYyMGEwN2FlY2Y3N2UwM2RjMjJfNjQwLmpwZw==_1242.jpg","w":"640","h":"357"}],"app_ids":"10386","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10386&pk=57c6761a9490cb044b000037&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c6761a9490cb044b000037%26app_id%3D10386%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c6761a9490cb044b000037&m=1472718745","list_dtime":""},{"pk":"57c639539490cbc24a00002b","title":"国内最受争议的蔬菜，被岛国人民玩脱了\u2026","date":"","auther_name":"豆果美食","weburl":"http://iphone.myzaker.com/l.php?l=57c639539490cbc24a00002b","thumbnail_pic":"http://zkres.myzaker.com/201608/57c5cd827f52e9275e0002a3_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c5cd827f52e9275e0002a3_320.jpg","thumbnail_picsize":"640,480","media_count":"28","thumbnail_medias":[{"type":"image","id":"57c5cd827f52e9275e0002a3","url":"http://zkres.myzaker.com/201608/57c5cd827f52e9275e0002a3_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c5cd827f52e9275e0002a3_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c5cd827f52e9275e0002a3_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_jpg/44pws9Yz5pVQtNC7BpqtibXuaL2dcicLEK2NU9PIAgvaZl38ibuZkiagCFafFWz8vpbtZBLxr0aq9HBLic1DWOTgb6Q/0?wx_fmt=jpeg","w":"640","h":"480"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c639539490cbc24a00002b&m=1472610548","list_dtime":""},{"pk":"57c676969490cbcc4a00003a","title":"7道水煮菜，给你香麻的川味体验！","date":"","auther_name":"美食工场","weburl":"http://iphone.myzaker.com/l.php?l=57c676969490cbcc4a00003a","thumbnail_pic":"http://zkres.myzaker.com/201608/57c6769da07aecf77e03dc4a_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c6769da07aecf77e03dc4a_320.jpg","thumbnail_picsize":"640,577","media_count":"7","thumbnail_medias":[{"type":"image","id":"57c6769da07aecf77e03dc4a","url":"http://zkres.myzaker.com/201608/57c6769da07aecf77e03dc4a_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c6769da07aecf77e03dc4a_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c6769da07aecf77e03dc4a_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/j9FBeXAB9nWFruj63OVJ0OI71jygPnXFCicibnCYWun50jLiczJkFUTxlAXia8yk0n0OpQkdia7riaRhw2GMqicYGX3tA/640?wx_fmt=jpeg","w":"640","h":"577"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c676969490cbcc4a00003a&m=1472627840","list_dtime":""},{"pk":"57c63a189490cbe04a000034","title":"炒青菜还能有什么花样？多花1分钟","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a000034","thumbnail_pic":"http://zkres.myzaker.com/201608/57c50e547f52e96963000323_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c50e547f52e96963000323_320.jpg","thumbnail_picsize":"545,505","media_count":"13","thumbnail_medias":[{"type":"image","id":"57c50e547f52e96963000323","url":"http://zkres.myzaker.com/201608/57c50e547f52e96963000323_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c50e547f52e96963000323_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c50e547f52e96963000323_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/E1QqbPzMaLska60YmsQ1RFKeCIvb76M6INg4uF4BIJDqyrXDlu6oJNw1gaicSRbsEWRDicNhZWbbC5Ysgp5IkIsw/640?wx_fmt=png","w":"545","h":"505"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a000034&m=1472610709","list_dtime":""},{"pk":"57c63a189490cbe04a000039","title":"这些水果晚上不要吃，再喜欢也要戒","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a000039","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwMy81NmUwZDNlYzdmNTJlOTU2NWEwMDA0MDJfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwMy81NmUwZDNlYzdmNTJlOTU2NWEwMDA0MDJfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"13","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwMy81NmUwZDNlYzdmNTJlOTU2NWEwMDA0MDJfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwMy81NmUwZDNlYzdmNTJlOTU2NWEwMDA0MDJfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwMy81NmUwZDNlYzdmNTJlOTU2NWEwMDA0MDJfNjQwLmpwZw==_1242.jpg","w":"640","h":"427"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a000039&m=1472609467","list_dtime":""},{"pk":"57c4e54e9490cb9713000043","title":"饺子馅加一物，就变成了日式！","date":"","auther_name":"美食工坊","weburl":"http://iphone.myzaker.com/l.php?l=57c4e54e9490cb9713000043","thumbnail_pic":"http://zkres.myzaker.com/201608/57c2f24f7f52e9cf31000202_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c2f24f7f52e9cf31000202_320.jpg","thumbnail_picsize":"1200,890","media_count":"12","thumbnail_medias":[{"type":"image","id":"57c2f24f7f52e9cf31000201","url":"http://zkres.myzaker.com/201608/57c2f24f7f52e9cf31000201_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c2f24f7f52e9cf31000201_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c2f24f7f52e9cf31000201_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_jpg/RgAhJKheXgEsxeAT75nSKnUhpz8wLjHWj2vpRa4sq9uuG7NfxMS2juibm9qic5kxGqZmy518WCSdmp9OOqU27kVg/0?wx_fmt=jpeg","w":"1200","h":"1798"}],"app_ids":"10386","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10386&pk=57c4e54e9490cb9713000043&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c4e54e9490cb9713000043%26app_id%3D10386%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c4e54e9490cb9713000043&m=1472610421","list_dtime":""},{"pk":"57c63a189490cbe04a00003a","title":"这么多好吃的家常菜，一周的菜单都不用愁了","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a00003a","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmYxZDdmNTJlOWMyMDUwMDA1MjVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmYxZDdmNTJlOWMyMDUwMDA1MjVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"400,257","media_count":"10","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmYxZDdmNTJlOWMyMDUwMDA1MjVfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmYxZDdmNTJlOWMyMDUwMDA1MjVfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmYxZDdmNTJlOWMyMDUwMDA1MjVfNjQwLmpwZw==_1242.jpg","w":"400","h":"257"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a00003a&m=1472610009","list_dtime":""},{"pk":"57c639af9490cbfd4a000017","title":"好想养一只刺猬啊！吃货属性萌翻天！","date":"","auther_name":"美食天下","weburl":"http://iphone.myzaker.com/l.php?l=57c639af9490cbfd4a000017","thumbnail_pic":"http://zkres.myzaker.com/201608/57c5a2617f52e9100e000081_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c5a2617f52e9100e000081_320.jpg","thumbnail_picsize":"241,225","media_count":"27","thumbnail_medias":[{"type":"image","id":"57c5a2617f52e9100e000081","url":"http://zkres.myzaker.com/201608/57c5a2617f52e9100e000081_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c5a2617f52e9100e000081_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c5a2617f52e9100e000081_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_gif/icdHpHMYRdfqhMpj0uicvvicSGJ7fyler5eSudL3LDQpo1OiaN5jTsaMFAicKruuCnKGvHUo4WWraJMiaTqThTUickzUA/0?wx_fmt=gif","w":"241","h":"225","gif_url":"http://zkres.myzaker.com/201608/57c5a2617f52e9100e000081_raw.gif"}],"app_ids":"10386","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10386&pk=57c639af9490cbfd4a000017&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c639af9490cbfd4a000017%26app_id%3D10386%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c639af9490cbfd4a000017&m=1472610861","list_dtime":""},{"pk":"57c63a189490cbe04a000037","title":"50种排骨美味做法，够吃一年了！","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a000037","thumbnail_pic":"http://zkres.myzaker.com/201606/57630d73a07aec5e7003b0fd_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201606/57630d73a07aec5e7003b0fd_320.jpg","thumbnail_picsize":"426,315","media_count":"50","thumbnail_medias":[{"type":"image","id":"57630d73a07aec5e7003b0fd","url":"http://zkres.myzaker.com/201606/57630d73a07aec5e7003b0fd_640.jpg","m_url":"http://zkres.myzaker.com/201606/57630d73a07aec5e7003b0fd_320.jpg","min_url":"http://zkres.myzaker.com/201606/57630d73a07aec5e7003b0fd_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/E1QqbPzMaLuZsqicxQEsp5hE6FlcQGJOaWibAicgYKYU6w1tnNRDzsohk4wibPvWgyncpyWMzIIPAIIe0rNnRZ0gkQ/640?wx_fmt=jpeg","w":"426","h":"315"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a000037&m=1472610774","list_dtime":""},{"pk":"57c639539490cbc24a00002c","title":"35道微波炉美食，让你告别刷锅和油烟！","date":"","auther_name":"豆果美食","weburl":"http://iphone.myzaker.com/l.php?l=57c639539490cbc24a00002c","thumbnail_pic":"http://zkres.myzaker.com/201608/57c567c17f52e9374200052c_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201608/57c567c17f52e9374200052c_320.jpg","thumbnail_picsize":"640,469","media_count":"17","thumbnail_medias":[{"type":"image","id":"57c567c17f52e9374200052c","url":"http://zkres.myzaker.com/201608/57c567c17f52e9374200052c_640.jpg","m_url":"http://zkres.myzaker.com/201608/57c567c17f52e9374200052c_320.jpg","min_url":"http://zkres.myzaker.com/201608/57c567c17f52e9374200052c_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz_jpg/44pws9Yz5pXWd3qZ7Jyea66rZjdgaPRrmmMBreaKqSb7nYzicgbQ0Z840wdTUaEzXRWJM9I3IEfsYLZdILbsyMA/0?wx_fmt=jpeg","w":"640","h":"469"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c639539490cbc24a00002c&m=1472610321","list_dtime":""},{"pk":"57c63a189490cbe04a000038","title":"这样做烙饼香到骨头里！来，咬一口...","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a000038","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNi81NzVmNmI5NDc3YTMyNDQ3NWYwMDAwMTFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNi81NzVmNmI5NDc3YTMyNDQ3NWYwMDAwMTFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"465,391","media_count":"6","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNi81NzVmNmI5NDc3YTMyNDQ3NWYwMDAwMTFfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNi81NzVmNmI5NDc3YTMyNDQ3NWYwMDAwMTFfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNi81NzVmNmI5NDc3YTMyNDQ3NWYwMDAwMTFfNjQwLmpwZw==_1242.jpg","w":"465","h":"391"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a000038&m=1472609752","list_dtime":""},{"pk":"57c63a549490cb064b00001e","title":"细数105个城市的招牌菜，你的家乡上榜了吗？","date":"","auther_name":"天天美食","weburl":"http://iphone.myzaker.com/l.php?l=57c63a549490cb064b00001e","thumbnail_pic":"http://zkres.myzaker.com/201510/561792687f52e96953000156_640.jpg","thumbnail_mpic":"http://zkres.myzaker.com/201510/561792687f52e96953000156_320.jpg","thumbnail_picsize":"580,463","media_count":"24","thumbnail_medias":[{"type":"image","id":"561792687f52e96953000156","url":"http://zkres.myzaker.com/201510/561792687f52e96953000156_640.jpg","m_url":"http://zkres.myzaker.com/201510/561792687f52e96953000156_320.jpg","min_url":"http://zkres.myzaker.com/201510/561792687f52e96953000156_120.jpg","raw_url":"http://mmbiz.qpic.cn/mmbiz/AMCUFlyHOI9USBZVcrSoqV7GGmicYMjWG5VDrSP0IpWeX0tDr7XmKwe3k1NtGWicrUwbqj3jibW2fqSmLzaNKj2yw/0?wx_fmt=jpeg","w":"580","h":"463"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a549490cb064b00001e&m=1472609527","list_dtime":""},{"pk":"57c63a189490cbe04a000035","title":"五花肉销魂吃法，饿么饿么饿么？","date":"","auther_name":"美味食尚","weburl":"http://iphone.myzaker.com/l.php?l=57c63a189490cbe04a000035","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGU1YjdmNTJlOTBlNDUwMDA0OWVfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGU1YjdmNTJlOTBlNDUwMDA0OWVfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"638,310","media_count":"8","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGU1YjdmNTJlOTBlNDUwMDA0OWVfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGU1YjdmNTJlOTBlNDUwMDA0OWVfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M1MGU1YjdmNTJlOTBlNDUwMDA0OWVfNjQwLmpwZw==_1242.jpg","w":"638","h":"310"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a189490cbe04a000035&m=1472609364","list_dtime":""},{"pk":"57c639539490cbc24a00002a","title":"童年时期的小零食，都吃过说明你老了\u2026","date":"","auther_name":"豆果美食","weburl":"http://iphone.myzaker.com/l.php?l=57c639539490cbc24a00002a","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwOTI1MF80MDM3X1c2NDBIMzYwUzYyMDM5LmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwOTI1MF80MDM3X1c2NDBIMzYwUzYyMDM5LmpwZw==_1242.jpg","thumbnail_picsize":"640,360","media_count":"0","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwOTI1MF80MDM3X1c2NDBIMzYwUzYyMDM5LmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwOTI1MF80MDM3X1c2NDBIMzYwUzYyMDM5LmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA4MzEvdXBfMTQ3MjYwOTI1MF80MDM3X1c2NDBIMzYwUzYyMDM5LmpwZw==_1242.jpg","w":"640","h":"360"}],"app_ids":"10386","is_full":"NO","content":"","type":"web3","special_info":{"open_type":"web3","need_user_info":"Y","web_url":"http://iphone.myzaker.com/zaker/article_turn.php?target=web3&app_id=10386&pk=57c639539490cbc24a00002a&url=http%3A%2F%2Fiphone.myzaker.com%2Fzaker%2Farticle_web3.php%3Fpk%3D57c639539490cbc24a00002a%26app_id%3D10386%26_appid%3Dandroidphone%26target%3Dweb3","show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c639539490cbc24a00002a&m=1472609138","list_dtime":""},{"pk":"57c63a549490cb064b00001d","title":"好吃的鸡块做法精选，赶快来试试吧","date":"","auther_name":"天天美食","weburl":"http://iphone.myzaker.com/l.php?l=57c63a549490cb064b00001d","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNC81NzAxY2E5MWEwN2FlYzQ3NzcwNDc3NzBfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNC81NzAxY2E5MWEwN2FlYzQ3NzcwNDc3NzBfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"490,338","media_count":"8","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNC81NzAxY2E5MWEwN2FlYzQ3NzcwNDc3NzBfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNC81NzAxY2E5MWEwN2FlYzQ3NzcwNDc3NzBfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwNC81NzAxY2E5MWEwN2FlYzQ3NzcwNDc3NzBfNjQwLmpwZw==_1242.jpg","w":"490","h":"338"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c63a549490cb064b00001d&m=1472609299","list_dtime":""},{"pk":"57c4e54e9490cb9713000041","title":"水果和生鲜这样来保鲜，冰箱都省了","date":"","auther_name":"美食工坊","weburl":"http://iphone.myzaker.com/l.php?l=57c4e54e9490cb9713000041","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MxNmU3YzdmNTJlOWVlNzUwMDA2MjFfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MxNmU3YzdmNTJlOWVlNzUwMDA2MjFfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,427","media_count":"9","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MxNmU3YzdmNTJlOWVlNzUwMDA2MjFfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MxNmU3YzdmNTJlOWVlNzUwMDA2MjFfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MxNmU3YzdmNTJlOWVlNzUwMDA2MjFfNjQwLmpwZw==_1242.jpg","w":"640","h":"427"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c4e54e9490cb9713000041&m=1472550914","list_dtime":""},{"pk":"57c4e4b09490cb9113000023","title":"鸡蛋煎馄饨，这么新鲜的吃法还是头一次见","date":"","auther_name":"美食杰","weburl":"http://iphone.myzaker.com/l.php?l=57c4e4b09490cb9113000023","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ODczYzFiYzhlMDM0NDcwMDAwMDhfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ODczYzFiYzhlMDM0NDcwMDAwMDhfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"600,450","media_count":"10","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ODczYzFiYzhlMDM0NDcwMDAwMDhfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ODczYzFiYzhlMDM0NDcwMDAwMDhfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ODczYzFiYzhlMDM0NDcwMDAwMDhfNjQwLmpwZw==_1242.jpg","w":"600","h":"450"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c4e4b09490cb9113000023&m=1472541310","list_dtime":""},{"pk":"57c4ec931bc8e08132000036","title":"百吃不厌豆腐的万能吃法，大师级的水准","date":"","auther_name":" 高质量生活知识","weburl":"http://iphone.myzaker.com/l.php?l=57c4ec931bc8e08132000036","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ZWMxNmEwN2FlY2Y3N2UwMzFjYmNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ZWMxNmEwN2FlY2Y3N2UwMzFjYmNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"640,454","media_count":"6","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ZWMxNmEwN2FlY2Y3N2UwMzFjYmNfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ZWMxNmEwN2FlY2Y3N2UwMzFjYmNfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2M0ZWMxNmEwN2FlY2Y3N2UwMzFjYmNfNjQwLmpwZw==_1242.jpg","w":"640","h":"454"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c4ec931bc8e08132000036&m=1472552333","list_dtime":""},{"pk":"57c4e5759490cb5213000015","title":"世界上最臭的食物排行，你敢挑战看看吗？","date":"","auther_name":"天天美食","weburl":"http://iphone.myzaker.com/l.php?l=57c4e5759490cb5213000015","thumbnail_pic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmVlYzdmNTJlOTVjM2EwMDAwZWNfNjQwLmpwZw==_1242.jpg","thumbnail_mpic":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmVlYzdmNTJlOTVjM2EwMDAwZWNfNjQwLmpwZw==_1242.jpg","thumbnail_picsize":"542,397","media_count":"11","thumbnail_medias":[{"type":"image","url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmVlYzdmNTJlOTVjM2EwMDAwZWNfNjQwLmpwZw==_1242.jpg","m_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmVlYzdmNTJlOTVjM2EwMDAwZWNfNjQwLmpwZw==_1242.jpg","raw_url":"http://zkres3.myzaker.com/201608/aHR0cDovL3prcmVzLm15emFrZXIuY29tLzIwMTYwOC81N2MyNmVlYzdmNTJlOTVjM2EwMDAwZWNfNjQwLmpwZw==_1242.jpg","w":"542","h":"397"}],"app_ids":"10386","is_full":"NO","content":"","special_info":{"show_jingcai":"Y","item_type":"1_b"},"full_url":"http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c4e5759490cb5213000015&m=1472540751","list_dtime":""}]
     * ipadconfig : {"pages":[{"pk":"1","page":"1","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c639539490cbc24a00002d,57c644f29490cbcb4a000024,57c795e39490cbad2c00003b,57c7d24c1bc8e07a61000044,57c65d211bc8e0500c000033,57c790269490cb922c000019","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"2","page":"2","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c78f5c9490cb882c000015,57c78f3f9490cbc52c00001a,57c78fc09490cb741e000007,57c6391f9490cbe34a000025,57c78ab61bc8e0786100003a,57c78f3f9490cbc52c000019","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"3","page":"3","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"1","articles":"57c6765e9490cb024b000040,57c7893a1bc8e06a6100001f,57c39c0d9490cb257300003b,57c639af9490cbfd4a000016,57c63a189490cbe04a000036,57c6761a9490cb044b000037","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"4","page":"4","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c639539490cbc24a00002b,57c676969490cbcc4a00003a,57c63a189490cbe04a000034,57c63a189490cbe04a000039,57c4e54e9490cb9713000043,57c63a189490cbe04a00003a","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"5","page":"5","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"2","articles":"57c639af9490cbfd4a000017,57c63a189490cbe04a000037,57c639539490cbc24a00002c,57c63a189490cbe04a000038,57c63a549490cb064b00001e,57c63a189490cbe04a000035","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}},{"pk":"6","page":"6","tpl_group":"6","tpl_type":"news","tpl_styletype":"photo","tpl_style":"5","articles":"57c639539490cbc24a00002a,57c63a549490cb064b00001d,57c4e54e9490cb9713000041,57c4e4b09490cb9113000023,57c4ec931bc8e08132000036,57c4e5759490cb5213000015","diy":{"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}}],"article_block_colors":["#fc9a64","#fc9a64"],"only_text_page_bgcolors":["#fc9a64","#fc9a64"]}
     * block_info : {"title":"","stitle":"","skey":"","pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/10386.png?t=1458288274","large_pic":"http://zkres3.myzaker.com/data/image/logo/ipad3/10386.png?t=1458288274","hidden_time":"24","need_userinfo":"NO","block_title":"美食频道","block_color":"#fc9a64","desktop_color_number":"8","use_original_icon":"N"}
     * top_tab_info_url : http://iphone.myzaker.com/zaker/top_tab_info.php?app_id=10386&full_arg=_appid,_v,_version,_lbs_city
     * show_type : top_tab
     */

    private DataBean data;

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public String getNewrule() {
        return newrule;
    }

    public void setNewrule(String newrule) {
        this.newrule = newrule;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String refresh_interval;
        /**
         * comment_list_url : http://c.myzaker.com/weibo/api_comment_article_url.php?act=get_comments
         * comment_url : http://c.myzaker.com/weibo/api_comment_article.php?act=get_comments
         * comment_reply_url : http://c.myzaker.com/weibo/api_post_article.php?act=reply
         * comment_count_url : http://c.myzaker.com/weibo/api_comment_count.php?act=get_count
         * comment_hot_url : http://c.myzaker.com/weibo/api_comment_article_hot.php
         * like_count_url : http://iphone.myzaker.com/zaker/like.php
         * like_save_url : http://iphone.myzaker.com/zaker/like.php?act=add
         * like_remove_url : http://iphone.myzaker.com/zaker/like.php?act=remove
         * readstat : http://stat.myzaker.com/stat.php
         * next_url : http://iphone.myzaker.com/zaker/blog2news.php?app_id=10386&since_date=1472199356&nt=1&next_aticle_id=57c4e4d29490cbad13000022&_appid=androidphone&opage=2&otimestamp=186&top_tab_id=10386
         * localremove_url : http://api.myzaker.com/zaker/fav_act.php?act=delete2
         * localsave_url : http://api.myzaker.com/zaker/fav_act.php?act=add
         * ad_url : http://ggs.myzaker.com/zk_block_ad.php?app_id=10386&need_app_integration=1
         * tuijian_list_url : http://iphone.myzaker.com/zaker/jingcaituijian.php?app_id=10386&ids=5642f2aa9490cbb13200000e,54f40b639490cb12100000da&k=201609011630
         */

        private InfoBean info;
        private String catalog;
        private IpadconfigBean ipadconfig;
        /**
         * title :
         * stitle :
         * skey :
         * pic : http://zkres3.myzaker.com/data/image/logo/ipad3/10386.png?t=1458288274
         * large_pic : http://zkres3.myzaker.com/data/image/logo/ipad3/10386.png?t=1458288274
         * hidden_time : 24
         * need_userinfo : NO
         * block_title : 美食频道
         * block_color : #fc9a64
         * desktop_color_number : 8
         * use_original_icon : N
         */

        private BlockInfoBean block_info;
        private String top_tab_info_url;
        private String show_type;
        /**
         * title : 转发至新浪微博
         * block_pk : 100000
         * share_url : http://wbapi.myzaker.com/weibo/api_post.php?act=post_article
         * action_type : sendForward
         * require_pk : Y
         * require_title : Y
         * require_web_url : Y
         */

        private List<ShareBean> share;
        /**
         * pk : 57c639539490cbc24a00002d
         * title : 吃牛排，千万别点八分熟！
         * date :
         * auther_name : 豆果美食
         * page : 1
         * index : 1
         * weburl : http://iphone.myzaker.com/l.php?l=57c639539490cbc24a00002d
         * thumbnail_pic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg
         * thumbnail_mpic : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg
         * thumbnail_picsize : 640,360
         * media_count : 18
         * thumbnail_medias : [{"type":"image","url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg","m_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg","raw_url":"http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg","w":"640","h":"360"}]
         * app_ids : 10386
         * is_full : NO
         * content :
         * special_info : {"show_jingcai":"Y","list_nodsp":"Y","item_type":"1_b"}
         * full_url : http://iphone.myzaker.com/zaker/article_mongo.php?app_id=10386&pk=57c639539490cbc24a00002d&m=1472696728
         * list_dtime :
         */

        private List<ArticlesBean> articles;

        public String getRefresh_interval() {
            return refresh_interval;
        }

        public void setRefresh_interval(String refresh_interval) {
            this.refresh_interval = refresh_interval;
        }

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public IpadconfigBean getIpadconfig() {
            return ipadconfig;
        }

        public void setIpadconfig(IpadconfigBean ipadconfig) {
            this.ipadconfig = ipadconfig;
        }

        public BlockInfoBean getBlock_info() {
            return block_info;
        }

        public void setBlock_info(BlockInfoBean block_info) {
            this.block_info = block_info;
        }

        public String getTop_tab_info_url() {
            return top_tab_info_url;
        }

        public void setTop_tab_info_url(String top_tab_info_url) {
            this.top_tab_info_url = top_tab_info_url;
        }

        public String getShow_type() {
            return show_type;
        }

        public void setShow_type(String show_type) {
            this.show_type = show_type;
        }

        public List<ShareBean> getShare() {
            return share;
        }

        public void setShare(List<ShareBean> share) {
            this.share = share;
        }

        public List<ArticlesBean> getArticles() {
            return articles;
        }

        public void setArticles(List<ArticlesBean> articles) {
            this.articles = articles;
        }

        public static class InfoBean {
            private String comment_list_url;
            private String comment_url;
            private String comment_reply_url;
            private String comment_count_url;
            private String comment_hot_url;
            private String like_count_url;
            private String like_save_url;
            private String like_remove_url;
            private String readstat;
            private String next_url;
            private String localremove_url;
            private String localsave_url;
            private String ad_url;
            private String tuijian_list_url;

            public String getComment_list_url() {
                return comment_list_url;
            }

            public void setComment_list_url(String comment_list_url) {
                this.comment_list_url = comment_list_url;
            }

            public String getComment_url() {
                return comment_url;
            }

            public void setComment_url(String comment_url) {
                this.comment_url = comment_url;
            }

            public String getComment_reply_url() {
                return comment_reply_url;
            }

            public void setComment_reply_url(String comment_reply_url) {
                this.comment_reply_url = comment_reply_url;
            }

            public String getComment_count_url() {
                return comment_count_url;
            }

            public void setComment_count_url(String comment_count_url) {
                this.comment_count_url = comment_count_url;
            }

            public String getComment_hot_url() {
                return comment_hot_url;
            }

            public void setComment_hot_url(String comment_hot_url) {
                this.comment_hot_url = comment_hot_url;
            }

            public String getLike_count_url() {
                return like_count_url;
            }

            public void setLike_count_url(String like_count_url) {
                this.like_count_url = like_count_url;
            }

            public String getLike_save_url() {
                return like_save_url;
            }

            public void setLike_save_url(String like_save_url) {
                this.like_save_url = like_save_url;
            }

            public String getLike_remove_url() {
                return like_remove_url;
            }

            public void setLike_remove_url(String like_remove_url) {
                this.like_remove_url = like_remove_url;
            }

            public String getReadstat() {
                return readstat;
            }

            public void setReadstat(String readstat) {
                this.readstat = readstat;
            }

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }

            public String getLocalremove_url() {
                return localremove_url;
            }

            public void setLocalremove_url(String localremove_url) {
                this.localremove_url = localremove_url;
            }

            public String getLocalsave_url() {
                return localsave_url;
            }

            public void setLocalsave_url(String localsave_url) {
                this.localsave_url = localsave_url;
            }

            public String getAd_url() {
                return ad_url;
            }

            public void setAd_url(String ad_url) {
                this.ad_url = ad_url;
            }

            public String getTuijian_list_url() {
                return tuijian_list_url;
            }

            public void setTuijian_list_url(String tuijian_list_url) {
                this.tuijian_list_url = tuijian_list_url;
            }
        }

        public static class IpadconfigBean {
            /**
             * pk : 1
             * page : 1
             * tpl_group : 6
             * tpl_type : news
             * tpl_styletype : photo
             * tpl_style : 5
             * articles : 57c639539490cbc24a00002d,57c644f29490cbcb4a000024,57c795e39490cbad2c00003b,57c7d24c1bc8e07a61000044,57c65d211bc8e0500c000033,57c790269490cb922c000019
             * diy : {"bgimage_url":"http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274","bgimage_frame":"0,0,320,44","title_h":"44","hide_title":"YES","open_type":""}
             */

            private List<PagesBean> pages;
            private List<String> article_block_colors;
            private List<String> only_text_page_bgcolors;

            public List<PagesBean> getPages() {
                return pages;
            }

            public void setPages(List<PagesBean> pages) {
                this.pages = pages;
            }

            public List<String> getArticle_block_colors() {
                return article_block_colors;
            }

            public void setArticle_block_colors(List<String> article_block_colors) {
                this.article_block_colors = article_block_colors;
            }

            public List<String> getOnly_text_page_bgcolors() {
                return only_text_page_bgcolors;
            }

            public void setOnly_text_page_bgcolors(List<String> only_text_page_bgcolors) {
                this.only_text_page_bgcolors = only_text_page_bgcolors;
            }

            public static class PagesBean {
                private String pk;
                private String page;
                private String tpl_group;
                private String tpl_type;
                private String tpl_styletype;
                private String tpl_style;
                private String articles;
                /**
                 * bgimage_url : http://zkres3.myzaker.com/data/image/template/iphone/10386.png?t=1458288274
                 * bgimage_frame : 0,0,320,44
                 * title_h : 44
                 * hide_title : YES
                 * open_type :
                 */

                private DiyBean diy;

                public String getPk() {
                    return pk;
                }

                public void setPk(String pk) {
                    this.pk = pk;
                }

                public String getPage() {
                    return page;
                }

                public void setPage(String page) {
                    this.page = page;
                }

                public String getTpl_group() {
                    return tpl_group;
                }

                public void setTpl_group(String tpl_group) {
                    this.tpl_group = tpl_group;
                }

                public String getTpl_type() {
                    return tpl_type;
                }

                public void setTpl_type(String tpl_type) {
                    this.tpl_type = tpl_type;
                }

                public String getTpl_styletype() {
                    return tpl_styletype;
                }

                public void setTpl_styletype(String tpl_styletype) {
                    this.tpl_styletype = tpl_styletype;
                }

                public String getTpl_style() {
                    return tpl_style;
                }

                public void setTpl_style(String tpl_style) {
                    this.tpl_style = tpl_style;
                }

                public String getArticles() {
                    return articles;
                }

                public void setArticles(String articles) {
                    this.articles = articles;
                }

                public DiyBean getDiy() {
                    return diy;
                }

                public void setDiy(DiyBean diy) {
                    this.diy = diy;
                }

                public static class DiyBean {
                    private String bgimage_url;
                    private String bgimage_frame;
                    private String title_h;
                    private String hide_title;
                    private String open_type;

                    public String getBgimage_url() {
                        return bgimage_url;
                    }

                    public void setBgimage_url(String bgimage_url) {
                        this.bgimage_url = bgimage_url;
                    }

                    public String getBgimage_frame() {
                        return bgimage_frame;
                    }

                    public void setBgimage_frame(String bgimage_frame) {
                        this.bgimage_frame = bgimage_frame;
                    }

                    public String getTitle_h() {
                        return title_h;
                    }

                    public void setTitle_h(String title_h) {
                        this.title_h = title_h;
                    }

                    public String getHide_title() {
                        return hide_title;
                    }

                    public void setHide_title(String hide_title) {
                        this.hide_title = hide_title;
                    }

                    public String getOpen_type() {
                        return open_type;
                    }

                    public void setOpen_type(String open_type) {
                        this.open_type = open_type;
                    }
                }
            }
        }

        public static class BlockInfoBean {
            private String title;
            private String stitle;
            private String skey;
            private String pic;
            private String large_pic;
            private String hidden_time;
            private String need_userinfo;
            private String block_title;
            private String block_color;
            private String desktop_color_number;
            private String use_original_icon;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getStitle() {
                return stitle;
            }

            public void setStitle(String stitle) {
                this.stitle = stitle;
            }

            public String getSkey() {
                return skey;
            }

            public void setSkey(String skey) {
                this.skey = skey;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getLarge_pic() {
                return large_pic;
            }

            public void setLarge_pic(String large_pic) {
                this.large_pic = large_pic;
            }

            public String getHidden_time() {
                return hidden_time;
            }

            public void setHidden_time(String hidden_time) {
                this.hidden_time = hidden_time;
            }

            public String getNeed_userinfo() {
                return need_userinfo;
            }

            public void setNeed_userinfo(String need_userinfo) {
                this.need_userinfo = need_userinfo;
            }

            public String getBlock_title() {
                return block_title;
            }

            public void setBlock_title(String block_title) {
                this.block_title = block_title;
            }

            public String getBlock_color() {
                return block_color;
            }

            public void setBlock_color(String block_color) {
                this.block_color = block_color;
            }

            public String getDesktop_color_number() {
                return desktop_color_number;
            }

            public void setDesktop_color_number(String desktop_color_number) {
                this.desktop_color_number = desktop_color_number;
            }

            public String getUse_original_icon() {
                return use_original_icon;
            }

            public void setUse_original_icon(String use_original_icon) {
                this.use_original_icon = use_original_icon;
            }
        }

        public static class ShareBean {
            private String title;
            private String block_pk;
            private String share_url;
            private String action_type;
            private String require_pk;
            private String require_title;
            private String require_web_url;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBlock_pk() {
                return block_pk;
            }

            public void setBlock_pk(String block_pk) {
                this.block_pk = block_pk;
            }

            public String getShare_url() {
                return share_url;
            }

            public void setShare_url(String share_url) {
                this.share_url = share_url;
            }

            public String getAction_type() {
                return action_type;
            }

            public void setAction_type(String action_type) {
                this.action_type = action_type;
            }

            public String getRequire_pk() {
                return require_pk;
            }

            public void setRequire_pk(String require_pk) {
                this.require_pk = require_pk;
            }

            public String getRequire_title() {
                return require_title;
            }

            public void setRequire_title(String require_title) {
                this.require_title = require_title;
            }

            public String getRequire_web_url() {
                return require_web_url;
            }

            public void setRequire_web_url(String require_web_url) {
                this.require_web_url = require_web_url;
            }
        }

        public static class ArticlesBean {
            private String pk;
            private String title;
            private String date;
            private String auther_name;
            private String page;
            private String index;
            private String weburl;
            private String thumbnail_pic;
            private String thumbnail_mpic;
            private String thumbnail_picsize;
            private String media_count;
            private String app_ids;
            private String is_full;
            private String content;
            /**
             * show_jingcai : Y
             * list_nodsp : Y
             * item_type : 1_b
             */

            private SpecialInfoBean special_info;
            private String full_url;
            private String list_dtime;
            /**
             * type : image
             * url : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg
             * m_url : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg
             * raw_url : http://zkres3.myzaker.com/201609/aHR0cDovL3prcmVzLm15emFrZXIuY29tL2ltZ191cGxvYWQvZWRpdG9yL2ltZ191cGxvYWQvMjAxNjA5MDEvdXBfMTQ3MjY5Njc0NF85MTgwM19XNjQwSDM2MFM3NDgyMi5qcGc=_1242.jpg
             * w : 640
             * h : 360
             */

            private List<ThumbnailMediasBean> thumbnail_medias;

            public String getPk() {
                return pk;
            }

            public void setPk(String pk) {
                this.pk = pk;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getAuther_name() {
                return auther_name;
            }

            public void setAuther_name(String auther_name) {
                this.auther_name = auther_name;
            }

            public String getPage() {
                return page;
            }

            public void setPage(String page) {
                this.page = page;
            }

            public String getIndex() {
                return index;
            }

            public void setIndex(String index) {
                this.index = index;
            }

            public String getWeburl() {
                return weburl;
            }

            public void setWeburl(String weburl) {
                this.weburl = weburl;
            }

            public String getThumbnail_pic() {
                return thumbnail_pic;
            }

            public void setThumbnail_pic(String thumbnail_pic) {
                this.thumbnail_pic = thumbnail_pic;
            }

            public String getThumbnail_mpic() {
                return thumbnail_mpic;
            }

            public void setThumbnail_mpic(String thumbnail_mpic) {
                this.thumbnail_mpic = thumbnail_mpic;
            }

            public String getThumbnail_picsize() {
                return thumbnail_picsize;
            }

            public void setThumbnail_picsize(String thumbnail_picsize) {
                this.thumbnail_picsize = thumbnail_picsize;
            }

            public String getMedia_count() {
                return media_count;
            }

            public void setMedia_count(String media_count) {
                this.media_count = media_count;
            }

            public String getApp_ids() {
                return app_ids;
            }

            public void setApp_ids(String app_ids) {
                this.app_ids = app_ids;
            }

            public String getIs_full() {
                return is_full;
            }

            public void setIs_full(String is_full) {
                this.is_full = is_full;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public SpecialInfoBean getSpecial_info() {
                return special_info;
            }

            public void setSpecial_info(SpecialInfoBean special_info) {
                this.special_info = special_info;
            }

            public String getFull_url() {
                return full_url;
            }

            public void setFull_url(String full_url) {
                this.full_url = full_url;
            }

            public String getList_dtime() {
                return list_dtime;
            }

            public void setList_dtime(String list_dtime) {
                this.list_dtime = list_dtime;
            }

            public List<ThumbnailMediasBean> getThumbnail_medias() {
                return thumbnail_medias;
            }

            public void setThumbnail_medias(List<ThumbnailMediasBean> thumbnail_medias) {
                this.thumbnail_medias = thumbnail_medias;
            }

            public static class SpecialInfoBean {
                private String show_jingcai;
                private String list_nodsp;
                private String item_type;

                public String getShow_jingcai() {
                    return show_jingcai;
                }

                public void setShow_jingcai(String show_jingcai) {
                    this.show_jingcai = show_jingcai;
                }

                public String getList_nodsp() {
                    return list_nodsp;
                }

                public void setList_nodsp(String list_nodsp) {
                    this.list_nodsp = list_nodsp;
                }

                public String getItem_type() {
                    return item_type;
                }

                public void setItem_type(String item_type) {
                    this.item_type = item_type;
                }
            }

            public static class ThumbnailMediasBean {
                private String type;
                private String url;
                private String m_url;
                private String raw_url;
                private String w;
                private String h;

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public String getUrl() {
                    return url;
                }

                public void setUrl(String url) {
                    this.url = url;
                }

                public String getM_url() {
                    return m_url;
                }

                public void setM_url(String m_url) {
                    this.m_url = m_url;
                }

                public String getRaw_url() {
                    return raw_url;
                }

                public void setRaw_url(String raw_url) {
                    this.raw_url = raw_url;
                }

                public String getW() {
                    return w;
                }

                public void setW(String w) {
                    this.w = w;
                }

                public String getH() {
                    return h;
                }

                public void setH(String h) {
                    this.h = h;
                }
            }
        }
    }
}
