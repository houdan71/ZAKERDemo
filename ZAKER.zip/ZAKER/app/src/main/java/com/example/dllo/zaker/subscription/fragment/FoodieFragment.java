package com.example.dllo.zaker.subscription.fragment;

import android.view.View;

import com.example.dllo.zaker.R;
import com.example.dllo.zaker.base.BaseFragment;

/**
 * Created by dllo on 16/9/1.
 */
public class FoodieFragment extends BaseFragment {
    @Override
    protected int initLayout() {
        return R.layout.fragment_foodie;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
