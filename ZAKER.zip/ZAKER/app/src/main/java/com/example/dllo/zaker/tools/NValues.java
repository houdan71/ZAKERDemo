package com.example.dllo.zaker.tools;

/**
 * Created by dllo on 16/8/30.
 */
public class NValues {

    public static final String URL_HOTSPOT = "http://hotphone.myzaker.com/daily_hot_new.php?_appid=AndroidPhone&_bsize=1080_1920&_city=%E5%A4%A7%E8%BF%9E&_dev=515&_lat=38.88973&_lbs_city=%E5%A4%A7%E8%BF%9E&_lbs_province=%E8%BE%BD%E5%AE%81%E7%9C%81&_lng=121.551023&_mac=08%3A00%3A27%3A79%3Aac%3Ae9&_mcode=0610D063&_net=wifi&_nudid=50789d6ae16e0bde&_os=5.1_GoogleNexus5-5.1.0-API22-1080x1920&_os_name=GoogleNexus5-5.1.0-API22-1080x1920&_province=%E8%BE%BD%E5%AE%81%E7%9C%81&_udid=5.1_GoogleNexus5-5.1.0-API22-1080x1920.08%3A00%3A27%3A79%3Aac%3Ae9&_v=6.7&_version=6.7&act=pre&last_time=1472280385&rank=136676";
    public static final String URL_COMMENTS = "http://c.myzaker.com/weibo/api_comment_article_url.php?_appid=AndroidPhone&_dev=515&_v=6.7&_version=6.7&act=get_comments&pk=";
}
