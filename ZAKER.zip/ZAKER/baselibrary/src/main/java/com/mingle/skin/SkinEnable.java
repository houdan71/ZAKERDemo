package com.mingle.skin;

/**
 * Created by zzz40500 on 15/8/27.
 */
public interface SkinEnable {



    void setSkinStyle(SkinStyle skinStyle);



}
