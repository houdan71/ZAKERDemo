package com.mingle.widget;

import com.mingle.skin.SkinStyle;

/**
 * Created by zzz40500 on 15/9/5.
 */
public interface SLayoutParamsI {

     void setSkinStyle(SkinStyle skinStyle);
}
