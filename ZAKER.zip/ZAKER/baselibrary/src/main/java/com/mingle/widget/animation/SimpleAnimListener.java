package com.mingle.widget.animation;

/**
 * Created by zzz40500 on 15/9/3.
 */
public class SimpleAnimListener {

    public void onAnimationStart(CRAnimation animation) {

    }

    public void onAnimationEnd(CRAnimation animation) {

    }

    public void onAnimationCancel(CRAnimation animation) {

    }

    public void onAnimationRepeat(CRAnimation animation) {

    }
}
